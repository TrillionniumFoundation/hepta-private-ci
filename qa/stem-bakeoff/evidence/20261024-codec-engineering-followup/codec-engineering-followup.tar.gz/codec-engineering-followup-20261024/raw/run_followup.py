"""Execute the sealed historical codec environment replay exactly once per arm."""

import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import subprocess
import time
import traceback


ROOT = Path(__file__).resolve().parent
PROTOCOL_SHA = "a17a78785482c1e06220d3f973cd9bf73ea5460235f9cdb0d1fa126bc20f00b9"
MANIFEST_SHA = "c880266b1f27eee68e0e7ff7a2b47def718070b5b8caa8727a591446d77e22b3"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def retain(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def source_identity(manifest):
    result = []
    for item in manifest["files"]:
        path = ROOT / "source" / item["path"]
        if path.is_symlink():
            raise ValueError("source must not be a symlink")
        raw = path.read_bytes()
        git_sha = hashlib.sha1(
            b"blob " + str(len(raw)).encode() + b"\0" + raw
        ).hexdigest()
        actual = dict(
            path=item["path"], bytes=len(raw), sha256=sha(raw), git_blob_sha=git_sha
        )
        if actual != item:
            raise ValueError("pinned source changed: " + item["path"])
        result.append(actual)
    return result


def main():
    protocol_raw = (ROOT / "protocol.json").read_bytes()
    manifest_raw = (ROOT / "source-manifest.json").read_bytes()
    if sha(protocol_raw) != PROTOCOL_SHA or sha(manifest_raw) != MANIFEST_SHA:
        raise ValueError("frozen replay protocol or source manifest changed")
    protocol, manifest = json.loads(protocol_raw), json.loads(manifest_raw)
    before = source_identity(manifest)
    output = ROOT / "run-001"
    output.mkdir(exist_ok=False)
    retain(output / "source-before.json", before)
    retain(
        output / "launch.json",
        dict(
            protocol_sha256=PROTOCOL_SHA,
            manifest_sha256=MANIFEST_SHA,
            driver_sha256=sha(Path(__file__).read_bytes()),
            started_unix_ns=time.time_ns(),
            no_benchmark_credit=True,
            automatic_retry=False,
        ),
    )
    rows = []
    for command in protocol["commands"]:
        prefix = output / command["name"]
        environment = os.environ.copy()
        environment.update(command["env_overlay"])
        wall, parent_cpu = time.monotonic_ns(), time.process_time_ns()
        child_before = resource.getrusage(resource.RUSAGE_CHILDREN)
        timed_out = False
        with (
            prefix.with_suffix(".stdout").open("xb") as stdout,
            prefix.with_suffix(".stderr").open("xb") as stderr,
        ):
            with subprocess.Popen(
                command["argv"],
                cwd=command["cwd"],
                env=environment,
                stdout=stdout,
                stderr=stderr,
                start_new_session=True,
            ) as process:
                retain(
                    prefix.with_suffix(".start.json"),
                    dict(
                        command=command, pid=process.pid, started_unix_ns=time.time_ns()
                    ),
                )
                try:
                    returncode = process.wait(
                        timeout=protocol["maximum_seconds_per_command"]
                    )
                except subprocess.TimeoutExpired:
                    timed_out = True
                    os.killpg(process.pid, signal.SIGKILL)
                    returncode = process.wait()
        child_after = resource.getrusage(resource.RUSAGE_CHILDREN)
        stderr_raw, stdout_raw = (
            prefix.with_suffix(".stderr").read_bytes(),
            prefix.with_suffix(".stdout").read_bytes(),
        )
        diagnostic = stderr_raw.decode("utf-8", errors="replace")
        count_match = re.search(r"Ran (\d+) tests? in ", diagnostic)
        skip_match = re.search(r"(?:^|[,( ])skipped=(\d+)", diagnostic)
        ran = int(count_match.group(1)) if count_match else None
        skipped = int(skip_match.group(1)) if skip_match else 0
        counts = {}
        for field, label in (
            ("failures", "failures"),
            ("errors", "errors"),
            ("expected_failures", "expected failures"),
            ("unexpected_successes", "unexpected successes"),
        ):
            match = re.search(r"(?:^|[,( ])" + re.escape(label) + r"=(\d+)", diagnostic)
            counts[field] = int(match.group(1)) if match else 0
        row = dict(
            name=command["name"],
            returncode=returncode,
            timed_out=timed_out,
            pid=process.pid,
            wall_ns=time.monotonic_ns() - wall,
            parent_cpu_ns=time.process_time_ns() - parent_cpu,
            child_cpu_ns=int(
                round(
                    (
                        (child_after.ru_utime + child_after.ru_stime)
                        - (child_before.ru_utime + child_before.ru_stime)
                    )
                    * 1e9
                )
            ),
            tests_run=ran,
            skipped=skipped,
            **counts,
            passed_registered_environment_check=not timed_out
            and returncode == command["expected_original_exit"]
            and ran == command["expected_tests_run"]
            and skipped == command["expected_skipped"]
            and all(
                value == command.get("expected_" + field, 0)
                for field, value in counts.items()
            ),
            stdout=dict(bytes=len(stdout_raw), sha256=sha(stdout_raw)),
            stderr=dict(bytes=len(stderr_raw), sha256=sha(stderr_raw)),
            not_model_selected_repair=True,
        )
        retain(prefix.with_suffix(".result.json"), row)
        rows.append(row)
    after = source_identity(manifest)
    retain(output / "source-after.json", after)
    result = dict(
        schema="hepta.codec-engineering.followup-result.v1",
        source_unchanged=before == after,
        source_commit=protocol["source_commit"],
        rows=rows,
        completed=True,
        model_calls=0,
        A_B_benchmark_results_changed=False,
        original_hosted_installation_qualified=False,
        memory_repair_credit=False,
    )
    retain(output / "result.json", result)
    print(json.dumps(result, sort_keys=True), flush=True)
    return 0 if all(row["passed_registered_environment_check"] for row in rows) else 2


if __name__ == "__main__":
    try:
        code = main()
    except BaseException as error:
        output = ROOT / "run-001"
        if output.is_dir():
            retain(
                output / "execution-failure.json",
                dict(
                    error_type=type(error).__name__,
                    message=str(error),
                    traceback=traceback.format_exc(),
                    automatic_retry=False,
                ),
            )
        raise
    raise SystemExit(code)
