"""Create a new completed-phase summary from three immutable, read-only audits."""
import datetime
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
TICK = ROOT.parent / 'tick-shadow-recovery-20261024'


def read(path):
    return json.loads(path.read_text())


def identity(path):
    raw = path.read_bytes()
    return {'file': path.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    raw_path = ROOT / 'raw-audit-001.json'
    crash_path = ROOT / 'crash-reader/actual-crash-audit-001.json'
    tick_path = TICK / 'ci-40152367005-shadow-audit-001.json'
    audit, crash, tick = (read(path) for path in (raw_path, crash_path, tick_path))
    assert identity(raw_path)['sha256'] == '03dc61488dc8d57dc6336c56be2d74a47ef11a3383e37c514565012da5bd90c4'
    assert identity(crash_path)['sha256'] == '0b358a1b87fe9f38119698266cdec4f2d5bf4926b0b141fc83070f78a0e42293'
    assert identity(tick_path)['sha256'] == '4262b2a9154ad8a70f6b8c6ccb2354bcf57160ca5bdd2637125adde6f3809e43'
    assert audit['checks_passed'] == 60 and not audit['checks_failed']
    assert len(crash['checks']) == 90 and all(row['passed'] for row in crash['checks'])
    assert tick['checks_passed'] == len(tick['checks']) == 598 and all(row['result'] == 'pass' for row in tick['checks'])
    assert crash['ci_run']['head'] == tick['source_head'] == audit['source_head']
    files = audit['retained_files']
    findings = audit['findings']
    artifact = ROOT / 'artifact'
    v1, v2 = (read(artifact / name / 'report.json') for name in ('run', 'shadow'))
    owner = read(artifact / 'shadow/shadow-owner/report.json')
    native = read(artifact / 'run/native-owner/report.json')
    protocol = read(artifact / 'run/trial/protocol.json')
    runtime = read(artifact / 'run/trial/native_inspection.json')['runtime']
    job = next(row for row in read(ROOT / 'jobs-final.json')['jobs'] if row['id'] == audit['job_id'])
    wall = (datetime.datetime.fromisoformat(job['completed_at'].replace('Z', '+00:00')) - datetime.datetime.fromisoformat(job['started_at'].replace('Z', '+00:00'))).total_seconds()
    partitions = {prefix: {'files': len(rows), 'bytes': sum(row['bytes'] for row in rows)}
                  for prefix in ('run/', 'shadow/', 'bootstrap-crash-tests/')
                  for rows in [[value for path, value in files.items() if path.startswith(prefix)]]}
    regressions = {}
    for name in ('evidence-driver-tests.log', 'tick-wire-tests.log'):
        text = (artifact / name).read_text()
        match = re.search(r'Ran (\d+) tests in ([\d.]+)s', text)
        assert match is not None and text.rstrip().endswith('OK')
        regressions[name] = {'passed': int(match[1]), 'wall_seconds': float(match[2])}
    cases = []
    for case in crash['cases']:
        children = case['children']
        cases.append({'name': case['case'], 'generation': case['generation'], 'qualified': case['complete_qualified_attempt'],
                      'source_cut': case['handoff']['cut'], 'recovered_write': case['recovered_write'], 'wal_layout': case['wal_layout'],
                      'source_before_equals_after': case['source_before'] == case['source_after'],
                      'captured_runner_modes': sorted({row['mode'] for row in case['source_before'].values()}),
                      'children': [{'phase': row['phase'], 'parent_pid': row['request']['parent_pid'],
                                    'pid': row['receipt']['pid'], 'exit_code': row['receipt']['exit_code'],
                                    'umask_line': row['actual_process']['linux_proc_umask_line'],
                                    'wall_seconds': row['receipt']['wall_seconds']} for row in children]})
    summary = {
        'schema': 'hepta.memory.bootstrap-ci-delta.v1', 'status': 'completed_general_crash_and_full_tick_audits_passed_with_explicit_limits',
        'run_id': audit['run_id'], 'job_id': audit['job_id'], 'run_attempt': 1,
        'source_head': audit['source_head'], 'source_tree': audit['source_tree'], 'original_api_artifact': read(ROOT / 'artifact-final.json'),
        'audits': {'general': {**identity(raw_path), 'passed': 60, 'failed': 0},
                   'bootstrap_crash': {**identity(crash_path), 'passed': 90, 'failed': 0, 'method_sha256': crash['reader_sha256']},
                   'v2_full_tick_frame': {**identity(tick_path), 'passed': 598, 'failed': 0, 'method_sha256': tick['method_sha256']}},
        'audit_checks_are_not_task_samples': True,
        'bootstrap_crash': {'attempt_counts': crash['observed_case_attempt_counts'], 'qualified_attempt_counts': crash['qualified_attempt_counts'],
                            'extra_attempts': crash['extra_attempts_not_unique_tests'], 'retry_log_lines': crash['actual_scoped_log']['retry_or_flaky_lines'],
                            'named_pass_lines': crash['actual_scoped_log']['named_pass_lines'], 'cases': cases, 'limits': crash['bounds']},
        'actual_native_paths': {'v1_actual_control_socket_neuron_port_worker': True, 'v1_dispatches': native['backend_dispatch_attempts'],
                                'v1_refusals': native['refused'], 'v1_source_revision_sequence': [read(artifact / 'run/native-owner' / name)['write']['memory']['id']['revision'] for name in ('production-source.json', 'controlled-correction.json', 'withdrawal.json')],
                                'v2_factory': 'AgentdNativeMemoryCell::shadow_owner', 'v2_tick': 'NeuronRuntime::tick_shadow',
                                'v2_backend_dispatches': owner['actual_backend_dispatches'], 'v2_provider_calls': owner['context_provider_calls'],
                                'v2_same_process_owner_recoveries': owner['same_process_owner_recoveries'],
                                'v2_journal_bytes': owner['anchors']['journal_bytes'], 'v2_witness_bytes': owner['anchors']['witness_bytes'],
                                'v2_replay_and_tombstone_added_dispatches': tick['observed_process']['new_dispatches_for_replay_or_withdrawal'],
                                'v2_complete_digests': tick['digests'], 'v2_proof_limits': tick['proof_limits']},
        'fresh_training': {**findings['fresh_training'], 'fixed_protocol': {key: protocol[key] for key in ('steps', 'rank', 'seed', 'learning_rate', 'objective')},
                           'initialization': v1['training_receipt']['receipt']['initialization'], 'prior_33c_or_local_training_counted_here': False},
        'model_counts': {'bootstrapped_model_children': len(audit['counts']['processes']), 'training_children': 1,
                         'v1_decoder_queries': v1['actual_decoder_queries'], 'v2_decoder_queries': v2['actual_shadow_decoder_queries'],
                         'decoder_queries': v2['actual_total_decoder_queries_including_original_v1'],
                         'explicit_feature_forwards': v2['actual_total_native_feature_forwards_including_original_v1'],
                         'shadow_added_training': v2['training_updates_added'], 'shadow_reused_this_CI_training': v2['training_updates_reused'],
                         'decoder_prompt_tokens': v1['execution_cost']['decoder_prompt_tokens'] + v2['cost']['prompt_tokens'],
                         'generated_tokens': v1['execution_cost']['generated_tokens'] + v2['cost']['generated_tokens'],
                         'unknown_partial_work': audit['counts']['unknown_partial_work'],
                         'generation_internal_forward_count': 'not separately instrumented; queries are not total forward calls'},
        'raw_observations': findings['observations'], 'tests': {'six_crates': findings['scoped_tests'], 'python_regressions': regressions},
        'final_source': {'selected_files_per_execution_archive': findings['sources']['native_files'],
                         'source_before_after_clean_and_identical': True,
                         'actual_patch_stat_status_sizes': {name: files[name]['bytes'] for name in ('post-test-fix-format.patch', 'post-test-fix-format.stat', 'final-worktree-status.txt')},
                         'formatter_stdout_bytes': files['final-format.log']['bytes'], 'all_named_steps_success': all(row['conclusion'] == 'success' for row in job['steps']),
                         'lint_warnings_preserved': True, 'tests_after_final_fix_fmt': False},
        'cost': {'api_job_wall_seconds': wall, 'api_clock_precision_seconds': 1, 'drivers': findings['driver_wall_seconds'],
                 'training_command_wall_seconds': findings['fresh_training']['command_receipt']['wall_seconds'],
                 'training_function_wall_seconds': v1['training_receipt']['wall_seconds'], 'training_loop_wall_seconds': v1['training_receipt']['receipt']['seconds'],
                 'acquisition': findings['acquisition'], 'nested_times_not_resummed': True,
                 'original_zip_bytes': read(ROOT / 'artifact-final.json')['size_in_bytes'],
                 'artifact_regular_files': len(files), 'artifact_file_bytes': sum(row['bytes'] for row in files.values()), 'partitions': partitions,
                 'rss_scope': 'actual inference workers only; not complete CI or training peak', 'native_binaries_retained_in_zip': False,
                 'binary_identity_receipts': {name: read(artifact / name / 'invocation.json') for name in ('run', 'shadow')},
                 'actual_runtime_versions': runtime['versions'], 'original_runner_modes_proven_by_zip': False,
                 'quality_matched_net_compression_proven': False, 'full_storage_runtime_cost_closed': False},
        'limits': {**tick['qualification_limits'], 'previously_exposed_cases': 1, 'future_tasks': 0, 'future_accuracy': None,
                   'parameter_success_gate': None, 'bootstrap_process_exit_recovery_observed': True, 'power_loss_recovery_proven': False,
                   'wal_only_persistence_or_replay_necessity_proven': False, 'crash_recovery_third_verifier_process': False},
        'eight_blockers': [{'name': name, 'full_closure': False} for name in (
            '长期纠正与保留准确性', '真实来源与查询绑定', '未来任务优于强检索', '相同总预算下的分裂收益',
            '学习连边与自治生长', '多物理节点与数据本地性', '净压缩和规模成本', '原生生产集成')],
        'previous_33c_ci_source': '33c741cb0abe5faac1d92abe5d0ac90bee4abb51',
        'previous_33c_ci_evidence_publication': '25b553f3feec0e99ef2f049822e9f1842b41f97c',
        'previous_frozen_program_status': 'f92ddcacbe21267514f5040c1df6c380a96f0643',
        'audit_operations': {'model_calls': 0, 'training_updates': 0, 'tests_executed': 0, 'rust_executed': 0, 'sqlite_opens': 0, 'old_phase_modified': False}}
    text = '{\n' + ',\n'.join('  ' + json.dumps(key) + ': ' + json.dumps(value, ensure_ascii=False) for key, value in summary.items()) + '\n}\n'
    path = ROOT / 'publication/summary.json'
    with path.open('x') as output:
        output.write(text)
    print(json.dumps({**identity(path), 'lines': len(text.splitlines())}))


if __name__ == '__main__':
    main()
