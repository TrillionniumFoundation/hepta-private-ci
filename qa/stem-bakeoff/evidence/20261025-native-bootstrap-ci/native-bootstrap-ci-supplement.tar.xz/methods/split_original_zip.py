"""Split the preserved ZIP without recompression and verify byte-exact reassembly."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ZIP = ROOT / 'native-memory-40152367005-1.zip'
OUT = ROOT / 'publication'
CHUNK = 5 * 1024 * 1024


def main():
    metadata = json.loads((ROOT / 'artifact-final.json').read_text())
    OUT.mkdir(exist_ok=True)
    records = []
    original = hashlib.sha256()
    with ZIP.open('rb') as source:
        for index, content in enumerate(iter(lambda: source.read(CHUNK), b''), 1):
            name = ZIP.name + f'.part-{index:03d}'
            with (OUT / name).open('xb') as destination:
                destination.write(content)
            original.update(content)
            records.append({'file': name, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
    reconstructed = hashlib.sha256()
    for record in records:
        raw = (OUT / record['file']).read_bytes()
        assert len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256']
        reconstructed.update(raw)
    assert original.hexdigest() == reconstructed.hexdigest() == metadata['digest'].removeprefix('sha256:')
    assert sum(record['bytes'] for record in records) == ZIP.stat().st_size == metadata['size_in_bytes']
    receipt = {'schema': 'hepta.bootstrap-ci-original-zip-parts.v1', 'archive_sha256': original.hexdigest(),
               'archive_bytes': ZIP.stat().st_size, 'maximum_part_bytes': CHUNK, 'part_count': len(records),
               'reassembled_hash_verified_without_second_full_copy': True, 'recompressed': False, 'parts': records}
    with (ROOT / 'split-receipt.json').open('x') as output:
        output.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'parts'}))


if __name__ == '__main__':
    main()
