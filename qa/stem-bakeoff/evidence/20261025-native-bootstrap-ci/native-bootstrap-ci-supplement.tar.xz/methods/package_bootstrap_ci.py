"""Seal this completed CI phase without changing previous packages or original inputs."""
import hashlib
import json
from pathlib import Path
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'publication'
TICK = ROOT.parent / 'tick-shadow-recovery-20261024'


def record(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest(), 'mode': stat.S_IMODE(path.stat().st_mode)}


def compact(value):
    return '{\n' + ',\n'.join('  ' + json.dumps(key) + ': ' + json.dumps(item, ensure_ascii=False) for key, item in value.items()) + '\n}\n'


def main():
    summary = json.loads((OUT / 'summary.json').read_text())
    assert summary['source_head'] == 'a47190bb84714cb1262fcd85ebb723081fdb0581'
    assert [summary['audits'][name]['passed'] for name in ('general', 'bootstrap_crash', 'v2_full_tick_frame')] == [60, 90, 598]
    assert all(not row['full_closure'] for row in summary['eight_blockers'])
    sources = {}
    for name in ('run-final.json', 'jobs-final.json', 'artifacts-final.json', 'artifact-final.json', 'source-commit-a47190.json'):
        sources['metadata/' + name] = ROOT / name
    sources['logs/job-121046374239.log'] = ROOT / 'job-121046374239.log'
    for name in ('native-memory-40152367005-1.download.json', 'extraction-receipt.json', 'split-receipt.json'):
        sources['receipts/' + name] = ROOT / name
    sources['audits/general/raw-audit-001.json'] = ROOT / 'raw-audit-001.json'
    handoff_path = TICK / 'ci-40152367005-shadow-audit-handoff.json'
    assert record(handoff_path)['sha256'] == '9fa7f34c4dff1eeaf2882e2a673f6a0bd447c82eb2d9d586e35de152e874cb6d'
    handoff = json.loads(handoff_path.read_text())
    sources['audits/tick/' + handoff_path.name] = handoff_path
    for row in handoff['files']:
        path = Path(row['path'])
        assert record(path)['sha256'] == row['sha256'] and path.stat().st_size == row['bytes']
        sources['audits/tick/' + str(path.relative_to(TICK))] = path
    for path in sorted((ROOT / 'crash-reader').rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            sources['audits/crash/' + str(path.relative_to(ROOT / 'crash-reader'))] = path
    assert len([name for name in sources if name.startswith('audits/crash/')]) == 10
    for name in ('audit_bootstrap_ci.py', 'ci_evidence.py', 'extract_verified_artifact.py', 'split_original_zip.py', 'prepare_phase.py', 'build_summary.py', 'package_bootstrap_ci.py'):
        sources['methods/' + name] = ROOT / name
    for name in ('README.md', 'phase-preparation.json', 'archive-method-preparation.json', 'run-initial.json', 'jobs-initial.json'):
        sources['preparation/' + name] = ROOT / name
    for path in sorted((ROOT / 'monitor').glob('*.json')):
        sources['monitor/' + path.name] = path
    assert len([name for name in sources if name.startswith('monitor/')]) == 12
    before = {name: record(path) for name, path in sources.items()}
    for name, key in [('audits/general/raw-audit-001.json', 'general'), ('audits/crash/actual-crash-audit-001.json', 'bootstrap_crash'), ('audits/tick/ci-40152367005-shadow-audit-001.json', 'v2_full_tick_frame')]:
        assert before[name]['sha256'] == summary['audits'][key]['sha256']
    archive = OUT / 'native-bootstrap-ci-supplement.tar.xz'
    with tarfile.open(archive, 'x:xz', preset=6, format=tarfile.PAX_FORMAT) as output:
        for name, path in sorted(sources.items()):
            output.add(path, arcname=name, recursive=False)
    seen = set()
    with tarfile.open(archive) as retained:
        for member in retained:
            assert member.isfile() and member.name in before and member.name not in seen
            seen.add(member.name)
            data = retained.extractfile(member).read()
            expected = before[member.name]
            assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256'] and member.mode == expected['mode']
    assert seen == set(before) and before == {name: record(path) for name, path in sources.items()}
    assert archive.stat().st_size <= 5 * 1024 * 1024
    split = json.loads((ROOT / 'split-receipt.json').read_text())
    rebuilt = hashlib.sha256()
    for part in split['parts']:
        data = (OUT / part['file']).read_bytes()
        assert len(data) == part['bytes'] and hashlib.sha256(data).hexdigest() == part['sha256']
        rebuilt.update(data)
    assert rebuilt.hexdigest() == record(ROOT / 'native-memory-40152367005-1.zip')['sha256'] == split['archive_sha256']
    api = json.loads((ROOT / 'artifact-final.json').read_text())
    assert api['digest'] == 'sha256:' + split['archive_sha256'] and api['size_in_bytes'] == split['archive_bytes']
    publication = {path.name: record(path) for path in sorted(OUT.iterdir()) if path.is_file()}
    assert len(publication) == 15
    manifest = {
        'schema': 'hepta.memory.bootstrap-ci-publication-manifest.v1',
        'planned_repository_directory': 'qa/stem-bakeoff/evidence/20261025-native-bootstrap-ci',
        'run_id': 40152367005, 'job_id': 121046374239, 'attempt': 1, 'artifact_id': api['id'],
        'source_head': summary['source_head'], 'source_tree': summary['source_tree'],
        'original_zip': {'file': 'native-memory-40152367005-1.zip', 'bytes': split['archive_bytes'], 'sha256': split['archive_sha256'], 'parts': split['parts'], 'recompressed': False},
        'original_zip_extracted_files': summary['cost']['artifact_regular_files'], 'original_zip_extracted_file_bytes': summary['cost']['artifact_file_bytes'],
        'supplement': {'file': archive.name, **record(archive), 'members': before, 'files': len(before), 'file_bytes': sum(value['bytes'] for value in before.values())},
        'verification': {'original_zip_digest_size_matches_github_api': True, 'all_parts_hashes_and_reassembly_checked': True,
                         'complete_raw_zip_preserved': True, 'supplement_all_member_bytes_and_modes_readback_verified': True,
                         'supplement_original_inputs_unchanged': True, 'general_audit_passed': 60, 'crash_audit_passed': 90, 'complete_tick_audit_passed': 598,
                         'final_patch_stat_status_each_zero_bytes': True, 'auditor_model_calls': 0, 'auditor_training_updates': 0,
                         'auditor_tests_run': 0, 'auditor_sqlite_opens': 0},
        'scope_limits': summary['limits'], 'eight_full_closure_flags': [False] * 8,
        'publication_files_excluding_this_manifest': publication, 'publication_file_count_including_manifest': 16,
        'api_json_storage': 'exact UTF-8 JSON content returned by read-only GitHub connector; selected single artifact record separately retained',
        'job_log_storage': 'complete decoded GitHub job log string preserved as UTF-8 including its initial BOM',
        'permission_evidence': 'ZIP extraction modes do not prove original runner permissions; case source-before/source-after metadata and byte bindings are retained separately',
        'preparation_and_monitoring': 'historical pending preparation unchanged; six run/jobs observations retained; no active artifact downloaded',
        'old_phase_and_original_raw_evidence_modified': False}
    with (OUT / 'manifest.json').open('x') as output:
        output.write(compact(manifest))
    text_lines = sum(len(path.read_text().splitlines()) for path in OUT.iterdir() if path.suffix in ('.md', '.json'))
    assert text_lines <= 500
    final = {path.name: record(path) for path in sorted(OUT.iterdir()) if path.is_file()}
    receipt = {'schema': 'hepta.memory.bootstrap-ci-publication-ready.v1', 'publication_directory': str(OUT),
               'files': final, 'file_count': len(final), 'total_bytes': sum(value['bytes'] for value in final.values()),
               'text_lines': text_lines, 'largest_file_bytes': max(value['bytes'] for value in final.values()),
               'supplement_members': len(before), 'all_verification_passed': True, 'uploaded': False}
    with (ROOT / 'publication-receipt.json').open('x') as output:
        output.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'files'}))


if __name__ == '__main__':
    main()
