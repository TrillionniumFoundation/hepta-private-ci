"""Read completed final CI evidence without running tests, models or repo code."""
import argparse
import datetime
import json
from pathlib import Path
import sys
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ci_evidence import HEAD, TREE, RUN, JOB, bootstrap, file_sha, files, nextest_summary, read, sha, source_archive, stage_counts, tensor_header, zip_files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('artifact-dir', 'run-metadata', 'jobs-metadata', 'out'):
        parser.add_argument('--' + name, required=True)
    for name in ('artifact-zip', 'artifact-metadata', 'job-log'):
        parser.add_argument('--' + name)
    parser.add_argument('--zip-prefix', default='')
    args = parser.parse_args()
    run = read(Path(args.run_metadata))
    jobs = read(Path(args.jobs_metadata))['jobs']
    job = next(j for j in jobs if j['id'] == JOB)
    if (run['id'] != RUN or run['head_sha'] != HEAD or run['run_attempt'] != 1
            or job['run_id'] != RUN or job['head_sha'] != HEAD or job['run_attempt'] != 1):
        raise ValueError('explicit run/job/head/attempt identity differs')
    if run['status'] != 'completed' or job['status'] != 'completed':
        raise ValueError('completed API metadata required; this reader never promotes in-progress evidence')
    root = Path(args.artifact_dir).resolve(strict=True)
    output = Path(args.out).resolve()
    if output.exists() or output.is_relative_to(root) or root.is_relative_to(output):
        raise ValueError('create-new audit output must be outside raw artifact')
    before = files(root)
    checks = []
    findings = {}

    def check(label, value):
        checks.append({'check': label, 'passed': bool(value)})

    def section(label, operation):
        try:
            operation()
        except Exception as error:
            check(label + ' completed evidence readable', False)
            findings[label + '_error'] = {'error': f'{type(error).__name__}: {error}', 'traceback': traceback.format_exc()}

    check('run and job concluded success', run['conclusion'] == job['conclusion'] == 'success')
    check('original ZIP supplied for independent byte comparison', bool(args.artifact_zip))
    check('artifact API metadata supplied for external identity binding', bool(args.artifact_metadata))
    check('full job log supplied for retained process provenance', bool(args.job_log))
    def inspect_zip():
        if args.artifact_zip:
            archive = Path(args.artifact_zip).resolve(strict=True)
            check('all extracted bytes match original ZIP', zip_files(archive, args.zip_prefix) == before)
            findings['original_zip'] = {'sha256': file_sha(archive), 'bytes': archive.stat().st_size, 'explicit_prefix': args.zip_prefix}
            if args.artifact_metadata:
                metadata = read(Path(args.artifact_metadata))
                expected = metadata.get('digest')
                check('artifact belongs to exact run/head', metadata['workflow_run']['id'] == RUN and metadata['workflow_run']['head_sha'] == HEAD and not metadata['expired'])
                if expected is not None:
                    check('original ZIP matches artifact API digest', expected == 'sha256:' + file_sha(archive))
                findings['artifact_api'] = {'id': metadata['id'], 'digest': expected, 'name': metadata['name']}
        if args.job_log:
            path = Path(args.job_log).resolve(strict=True)
            findings['full_job_log'] = {'sha256': file_sha(path), 'bytes': path.stat().st_size}
    section('zip_binding', inspect_zip)
    source_text = (root / 'source.txt').read_text().splitlines() if (root / 'source.txt').exists() else []
    check('exact checkout head and tree', source_text == [HEAD, TREE])
    test_summary = nextest_summary(root / 'scoped-tests.log')
    findings['scoped_tests'] = test_summary
    check('expected six-crate tests actually passed', test_summary is not None and test_summary['run'] == test_summary['passed'] == 653 and test_summary['failed'] == 0 and test_summary['skipped'] == 13)
    counts = stage_counts(root)
    native, shadow = root / 'run', root / 'shadow'
    model_step = next((s for s in job.get('steps', []) if s['name'] == 'Fixed fresh training and actual Agentd control-socket probe'), None)
    if model_step and model_step.get('conclusion') == 'skipped' and not (native / 'commands/train-96').exists():
        counts['training_updates'] = counts['training_forwards'] = 0
        counts['training_zero_basis'] = 'completed job explicitly skipped original fresh-model step; no train command exists'

    def inspect_sources():
        identities = {}
        archives = {}
        for label, directory in [('native', native), ('shadow', shadow)]:
            source = read(directory / 'source-before.json')
            check(label + ' clean exact head/tree', source['head'] == HEAD and source['tree'] == TREE and source['status'] == '')
            check(label + ' source unchanged during actual execution', source == read(directory / 'source-after.json'))
            inventory, contents, comment = source_archive(directory / 'executed-source.tar.gz')
            check(label + ' Git archive and head match actual source inventory', inventory == source['files'] and comment == HEAD)
            invocation = read(directory / 'invocation.json')
            check(label + ' explicitly requested this head', invocation['expected_head'] == HEAD)
            identities[label], archives[label] = source, contents
        check('both native phases execute same source', identities['native'] == identities['shadow'])
        findings['sources'] = {'native_head': identities['native']['head'], 'shadow_head': identities['shadow']['head'],
                               'native_files': len(identities['native']['files']), 'shadow_files': len(identities['shadow']['files'])}
        return identities, archives

    source_data = []
    section('source_identity', lambda: source_data.append(inspect_sources()))

    def inspect_training():
        protocol = read(native / 'trial/protocol.json')
        training = read(native / 'trial/training.json')
        receipt = training['receipt']
        command = read(native / 'commands/train-96/receipt.json')
        boot = bootstrap(native / 'commands/train-96/stderr.log')
        invocation = read(native / 'invocation.json')
        check('fresh original driver, not continuation', Path(invocation['argv'][0]).name == 'native_ci.py' and not (native / 'continuation.json').exists())
        check('fresh train96 child completed once', command['exit_code'] == 0 and command['attempts'] == 1 and not command['timed_out'] and boot is not None and boot['pid'] == command['pid'])
        check('fixed recipe and full actual96 schedule', protocol['steps'] == receipt['steps'] == receipt['actual_model_forwards'] == 96 and receipt['schedule_indices'] == [0] * 96 and protocol['rank'] == 8 and protocol['seed'] == receipt['writer_seed'] == 24031 and protocol['learning_rate'] == receipt['learning_rate'] == 0.01 and protocol['objective'] == receipt['objective'] == 'completion_ce')
        check('fresh initialization without eval tuning', receipt['initialization'] == 'frozen_base' and not receipt['evaluation_targets_used'] and receipt['inherited_roots'] == [] and receipt['base_unchanged'])
        checkpoint = native / 'trial/checkpoint'
        lineage = read(checkpoint / 'lineage.json')
        source_root = file_sha(native / 'trial/source_document.json')
        check('training/source/lineage bytes bind', receipt['roots'] == receipt['source_digests'] == lineage['roots'] == [source_root] and lineage['training'] == receipt and file_sha(checkpoint / 'lineage.json') == training['manifest_sha256'])
        check('checkpoint remains frozen through reads', read(native / 'checkpoint-before.json') == {p.name: file_sha(p) for p in checkpoint.iterdir() if p.is_file()})
        adapter = tensor_header(checkpoint / 'adapter_model.safetensors')
        check('complete adapter parameter accounting', adapter['parameters'] == receipt['trainable_parameters'] == 460800 and adapter['payload_bytes'] == receipt['parameter_bytes'] == 1843200)
        findings['fresh_training'] = {'source_head': HEAD, 'new_updates': receipt['steps'], 'new_forwards': receipt['actual_model_forwards'],
                                      'input_tokens': receipt['input_tokens'], 'supervised_tokens': receipt['supervised_tokens'],
                                      'gradient_bytes': receipt['gradient_bytes'], 'optimizer_tensor_bytes': receipt['optimizer_tensor_bytes'],
                                      'command_receipt': command, 'function_wall_seconds': training['wall_seconds'], 'adapter': adapter}
        acquisition = read(native / 'acquisition.json')
        inspection = read(native / 'trial/native_inspection.json')
        model = {r['path']: {'bytes': r['bytes'], 'sha256': r['sha256']} for r in acquisition['files']}
        check('all six pinned model files freshly acquired', len(model) == 6 and acquisition['automatic_retries'] == 0 and all(r['complete'] and r['bytes'] == r['expected']['bytes'] and r['sha256'] == r['expected']['sha256'] for r in acquisition['files']))
        check('actual inspected base matches acquisition and lineage', model == inspection['model'] and sha(json.dumps(model, sort_keys=True, separators=(',', ':')).encode()) == lineage['base_identity'])
        source, archive = source_data[0]
        check('acquisition matches executed fixture', acquisition['spec'] == json.loads(archive['native']['scripts/memory_cell_native/fixtures/base-acquisition.json']))
        check('runtime Python sources match exact executed archive', all(source['native']['files'].get(p) == v for p, v in inspection['runtime']['sources'].items()))
        findings['acquisition'] = {'fresh_bytes': sum(r['bytes'] for r in model.values()), 'files': len(model), 'wall_seconds': acquisition['wall_seconds'], 'base_bytes_retained_in_artifact': False, 'identity_basis': 'acquisition + inspected inventory + lineage + actual worker pins; original base directory is outside upload path'}
    section('fresh_training', inspect_training)

    def inspect_models():
        document, query = read(native / 'trial/source_document.json'), read(native / 'trial/read_query.json')
        report1, report2 = read(native / 'report.json'), read(shadow / 'report.json')
        result1 = read(native / 'native-owner/raw-result.json')
        e1, e2 = json.loads(result1['execution_json']), read(shadow / 'shadow-owner/raw-execution.json')
        check('v1 returned actual unmodified worker text', result1['state'] == 'succeeded' and result1['text'] == e1['text'] and sha(result1['execution_json'].encode()) == result1['execution_sha256'])
        observations = {}
        for label, directory, execution, width in [('native', native / 'trial/native-process-receipts', e1, 4), ('shadow', shadow / 'native-process-receipts', e2, 5)]:
            entries = list(directory.iterdir())
            check(label + ' one actual worker namespace', len(entries) == 1)
            folder = entries[0]
            request, process, raw = read(folder / 'request.json'), read(folder / 'process.json'), read(folder / 'stdout.json')
            boot = bootstrap(folder / 'stderr.log')
            check(label + ' exact request and raw response', file_sha(folder / 'request.json') == execution['request_sha256'] == folder.name and raw == execution)
            check(label + ' actual successful subprocess', process['exit_code'] == 0 and not process['timed_out'] and process['stdin_completed'] and boot is not None and process['pid'] == boot['pid'] and process['parent_pid'] == boot['parent_pid'] == boot['expected_parent_pid'])
            check(label + ' source/query/pins bound', request['question'] == execution['question'] == query['question'] and request['source_root'] == query['source_root'] == file_sha(native / 'trial/source_document.json') and request['pins'] == execution['pins'] and request['query_digest'] == execution['query_digest'] and request['source_binding_digest'] == execution['source_binding_digest'])
            check(label + ' actual profile width', len(execution['drive_q24']) == len(execution['prediction_q24']) == request['neuron_request']['expected_output_width'] == width)
            check(label + ' no oracle input or text postprocessing', not ({'answer', 'value', 'document', 'facts', 'retrieval'} & set(request)) and not execution['facts_received'] and not execution['retrieval_received'] and not execution['answer_postprocessed'])
            observations[label] = {'text': execution['text'], 'tokens': execution['generated_token_ids'], 'correct': execution['text'].strip() == document['value'], 'denominator': 1, 'prompt_tokens': len(execution['prompt_token_ids']), 'resident_parameter_bytes': execution['resident_bytes'], 'peak_rss_bytes': execution['process_peak_rss_bytes'], 'model_phase_latency_micros': execution['latency_micros']}
        for control in ('base', 'shuffled'):
            raw = read(native / 'commands' / f'control-{control}' / 'stdout.log')
            row = raw['rows'][0]
            check(control + ' original query and raw intervention', len(raw['rows']) == 1 and row['question'] == query['question'] and row['prompt_token_ids'] == e1['prompt_token_ids'] and not raw['fact_input'] and not raw['retrieval_input'] and not raw['answer_lexicon_input'] and not row['answer_postprocessed'])
            check(control + ' actual adapter control', not row['adapter_enabled'] if control == 'base' else row['adapter_enabled'] and raw['consumed_adapter_state_sha256'] != raw['admitted_adapter_state_sha256'])
            observations[control] = {'text': row['text'], 'tokens': row['token_ids'], 'correct': row['text'].strip() == document['value'], 'denominator': 1, 'prompt_tokens': row['input_tokens']}
        check('fresh five child PIDs with completed96+4queries+2features', counts['training_updates'] == counts['training_forwards'] == 96 and counts['completed_native_queries'] == counts['completed_shadow_queries'] == 1 and counts['completed_control_queries'] == counts['completed_explicit_feature_forwards'] == 2 and len(counts['processes']) == len({p['pid'] for p in counts['processes']}) == 5 and not counts['unknown_partial_work'])
        check('driver totals match actual raw evidence', report1['actual_decoder_queries'] == 3 and report1['actual_native_feature_forwards'] == report2['actual_shadow_decoder_queries'] == report2['actual_shadow_feature_forwards'] == 1 and report2['actual_total_decoder_queries_including_original_v1'] == 4 and report2['actual_total_native_feature_forwards_including_original_v1'] == 2)
        check('same CI checkpoint reused with no additional shadow training', report2['training_updates_added'] == 0 and report2['training_updates_reused'] == 96 and report2['original_v1_source_head'] == HEAD and e1['pins'] == e2['pins'])
        registration = read(shadow / 'registration.json')
        after = read(shadow / 'frozen-after.json')
        check('entire CI v1 frozen through shadow', registration['frozen_before'] == after['files'] == files(native) and registration['checkpoint_before'] == after['checkpoint'] == files(native / 'trial/checkpoint') and registration['original_v1_report_sha256'] == file_sha(native / 'report.json'))
        check('explicit development qualification boundary', report1['previously_exposed_case'] and report2['controlled_context_provider'] and not report1['production_qualified'] and not report2['production_qualified'] and report2['future_tasks'] == 0 and report1['parameter_success_gate'] is None)
        findings['observations'] = observations
        findings['driver_wall_seconds'] = {'fresh_v1': report1['wall_seconds'], 'shadow': report2['wall_seconds'], 'sum_without_double_counting_nested_commands': report1['wall_seconds'] + report2['wall_seconds']}
        findings['commands'] = {label: {p.parent.name: read(p) for p in sorted((directory / 'commands').glob('*/receipt.json'))}
                                for label, directory in [('fresh_v1', native), ('shadow', shadow)]}
    section('models', inspect_models)

    def inspect_lifecycle():
        owner = native / 'native-owner'
        revisions = [read(owner / n)['write']['memory']['id']['revision'] for n in ('production-source.json', 'controlled-correction.json', 'withdrawal.json')]
        check('v1 actual correction and tombstone sequence', revisions == [1, 2, 3] and read(owner / 'withdrawal.json')['write']['memory']['lifecycle']['state'] == 'tombstoned')
        engineering = read(owner / 'report.json')
        check('v1 all original refusals without additional dispatch', engineering['backend_dispatch_attempts'] == 1 and set(engineering['refused']) == {'unknown-key', 'wrong-role', 'forged-production-receipt', 'replayed-nonce', 'withdrawn-authority', 'corrected-cached-result', 'corrected-old-adapter', 'withdrawn-source'})
        owner = shadow / 'shadow-owner'
        replay, before_delivery, after_delivery = [read(owner / n) for n in ('replay-refusal.json', 'delivery-before-tombstone.json', 'delivery-after-tombstone.json')]
        check('v2 exact replay refusal', replay['error_kind'] == 'Source(Replay)' and replay['backend_dispatches_before'] == replay['backend_dispatches_after'] == 1)
        check('v2 recovered owner delivers before source withdrawal', before_delivery['delivery_allowed'] and before_delivery['same_process_owner_recovered'])
        check('v2 source invalid after actual tombstone, not withdrawn writer', not after_delivery['delivery_allowed'] and not after_delivery['writer_authority_withdrawn'] and after_delivery['error_kind'] == 'Source(Invalid("current source revision or typed identity"))' and after_delivery['backend_dispatches_before'] == after_delivery['backend_dispatches_after'] == 1)
        anchors = read(owner / 'anchors-after-read.json')
        check('journal/witness retained unchanged through withdrawal', anchors == read(owner / 'anchors-after-withdrawal.json') and anchors['journal_anchor'] == anchors['witness_anchor'] and anchors['journal_anchor']['sequence'] == 1 and anchors['journal_sha256'] == file_sha(owner / 'shadow-journal') and anchors['witness_sha256'] == file_sha(owner / 'shadow-witness'))
        engineering = read(owner / 'report.json')
        check('uncalibrated controlled shadow only', engineering['abstain'] and not engineering['authority_grants_any'] and engineering['calibration'] is None and not engineering['production_context_provider'] and not engineering['v2_control_socket_exercised'] and not engineering['default_daemon_installed'] and not engineering['cross_process_recovery'])
        findings['full_tick_frame_independent_recomputation'] = 'separate pure-stdlib audit required from archived executed source; not inferred from receipt flags'
    section('lifecycle', inspect_lifecycle)
    clean_files = ('post-test-fix-format.patch', 'post-test-fix-format.stat', 'final-worktree-status.txt')
    check('final actual fix/fmt proposed no source change', all((root / name).exists() and (root / name).stat().st_size == 0 for name in clean_files))
    check('artifact unchanged by audit', before == files(root))
    report = {'schema': 'hepta.memory.bootstrap-ci-raw-audit.v1', 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'run_id': RUN, 'job_id': JOB, 'source_head': HEAD, 'source_tree': TREE,
              'run_conclusion': run['conclusion'], 'job_conclusion': job['conclusion'],
              'checks': checks, 'checks_passed': sum(c['passed'] for c in checks), 'checks_failed': sum(not c['passed'] for c in checks),
              'strict_reader_checks_passed': all(c['passed'] for c in checks), 'full_tick_frame_audit_completed_here': False,
              'outer_zip_bytes_match_extraction': any(c['check'] == 'all extracted bytes match original ZIP' and c['passed'] for c in checks),
              'counts': counts, 'findings': findings, 'retained_files': before,
              'retained_storage': {'files': len(before), 'file_bytes': sum(row['bytes'] for row in before.values()), 'original_runner_file_modes_independently_proven': False},
              'audit_model_calls': 0, 'audit_training_updates': 0, 'audit_tests_executed': 0,
              'source_code_modified': False, 'future_tasks': 0, 'future_accuracy': None, 'production_qualified': False,
              'all_eight_full_closure': False, 'bootstrap_permission_repair_source_included': True, 'bootstrap_crash_case_audit_completed_here': False}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x') as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'output': str(output), 'sha256': file_sha(output), 'checks_passed': report['checks_passed'], 'checks_failed': report['checks_failed'], 'audit_model_calls': 0}))


if __name__ == '__main__':
    main()
