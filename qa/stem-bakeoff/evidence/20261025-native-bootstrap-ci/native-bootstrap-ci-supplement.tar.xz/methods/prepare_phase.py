"""Create a separate audit phase from immutable previous reader bytes; execute no audits."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'native-final-ci-audit-20261025'
CONTROL = ROOT.parent / 'memory-resume-control-20261024/bootstrap-ci-001'
HEAD = 'a47190bb84714cb1262fcd85ebb723081fdb0581'
TREE = 'b4150dc0e76e216792a36b8478580dfed3270af2'


def create(name, data):
    with (ROOT / name).open('xb') as output:
        output.write(data)
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    commit = json.loads((ROOT / 'source-commit-a47190.json').read_text())
    assert commit['sha'] == HEAD and commit['tree']['sha'] == TREE
    initial = json.loads((CONTROL / 'run-initial.json').read_text())
    assert initial['id'] == 40152367005 and initial['head_sha'] == HEAD and initial['run_attempt'] == 1
    outputs = {}
    for name in ('run-initial.json', 'jobs-initial.json'):
        outputs[name] = create(name, (CONTROL / name).read_bytes())
    sources = {'ci_evidence.py': '1db7bc7513e8a7344240f17f49071b40d8095906f72ac339c5b32f39cb1f9e01',
               'audit_final_ci.py': 'db4878f94d002afafdf24e23f5b342f292f3a9b6ada8cf4c99ccd29439f38a52'}
    for name, expected in sources.items():
        raw = (OLD / name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == expected
        text = raw.decode()
        if name == 'ci_evidence.py':
            for old, new in [('33c741cb0abe5faac1d92abe5d0ac90bee4abb51', HEAD),
                             ('02d11c75658c23b498ba2e7f8b6f082d76ec33b3', TREE), ('40149732280', '40152367005'), ('121038539566', '121046374239')]:
                assert text.count(old) == 1
                text = text.replace(old, new)
        else:
            assert text.count("test_summary['passed'] == 651") == 1
            text = text.replace("test_summary['passed'] == 651", "test_summary['passed'] == 653")
            text = text.replace('hepta.memory.final-ci-raw-audit.v1', 'hepta.memory.bootstrap-ci-raw-audit.v1')
            text = text.replace("or job['run_id'] != RUN):", "or job['run_id'] != RUN or job['head_sha'] != HEAD or job['run_attempt'] != 1):")
            text = text.replace("'separate_bootstrap_permission_repair_included': False", "'bootstrap_permission_repair_source_included': True, 'bootstrap_crash_case_audit_completed_here': False")
            name = 'audit_bootstrap_ci.py'
        ast.parse(text)
        outputs[name] = create(name, text.encode())
    record = {'schema': 'hepta.memory.bootstrap-ci-audit-preparation.v1', 'source_head': HEAD, 'source_tree': TREE,
              'run_id': 40152367005, 'job_id': 121046374239, 'run_attempt': 1,
              'copied_reader_source_hashes': sources, 'new_files': outputs,
              'expected_six_crate_tests': 653, 'expected_skipped': 13,
              'test_expectation_basis': 'actual same-command head33c baseline651 plus two newly added abrupt-child test functions; preserve and analyze any completed-log difference',
              'completion_known': False, 'audits_executed': 0, 'model_calls': 0, 'tests_executed': 0,
              'artifact_downloaded': False, 'old_phase_modified': False, 'full_closure_flags': [False] * 8}
    create('phase-preparation.json', (json.dumps(record, indent=2) + '\n').encode())
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
