# Independent bootstrap-repair CI audit preparation

This is a new, unexecuted audit phase for run **40152367005**, job
**121046374239**, attempt **1**, source
`a47190bb84714cb1262fcd85ebb723081fdb0581`, tree
`b4150dc0e76e216792a36b8478580dfed3270af2`.
The externally fetched immutable commit API confirms this head/tree identity.
The locally retained initial run/job metadata remains an in-progress observation;
it does not establish a completed result. No active artifact is downloaded here.

The readers are separately created copies with new constants and schema. The old
33c reader, its raw audits and the published PR3835 evidence remain unchanged.
`phase-preparation.json` identifies both parent reader hashes and the new bytes.
Only Python AST parsing has occurred; the evidence reader has not executed.

## Evidence admission after completion

- Require completed raw GitHub run/jobs metadata, exact new run/job/head/attempt,
  the original artifact API metadata, byte-exact original ZIP and complete logs.
- Verify API size/digest, every extracted file and the pinned source archives.
- Expect **653 six-crate tests**, based on the same-command observed old 651 plus
  two added abrupt-child tests. A different actual count is retained and analyzed;
  it must not be silently rewritten to fit the expectation. Expected skips: 13.
- Preserve fresh 96-update training, all raw v1/base/shuffle outputs, v2 fresh
  worker, callback and feature counts, source corrections and tombstones, frozen
  checkpoint, full costs, and actual final patch/stat/status as separate evidence.
- Independent complete v2 tick/frame reconstruction remains a separate audit;
  general driver success cannot replace either that audit or the crash-case audit.

## Additional bootstrap crash evidence

The exact workflow exports `HEPTA_MEMORY_CRASH_EVIDENCE_ROOT` under the uploaded
artifact's `bootstrap-crash-tests/` directory. Each retained case should include
writer/recovery requests, self-reported process records, parent exit receipts,
stdout/stderr, handoff, full source-before/source-after inventories, recovered
write receipt, and the actual database/WAL/SHM bytes. Case directory names are
dynamic; they are not assumed from the earlier local experiment.

The separate specialist audit will map runner absolute paths to retained case
members, bind the exact test names and source, compare full source cut and all
source bytes/metadata before versus after, and verify actual child PID, umask,
writer exit73 then recovery exit0, new durable write and same-child close/reopen.
Missing case artifacts cannot be replaced by the overall green CI badge.
Runner file modes must come from the original captured JSON, not extracted ZIP
permissions. The source-before/after comparison includes device, inode, links,
mtime and ctime in addition to byte hashes.

This checks committed-WAL-present recovery after an abrupt process exit. It does
not establish power-loss recovery, WAL-only persistence, physical unlearning,
production authority or default daemon attachment. The eight research gates
remain false. The new CI's actual model/update costs must be added as a distinct
fresh experiment; none are inherited from either the old 33c CI or local runs.

Root will supply the completion notice before any artifact retrieval or reader
execution. Preparation performs no model, Rust, tests, SQLite opens or remote
writes and does not poll the active workflow.
