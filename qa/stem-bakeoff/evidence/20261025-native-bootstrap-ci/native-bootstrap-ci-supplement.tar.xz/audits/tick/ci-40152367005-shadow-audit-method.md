# a471 CI v2：独立完整 tick / frame 审计

## 输入与结论

- 精确源提交：`a47190bb84714cb1262fcd85ebb723081fdb0581`；tree `b4150dc0e76e216792a36b8478580dfed3270af2`。
- GitHub run `40152367005`、job `121046374239`、attempt `1`、artifact `12584240824`，完成状态由保存的 final API 记录核对。
- 原始 ZIP：`native-memory-40152367005-1.zip`，62,069,755 B；SHA `d3ad050d06cafe321e9bf4bbd024140973a252d2cc41355e7dc1e1c5e8acf144`，重新与 artifact API 的 digest/size 比较。
- 只读输入：`native-bootstrap-ci-audit-20261025/artifact/shadow`；同一次 CI 的 v1 位于 `artifact/run`。
- 审计结果：**598/598 比较通过**，包括 345 个 archived source pins、57 个 v2 ZIP 成员和 196 项身份、绑定、数值、二进制及拒绝路径比较。
- 检查数来自实际输入；比旧审计多一个源码文件和两项 raw text/token IDs 一致性检查。这些检查不是新增实验样本。

## 方法身份与继承

新方法为 `audit_ci_shadow_40152367005.py`，400 行，仅使用 Python 标准库读取、哈希、JSON、ZIP/TAR、整数运算。
它不 import 仓库模块，不执行模型、Rust、测试或 SQLite，不写入证据目录；输出已经存在时拒绝覆盖。
前序方法 SHA 为 `6981f26c08f391c50ae4d48da7f1ec1e4ca426322b76f15ecdbf1437b60ecacc`。
此次调整仅为新 run/job/artifact/source 身份、输出防覆盖、两项报告与 raw 输出比较，以及新 cohort/原始输出记录。
25 个决定 canonical 编码、Q24 运算和探针顺序的实现文件，与旧 CI 保存的文件逐项 SHA/size 相同。
完整 source inventory 的四处变化为 workflow、cognitive_store initializer、其 recovery tests 和新增 bootstrap crash tests；345 个当前 source blobs 均从本次 tar 内重新核对。
适配记录保留上述差异、方法身份和旧三份审计文件 SHA；旧方法、旧 JSON、旧说明已再次确认字节未变。

## 独立重算内容

1. 核对 run/job/artifact/head/tree 和 ZIP digest；逐项读取 ZIP 内 v2 原始文件，并核对 executed-source 的 embedded commit、所有 source pins 和 qualification 前后 clean source。
2. 从同次 v1 config/report/checkpoint 证明 v2 重用来源；核对 v2 仅 width/config-id/receipt-directory 改动和冻结前后 checkpoint/inventory。实际 retained adapter/lineage 字节重新哈希。
3. 从实际 typed question 生成全部 512 个整数特征；从原始 query、source binding、HNMF 和 production remember/forget receipts 重算所有 canonical 身份与 mutation 摘要。
4. 从完整 tick 的 nonce、subject、logical sequence、实际 monotonic time、predecessor、feature/objective/NDU、body/modulator 和完整向量重算 semantic digest，再计算 source/query/tick join。
5. 从模型实际 drive/prediction 和 runtime receipt 重算输出摘要、runtime 摘要及 encoder/head/output/runtime 联合绑定。runtime 源码 inventory 与本次 source archive 逐项比较。
6. 从配置、参数和实际 pins 计算 sparse config、shadow profile、source/profile namespace；检查 objective/NDU 摘要确实来自独立 controlled context 文件，并与 HNMF fixture/source root 不同。
7. 使用精确 signed Q24 算术重建第一次 sparse 状态转换：ties-to-even 乘法、阈值、top-k、activity、eligibility 和投影计数；不执行模型。完整 canonical checkpoint 从这些独立状态和本次 tick 构造。
8. 完整重建 384 B frame，包括实际 tick/raw vectors、前后 checkpoint、journal signal 的 requires-calibration 与 DENY_ALL 位及 checksum；同时重建并比较 520 B journal 和 224 B witness 的 headers、校验和及 0→1 anchor。
9. 核对 exact `Source(Replay)`、第二次 Recover 后实际成功交付、真实 forget/tombstone、精确 `Source(Invalid("current source revision or typed identity"))` 和 writer authority 未撤回。全程模型 dispatch 保持 1，journal/witness anchors 未增长。
10. 结合 pinned probe 顺序、实际 stdout/stderr、父子 PID/exit 和 precise error receipts 核对路径；审计前后 v1/v2 文件 inventory、API/log、原始 ZIP 全部一致。

## 本次实际值

| 项目 | 结果 |
| --- | --- |
| full tick digest | `d2811647372efc7f4d944ec3a543e90a14dacaaad47827198586e1b189971412` |
| source/query/tick join | `f9ce9e56e1a11a32b254767e67810d92f96d93cb5afc001c54cf4507aca6e610` |
| source/profile namespace | `173cf1975d9bebe6e3a7109e51f6cdb2fc7cd195b92a8fa94a9f4999d2c2f9eb` |
| independent checkpoint | `46ef708f9df4713caf0b5e650544e1127c9d9c9580eb2174be9270e5a8147bc9` |
| journal SHA-256 | `fec215059de3d2132a85419b67ec358d171e99f7291901fad5f37d023fbd547f` |
| witness SHA-256 | `79c5684d5393cf659e78efd6ebd3d430827b0b3b130c663b77da8f4970818a18` |
| v2 parent / model PID | 34995 / 35005 |
| 实际 callback / decoder / explicit feature forward | 1 / 1 / 1 |
| replay / tombstone 新增 dispatch | 0 / 0 |
| 原始 decoder 输出 | `order`，tokens `[2559, 2]`；已见同一案例 |

实际 temporal 为 `[-5770727, -2798424, 15968534, 15986188, -10268409]`；activation 为 `[0, 0, 0, 15986188, 0]`。
activity 为 `[0, 0, 0, 16777216, 0]`；threshold 为 `[-262144, -262144, -262144, 1835008, -262144]`；eligibility 为 `[0, 0, 0, 15232456, 0]`。
projections 为 0；prediction error Q24 为 22547925。这些值从本次 raw drive/prediction 重算，不复用旧 CI 的状态。

## 训练与成本分组

本次 CI 的训练命令 PID 为 34806，实际 96 updates、96 training forwards、96 losses，初始化为 frozen_base、无 learned parent，命令 exit0。
本次 v2 加训 0 次、复用本次 CI 的 96 次；不计入旧 33c CI 的 96 次，也不与本地 continuation 复用96混合。
审计本身运行 1.421 秒，新增模型调用、训练更新、任务样本均为 0。完整 CI 的五模型子进程/四decoder/两explicit-features成本由独立 general reader 负责，本审计不重复相加。

## 复现

在另一个输出路径执行标准库审计器：

```sh
python3 audit_ci_shadow_40152367005.py --package /path/to/native-bootstrap-ci-audit-20261025 --out /outside-evidence/audit.json
```

package 需要原始 ZIP、final API、完整 job log、source commit API 和解包的 artifact/run、artifact/shadow。审计器不下载任何内容。

## 证明范围

- controlled context，calibration=null、abstain、DENY_ALL；未证明 production Objective/NDU attachment、默认 daemon 或 v2 control socket。
- 两次 Recover 都在同一实际父进程，不能推导跨进程 Instant 连续性或独立运营 witness 信任。
- nonce/source 的 SQLite logical rows 未被重新打开或重建；其因果顺序依靠归档的 pinned executed probe、实际成功进程和 precise error/mutation receipts，不能称为硬件证明。
- ZIP 未保留大型 base 文件和 Python executable 本体；其 inventory pins 可重算，但本审计没有独立重哈希这些外部字节。
- ZIP 解包 mode 不是原 runner 权限证明。首次建库 crash 的实际新 CI 资格由独立 crash reader 审计，不归入本次 frame 检查。
- 一个已见案例、受控授权和固定 checkpoint 不能证明未来任务优势、校准、净压缩或八项完整研究/生产目标；八 gate 仍全部 false。
