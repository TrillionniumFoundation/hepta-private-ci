# Independent a471 CI crash-case audit

The frozen reader ran once against the completed run `40152367005`, job `121046374239`, and returned exit 0. All **90 checks passed**, with no method correction, failed check, missing field, or retry. The CI metadata independently reports `completed / success`; the audit checks the two crash cases in detail, while the overall native model stages belong to the companion CI audit.

## Source and actual tests

The artifact binds head `a47190bb84714cb1262fcd85ebb723081fdb0581` and tree `b4150dc0e76e216792a36b8478580dfed3270af2`. The source-before and source-after maps contain 345 files and are identical. The archived initializer, module hook, workflow and final 333-line `let _ = temp.keep();` test all match the four frozen file hashes.

The raw scoped log reports **653 tests run, 653 passed, 13 skipped, 91.982 seconds**. It contains the exact initial-generation PASS at `(319/653)` and recovered-generation PASS at `(322/653)`. There is one retained attempt per new test and no retry/flaky line.

| Case | Parent PID | Writer PID / exit | Recovery PID / exit | Actual self-reported mask |
| --- | ---: | --- | --- | --- |
| `initial-generation-pnxtNz` | 33006 | 33008 / 73 | 33051 / 0 | Both `0022` |
| `recovered-generation-rxQLr8` | 33078 | 33080 / 73 | 33119 / 0 | Both `0022` |

Each receipt PID matches the corresponding child-written process identity. Both recovery children report one actual test passed. Their external full cut equals the actual observed cut after recovery; a real new write advances the state digest and survives close/reopen inside that recovery child. Each resulting new database is retained as 589,824 bytes.

## Original source bundles

Runner `source-before.json` and `source-after.json` are equal in all captured fields: mode, device, inode, link count, timestamps, byte count and SHA. Every recorded original source mode is `0600`, and every recorded link count is one. Actual ZIP member bytes independently match all original DB/WAL/SHM byte counts and hashes.

| Case | Original main | Original WAL | Original SHM | WAL frame slots |
| --- | ---: | ---: | ---: | ---: |
| Initial generation | 4,096 B | 1,030,032 B | 32,768 B | 250 |
| Recovered generation | 589,824 B | 8,272 B | 32,768 B | 2 |

No permission conclusion comes from ZIP attributes or an extracted file's mode. No original runner inode is inferred from the download. The reader never extracts members, opens SQLite, or executes Rust or a model. The ZIP, metadata and method bytes/mode/mtime/ctime/inode remained unchanged across the read; access time is excluded.

## Immutable references and limits

- ZIP: `native-memory-40152367005-1.zip`, 62,069,755 B, SHA `d3ad050d06cafe321e9bf4bbd024140973a252d2cc41355e7dc1e1c5e8acf144`.
- Method: `read_ci_crash_evidence.py`, SHA `bef2997a2a9e06797832aac6bc5a62634a57287f41788edc7ba6560abe7acb10`.
- Actual result: `actual-crash-audit-001.json`, 52,036 B, SHA `0b358a1b87fe9f38119698266cdec4f2d5bf4926b0b141fc83070f78a0e42293`.
- The exact invocation, raw stdout/stderr, receipt and input before/after hashes are in `actual-reader-command-001/`.

Process exit 73 is not physical power-loss qualification. WAL frames do not establish WAL-only necessity. The full-cut comparison uses the actual serialized child receipts and frozen test, without independently recomputing SQL table state. The close/reopen remains inside the recovery child, not a third verifier process. Authority is the controlled fixture; this result does not establish production authentication/currentness or close the eight complete memory research gates.
