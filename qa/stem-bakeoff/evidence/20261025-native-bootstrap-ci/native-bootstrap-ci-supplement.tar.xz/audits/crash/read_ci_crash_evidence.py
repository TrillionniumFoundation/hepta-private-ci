"""Inspect a completed, verified a471 artifact ZIP without extraction or SQLite."""

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import struct
import tarfile
import zipfile


HEAD = "a47190bb84714cb1262fcd85ebb723081fdb0581"
TREE = "b4150dc0e76e216792a36b8478580dfed3270af2"
RUN = 40152367005
JOB = 121046374239
PINS = {
    ".github/workflows/hepta-native-memory.yml": "c04bb40cfe41fac3095cee53fea96756bc6b87e1544de4990f68f7ca98aa59bc",
    "codex-rs/hepta-memory/src/cognitive_store.rs": "2ea1c39f6887d8069270c393886215f8c32d00487e2841e20527117ad21f687c",
    "codex-rs/hepta-memory/src/cognitive_store_recovery_tests.rs": "e8dbb6dfd8a2fa52e70578a02c75bc9f4e853be64ad94c2347d4820b44a602f5",
    "codex-rs/hepta-memory/src/cognitive_store_bootstrap_crash_tests.rs": "4e428fb4876ad2f833713558cad601a9ac73a9e871824528d27b3b8158f8b88e",
}
TEST_PREFIX = "cognitive_store::recovery::tests::bootstrap_crash::"
TESTS = {kind: TEST_PREFIX + kind + "_generation_abrupt_exit_recovers_exact_cut" for kind in ["initial", "recovered"]}
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
SOURCE_FIELDS = {"bytes", "sha256", "mode", "device", "inode", "links", "mtime_seconds", "mtime_nanoseconds", "ctime_seconds", "ctime_nanoseconds"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument("--artifact", required=True, type=Path)
parser.add_argument("--expected-zip-sha256", required=True)
parser.add_argument("--run-final", required=True, type=Path)
parser.add_argument("--jobs-final", required=True, type=Path)
parser.add_argument("--output", required=True, type=Path)
args = parser.parse_args()
assert not args.output.exists(), "output must be a new evidence file"
run = json.loads(args.run_final.read_bytes())
jobs = json.loads(args.jobs_final.read_bytes())["jobs"]
job = next(item for item in jobs if item["id"] == JOB)
assert run["id"] == RUN and run["head_sha"] == HEAD and job["run_id"] == RUN
assert run["status"] == job["status"] == "completed", "never read an active artifact"
assert file_sha(args.artifact) == args.expected_zip_sha256
checks, errors, cases = [], [], []
read_members = {}


def check(name, ok, *, scope="integrity"):
    checks.append({"check": name, "passed": bool(ok), "scope": scope})
    return bool(ok)


def required_cut(value):
    return (
        set(value) == {"profile", "owner_agent_id", "schema_digest", "state_digest"}
        and value["profile"] == "hepta:cognitive:exact-current-cut:v1"
        and value["owner_agent_id"] == "00000000-0000-4000-8000-0000000000c6"
        and all(re.fullmatch("[0-9a-f]{64}", value[key]) for key in ["schema_digest", "state_digest"])
    )


source_observation, log_observation = {}, {}
with zipfile.ZipFile(args.artifact) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)), "duplicate ZIP names"
    assert all(not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts and "\\" not in name for name in names)
    name_set = set(names)
    candidates = [name[:-len("source.txt")] for name in names if name == "source.txt" or name.endswith("/source.txt")]
    candidates = [prefix for prefix in candidates if prefix + "scoped-tests.log" in name_set]
    assert len(candidates) == 1, "unique artifact root required"
    prefix = candidates[0]

    def read(relative):
        name = prefix + relative
        data = archive.read(name)
        read_members[relative] = {"bytes": len(data), "sha256": sha(data)}
        return data

    def load(relative):
        return json.loads(read(relative))

    try:
        source_text = read("source.txt").decode().splitlines()
        check("exact_checkout_head_and_tree", source_text == [HEAD, TREE])
        source_before, source_after = load("run/source-before.json"), load("run/source-after.json")
        check("native_source_maps_same", source_before == source_after)
        check("native_source_maps_clean_exact_head", source_before["head"] == HEAD and source_before["tree"] == TREE and source_before["status"] == "")
        source_observation = {"source_txt": source_text, "head": source_before["head"], "tree": source_before["tree"], "file_count": len(source_before["files"])}
        with tarfile.open(fileobj=io.BytesIO(read("run/executed-source.tar.gz")), mode="r:gz") as source_tar:
            for path, expected in PINS.items():
                data = source_tar.extractfile(path).read()
                check("archived_final_source_pin:" + path, sha(data) == expected)
                check("source_map_pin:" + path, source_before["files"][path] == {"sha256": expected, "bytes": len(data)})
    except (KeyError, ValueError, OSError, tarfile.TarError) as error:
        errors.append({"section": "source-binding", "error": repr(error)})

    try:
        raw_log = read("scoped-tests.log")
        text = ANSI.sub("", raw_log.decode(errors="replace"))
        summaries = list(re.finditer(r"Summary\s*\[\s*([\d.]+)s\]\s*(\d+) tests run:\s*([^\n]+)", text))
        check("one_actual_nextest_summary", len(summaries) == 1)
        summary = summaries[-1]
        counts = {name: int(count) for count, name in re.findall(r"(\d+) (passed|failed|skipped)", summary[3])}
        check("expected_653_selected_tests", int(summary[2]) == 653, scope="selection")
        actual_passes = {kind: [line for line in text.splitlines() if re.search(r"\bPASS\b", line) and "codex-hepta-memory " + name in line] for kind, name in TESTS.items()}
        retry_lines = [line for line in text.splitlines() if re.search(r"\bTRY\s+\d+\s+FAIL\b|\bFLAKY\b", line) and any(name in line for name in TESTS.values())]
        for kind, lines in actual_passes.items():
            check("actual_named_parent_test_pass:" + kind, bool(lines), scope="qualification")
        log_observation = {"raw_sha256": sha(raw_log), "summary": summary[0], "run": int(summary[2]), "counts": counts, "seconds": float(summary[1]), "named_pass_lines": actual_passes, "retry_or_flaky_lines": retry_lines}
    except (KeyError, ValueError, IndexError) as error:
        errors.append({"section": "actual-test-log", "error": repr(error)})

    case_root = "bootstrap-crash-tests/"
    case_names = sorted({name[len(prefix + case_root):].split("/", 1)[0] for name in names if name.startswith(prefix + case_root) and name[len(prefix + case_root):]})
    check("raw_case_directories_exist", bool(case_names), scope="qualification")
    for case_name in case_names:
        case_prefix = case_root + case_name + "/"
        kind = "initial" if case_name.startswith("initial-generation-") else "recovered" if case_name.startswith("recovered-generation-") else None
        item = {"case": case_name, "generation": kind, "checks": [], "errors": [], "children": []}
        start = len(checks)
        try:
            assert kind is not None, "unknown case directory"
            handoff = load(case_prefix + "handoff.json")
            before, after = load(case_prefix + "source-before.json"), load(case_prefix + "source-after.json")
            write_request = load(case_prefix + "command-write/request.json")
            original_root = PurePosixPath(write_request["child_root"])
            check(case_name + ":runner_case_path", original_root.is_absolute() and original_root.parts[-2:] == ("bootstrap-crash-tests", case_name))

            def member_for(absolute):
                relative = PurePosixPath(absolute).relative_to(original_root)
                assert ".." not in relative.parts
                return case_prefix + relative.as_posix()

            original_source = PurePosixPath(handoff["source_path"])
            check(case_name + ":complete_cut_shape", required_cut(handoff["cut"]))
            check(case_name + ":source_owner_path", original_source.parent.name == "cognitive" and original_source.parent.parent.name == handoff["cut"]["owner_agent_id"])
            check(case_name + ":runner_before_after_all_metadata_equal", before == after)
            check(case_name + ":main_wal_shm_present_in_snapshots", all(original_source.name + suffix in before for suffix in ["", "-wal", "-shm"]))
            expected_names = {original_source.name + suffix for suffix in ["", "-wal", "-shm", "-journal"]}
            check(case_name + ":snapshot_only_original_bundle", set(before) <= expected_names)
            for name, captured in before.items():
                check(case_name + ":complete_captured_metadata:" + name, set(captured) == SOURCE_FIELDS)
                data = read(member_for(str(original_source.parent / name)))
                check(case_name + ":original_bytes_match_runner_snapshot:" + name, len(data) == captured["bytes"] and sha(data) == captured["sha256"])
                check(case_name + ":captured_runner_0600:" + name, captured["mode"] == 0o600, scope="qualification")
                check(case_name + ":captured_runner_single_link:" + name, captured["links"] == 1)
            wal = read(member_for(str(original_source) + "-wal"))
            magic, version, page_size = struct.unpack(">III", wal[:12])
            layout_ok = magic in [0x377F0682, 0x377F0683] and version == 3007000 and page_size >= 512 and len(wal) > 32 and (len(wal) - 32) % (24 + page_size) == 0
            check(case_name + ":wal_frames_present", layout_ok)
            item.update(handoff=handoff, source_before=before, source_after=after, wal_layout={"bytes": len(wal), "page_size": page_size, "frame_slots": (len(wal) - 32) // (24 + page_size) if layout_ok else None})
            for phase in ["write", "recover"]:
                path = case_prefix + "command-" + phase + "/"
                request, process, receipt = (load(path + name) for name in ["request.json", "process.json", "receipt.json"])
                stdout, stderr = read(path + "stdout.log"), read(path + "stderr.log")
                check(case_name + ":exact_child_command:" + phase, request["args"] == ["--exact", TESTS[kind], "--nocapture"] and request["phase"] == phase and request["child_root"] == str(original_root))
                check(case_name + ":actual_child_identity:" + phase, process["pid"] == receipt["pid"] and process["phase"] == phase and process["pid"] != request["parent_pid"])
                mask = process["linux_proc_umask_line"]
                check(case_name + ":actual_child_mask_recorded:" + phase, isinstance(mask, str) and re.fullmatch(r"Umask:\s+[0-7]{4}", mask) is not None)
                check(case_name + ":actual_exit:" + phase, receipt["exit_code"] == (73 if phase == "write" else 0), scope="qualification")
                check(case_name + ":one_child_test_started:" + phase, b"running 1 test" in stdout)
                if phase == "recover":
                    check(case_name + ":one_recovery_test_passed", b"test result: ok. 1 passed; 0 failed" in stdout and not stderr, scope="qualification")
                item["children"].append({"phase": phase, "request": request, "actual_process": process, "receipt": receipt, "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr), "stderr": stderr.decode(errors="replace")})
            writer, recovery = item["children"]
            check(case_name + ":distinct_processes_same_parent", writer["receipt"]["pid"] != recovery["receipt"]["pid"] and writer["request"]["parent_pid"] == recovery["request"]["parent_pid"])
            result = load(case_prefix + "recovered-write.json")
            check(case_name + ":observed_full_cut_equals_external_cut", result["observed_before_write"] == handoff["cut"], scope="qualification")
            persisted = result["persisted_after_write"]
            check(case_name + ":new_write_persists_changed_complete_cut", required_cut(persisted) and persisted != handoff["cut"] and all(persisted[key] == handoff["cut"][key] for key in ["profile", "owner_agent_id", "schema_digest"]), scope="qualification")
            check(case_name + ":new_database_path", result["database_path"] != str(original_source) and PurePosixPath(result["database_path"]).parent == original_source.parent)
            new_database = read(member_for(result["database_path"]))
            check(case_name + ":actual_new_database_retained", new_database.startswith(b"SQLite format 3\x00"))
            item["recovered_write"] = result
            item["new_database_bytes"] = {"bytes": len(new_database), "sha256": sha(new_database)}
        except (AssertionError, KeyError, ValueError, OSError, struct.error) as error:
            item["errors"].append(repr(error))
        item["checks"] = checks[start:]
        item["complete_qualified_attempt"] = not item["errors"] and all(value["passed"] for value in item["checks"])
        cases.append(item)

check("artifact_zip_bytes_unchanged", file_sha(args.artifact) == args.expected_zip_sha256)
check("all_case_directories_recognized", all(item["generation"] in TESTS for item in cases))
counts = {kind: sum(item["generation"] == kind for item in cases) for kind in TESTS}
qualified = {kind: sum(item["generation"] == kind and item["complete_qualified_attempt"] for item in cases) for kind in TESTS}
for kind, count in qualified.items():
    check("qualified_actual_generation_present:" + kind, count >= 1, scope="qualification")
extra_attempts = sum(max(0, count - 1) for count in counts.values())
if extra_attempts:
    check("extra_attempts_have_actual_retry_log", bool(log_observation.get("retry_or_flaky_lines")), scope="selection")
outside_cases = [value for value in checks if not any(value["check"].startswith(item["case"] + ":") for item in cases)]
qualified_claim = not errors and all(value["passed"] for value in outside_cases) and all(qualified.values())
report = {
    "schema": "hepta-a471-ci-crash-evidence-audit-v1", "reader_sha256": file_sha(Path(__file__)),
    "artifact_zip_sha256": args.expected_zip_sha256, "ci_run": {"id": RUN, "head": run["head_sha"], "status": run["status"], "conclusion": run["conclusion"]},
    "ci_job": {"id": JOB, "status": job["status"], "conclusion": job["conclusion"]},
    "ci_pipeline_succeeded": run["conclusion"] == job["conclusion"] == "success",
    "source": source_observation, "actual_scoped_log": log_observation, "cases": cases,
    "observed_case_attempt_counts": counts, "qualified_attempt_counts": qualified, "extra_attempts_not_unique_tests": extra_attempts,
    "all_retained_case_attempts_qualified": bool(cases) and all(item["complete_qualified_attempt"] for item in cases),
    "nonqualified_attempts_retained": [item["case"] for item in cases if not item["complete_qualified_attempt"]],
    "checks": checks, "errors": errors, "both_generations_have_complete_actual_evidence": qualified_claim,
    "read_member_bytes": read_members,
    "bounds": ["ZIP member modes and local extraction st_mode are never used as runner permission evidence.", "Captured runner metadata is compared before/after; original inode identity is not inferred from downloaded files.", "Whole-cut receipts are checked without opening SQLite or independently recomputing SQL table state.", "Close/reopen occurs inside the recovery child; no third verifier process or physical power-loss claim.", "WAL frames do not prove replay necessity; controlled authority is not production authorization.", "Retry attempts and any nonqualified attempts remain explicit; expected653 never substitutes for the actual test summary."],
    "operations": {"zip_extracted": False, "sqlite_connections": 0, "rust_or_model_executions": 0, "remote_operations": 0, "old_evidence_modified": False},
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"output": str(args.output), "sha256": file_sha(args.output), "checks": len(checks), "failed_checks": sum(not value["passed"] for value in checks), "case_attempts": counts, "qualified_attempts": qualified, "qualified_claim": qualified_claim}))
raise SystemExit(0 if qualified_claim else 1)
