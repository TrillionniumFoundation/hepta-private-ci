# File search matcher continuation: original ca77 leaf

**Source review complete; compilation and Rust tests NOT RUN.** The candidate changes only `codex-rs/file-search/src/lib.rs`. It is byte-exact original ca77 source, including its original regression test. Current root68 and QA leaf73 have the merge-base file byte-exact, so no current implementation or guard is discarded. No dependency, public API, manifest, lock, root worktree or ref was changed.

## Problem and concrete behavior

The session worker calls `nucleo.tick(10)` after query, injection or walk-complete signals. The previous code consumed that timer and depended on a later notification even when the returned status said a matcher was still running. The pinned Nucleo implementation clears `should_notify` at tick entry, arms it after a timed lock failure or before spawning work, and lets the worker read it before invoking the callback. A completion can race that notification arm. Independently, the original regression intentionally supplies a no-op notification callback to the actual Nucleo worker to test the required continuation behavior directly.

The incoming production delta is the tail of the timer branch. When `status.running` is true it sets `will_notify = true` and schedules another tick after the existing 10 ms interval. When false it sets the timer to `never()` and emits completion only if the walk has also finished. This bounds active polling rather than creating an idle busy loop. `QueryUpdated` still reparses and schedules an immediate tick; `NucleoNotify` still avoids duplicating an already scheduled timer; `WalkComplete`, shutdown and the existing cancellation check are unchanged. Snapshot construction, limits, ordering, directory classification, ignore-file policy and sibling cancellation isolation are all byte-exact current code.

## Actual dependency contract inspected

Workspace and lock both bind Nucleo to `4253de9faabb4e5c6d81d946a5e35a90f87347ee`. Its existing local Git checkout was read without modification: HEAD is exact, tracked status clean, and both source files matched their original Git blobs before inspection. Lossless source evidence and hashes are retained.

`src/lib.rs::Status` documents `running` as outstanding background work. `tick` clears notification state, delegates to `tick_inner`, and reports whether matching is still needed. `tick_inner` reports running after a lock timeout and after scheduling additional items. `src/worker.rs::run` checks `should_notify` before invoking the supplied callback in both empty-pattern and matched-pattern paths. No callback wrapper or synthetic matcher is introduced by the original test.

## Original regression and preservation

The original new `matcher_completes_without_a_worker_notification` test primes an empty real matcher until idle, injects one real indexed file without changing the primed pattern, and sends `WalkComplete` with all Nucleo callbacks deliberately disabled. It waits at most five seconds for completion, sends Shutdown and joins the worker before asserting completion, walk-complete state, scanned count 1, match count 1 and the expected relative path. Assertions and fixture are unmodified. This is a source review of the test, not a claim that it has run.

All 16 current library test functions are unchanged. A mechanical whole-file proof removes only the newly added test and restores only the original timer tail; the result is exactly the current/base file. The preservation receipt records every original test name. Existing cancellation, sibling-session, post-walk query updates, no-match completion, streamed snapshots, directory/symlink classification and gitignore assertions remain intact.

## Qualification plan

After final combined source is frozen, run `just test -p codex-file-search --lib --locked --offline` through the original repository runner. This targets the entire original library suite plus the one incoming regression; no external test helper, GPU, network service, added fixture file or new dependency is required. The fixture creates its own files and an in-process Nucleo worker pool. Retain actual case/skip/failure output and source binding. Then perform required scoped final fix/fmt without rerunning unchanged tests. The planned suite is NOT_RUN now.

Pinned Rust 1.96 rustfmt parsed this exact original source and returned identical bytes. Codespell passed with no source or dictionary changes. Those checks establish formatting/spelling only. Native resource use remains unchanged.

## Delivery

`candidate/codex-rs/file-search/src/lib.rs` is the single final postimage. `original` keeps all three source versions; `current-to-candidate.diff` is the complete delta. `source-manifest.json` includes source, retained graph and pinned dependency evidence. The ZIP/MCP frozen candidate directory is untouched. Whole ca77 and all remaining pending sources are still unmerged.
