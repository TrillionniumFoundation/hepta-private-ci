use chrono::Datelike;
use chrono::TimeZone;
use chrono::Utc;
use codex_utils_time::LocalFormat;
use codex_utils_time::Timestamp;
use serde_json::json;

fn main() {
    std::panic::set_hook(Box::new(|_| {}));
    let layouts = [
        LocalFormat::Date,
        LocalFormat::Time,
        LocalFormat::DayMonth,
        LocalFormat::TimeOnDate,
        LocalFormat::MonthDayTime,
        LocalFormat::TwelveHourTime,
        LocalFormat::OrdinalDateTime,
    ];
    let years = [-262143, -10000, -9999, -1, 0, 1, 99, 1800, 1900, 1969, 1970, 2000, 2024, 2025, 2026, 9999, 10000, 262142];
    let mut cases = Vec::new();
    for year in years {
        for month in 1..=12 {
            for day in [1, 2, 3, 11, 12, 13, 21, 22, 23, 28, 31] {
                for hour in [0, 12, 23] {
                    if let Some(value) = Utc.with_ymd_and_hms(year, month, day, hour, 59, 59).single() {
                        for nanos in [0, 1, 1_500_000_000] {
                            cases.push((value.timestamp(), nanos));
                        }
                    }
                }
            }
        }
    }
    for (month, day, hours) in [(3, 10, [6, 7, 8]), (11, 3, [5, 6, 7]), (4, 6, [14, 15, 16]), (10, 5, [14, 15, 16])] {
        for hour in hours {
            for delta in [-1, 0, 1] {
                cases.push((Utc.with_ymd_and_hms(2024, month, day, hour, 0, 0).unwrap().timestamp() + delta, 0));
            }
        }
    }
    cases.extend([
        (chrono::DateTime::<Utc>::MIN_UTC.timestamp(), 0),
        (chrono::DateTime::<Utc>::MAX_UTC.timestamp(), 999_999_999),
        (-1, 999_999_999),
        (0, 0),
        (1, 0),
    ]);
    let mut mismatches = 0;
    for &(seconds, nanos) in &cases {
        let old_utc = chrono::DateTime::<Utc>::from_timestamp(seconds, nanos).unwrap();
        let new_utc = Timestamp::from_timestamp(seconds, nanos).unwrap();
        let old = std::panic::catch_unwind(|| old_utc.with_timezone(&chrono::Local));
        let new = new_utc.try_local();
        let old_wire = serde_json::to_string(&old_utc).unwrap();
        let new_wire = serde_json::to_string(&new_utc).unwrap();
        match (old, new) {
            (Ok(old), Ok(new)) => {
                let day = old.day();
                let suffix = match day {
                    11..=13 => "th",
                    _ => match day % 10 { 1 => "st", 2 => "nd", 3 => "rd", _ => "th" },
                };
                let patterns = [
                    "%Y-%m-%d".to_owned(), "%H:%M".to_owned(), "%-d %b".to_owned(),
                    "%H:%M on %-d %b %Y".to_owned(), "%b %e %H:%M".to_owned(),
                    "%-I:%M %p".to_owned(), format!("%b %-d{suffix}, %Y %-I:%M %p"),
                ];
                let old_formats: Vec<_> = patterns.iter().map(|pattern| old.format(pattern).to_string()).collect();
                let new_formats: Vec<_> = layouts.iter().map(|&layout| new.format(layout)).collect();
                let old_date = std::panic::catch_unwind(|| old.date_naive()).ok().map(|date| (date.year(), date.month(), date.day()));
                let new_date = std::panic::catch_unwind(|| new.date()).ok().map(|date| (date.year(), u32::from(u8::from(date.month())), u32::from(date.day())));
                if old_formats != new_formats || old_date != new_date || old_wire != new_wire {
                    mismatches += 1;
                    println!("{}", json!({"seconds":seconds,"nanos":nanos,"old_formats":old_formats,"new_formats":new_formats,"old_date":old_date,"new_date":new_date,"old_wire":old_wire,"new_wire":new_wire}));
                }
            }
            (Err(_), Err(_)) if old_wire == new_wire => {}
            (old, new) => {
                mismatches += 1;
                println!("{}", json!({"seconds":seconds,"nanos":nanos,"old_query_ok":old.is_ok(),"new_query":format!("{new:?}"),"old_wire":old_wire,"new_wire":new_wire}));
            }
        }
    }
    println!("{}", json!({"summary":true,"cases":cases.len(),"mismatches":mismatches,"layouts_per_case":layouts.len()}));
    if mismatches != 0 { std::process::exit(1); }
}
