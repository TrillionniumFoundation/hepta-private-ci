#[derive(Clone, Copy, Debug)]
enum LocalTimeError {
    Unavailable,
    InvalidOffset,
}

#[path = "overlay/codex-rs/utils/time/src/local_posix_compat.rs"]
mod compatibility;
#[path = "overlay/codex-rs/utils/time/src/local_zone.rs"]
mod zone;

fn fixture(version: u8, standard: Option<u8>, universal: Option<u8>) -> Vec<u8> {
    let mut header = b"TZif".to_vec();
    header.push(version);
    header.extend([0; 15]);
    for count in [u32::from(universal.is_some()), u32::from(standard.is_some()), 0, 0, 1, 4] {
        header.extend(count.to_be_bytes());
    }
    let mut block = header;
    block.extend(3_600_i32.to_be_bytes());
    block.extend([0, 0]);
    block.extend(b"STD\0");
    block.extend(standard);
    block.extend(universal);
    if version == 0 {
        block
    } else {
        let mut result = block.clone();
        result.extend(block);
        result.extend(b"\n\n");
        result
    }
}

fn main() {
    let mut checked = 0;
    for version in [0, b'2', b'3'] {
        for standard in (0..=255).map(Some).chain([None]) {
            for universal in (0..=255).map(Some).chain([None]) {
                let bytes = fixture(version, standard, universal);
                let actual = zone::Zone::tzif(&bytes).ok().and_then(|zone| zone.offset(0).ok());
                let expected = if (standard.unwrap_or(0), universal.unwrap_or(0)) == (0, 1) {
                    None
                } else {
                    Some(3_600)
                };
                assert_eq!(actual, expected, "version={version} standard={standard:?} universal={universal:?}");
                checked += 1;
            }
        }
        let fixture = fixture(version, Some(2), Some(255));
        for length in 0..fixture.len() {
            assert!(zone::Zone::tzif(&fixture[..length]).is_err(), "truncated version={version} length={length}");
            checked += 1;
        }
    }
    println!("checked={checked}; mismatches=0; forbidden_(0,1)_retained=true");
}
