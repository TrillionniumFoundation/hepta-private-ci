from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys

STAGE = Path(__file__).resolve().parent
BASE = Path('/workspace/scratch/0149054cbc33/current-audit/chrono')
DEPS = Path('/workspace/scratch/2f490fb85225/cache-timestamp-validation/target/debug/deps')
RUSTC = Path('/home/agent/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin/rustc')
OUT = STAGE / sys.argv[1]
OUT.mkdir(exist_ok=False)
SOURCE = OUT / 'source'
shutil.copytree(STAGE / 'overlay/codex-rs/utils/time/src', SOURCE)
(OUT / 'build').mkdir()
(OUT / 'fixtures').mkdir()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sources = [{'path': p.relative_to(SOURCE).as_posix(), 'sha256': sha(p)} for p in sorted(SOURCE.rglob('*')) if p.is_file()]
(OUT / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
extern = {name: DEPS / filename for name, filename in {
    'serde':'libserde-c3932525c7ac8ad3.rlib',
    'serde_json':'libserde_json-96724b035ed04bef.rlib',
    'time':'libtime-dc16b3c184a8ae9a.rlib',
    'iana_time_zone':'libiana_time_zone-1e9ae51bcc570c95.rlib',
    'chrono':'libchrono-80dfcadf55c29d25.rlib',
}.items()}
extern['tz'] = BASE / 'tz-source-check-01/libtz.rlib'
(OUT / 'inputs.json').write_text(json.dumps([{'path': str(p), 'sha256': sha(p)} for p in [RUSTC, *extern.values(), STAGE / 'local_projection_oracle.rs']], indent=2) + '\n')
rows = []
def run(name, arguments, zone=None):
    environment = os.environ.copy()
    if zone is not None:
        environment['TZ'] = zone
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run([str(arg) for arg in arguments], env=environment, capture_output=True)
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    row = {'name':name, 'args':[str(arg) for arg in arguments], 'TZ':zone, 'started_utc':start, 'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code':result.returncode, 'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(), 'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
    if name.startswith('zone') and result.stdout:
        row['summary'] = json.loads(result.stdout.decode().splitlines()[-1])
    (OUT / (name + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    rows.append(row)
    print(json.dumps(row), flush=True)
    return result

compile_args = [RUSTC, '--edition=2024', '-C', 'debuginfo=0', '-L', f'dependency={DEPS}', '-L', f'dependency={BASE}/tz-source-check-01']
library = OUT / 'build/libcodex_utils_time.rlib'
arguments = [*compile_args, '--crate-name', 'codex_utils_time', '--crate-type', 'lib', SOURCE / 'lib.rs', '-o', library]
for name in ['serde','time','iana_time_zone','tz']:
    arguments += ['--extern', f'{name}={extern[name]}']
result = run('compile-library', arguments)
if result.returncode:
    print(result.stderr.decode(), flush=True)
    raise SystemExit(result.returncode)
binary = OUT / 'build/oracle'
arguments = [*compile_args, STAGE / 'local_projection_oracle.rs', '--extern', f'codex_utils_time={library}', '-o', binary]
for name in ['chrono','serde_json']:
    arguments += ['--extern', f'{name}={extern[name]}']
result = run('compile-oracle', arguments)
if result.returncode:
    print(result.stderr.decode(), flush=True)
    raise SystemExit(result.returncode)

def tzif(version=b'\0', transitions=(), types=((3600,0,0),), names=b'STD\0', footer=b'', indicators=None):
    indicators = b'' if indicators is None else indicators
    count = len(types) if indicators else 0
    header = b'TZif' + version + b'\0'*15 + struct.pack('>6I',0,count,0,len(transitions),len(types),len(names))
    def block(width):
        times = b''.join(struct.pack('>i' if width == 4 else '>q', instant) for instant, _ in transitions)
        indices = bytes(index for _, index in transitions)
        local = b''.join(struct.pack('>iBB', *value) for value in types)
        return header + times + indices + local + names + indicators
    return block(4) if version == b'\0' else block(4) + block(8) + b'\n' + footer + b'\n'

fixtures = {
    'missing-footer.tzif':tzif(transitions=((0,1),),types=((0,0,0),(3600,0,4)),names=b'UTC\0STD\0'),
    'invalid-offset.tzif':tzif(types=((86400,0,0),)),
    'short-name.tzif':tzif(names=b'AB\0'),
    'inconsistent-posix-footer.tzif':tzif(version=b'2',types=((-18000,0,0),(-14400,1,4)),names=b'EST\0EDT\0',footer=b'EST5EDT,J60/2,60/2'),
    'valid-transition-footer.tzif':tzif(version=b'2',transitions=((0,0),),types=((-18000,0,0),(-14400,1,4)),names=b'EST\0EDT\0',footer=b'EST5EDT,J60/2,60/2'),
    'invalid-transition-footer.tzif':tzif(version=b'2',transitions=((0,1),),types=((-18000,0,0),(-14400,1,4)),names=b'EST\0EDT\0',footer=b'EST5EDT,J60/2,60/2'),
    'legacy-indicator.tzif':tzif(indicators=bytes([2])),
}
for name, data in fixtures.items():
    (OUT / 'fixtures' / name).write_bytes(data)
(OUT / 'fixtures.json').write_text(json.dumps([{'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in fixtures.items()],indent=2)+'\n')
zones = ['Etc/UTC','America/New_York','Europe/Paris','Australia/Lord_Howe','Pacific/Apia','Asia/Kathmandu','','AB-5',':no-such-timezone-file','EST5EDT,M3.2.0,M11.1.0','EST5EDT,J60/2,60/2']
zones += [':' + str(OUT / 'fixtures' / name) for name in fixtures]
for index, zone in enumerate(zones):
    run(f'zone-{index:02}', [binary], zone)
assert all(sha(SOURCE / row['path']) == row['sha256'] for row in sources)
(OUT / 'result.json').write_text(json.dumps({'classification':'fresh Linux differential, not repository package tests or Windows OS execution','source_unchanged':True,'cases':sum(row.get('summary',{}).get('cases',0) for row in rows),'mismatches':sum(row.get('summary',{}).get('mismatches',0) for row in rows),'rows':rows},indent=2)+'\n')
