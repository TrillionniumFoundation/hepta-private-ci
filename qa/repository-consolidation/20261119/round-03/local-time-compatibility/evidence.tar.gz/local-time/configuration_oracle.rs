use chrono::Utc;
use codex_utils_time::LocalFormat;
use codex_utils_time::Timestamp;
use serde_json::json;

fn main() {
    std::panic::set_hook(Box::new(|_| {}));
    let cases = [-1, 0, 1, 1_705_276_800, 1_710_054_000, 1_721_001_600, 1_730_613_600];
    let mut mismatches = 0;
    for seconds in cases {
        let old_utc = chrono::DateTime::<Utc>::from_timestamp(seconds, 0).unwrap();
        let new_utc = Timestamp::from_timestamp(seconds, 0).unwrap();
        let old = std::panic::catch_unwind(|| {
            old_utc.with_timezone(&chrono::Local).format("%Y-%m-%d %H:%M").to_string()
        }).ok();
        let new = new_utc.try_local().ok().map(|local| {
            format!("{} {}", local.format(LocalFormat::Date), local.format(LocalFormat::Time))
        });
        if old != new {
            mismatches += 1;
            println!("{}", json!({"seconds":seconds,"old":old,"new":new}));
        }
    }
    println!("{}", json!({"summary":true,"cases":cases.len(),"mismatches":mismatches}));
    if mismatches != 0 { std::process::exit(1); }
}
