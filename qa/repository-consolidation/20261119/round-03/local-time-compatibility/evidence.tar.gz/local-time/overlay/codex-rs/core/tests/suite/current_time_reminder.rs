use std::sync::Arc;
use std::sync::atomic::AtomicI64;
use std::sync::atomic::AtomicU64;
use std::sync::atomic::Ordering;
use std::time::Duration;

use anyhow::Result;
use anyhow::anyhow;
use codex_core::SleepFuture;
use codex_core::TimeFuture;
use codex_core::TimeProvider;
use codex_core::TurnInputRequest;
use codex_core::config::CurrentTimeReminderConfig;
use codex_features::CurrentTimeReminderDeliveryMode;
use codex_features::CurrentTimeSource;
use codex_features::Feature;
use codex_model_provider_info::built_in_model_providers;
use codex_protocol::ThreadId;
use codex_protocol::models::PermissionProfile;
use codex_protocol::protocol::CodexErrorInfo;
use codex_protocol::protocol::EventMsg;
use codex_protocol::protocol::Op;
use codex_protocol::user_input::UserInput;
use core_test_support::assert_regex_match;
use core_test_support::responses::ResponsesRequest;
use core_test_support::responses::ev_assistant_message;
use core_test_support::responses::ev_completed;
use core_test_support::responses::ev_function_call;
use core_test_support::responses::ev_function_call_with_namespace;
use core_test_support::responses::ev_response_created;
use core_test_support::responses::mount_sse_once;
use core_test_support::responses::mount_sse_sequence;
use core_test_support::responses::sse;
use core_test_support::responses::start_mock_server;
use core_test_support::skip_if_no_network;
use core_test_support::test_codex::test_codex;
use core_test_support::wait_for_event;
use pretty_assertions::assert_eq;
use serde_json::json;

const FIRST_REMINDER: &str =
    "<current_time_reminder>It is 2026-06-17 17:34:15 UTC.</current_time_reminder>";
const EARLIER_REMINDER: &str =
    "<current_time_reminder>It is 2026-06-17 17:33:15 UTC.</current_time_reminder>";
const SECOND_REMINDER: &str =
    "<current_time_reminder>It is 2026-06-17 17:35:15 UTC.</current_time_reminder>";
const THIRD_REMINDER: &str =
    "<current_time_reminder>It is 2026-06-17 17:36:15 UTC.</current_time_reminder>";
const FIRST_TIME_UNIX_SECONDS: i64 = 1_781_717_655;

struct TestTimeProvider {
    current_time: AtomicI64,
    sleep_seconds: AtomicU64,
}

impl Default for TestTimeProvider {
    fn default() -> Self {
        Self {
            current_time: AtomicI64::new(FIRST_TIME_UNIX_SECONDS),
            sleep_seconds: AtomicU64::new(0),
        }
    }
}

impl TimeProvider for TestTimeProvider {
    fn current_time(&self, _thread_id: ThreadId) -> TimeFuture<'_> {
        let timestamp = self.current_time.fetch_add(60, Ordering::Relaxed);
        Box::pin(async move {
            Ok(
                codex_utils_time::Timestamp::from_timestamp(timestamp, /*nanoseconds*/ 0)
                    .expect("test timestamp should be valid"),
            )
        })
    }

    fn sleep(&self, _thread_id: ThreadId, duration: Duration) -> SleepFuture<'_> {
        self.sleep_seconds
            .store(duration.as_secs(), Ordering::Relaxed);
        Box::pin(async { Ok(()) })
    }
}

struct FailingTimeProvider;

impl TimeProvider for FailingTimeProvider {
    fn current_time(&self, _thread_id: ThreadId) -> TimeFuture<'_> {
        Box::pin(async { Err(anyhow!("test clock unavailable")) })
    }

    fn sleep(&self, _thread_id: ThreadId, _duration: Duration) -> SleepFuture<'_> {
        Box::pin(async { Err(anyhow!("test clock unavailable")) })
    }
}

fn current_time_reminders(request: &ResponsesRequest) -> Vec<String> {
    request
        .message_input_texts("developer")
        .into_iter()
        .filter(|text| text.starts_with("<current_time_reminder>"))
        .collect()
}

fn enable_current_time_reminder(
    config: &mut codex_core::config::Config,
    interval: u64,
    clock_source: CurrentTimeSource,
) {
    config.include_environment_context = false;
    config
        .features
        .enable(Feature::CurrentTimeReminder)
        .expect("test config should allow current-time reminders");
    config.current_time_reminder = Some(CurrentTimeReminderConfig {
        reminder_interval_seconds: interval,
        clock_source,
        ..CurrentTimeReminderConfig::default()
    });
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn environment_context_uses_external_current_time_on_each_turn() -> Result<()> {
    skip_if_no_network!(Ok(()));

    let server = start_mock_server().await;
    let responses = mount_sse_sequence(
        &server,
        vec![
            sse(vec![ev_response_created("resp-1"), ev_completed("resp-1")]),
            sse(vec![ev_response_created("resp-2"), ev_completed("resp-2")]),
        ],
    )
    .await;
    let time_provider = Arc::new(TestTimeProvider::default());
    let test = test_codex()
        .with_config(|config| {
            enable_current_time_reminder(config, /*interval*/ 0, CurrentTimeSource::External);
            config.include_environment_context = true;
        })
        .with_external_time_provider(time_provider.clone())
        .build_with_auto_env(&server)
        .await?;

    test.submit_turn("first simulated day").await?;
    time_provider
        .current_time
        .store(FIRST_TIME_UNIX_SECONDS + 86_400, Ordering::Relaxed);
    test.submit_turn("second simulated day").await?;

    let requests = responses.requests();
    assert_eq!(requests.len(), 2);
    for (request, timestamp) in requests
        .iter()
        .zip([FIRST_TIME_UNIX_SECONDS, FIRST_TIME_UNIX_SECONDS + 86_400])
    {
        assert!(request.has_content_kinds(&["environments.environment_context"]));
        let current_date =
            codex_utils_time::Timestamp::from_timestamp(timestamp, /*nanoseconds*/ 0)
                .expect("test timestamp should be valid")
                .format_local(codex_utils_time::LocalFormat::Date);
        assert!(request.message_input_texts("user").iter().any(|text| {
            text.contains("<environment_context>")
                && text.contains(&format!("<current_date>{current_date}</current_date>"))
        }));
    }
    assert_eq!(current_time_reminders(&requests[0]), vec![SECOND_REMINDER]);

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn current_time_reminders_follow_time_interval_and_persist_in_history() -> Result<()> {
    skip_if_no_network!(Ok(()));

    let server = start_mock_server().await;
    let tool_args = json!({
        "cmd": "echo current time",
        "yield_time_ms": 1_000,
    });
    let responses = mount_sse_sequence(
        &server,
        vec![
            sse(vec![
                ev_response_created("resp-1"),
                ev_function_call(
                    "current-time-tool-call",
                    "exec_command",
                    &serde_json::to_string(&tool_args)?,
                ),
                ev_completed("resp-1"),
            ]),
            sse(vec![
                ev_response_created("resp-2"),
                ev_assistant_message("msg-2", "done"),
                ev_completed("resp-2"),
            ]),
            sse(vec![ev_response_created("resp-3"), ev_completed("resp-3")]),
        ],
    )
    .await;
    let test = test_codex()
        .with_config(|config| {
            enable_current_time_reminder(config, /*interval*/ 120, CurrentTimeSource::External)
        })
        .with_external_time_provider(Arc::new(TestTimeProvider::default()))
        .build(&server)
        .await?;

    test.submit_turn_with_permission_profile("first turn", PermissionProfile::Disabled)
        .await?;
    test.submit_turn("second turn").await?;

    let requests = responses.requests();
    assert_eq!(requests.len(), 3);
    assert_eq!(current_time_reminders(&requests[0]), vec![FIRST_REMINDER]);
    assert_eq!(current_time_reminders(&requests[1]), vec![FIRST_REMINDER]);
    assert_eq!(
        current_time_reminders(&requests[2]),
        vec![FIRST_REMINDER, THIRD_REMINDER]
    );
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn zero_current_time_reminder_interval_delivers_when_time_moves_backward() -> Result<()> {
    skip_if_no_network!(Ok(()));

    let server = start_mock_server().await;
    let responses = mount_sse_sequence(
        &server,
        vec![
            sse(vec![ev_response_created("resp-1"), ev_completed("resp-1")]),
            sse(vec![ev_response_created("resp-2"), ev_completed("resp-2")]),
        ],
    )
    .await;
    let time_provider = Arc::new(TestTimeProvider::default());
    let test = test_codex()
        .with_config(|config| {
            enable_current_time_reminder(config, /*interval*/ 0, CurrentTimeSource::External)
        })
        .with_external_time_provider(time_provider.clone())
        .build(&server)
        .await?;

    test.submit_turn("first turn").await?;
    time_provider
        .current_time
        .store(FIRST_TIME_UNIX_SECONDS - 60, Ordering::Relaxed);
    test.submit_turn("second turn").await?;

    let requests = responses.requests();
    assert_eq!(requests.len(), 2);
    assert_eq!(current_time_reminders(&requests[0]), vec![FIRST_REMINDER]);
    assert_eq!(
        current_time_reminders(&requests[1]),
        vec![FIRST_REMINDER, EARLIER_REMINDER]
    );
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn current_time_reminders_can_follow_only_user_or_tool_outputs() -> Result<()> {
    skip_if_no_network!(Ok(()));

    let server = start_mock_server().await;
    let tool_args = json!({
        "cmd": "echo current time",
        "yield_time_ms": 1_000,
    });
    let mut continue_response = ev_completed("resp-2");
    // Ask for another inference without recording a new user message or tool output.
    continue_response["response"]["end_turn"] = json!(false);
    let responses = mount_sse_sequence(
        &server,
        vec![
            sse(vec![
                ev_response_created("resp-1"),
                ev_function_call(
                    "current-time-tool-call",
                    "exec_command",
                    &serde_json::to_string(&tool_args)?,
                ),
                ev_completed("resp-1"),
            ]),
            sse(vec![
                ev_response_created("resp-2"),
                ev_assistant_message("msg-2", "continue"),
                continue_response,
            ]),
            sse(vec![ev_response_created("resp-3"), ev_completed("resp-3")]),
        ],
    )
    .await;
    let test = test_codex()
        .with_config(|config| {
            enable_current_time_reminder(config, /*interval*/ 0, CurrentTimeSource::External);
            config
                .current_time_reminder
                .as_mut()
                .expect("current-time reminder should be configured")
                .delivery_mode = CurrentTimeReminderDeliveryMode::AfterUserOrToolOutput;
        })
        .with_external_time_provider(Arc::new(TestTimeProvider::default()))
        .build(&server)
        .await?;

    test.submit_turn_with_permission_profile("first turn", PermissionProfile::Disabled)
        .await?;

    let requests = responses.requests();
    assert_eq!(requests.len(), 3);
    assert_eq!(current_time_reminders(&requests[0]), vec![FIRST_REMINDER]);
    assert_eq!(
        current_time_reminders(&requests[1]),
        vec![FIRST_REMINDER, SECOND_REMINDER]
    );
    assert_eq!(
        current_time_reminders(&requests[2]),
        vec![FIRST_REMINDER, SECOND_REMINDER]
    );
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn system_time_source_adds_current_time_reminder() -> Result<()> {
    skip_if_no_network!(Ok(()));

    let server = start_mock_server().await;
    let responses = mount_sse_once(
        &server,
        sse(vec![ev_response_created("resp-1"), ev_completed("resp-1")]),
    )
    .await;
    let test = test_codex()
        .with_config(|config| {
            enable_current_time_reminder(config, /*interval*/ 1, CurrentTimeSource::System)
        })
        .build(&server)
        .await?;

    test.submit_turn("what time is it?").await?;

    let request = responses.single_request();
    assert!(request.has_content_kinds(&["current_time.reminder"]));
    let reminders = current_time_reminders(&request);
    assert_eq!(reminders.len(), 1);
    assert_regex_match(
        r"^<current_time_reminder>It is \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} UTC\.</current_time_reminder>$",
        &reminders[0],
    );

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn current_time_reminder_is_refreshed_after_compaction() -> Result<()> {
    skip_if_no_network!(Ok(()));

    let server = start_mock_server().await;
    let responses = mount_sse_sequence(
        &server,
        vec![
            sse(vec![ev_response_created("resp-1"), ev_completed("resp-1")]),
            sse(vec![
                ev_response_created("resp-compact"),
                ev_assistant_message("msg-compact", "compact summary"),
                ev_completed("resp-compact"),
            ]),
            sse(vec![ev_response_created("resp-2"), ev_completed("resp-2")]),
        ],
    )
    .await;
    let mut model_provider = built_in_model_providers(/*openai_base_url*/ None)["openai"].clone();
    model_provider.name = "OpenAI-compatible test provider".to_string();
    model_provider.base_url = Some(format!("{}/v1", server.uri()));
    model_provider.supports_websockets = false;
    let test = test_codex()
        .with_config(move |config| {
            config.model_provider = model_provider;
            enable_current_time_reminder(
                config,
                /*interval*/ 3_000,
                CurrentTimeSource::External,
            );
            config
                .current_time_reminder
                .as_mut()
                .expect("current-time reminder should be configured")
                .delivery_mode = CurrentTimeReminderDeliveryMode::AfterUserOrToolOutput;
        })
        .with_external_time_provider(Arc::new(TestTimeProvider::default()))
        .build(&server)
        .await?;

    test.submit_turn("before compact").await?;
    test.codex.submit(Op::Compact).await?;
    wait_for_event(&test.codex, |event| {
        matches!(event, EventMsg::TurnComplete(_))
    })
    .await;
    test.submit_turn("after compact").await?;

    let requests = responses.requests();
    assert_eq!(requests.len(), 3);
    assert_eq!(
        current_time_reminders(&requests[2]),
        vec![SECOND_REMINDER],
        "a new context window should force a fresh reminder before the next model request"
    );

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn time_provider_failure_stops_before_inference() -> Result<()> {
    skip_if_no_network!(Ok(()));

    let server = start_mock_server().await;
    let responses = mount_sse_once(
        &server,
        sse(vec![
            ev_response_created("unused-response"),
            ev_completed("unused-response"),
        ]),
    )
    .await;
    let test = test_codex()
        .with_config(|config| {
            enable_current_time_reminder(config, /*interval*/ 1, CurrentTimeSource::External);
            config.include_environment_context = true;
        })
        .with_external_time_provider(Arc::new(FailingTimeProvider))
        .build_with_auto_env(&server)
        .await?;

    test.codex
        .start_or_steer_turn(TurnInputRequest::user_input(vec![UserInput::Text {
            text: "fail before inference".into(),
            text_elements: Vec::new(),
        }]))
        .await?;

    let EventMsg::Error(error) =
        wait_for_event(&test.codex, |event| matches!(event, EventMsg::Error(_))).await
    else {
        unreachable!();
    };
    assert_eq!(
        error.message,
        "Fatal error: failed to read current time: test clock unavailable"
    );
    assert_eq!(error.codex_error_info, Some(CodexErrorInfo::Other));

    wait_for_event(&test.codex, |event| {
        matches!(event, EventMsg::TurnComplete(_))
    })
    .await;
    assert!(responses.requests().is_empty());

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn current_time_tool_returns_the_latest_time() -> Result<()> {
    skip_if_no_network!(Ok(()));

    const CALL_ID: &str = "current-time";

    let server = start_mock_server().await;
    let responses = mount_sse_sequence(
        &server,
        vec![
            sse(vec![
                ev_response_created("resp-1"),
                ev_function_call_with_namespace(CALL_ID, "clock", "curr_time", "{}"),
                ev_completed("resp-1"),
            ]),
            sse(vec![ev_response_created("resp-2"), ev_completed("resp-2")]),
        ],
    )
    .await;
    let test = test_codex()
        .with_config(|config| {
            enable_current_time_reminder(
                config,
                /*interval*/ 3_000,
                CurrentTimeSource::External,
            )
        })
        .with_external_time_provider(Arc::new(TestTimeProvider::default()))
        .build(&server)
        .await?;

    test.submit_turn("check the current time").await?;

    let requests = responses.requests();
    assert!(
        requests[0].tool_by_name("clock", "curr_time").is_some(),
        "clock.curr_time should be exposed when current-time reminders are enabled"
    );
    assert_eq!(
        requests[1].function_call_output_text(CALL_ID),
        Some("It is 2026-06-17 17:35:15 UTC.".to_string())
    );

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn sleep_tool_uses_configured_time_provider() -> Result<()> {
    skip_if_no_network!(Ok(()));

    const CALL_ID: &str = "sleep";
    const DURATION_MS: u64 = 12 * 60 * 60 * 1000;

    let server = start_mock_server().await;
    let responses = mount_sse_sequence(
        &server,
        vec![
            sse(vec![
                ev_response_created("resp-1"),
                ev_function_call_with_namespace(
                    CALL_ID,
                    "clock",
                    "sleep",
                    &json!({ "duration_ms": DURATION_MS }).to_string(),
                ),
                ev_completed("resp-1"),
            ]),
            sse(vec![
                ev_response_created("resp-2"),
                ev_assistant_message("msg-2", "done"),
                ev_completed("resp-2"),
            ]),
        ],
    )
    .await;
    let time_provider = Arc::new(TestTimeProvider::default());
    let test = test_codex()
        .with_config(|config| {
            enable_current_time_reminder(
                config,
                /*interval*/ 3_000,
                CurrentTimeSource::External,
            );
            config
                .current_time_reminder
                .as_mut()
                .expect("current-time reminder config should be present")
                .sleep_tool = true;
        })
        .with_external_time_provider(time_provider.clone())
        .build(&server)
        .await?;

    test.submit_turn("sleep").await?;

    assert_eq!(
        time_provider.sleep_seconds.load(Ordering::Relaxed),
        DURATION_MS / 1_000
    );
    let requests = responses.requests();
    assert_eq!(requests.len(), 2);
    assert!(
        requests[1]
            .function_call_output_text(CALL_ID)
            .is_some_and(|output| output.ends_with("Sleep completed."))
    );

    Ok(())
}
