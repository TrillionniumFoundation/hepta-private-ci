## Rust consolidation continuation — 2026-11-19

Current published candidate: `8047312e93277de56726d5535f02bbbf7c985572`. Main remains `732e934ba496d90fbe042b8d41d479ef901643e5`; required acceptance and branch retirement remain pending.

The fresh complete census contains 7,635 heads: main, 7,241 ordinary branches, and 393 protected HIA branches. Protection includes unnamed descendants and retained historical names. The cleanup tool now protects newly named HIA branches even before their names enter the manifest. No HIA ref was updated or deleted.

This stage retains the original merge parents for the bimodal semantic delivery gate and the HOS2 history-only successor. It also ports the existing ordinary Windows authenticated owner-local transport and connects Agentd to it, with bounded handshakes and the original request deadline. Unix authentication and fail-closed Windows sandbox admission remain in place. The independent Windows fixture mutex now permits later tests to report their own outcome after an earlier test panic.

Validation: 18 branch-retirement regressions and 18 semantic-gate regressions passed; Linux and Windows-GNU all-targets UDS compilation passed. Native UDS execution in this restricted container had 7 passes and 5 socket-permission failures, including inherited tests; native host/Windows qualification is pending. Canonical joint Bazel lock regeneration and Cargo advisory closure are pending. The larger Windows-history merge and the remaining ordinary frontier are still under semantic review.

All six published commit trees and ordered parent lists were independently read back before the integration ref advanced with an expected-head lease.

---

## Current review checkpoint — 2026-11-18 (`38351c4`)

The integration branch now points to `38351c487b286c86ce5d54e7d20bac364a1819da`. This checkpoint adds **11 genuine ordinary-history merges**, the diagnostic/handoff repair, and the audit/format follow-up. All **13 published trees and ordered parent lists** were read back and matched the local normal-merge sequence. Connector-assigned commit metadata changes commit IDs; the reviewed file trees are identical.

The captured census has **7,615 branches: 7,225 ordinary, 389 protected HIA, and main**. Candidate ancestry covers **2,083 ordinary branch tips**, with **5,142 still pending**. The differently named chrono/OTEL joint branch is protected by HIA ancestry. A fresh pre-publication ref read found only external tip advances; main and the integration lease were unchanged.

The collector regression suite passed **9 tests**, bounded host diagnostics **6**, and real CPU Torch 2.8.0 continuation **9**. Final candidate blob-size and checkpoint spelling checks passed. The four native Agentd handoff tests and unchanged NextUse diagnostic remain pending: disk, SIGKILL during compilation, and a later ROG execution-permission failure occurred before test bodies ran. These are not passing results.

The separate large Windows merge is still under source, caller-contract, dependency and native-platform review and is **not included** here. Its results must not qualify this candidate. The required CI and Architecture checks must qualify the exact final source and prospective base merge before main is updated. **No branch has been deleted and no HIA ref has been changed by this work.**

Evidence: [round-01 audit and full captured ref census](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/38351c487b286c86ce5d54e7d20bac364a1819da/qa/repository-consolidation/20261119/round-01). Historical notes below retain their original source and validation scope.

---

## Current integration head: Windows diagnostic registration corrected

Current head: `36b3560de2bee1c05acb18ca6f53dbe9d69fd2eb`; tree: `e948b04b892c59ac644eecb752a9c2fabad0162c`; sole parent: `e2c3adbf1098b4a62e46a44376f0b4b0e836eb66`.

The first diagnostic run, [44353316661](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/44353316661), failed GitHub workflow registration because the job-level environment referenced the unavailable runner context. It had **zero jobs and zero native test executions**. The original static checks missed this context-availability rule; the complete original hosted page, API records and annotation remain preserved.

The three-hunk correction initializes the same absolute evidence directory in a valid step environment and exports it through GITHUB_ENV. Always-running collection and upload address the same path independently of bootstrap success. The original Rust source, exact target/case, single invocation, 250ms budget, assertions and collector are unchanged. All prior executable Bash/Python blocks remain byte-identical. New context/bootstrap validation, original-config Codespell/Prettier, independent review and real scoped native just fmt pass; no tests ran after maintenance.

The full 44-member correction evidence archive, independently checked member-by-member, is in `qa/repository-consolidation/20261118/windows-memory-diagnostic-a28/registration-fix/`. **The first real Windows baseline has now executed once: the original case passed, while the workflow itself failed during evidence collection.** [Run 44357445360](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/44357445360), attempt 1, job `134989280751`, checked out this exact 36b head. The original unchanged case reported 1 passed, 0 failed, 0 ignored, 99 filtered, in 0.10 seconds; Bazel and complete log capture both exited 0, with no retry and the original 250ms budget.

The collector counted the Windows wrapper's direct `test.xml.log` output copy as an additional execution log. Its 209 bytes exactly match the suffix of the 360-byte primary log; the original XML contains one successful case and the primary stdout. The artifact also omitted four hidden source copies because hidden-file upload was not enabled. Both original ZIPs and their hashes remain the baseline evidence; the missing members and failed workflow conclusion are not relabeled as complete or successful. A minimal collector/upload correction is under review and has not yet changed the branch.

**This isolated native PASS does not establish the cause of, or a production repair for, the earlier concurrent Windows Memory failure.** Required CI and Architecture checks remain incomplete. This checkpoint adds no branch ancestry. Main remains `732e934ba496d90fbe042b8d41d479ef901643e5`; no protected HIA ref or branch deletion was performed.

---

## Previous diagnostic checkpoint (2026-11-18)

Current integration head: `e2c3adbf1098b4a62e46a44376f0b4b0e836eb66`; exact tree: `103963d3e1cd827f9b551d36b4cb02a77eab5fc3`. Its only parent is `9a96facdfb878162bb0427b5313fd53a6996a5d4`.

This checkpoint adds the independent path-filtered Windows Memory baseline workflow and complete review records. It makes no production Rust change and preserves every existing workflow and both required aggregates. The exact original recovery case runs once through the existing MSVC Bazel wrapper, with the unchanged 250ms production budget and assertions. The raw source, command, platform, exit, test log and original XML are retained; missing/skipped/duplicate/retried/cached or failing case evidence cannot pass the collector. **The native Windows baseline result is pending. An isolated pass would not prove the original concurrent failure repaired.**

The original eight terminal Windows failures, including seven Agentd control-peer rejections and the Memory assertion failure, remain preserved with both complete native job logs. The independent static Memory review does not infer a unique timing cause or an uncommitted release from the retained active handle. It documents the need to distinguish a returned finalization error, timeout, and a transaction that commits after its acknowledgement receiver is cancelled.

All four complete evidence archives and their byte/member verification are in `qa/repository-consolidation/20261118/windows-memory-diagnostic-a28/`. The diagnostic's 17 receipt and four pipeline controls passed before maintenance; original-config Prettier/Codespell and the real scoped native `just fmt` passed with unchanged source. These are not native Windows Rust results. No tests were rerun after maintenance.

The retained 16:19:41 UTC census has 7,595 refs: 7,224 ordinary branches, 370 protected HIA branches, and main. The published parent contains 40,872 complete ancestor records with no protected-tip/root/anchor intersection; this single-parent checkpoint imports no additional branch ancestry. Ordinary coverage remains 2,070 branch names at that census. Only the existing integration ref was advanced with an expected-head lease. No main update, protected-ref write, or branch deletion has occurred. The earlier sections below retain their original source-specific qualification boundaries.

---

## Previous qualified source checkpoint: accepted handoff, fixture repair, and six ordinary histories

Published head: `9a96facdfb878162bb0427b5313fd53a6996a5d4`; tree `c7466f82606d312551a1266b131ad5e28e71e4ab`. GitHub readback confirms the exact final tree and the complete five-merge history chain. The final checkpoint has one parent, `bcf2dfbadba8f6a3e04869c91b89f731da8740d5`; that chain starts at the previously published `770179d`.

### Behavior and original history retained

- Learning owner work now continues after a response waiter disappears once a submission is durably accepted and queued. Existing cancellation, authority, deadline, checkpoint and reconciliation fences remain. Both ready-cancellation selection points keep explicit priority.
- The four incoming learning regressions use the current Result-returning fixtures without weakening assertions. The control run fails all four on the old production implementation; the repaired component passes **165/165 selected cases**, with zero retries. The complete caller verifier passes **7,874 Rust files / 1,645 boundaries / 820 protected boundaries**.
- Subsequent `just fix --offline --locked -p codex-hepta-agentd` and `just fmt` both pass. All **1,622 package Rust files** and all five caller/dependency manifests remain byte-identical. No tests were rerun after maintenance.
- The structured-input fixture uses the same explicit loopback HTTP provider for the manager and thread. A controlled delayed WebSocket upgrade fails at the original five-second assertion; the corrected fixture passes under that trap and in its clean original case without retries. Typed inputs, full equality, submission, shutdown and the deadline are unchanged. This establishes a fixture risk, not a unique explanation of the earlier Intel retry-recovered flaky result.
- AuthBus and both Fleet histories were reconciled through ordinary three-way merges with every conflict and automatic return-style edit reviewed. Their incoming behavior is already represented by current source. These history merges preserve the complete source bytes, including the verified clock and negative authorization assertions.
- All **39 historical d5af evidence files** remain byte-for-byte originals after content, execution-entry and existing quality-rule review. No archived request or driver was executed. Original failures and incomplete results stay explicit.

The original incoming parents are `60eb1a36`, `0e378dd3`, `307dced9`, `d5af612c`, and `7fd4b93c`. They cover six newly incorporated ordinary branch names, including the earlier Fleet authority commit. No conflict-preference strategy or unreviewed parent attachment was used. The larger `21df047` evidence candidate is still under separate review and is not attached.

### Boundary and remaining gates

The fully classified **15:56:37 UTC** census contains **7,593 branches = 7,224 ordinary + 368 protected HIA + main**. This candidate covers **2,070 ordinary names**, leaving **5,154** outside its ancestry. The complete 40,871-node local history proof has no missing parents and excludes all protected tips, both HIA roots and the established descendant anchor.

The immediate pre-write read at **16:19:41 UTC** saw 7,595 refs. Both newly added tips were independently excluded from the candidate; all 368 known protected names were rechecked at their current live tips and excluded. All six incoming ordinary branch tips were unchanged. Only the existing integration ref was advanced with an expected-old-SHA check and `force=false`.

**Main remains `732e934ba496d90fbe042b8d41d479ef901643e5`. No branch was deleted, and no HIA ref was written.** Required `CI required` and `Architecture required` checks must qualify this exact assembled head and prospective base merge before main merge or cleanup. The prior dependency-policy failure and Windows Agentd/Memory failures are not claimed repaired by this batch; macOS jobs that never acquired a hosted runner are recorded as infrastructure cancellations.

[Integration and native qualification record](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/9a96facdfb878162bb0427b5313fd53a6996a5d4/qa/repository-consolidation/20261118/rust-integration-a28) · [Latest protected-boundary evidence](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/9a96facdfb878162bb0427b5313fd53a6996a5d4/qa/repository-consolidation/20261118/branch-boundary-a28) · [Learning evidence](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/9a96facdfb878162bb0427b5313fd53a6996a5d4/qa/repository-consolidation/20261118/rust-learning-a28) · [Structured-input control and qualification](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/9a96facdfb878162bb0427b5313fd53a6996a5d4/qa/repository-consolidation/20261118/rust-structured-input-a28)

Earlier checkpoint notes below retain the original qualification history.

---

## Current checkpoint: Guardian fixtures and PTY draining

`770179d123b879355b53db1d75f8f9f301280d3e` is a single-parent follow-up to `342b284c1514da3d3d8b6451b6bd3fb6edfc783a`. GitHub readback confirms tree `6911d7b83a7d2ae573efb4fbe08446f748a7a3a4` and that exact parent.

- Guardian network fixtures route responses by request identity and release the parent final response only after the original execution ends. The diagnostic control fails at the original assertion; both corrected timing cases pass with the original ten-second total budget.
- Guardian multimodal registration now lists the same sixteen distinct cases once each, instead of twice. All sixteen pass without retries; parameter vectors, test body, image/privacy assertions, and time limit are unchanged.
- The PTY reader keeps draining after receiver closure while avoiding message allocation and futile sends. The original thirty-case suite passes both before and after the patch on ARM macOS; this does not establish repair of the original Intel failure or a measured speedup.
- Native maintenance completed after testing. Independent review verifies all three source postimages and all 63 Core plus 37 PTY archive members, including the original failures. Evidence: [`rust-ci-a28`](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/770179d123b879355b53db1d75f8f9f301280d3e/qa/repository-consolidation/20261118/rust-ci-a28).
- Corrected historical CI classification: Intel Core structured-input recovered on retry and finished flaky. PTY was the terminal Intel target failure. The structured-input cause remains under investigation.
- No additional branch parent is attached by this small PTY repair. Ordinary-branch ancestry coverage and protected HIA exclusions are unchanged by this follow-up. Required checks for this exact head remain mandatory before main merge or any branch deletion.

Earlier checkpoint notes below retain the original qualification history.

---
## 2026-11-18: Notes deadline merge and required-check repairs

Published candidate: `342b284c1514da3d3d8b6451b6bd3fb6edfc783a`; tree `1acf986408ad7d197875f0d549427835275b49e6`. The server tree exactly matches the reviewed local index. This is a real merge with parents `a91102d3639a5a1f02394bfc0331611e9ab101a1` and `59d05538c9a2be1d1240e328648935832fac7cf4`.

- Merged the ordinary Notes deadline history. Both new late-ready regressions fail on the original implementation; the real merge passes **126/126 selected Notes cases**, with 1,576 other cases outside the explicit filter and zero retries. The complete caller verifier passes **7,873 Rust files / 1,645 boundaries / 820 protected files**.
- Repaired the stale replay source checks, retaining their refusal conditions and adding two negative cases. The complete original B4 command passes **1,347 tests**, with no failures, errors, or skips, on its recorded source snapshot.
- Added the missing Bazel optimization annotation for the actual `sha2 0.10.9` digest backend. The actual compiler action ends at optimization level 3. Canonical lock generation succeeds without changing the lock, and the original Types/Evaluation targets pass **70 + 228 top-level cases**. The original 500 ms NextUse deadline remains unchanged and still requires its own new hosted result.
- All required formatting completed after testing with tested source bytes unchanged. The final independent review verifies all **64 outer evidence members, 22 nested native members, and 8 complete inventory carriers**. Original failures and the metadata-reader interruption remain preserved.

Latest audited census: **7,581 names = 7,224 ordinary + 356 protected HIA/Cell + main**. The candidate ancestry covers **2,064 ordinary names**, including the two Notes/desktop names newly incorporated here; **5,160 ordinary names remain outside it**. Seven of nine newly observed names are proved HIA descendants; the other two ordinary owner branches remain queued for source review.

Main remains `732e934ba496d90fbe042b8d41d479ef901643e5`. No branch deletion is yet eligible from that main. New exact-head hosted checks are starting; prior passes do not qualify this candidate. Windows, dependency policy, remaining platform cases, and the outstanding ordinary frontiers remain open. The independently validated Guardian fixture repairs are a separate following change and are not included here.

[Source, validation, and custody report](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/342b284c1514da3d3d8b6451b6bd3fb6edfc783a/qa/repository-consolidation/20261118/rust-main-a28).

---

## Unpublished candidate recovery checkpoint

The published integration head remains `6c6cf2f0aa296fb27d2e120a648dd961b79f9d9b`; `main` remains `732e934ba496d90fbe042b8d41d479ef901643e5`. No main merge or branch deletion has occurred. HIA/Cell protected refs have not been written.

The local workspace became unavailable and returned as a new empty scratch filesystem. The unpublished partial joint trees (`51a165a`, `83b0f743`, `5acc7035`) are not claimed to be remotely retained or qualified. Their source overlays must be reconstructed and checked before further publication. The incoming `6cfa2345cc26e271d443d32e3fff669f7492d1bc` parent has **not** been attached.

Durable native work remains on the configured ROG host, with original source commits and complete logs:

- Cloud-config Stage6: 37/37 package tests, zero skips/retries; 489,600 legacy-parser comparisons, 48 historical cache vectors and 81 ordering pairs. The final seven source postimages and single chrono→time internal dependency edge were verified before the workspace reset; canonical joint lock generation remains pending.
- NDU and linked packages: source `34f1b615efd31e246e46c540f4d7d2ae6fd798a9`, tree `4498fde67adab447de107663499df668b33253ce`, job `1a1ed540f7a-392-4760`: 1,080 passed across NDU/retrieval/memory/cognitive/types/extension; 16 original ignored cases remain explicitly recorded. Two real failing audit counterexamples (revocation-frontier relabeling and holdout-dependent early stopping) were retained before their narrow fixes. Maintenance/combined-workspace qualification is separate.
- Pure replay memo: source `9829dd5d489191caa5aa50bcaa94b4db8809351e`, job `1a1ed58f196-392-4779`: 273 passed, two existing ignored subprocess entry points explicitly invoked by parent tests. Six new physical-file invalidation/refusal cases are included. This does **not** prove the original Agentd NextUse 500 ms deadline is fixed; its exact joint-source regression is pending.
- Official ZIP/YAML vendor archives and original license bytes were verified. ZIP 9.1.3 has 37 formatting-only Rust changes; serde-saphyr 2.0.0 has 205 formatting-only Rust changes plus two explicitly reviewed compatibility modules. The workspace requirement must pin serde-saphyr to `=2.0.0` before fresh canonical resolution.

Recovery is using pinned published commits and retained native source, not an ancestry-only merge. The first explicit-single-base reconstruction produced a different raw tree and was rejected as an exact recovery; complete ancestry and merge-base checks are in progress. Remaining gates include complete source/QA reconstruction, canonical Cargo/Bazel locks, joint native regression, actual Windows qualification, all required hosted checks, and the remaining ordinary frontiers. Branch cleanup requires a fresh protected-ref census and exact-tip reachability from successfully merged main.

---

## Purpose

Consolidate ordinary Rust histories into one main branch, resolve source conflicts and qualify the resulting repository. Preserve every new HIA/Cell branch and its current work.

## Current published candidate

- Candidate: `6c6cf2f0aa296fb27d2e120a648dd961b79f9d9b`.
- Main: `732e934ba496d90fbe042b8d41d479ef901643e5`.
- Complete branch census: **7,498 names = 7,239 ordinary + 258 protected HIA/Cell + main**.
- Candidate ancestry covers **2,059 ordinary names**; **5,180 remain pending**.
- All **265 historical/current protected pins** and both established HIA lineage markers remain excluded.
- Main has not been moved and no branch has been deleted in this continuation.

The four new `codex/cell-research-*` branches are protected using their actual PR changes and ancestry. Their names alone would not identify the HIA stack.

[Round 06 native repairs and dependency migrations](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/6c6cf2f0aa296fb27d2e120a648dd961b79f9d9b/qa/repository-consolidation/20261118/round-06/README.md) · [Round 05 additive histories and custody repair](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/b373b72709c2c5bea0d4e751f922cf98af966f8c/qa/repository-consolidation/20261118/round-05/README.md) · [Round 04 audit and formatter repair](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/dafb60d0ccad1280381ce1ec97aa4f3b9febc425/qa/repository-consolidation/20261118/round-04/README.md) · [Protected branch census](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/dafb60d0ccad1280381ce1ec97aa4f3b9febc425/qa/repository-consolidation/20261118/round-04/protected-branch-audit.json) · [Round 03 source review and complete original evidence](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/86d4c92a89d1d4b0388a3b0a8f28280348105274/qa/repository-consolidation/20261118/round-03/README.md)

## Changes since the previous published checkpoint

### Reviewed source integration

Published Round 03 source `f571db956745d0702baba6da800b6c923aed34cc` and its complete 616-file evidence archive. It incorporates 21 reviewed ordinary heads across 210 paths: terminal memory reconciliation, authorized-read transport metadata, NDU/causal research, SDK/build fixtures, Agentd readback and sharding, private Scope-WAL fixtures, and initial clock-dependency migrations. The archive restores every original file with exact length and SHA-256 checks.

The source-bound native results include Memory 440 passes with 9 existing ignored cases, 42 distinct authorized-read cases, NDU 143 passes, scoped Neuron 29 passes, Scope-WAL 111 passes and state/thread-store 448 passes. OAuth2 migration has 75 upstream/boundary passes. Historical failures, optional skips and incomplete platform qualification remain recorded at their actual sources.

### Complete remaining-head structure audit

Compared all 4,962 distinct pending heads against their merge bases, checking every changed path, mode and blob; no head was unreadable. The source had 1,804 independent frontier heads. Different postimages still require source review and resolution.

Six heads were independently proved already present. Three have identical final blobs for every changed path; three pass full reverse/forward patch replay. Native Git merges of all six independently produce the unchanged source tree. Retaining these original heads as parents covers seven additional branch names without changing their already-integrated source behavior.

### Formatter bug

Both formatter modes incorrectly sent retained `BUILD.json` records to buildifier. A shared selector now preserves JSON metadata and continues selecting real BUILD, WORKSPACE, MODULE and Starlark sources. All 26 formatter-scope tests pass, including the real-Git metadata regression; repository `just fmt` completed afterward.

### Additional reviewed histories and exact archive custody

Round 05 composes 15 passive evidence heads and six additive source/artifact heads, retaining all 21 original parents and covering 23 more ordinary names. It preserves the original failures and frozen HCSN source seal; eight raw artifacts have lossless, independently verified carriers. Two offline audit fixes prevent report overwrite and bind scoring to the exact inventoried prediction bytes. Sixty distinct cases plus 11 optimized Python reruns passed. One historical profile identifier rename has complete normalized AST equality; recovery resolvers were not executed.

The hosted spelling failure came from three split gzip parts being interpreted as Latin-1 text. Their exact paths and SHA-256 digests now enter the existing custody verifier, without a new wildcard or workflow exemption. Twelve custody tests and the final complete Codespell 2.4.3 scan passed; `just fmt` completed afterward without changing the tracked source.

## Native repairs and dependency validation now published

Round 06 repairs the retained observation cache using immutable ArcSwap snapshots, a correctly ordered clock watermark and a revocation generation barrier. The original TTL, grant ceiling, clock/revision checks and permanent fencing remain. Fixtures issue their original grants within the production ceiling and test the first invalid millisecond after inclusive signed-evidence expiry.

The final qualified native source passed **2,682/2,682 ordinary cases** across the workflow's original six packages, with 184 original ignores, and **68/68 original Root entries**, with no skipped JUnit cases and zero retries. Exact case comparison with the earlier 2,672-case inventory shows no removed cases. The three new cache regressions and seven already-integrated fixture/temporal cases account for the increase. The original diagnostic failures remain preserved separately. Scoped fix/fmt and final compile-only checks completed afterward.

The complete genuine RMCP 3.9.0 source is retained with upstream identity and five exact patch carriers. Its native matrix passed **1,601/1,601 cases across 94 binaries**, with four original live-Keycloak ignores and zero retries, including actual JavaScript and Python interop. The resolver fixtures use the production policy chain with deterministic loopback transport and an explicit test-only no-proxy builder. Execution ran as a normal user in a loopback-only network namespace. Typed annotation constructors explicitly migrate to OffsetDateTime; raw lastModified strings remain unchanged. Final comment and JavaScript formatting edits have executable-token or normalized-AST equivalence records.

External-agent migration passed **171/171 cases**, no ignores or retries, and its actual parser matched Chrono 0.4.45 on **282,254 differential inputs**. Its initially failing marketplace fixture now verifies the exact inferred official request before supplying a local marketplace to the real addition path; all original assertions remain. The first 170/171 run remains available. Scoped fix/fmt, locked metadata and canonical Bazel generation completed; no dependency version/checksum was changed by this package's edge migration.

Three lossless bundles preserve **237 original files**, with complete raw logs, fresh JUnit, source/binary identities and terminal job records. Every member was verified. Local full Codespell and the unchanged blob-size gate passed; just fmt completed. One existing workflow's Prettier repair preserves its full parsed YAML. The broader local Prettier scan still reports nine pre-existing historical evidence scripts, which remain unchanged and explicitly unqualified.

These tests are bound to their recorded repair sources; the new assembled candidate must obtain its own hosted results. The dependency gate is still open: **19 normal and three dev-only first-party Chrono consumers remain**. No advisory ignore, weakened dependency policy or library stub is introduced.

## Active source integration and remaining gates

The large ordinary Windows/native frontier is being resolved by subsystem. Agentd's 68 conflicted paths have a reviewed candidate; the composed intelligence-eval source passed 248 cases, and cell-roles passed its complete 119-case suite. Those subsequent source packages are not yet included in this published candidate. Windows platform qualification, remaining linked-source reviews, cross-package interfaces, canonical locks and caller proofs remain in progress.

At parent b373, the Linux Bazel build succeeded but one original NextUse timing diagnostic failed at its retained deadline. This remains a concrete risk to verify on the repaired and subsequent combined sources. Production deadlines and the diagnostic are retained.

`CI required` and `Architecture required` remain required. Each final source-head and prospective base-merge must receive its own qualifying results. Scoped or historical passes do not qualify a different assembled candidate.

## Remaining merge conditions

Complete the remaining ordinary source reviews and conflict resolutions, repair the actual native/dependency/platform failures, and obtain both required checks for the final candidate. Then merge to main and remove only ordinary branches whose freshly read exact heads are reachable from merged main. Refresh and preserve all HIA/Cell branches throughout.


## 2026-11-18 round 07: verified recovery and NDU merge

Candidate advanced to `7f66ba922ad96d3b2153c2b12f5e28bc56ce3e1a` with a real additional parent `1b75bb2fbedff792ec3a9fafa8f5a0177b2ade83`; server tree `9ec861b80341fe64eca769bbec0500ba15553ffb` exactly matches the local reviewed tree. The underlying NDU merge tree also matches the independently tested composition.

- Repaired immediate interrupted-turn recovery by waiting for the exact retained terminalizer while preserving idle, identity, attach-epoch and shutdown fences. Native `just test` passed four Core regressions and the unchanged original failing App Server case. Scoped `just fix` and `just fmt` passed; only test formatting changed afterward.
- Merged the ordinary-kernel v4 width-32/depth-1/direct NDU source with its historical receipts intact. Validation passed 27 standalone Rust tests and 117 Python tests; full training/workflow parity is not claimed. Expanded PR path filters to every bound source component.
- Ref inventory: 7,526 original heads; 303 HIA refs protected by names, ancestry, PR relationships and aliases. Candidate ancestry covers 2,062 ordinary branch names, three more than round 06. No HIA refs changed and no branch deleted.
- Required CI is running on this candidate. Main remains unchanged; cargo-deny/chrono, exact NextUse diagnosis and Windows admission qualification remain open. The large Windows/Rust frontier is still under separate source/contract/lock reconciliation and is not attached by this commit.

Evidence: [round-07 audit](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/7f66ba922ad96d3b2153c2b12f5e28bc56ce3e1a/qa/repository-consolidation/20261118/round-07).

## 2026-11-18 Round 08: bounded execution replay reuse

Head: `a91102d3639a5a1f02394bfc0331611e9ab101a1`. Native evaluation package: **226 passed**. The original NextUse timing diagnostic passed with its unchanged **500 ms** deadline (command 248.483 ms; evidence 245.866 ms). The pure replay memo is bounded to 256 KiB and retains physical-image, witness, cursor-restoration and sticky-poison validation; it is cleared before writes.

The complete original caller verifier passed **1,645 boundaries / 820 protected files** with unchanged caller allowlists and `authorityGranted=false`. Native scoped fix and final format checks passed without source changes. The spelling-only Python fixture change preserves its exact malformed input bytes and all three existing tests pass.

Evidence: [round-08 audit](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/a91102d3639a5a1f02394bfc0331611e9ab101a1/qa/repository-consolidation/20261118/round-08). Whole-repository required CI remains mandatory. This update does not merge main, delete branches, or modify protected HIA refs.
