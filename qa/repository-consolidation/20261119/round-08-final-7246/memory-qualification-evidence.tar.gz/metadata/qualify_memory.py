#!/usr/bin/env python3
"""Run unmodified repository memory suites in a private, pinned CPU environment."""
from __future__ import annotations
import ast
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import signal
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path("/home/qian-qi/hepta-memory-7246-ci-audit")
ARCHIVE = ROOT / "incoming/memory-source-a498.tar.gz"
SOURCE = ROOT / "source-a498"
EVIDENCE = ROOT / "evidence/qualification-001"
PYTHON = ROOT / "python/bin/python"
TREE = "a498e119e6214723e4c8aae523892dd73407df68"
ARCHIVE_SHA = "a61857ba827d4c31a8329b2db7a415310d003de38be81c312185770772eb27fa"
MANIFEST_SHA = "a4961ee3843d7b57b49ddc2aabf656bbf7509037ed84974321eb6074ac35fe0f"
EXPECTED_PINS = {
    "torch": "2.10.0", "numpy": "1.26.4", "transformers": "4.57.1",
    "peft": "0.17.1", "accelerate": "1.10.1", "safetensors": "0.6.2",
    "huggingface-hub": "0.35.3",
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")

def progress(event, **values):
    print(json.dumps({"event": event, "unix_time": time.time(), **values}, sort_keys=True), flush=True)

def check_source(manifest):
    changed = []
    for rel, entry in manifest["paths"].items():
        path = SOURCE / rel
        try:
            data = path.read_bytes()
            expected_mode = int(entry["mode"], 8) & 0o777
            if path.is_symlink() or len(data) != entry["bytes"] or sha(data) != entry["sha256"] or path.stat().st_mode & 0o777 != expected_mode:
                changed.append(rel)
        except OSError:
            changed.append(rel)
    manifest_path = SOURCE / "source-manifest.json"
    if not manifest_path.is_file() or sha(manifest_path.read_bytes()) != MANIFEST_SHA:
        changed.append("source-manifest.json")
    return {"checked_paths": len(manifest["paths"]), "changed_paths": changed, "unchanged": not changed}

def extract_source():
    if sys.version_info[:3] != (3, 12, 3):
        raise RuntimeError("This qualification requires Python 3.12.3")
    archive = ARCHIVE.read_bytes()
    if len(archive) != 501587 or sha(archive) != ARCHIVE_SHA:
        raise RuntimeError("Source archive binding mismatch")
    with tarfile.open(ARCHIVE, mode="r:gz") as tf:
        members = tf.getmembers()
        if len(members) != 244 or len({m.name for m in members}) != 244:
            raise RuntimeError("Unexpected or duplicate archive members")
        for member in members:
            path = PurePosixPath(member.name)
            if not member.isfile() or path.is_absolute() or ".." in path.parts or str(path) != member.name or member.mode not in (0o644, 0o755):
                raise RuntimeError("Unsafe source archive member: " + member.name)
        manifest_data = tf.extractfile("source-manifest.json").read()
        if sha(manifest_data) != MANIFEST_SHA:
            raise RuntimeError("Source manifest digest mismatch")
        manifest = json.loads(manifest_data)
        if manifest["schema"] != "hepta.memory-original-source-archive.v1" or manifest["source_tree"] != TREE or manifest["path_count"] != 243 or len(manifest["paths"]) != 243:
            raise RuntimeError("Source manifest identity mismatch")
        if {m.name for m in members} != set(manifest["paths"]) | {"source-manifest.json"}:
            raise RuntimeError("Source manifest member closure mismatch")
        SOURCE.mkdir(mode=0o700, exist_ok=False)
        for member in members:
            data = tf.extractfile(member).read()
            if member.name != "source-manifest.json":
                entry = manifest["paths"][member.name]
                git_oid = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\x00" + data).hexdigest()
                if len(data) != entry["bytes"] or sha(data) != entry["sha256"] or git_oid != entry["git_blob"] or member.mode != int(entry["mode"], 8) & 0o777:
                    raise RuntimeError("Source postimage mismatch: " + member.name)
            target = SOURCE / member.name
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(data)
            target.chmod(member.mode)
    return manifest

def run_step(name, argv, env, cwd, timeout):
    stage = EVIDENCE / name
    stage.mkdir(mode=0o700)
    start = time.time()
    timed_out = False
    progress("stage_start", name=name, argv=[str(arg) for arg in argv])
    with (stage / "stdout.log").open("wb") as out, (stage / "stderr.log").open("wb") as err:
        proc = subprocess.Popen([str(arg) for arg in argv], cwd=cwd, env=env, stdout=out, stderr=err, start_new_session=True)
        try:
            code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                code = proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                code = proc.wait()
    result = {
        "name": name, "argv": [str(arg) for arg in argv], "cwd": str(cwd),
        "started_unix": start, "elapsed_seconds": round(time.time()-start, 3),
        "exit_code": code, "timeout_seconds": timeout, "timed_out": timed_out,
    }
    for channel in ("stdout", "stderr"):
        data = (stage / (channel + ".log")).read_bytes()
        result[channel] = {"path": str(stage / (channel + ".log")), "bytes": len(data), "sha256": sha(data)}
    save(stage / "result.json", result)
    progress("stage_complete", name=name, exit_code=code, elapsed_seconds=result["elapsed_seconds"], timed_out=timed_out)
    return result

def test_inventory(directory):
    tests = []
    for file in sorted(directory.glob("test_*.py")):
        module = ast.parse(file.read_text(encoding="utf-8"), filename=str(file))
        for item in module.body:
            if isinstance(item, ast.ClassDef):
                for method in item.body:
                    if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith("test_"):
                        tests.append(file.stem + "." + item.name + "." + method.name)
    return tests

def suite_receipt(name, result, inventory, before, after):
    text = (EVIDENCE / name / "stdout.log").read_text(errors="replace") + "\n" + (EVIDENCE / name / "stderr.log").read_text(errors="replace")
    runs = re.findall(r"Ran (\d+) tests? in ([0-9.]+)s", text)
    last = runs[-1] if runs else None
    failure = re.findall(r"^FAILED \(([^\n]+)\)$", text, re.MULTILINE)
    ok = re.findall(r"^OK(?: \(([^\n]+)\))?$", text, re.MULTILINE)
    fields = {}
    for item in (failure[-1] if failure else (ok[-1] if ok else "")).split(","):
        if "=" in item:
            k, v = item.strip().split("=", 1)
            if v.isdigit():
                fields[k] = int(v)
    errors = fields.get("errors", 0)
    failures = fields.get("failures", 0)
    skipped = fields.get("skipped", 0)
    count = int(last[0]) if last else None
    qualified = result["exit_code"] == 0 and not result["timed_out"] and count == len(inventory) and errors == failures == skipped == 0 and before["unchanged"] and after["unchanged"]
    result.update({
        "original_test_inventory": inventory, "original_test_count": len(inventory),
        "unittest_reported_count": count, "errors": errors, "failures": failures,
        "skipped": skipped, "unittest_elapsed_seconds": float(last[1]) if last else None,
        "source_before": before, "source_after": after, "qualified": qualified,
        "failure_trace_headers": re.findall(r"^(?:ERROR|FAIL): (.+)$", text, re.MULTILINE),
    })
    save(EVIDENCE / name / "result.json", result)
    return result

def main():
    os.umask(0o077)
    EVIDENCE.mkdir(mode=0o700, exist_ok=False)
    outcome = {
        "schema": "hepta.memory-original-qualification.v1",
        "source_tree": TREE, "source_archive_sha256": ARCHIVE_SHA,
        "source_manifest_sha256": MANIFEST_SHA, "source_path_count": 243,
        "runner_sha256": sha(Path(__file__).read_bytes()),
        "python": sys.executable, "python_version": sys.version,
        "cpu_only": True, "pretrained_downloads_permitted": False,
        "original_assertions_unchanged": True, "stages": [], "suites": {},
        "qualified": False,
    }
    manifest = None
    try:
        manifest = extract_source()
        outcome["source_initial"] = check_source(manifest)
        if not outcome["source_initial"]["unchanged"]:
            raise RuntimeError("Extracted source verification failed")
        progress("source_verified", source_tree=TREE, paths=243)
        env = os.environ.copy()
        env.update({
            "PATH": str(PYTHON.parent) + ":/usr/local/bin:/usr/bin:/bin",
            "PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": "",
            "VIRTUAL_ENV": str(ROOT / "python"), "CUDA_VISIBLE_DEVICES": "",
            "PIP_CONFIG_FILE": "/dev/null", "PIP_NO_INPUT": "1",
            "PIP_DISABLE_PIP_VERSION_CHECK": "1", "PIP_REQUIRE_VIRTUALENV": "1",
            "PIP_CACHE_DIR": str(ROOT / "cache/pip"), "PIP_EXTRA_INDEX_URL": "",
            "TMPDIR": str(ROOT / "tmp"), "HF_HOME": str(ROOT / "cache/huggingface"),
            "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
            "TOKENIZERS_PARALLELISM": "false",
        })
        outcome["qualification_environment"] = {k: env[k] for k in (
            "PATH", "PYTHONNOUSERSITE", "PYTHONDONTWRITEBYTECODE", "PYTHONPATH",
            "VIRTUAL_ENV", "CUDA_VISIBLE_DEVICES", "PIP_CONFIG_FILE",
            "PIP_REQUIRE_VIRTUALENV", "PIP_CACHE_DIR", "PIP_EXTRA_INDEX_URL",
            "TMPDIR", "HF_HOME", "HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE",
            "TOKENIZERS_PARALLELISM")}
        pip_base = [PYTHON, "-m", "pip", "--disable-pip-version-check", "--no-input", "--require-virtualenv"]
        stages = [
            ("install-torch", pip_base + ["install", "--only-binary=:all:", "--index-url", "https://download.pytorch.org/whl/cpu", "torch==2.10.0"], 1200),
            ("install-requirements", pip_base + ["install", "--only-binary=:all:", "--index-url", "https://pypi.org/simple", "-r", SOURCE / "scripts/memory_cell/requirements.txt", "-c", SOURCE / "scripts/memory_cell/torch_runtime_constraints.txt"], 1200),
            ("pip-check", pip_base + ["check"], 120),
            ("pip-freeze", pip_base + ["freeze", "--all"], 120),
        ]
        for name, argv, timeout in stages:
            result = run_step(name, argv, env, SOURCE, timeout)
            outcome["stages"].append(result)
            if result["exit_code"] != 0 or result["timed_out"]:
                raise RuntimeError("Dependency stage failed: " + name)
        validation = r"""
import importlib.metadata as metadata, json, sys
import torch, numpy, transformers, peft, accelerate, safetensors, huggingface_hub
expected = {expected}
versions = {{name: metadata.version(name) for name in expected}}
for name, wanted in expected.items():
    actual = versions[name].split("+", 1)[0] if name == "torch" else versions[name]
    assert actual == wanted, (name, versions[name], wanted)
assert sys.version_info[:3] == (3, 12, 3)
assert sys.prefix == {prefix!r}
assert torch.version.cuda is None, torch.version.cuda
x = torch.tensor([[1.0, 2.0], [3.0, 4.0]], device="cpu")
actual = (x @ x).tolist()
assert actual == [[7.0, 10.0], [15.0, 22.0]], actual
print(json.dumps({{"python": sys.version, "prefix": sys.prefix, "versions": versions, "torch_cuda_build": torch.version.cuda, "tensor_device": str(x.device), "tensor_matmul": actual}}, sort_keys=True))
""".format(expected=repr(EXPECTED_PINS), prefix=str(ROOT / "python"))
        validation_result = run_step("runtime-validation", [PYTHON, "-B", "-c", validation], env, SOURCE, 180)
        outcome["stages"].append(validation_result)
        if validation_result["exit_code"] != 0:
            raise RuntimeError("Native CPU runtime validation failed")
        outcome["runtime"] = json.loads((EVIDENCE / "runtime-validation/stdout.log").read_text())
        domain_paths = ["memory_cell", "memory_cell_growth", "memory_cell_catalog",
                        "memory_cell_hardening", "memory_cell_router", "memory_cell_codec",
                        "memory_cell_population", "memory_cell_domain"]
        domain_env = dict(env, PYTHONPATH=os.pathsep.join(str(SOURCE / "scripts" / name) for name in domain_paths))
        for name, argv, suite_env, expected in [
            ("domain", [PYTHON, "-B", "-m", "unittest", "discover", "-s", "scripts/memory_cell_domain", "-p", "test_*.py", "-v"], domain_env, 20),
            ("network", ["/bin/bash", "scripts/memory_cell_network/run_tests.sh"], env, 13),
        ]:
            before = check_source(manifest)
            inventory = test_inventory(SOURCE / "scripts" / ("memory_cell_" + name))
            if len(inventory) != expected or not before["unchanged"]:
                raise RuntimeError("Original test inventory/source mismatch: " + name)
            result = run_step(name, argv, suite_env, SOURCE, 1200)
            after = check_source(manifest)
            outcome["suites"][name] = suite_receipt(name, result, inventory, before, after)
            save(EVIDENCE / "result.json", outcome)
        outcome["qualified"] = all(outcome["suites"].get(name, {}).get("qualified", False) for name in ("domain", "network"))
    except Exception as exc:
        outcome["exception"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        progress("qualification_exception", type=type(exc).__name__, message=str(exc))
    finally:
        if manifest is not None:
            outcome["source_final"] = check_source(manifest)
            if not outcome["source_final"]["unchanged"]:
                outcome["qualified"] = False
        save(EVIDENCE / "result.json", outcome)
        artifact_manifest = {}
        for path in sorted(EVIDENCE.rglob("*")):
            if path.is_file():
                data = path.read_bytes()
                artifact_manifest[str(path.relative_to(EVIDENCE))] = {"bytes": len(data), "sha256": sha(data)}
        save(EVIDENCE / "artifact-manifest.json", artifact_manifest)
        progress("qualification_complete", qualified=outcome["qualified"], evidence=str(EVIDENCE),
                 suites={k: {field: v.get(field) for field in ("qualified", "original_test_count", "unittest_reported_count", "errors", "failures", "skipped", "exit_code")} for k, v in outcome["suites"].items()})
    return 0 if outcome["qualified"] else 1

if __name__ == "__main__":
    raise SystemExit(main())

