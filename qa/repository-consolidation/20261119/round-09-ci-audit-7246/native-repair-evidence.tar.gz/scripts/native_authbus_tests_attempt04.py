from pathlib import Path
import hashlib
import json
import os
import selectors
import shutil
import subprocess
import sys
import time

root = Path('/home/qian-qi/hepta-supervisor-expect-7246-ci-audit')
repo = root / 'source'
out = root / 'authbus-original-tests-004.json'
assert not out.exists()
prepared = json.loads((root / 'authbus-test-helper-prepare-001.json').read_text())
assert prepared['status'] == 'PASS'
manifest = json.loads((root / 'native-combined-source-manifest.json').read_text())
overlays = json.loads((root / 'combined-overlay-manifest-002.json').read_text())
overlay_map = {row['path']: row for row in overlays['paths']}
env = dict(os.environ)
env.update(
    PATH='/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/hepta-ndu480e-7246/tools/bin:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
    RUSTUP_TOOLCHAIN='1.96.0',
    TMPDIR=str(root / 'tmp'),
    TMP=str(root / 'tmp'),
    TEMP=str(root / 'tmp'),
    CARGO_HOME=str(root / 'cargo-home'),
    CARGO_CACHE_AUTO_CLEAN_FREQUENCY='never',
    CARGO_TARGET_DIR=str(root / 'cargo-target'),
    CARGO_BUILD_JOBS='2',
    CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0',
    CARGO_PROFILE_TEST_DEBUG='0',
    CARGO_TERM_COLOR='never',
    CARGO_NET_OFFLINE='true',
    PYTHONDONTWRITEBYTECODE='1',
    PYTHONNOUSERSITE='1',
    GIT_NO_LAZY_FETCH='1',
    GIT_OPTIONAL_LOCKS='0',
    GIT_TERMINAL_PROMPT='0',
)
result = {'status': 'RUNNING', 'source_commit': manifest['commit'],
          'baseline_manifest_sha256': hashlib.sha256((root / 'native-combined-source-manifest.json').read_bytes()).hexdigest(),
          'overlay_paths': overlays['paths'], 'started_at': time.time(), 'steps': [],
          'cargo_target': env['CARGO_TARGET_DIR'],
          'env': {key: env[key] for key in ['RUSTUP_TOOLCHAIN', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
                                          'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'CARGO_NET_OFFLINE', 'CARGO_HOME', 'CARGO_CACHE_AUTO_CLEAN_FREQUENCY', 'TMPDIR', 'TMP', 'TEMP']},
          'infer_tests': 'Not repeated; parent has exact f8 + replay-file patch original 131 pass / 8 default skip result.'}


def save():
    out.write_text(json.dumps(result, indent=2) + '\n')


def verify_sources():
    for row in manifest['files']:
        path = row['path']
        expected = overlay_map[path]['postimage_sha256'] if path in overlay_map else row['sha256']
        target = repo / path
        assert target.is_file() and not target.is_symlink(), path
        assert hashlib.sha256(target.read_bytes()).hexdigest() == expected, path
        assert bool(target.stat().st_mode & 0o111) == (row['mode'] == '100755'), path
    return len(manifest['files'])


def run(name, argv):
    started = time.time()
    stdout_path = root / (name + '.stdout')
    stderr_path = root / (name + '.stderr')
    print(json.dumps({'event': 'started', 'name': name, 'argv': argv,
                      'disk_free': shutil.disk_usage(root).free}), flush=True)
    with stdout_path.open('xb') as stdout_file, stderr_path.open('xb') as stderr_file:
        process = subprocess.Popen(argv, cwd=repo / 'codex-rs', env=env,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ, (stdout_file, sys.stdout.buffer))
        selector.register(process.stderr, selectors.EVENT_READ, (stderr_file, sys.stderr.buffer))
        while selector.get_map():
            for key, _ in selector.select():
                data = os.read(key.fileobj.fileno(), 65536)
                if data:
                    saved, terminal = key.data
                    saved.write(data)
                    saved.flush()
                    terminal.write(data)
                    terminal.flush()
                else:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
        exit_code = process.wait()
    row = {'name': name, 'argv': argv, 'cwd': str(repo / 'codex-rs'), 'exit': exit_code,
           'elapsed_seconds': time.time() - started,
           'stdout_bytes': stdout_path.stat().st_size,
           'stderr_bytes': stderr_path.stat().st_size,
           'stdout_sha256': hashlib.sha256(stdout_path.read_bytes()).hexdigest(),
           'stderr_sha256': hashlib.sha256(stderr_path.read_bytes()).hexdigest(),
           'disk_free_after': shutil.disk_usage(root).free}
    result['steps'].append(row)
    save()
    print(json.dumps({'event': 'completed', **row}), flush=True)
    return exit_code


try:
    result['verified_files_before'] = verify_sources()
    save()
    commands = [
        ('authbus-package-tests-004', ['/home/qian-qi/.cargo/bin/just', 'test', '-p',
            'codex-hepta-authbus', '--offline', '--locked']),
        ('authbus-qualification-tests-004', ['/home/qian-qi/.cargo/bin/just', 'test', '-p',
            'codex-hepta-authbus-p1-3-qualification', '--offline', '--locked']),
    ]
    for name, argv in commands:
        if run(name, argv) != 0:
            raise RuntimeError(name + ' failed; remaining steps were not run')
    result['verified_files_after'] = verify_sources()
    result.update(status='PASS', finished_at=time.time())
    save()
    print(json.dumps({'status': result['status'], 'source_commit': result['source_commit'],
                      'verified_files': result['verified_files_after'], 'steps': result['steps']}), flush=True)
except BaseException as error:
    result.update(status='FAIL', error=str(error), finished_at=time.time())
    save()
    print(json.dumps({'status': 'FAIL', 'error': str(error)}), flush=True)
    raise
