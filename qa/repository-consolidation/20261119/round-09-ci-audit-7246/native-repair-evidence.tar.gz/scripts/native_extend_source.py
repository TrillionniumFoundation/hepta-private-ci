from pathlib import Path
import base64
import gzip
import hashlib
import json
import os
import subprocess
import sys
import time

cfg = json.load(sys.stdin)
root = Path('/home/qian-qi/hepta-supervisor-expect-7246-ci-audit')
repo = root / 'source'
out = root / 'combined-source-prepare-001.json'
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')
git = ['git', '-c', 'protocol.allow=never', '--no-replace-objects']
result = {'status': 'RUNNING', 'source_commit': cfg['source_commit'], 'steps': [], 'started_at': time.time()}


def save():
    out.write_text(json.dumps(result, indent=2) + '\n')


def run(name, args, data=None):
    start = time.time()
    process = subprocess.run(args, input=data, capture_output=True, env=env, cwd=repo)
    (root / (name + '.stdout')).write_bytes(process.stdout)
    (root / (name + '.stderr')).write_bytes(process.stderr)
    row = {'name': name, 'argv': args, 'exit': process.returncode,
           'elapsed_seconds': time.time() - start,
           'stdout_sha256': hashlib.sha256(process.stdout).hexdigest(),
           'stderr_sha256': hashlib.sha256(process.stderr).hexdigest()}
    result['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    if process.returncode:
        raise RuntimeError(name + ': ' + process.stderr.decode(errors='replace')[-5000:])
    return process.stdout


def verify(row, expected):
    path = repo / row['path']
    assert path.is_file() and not path.is_symlink(), row['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, row['path']
    assert bool(path.stat().st_mode & 0o111) == (row['mode'] == '100755'), row['path']


try:
    assert not out.exists()
    prior = json.loads((root / 'source-prepare-002.json').read_text())
    assert prior['status'] == 'PASS' and prior['source_commit'] == cfg['source_commit']
    old_manifest = json.loads((root / 'native-candidate-source-manifest.json').read_text())
    old_overlay = json.loads((root / 'overlay-manifest.json').read_text())
    for row in old_manifest['files']:
        verify(row, old_overlay['after_sha256'] if row['path'] == old_overlay['path'] else row['sha256'])
    raw = gzip.decompress(base64.b64decode(cfg['manifest_gzip_base64'], validate=True))
    assert hashlib.sha256(raw).hexdigest() == cfg['manifest_sha256']
    manifest = json.loads(raw)
    assert manifest['commit'] == cfg['source_commit'] and manifest['tree'] == old_manifest['tree']
    old_rows = {row['path']: row for row in old_manifest['files']}
    new_rows = {row['path']: row for row in manifest['files']}
    assert all(new_rows[path] == row for path, row in old_rows.items())
    added = sorted(set(new_rows) - set(old_rows))
    assert len(added) == cfg['added_file_count']
    assert all(path.startswith(('codex-rs/hepta-authbus/', 'codex-rs/hepta-authbus-p1-3-qualification/')) for path in added)
    pack = base64.b64decode(cfg['extension_pack_base64'], validate=True)
    assert hashlib.sha256(pack).hexdigest() == cfg['extension_pack_sha256']
    (root / 'native-authbus-extension.pack').write_bytes(pack)
    run('extend-import-pack', git + ['index-pack', '--stdin', '--strict'], pack)
    names = b''.join((path + '\0').encode() for path in added)
    run('extend-activate-paths', git + ['update-index', '--no-skip-worktree', '-z', '--stdin'], names)
    run('extend-checkout-paths', git + ['checkout-index', '--force', '-z', '--stdin'], names)
    for row in manifest['files']:
        verify(row, old_overlay['after_sha256'] if row['path'] == old_overlay['path'] else row['sha256'])
    overlays = cfg['overlays']
    assert len(overlays) == 3 and len({row['path'] for row in overlays}) == 3
    for row in overlays:
        path = repo / row['path']
        assert new_rows[row['path']]['sha256'] == row['preimage_sha256']
        existing = hashlib.sha256(path.read_bytes()).hexdigest()
        assert existing == (old_overlay['after_sha256'] if row['path'] == old_overlay['path'] else row['preimage_sha256'])
        data = base64.b64decode(row['content_base64'], validate=True)
        assert len(data) == row['postimage_size']
        assert hashlib.sha256(data).hexdigest() == row['postimage_sha256']
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['postimage_git_blob']
        path.write_bytes(data)
    changed = run('extend-diff-paths', git + ['diff', '--name-only', '-z'])
    assert sorted(path.decode() for path in changed.split(b'\0') if path) == sorted(row['path'] for row in overlays)
    run('extend-diff-check', git + ['diff', '--check'])
    run('extend-source-diff', git + ['diff'])
    overlay_map = {row['path']: row for row in overlays}
    for row in manifest['files']:
        verify(row, overlay_map[row['path']]['postimage_sha256'] if row['path'] in overlay_map else row['sha256'])
    (root / 'native-combined-source-manifest.json').write_bytes(raw)
    clean_overlays = [{k: v for k, v in row.items() if k != 'content_base64'} for row in overlays]
    (root / 'combined-overlay-manifest.json').write_text(json.dumps({'source_commit': cfg['source_commit'], 'paths': clean_overlays}, indent=2) + '\n')
    result.update(status='PASS', verified_files=len(manifest['files']), added_files=len(added),
                  manifest_sha256=cfg['manifest_sha256'], overlays=clean_overlays, finished_at=time.time())
    save()
    print(json.dumps({k: v for k, v in result.items() if k != 'steps'}), flush=True)
except BaseException as error:
    result.update(status='FAIL', error=str(error), finished_at=time.time())
    save()
    print(json.dumps({'status': 'FAIL', 'error': str(error)}), flush=True)
    raise
