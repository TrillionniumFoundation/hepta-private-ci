from pathlib import Path
import base64
import hashlib
import json
import sys
import time

root = Path('/home/qian-qi/hepta-supervisor-expect-7246-ci-audit')
repo = root / 'source'
out = root / 'authbus-test-helper-prepare-001.json'
assert not out.exists()
cfg = json.load(sys.stdin)
previous = json.loads((root / 'final-fix-fmt-001.json').read_text())
assert previous['status'] == 'PASS'
manifest = json.loads((root / 'native-combined-source-manifest.json').read_text())
prior = {row['path']: row for row in previous['final_overlay_paths']}
for row in manifest['files']:
    target = repo / row['path']
    assert target.is_file() and not target.is_symlink(), row['path']
    expected = prior[row['path']]['sha256'] if row['path'] in prior else row['sha256']
    assert hashlib.sha256(target.read_bytes()).hexdigest() == expected, row['path']
    assert bool(target.stat().st_mode & 0o111) == (row['mode'] == '100755'), row['path']
overlays = cfg['overlay_manifest']
assert overlays['source_commit'] == manifest['commit']
assert len(overlays['paths']) == 5
allowed = {
    'codex-rs/hepta-authbus/src/authority_store.rs': 'last_trusted_time',
    'codex-rs/hepta-authbus/src/recovery.rs': 'recovery_required',
}
assert {row['path'] for row in cfg['repairs']} == set(allowed)
for row in cfg['repairs']:
    path = row['path']
    target = repo / path
    before = target.read_bytes()
    assert hashlib.sha256(before).hexdigest() == row['preimage_sha256']
    after = base64.b64decode(row['content_base64'], validate=True)
    old = ('    pub async fn ' + allowed[path] + '(').encode()
    new = b'    #[cfg(test)]\n' + old
    assert before.count(old) == 1 and after == before.replace(old, new)
    assert hashlib.sha256(after).hexdigest() == row['postimage_sha256']
    target.write_bytes(after)
overlay_map = {row['path']: row for row in overlays['paths']}
for row in manifest['files']:
    expected = overlay_map[row['path']]['postimage_sha256'] if row['path'] in overlay_map else row['sha256']
    assert hashlib.sha256((repo / row['path']).read_bytes()).hexdigest() == expected, row['path']
(root / 'combined-overlay-manifest-002.json').write_text(json.dumps(overlays, indent=2) + '\n')
result = {'status': 'PASS', 'source_commit': manifest['commit'], 'verified_files': len(manifest['files']),
          'overlay_paths': overlays['paths'], 'new_cfg_test_attributes': 2,
          'method_bodies_and_original_tests_unchanged': True, 'finished_at': time.time()}
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
