from pathlib import Path
import base64
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

cfg = json.load(sys.stdin)
root = Path('/home/qian-qi/hepta-supervisor-expect-7246-ci-audit')
repo = root / 'source'
out = root / 'source-prepare-002.json'
manifest_bytes = gzip.decompress(base64.b64decode(cfg['manifest_gzip_base64'], validate=True))
assert hashlib.sha256(manifest_bytes).hexdigest() == cfg['manifest_sha256']
manifest = json.loads(manifest_bytes)
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')
result = {'source_commit': manifest['commit'], 'source_tree': manifest['tree'],
          'manifest_sha256': cfg['manifest_sha256'], 'steps': [],
          'started_at': time.time(), 'status': 'RUNNING'}


def save():
    out.write_text(json.dumps(result, indent=2) + '\n')


def run(name, args, data=None):
    start = time.time()
    process = subprocess.run(args, input=data, capture_output=True, env=env,
                             cwd=repo if repo.exists() else root)
    (root / (name + '.stdout')).write_bytes(process.stdout)
    (root / (name + '.stderr')).write_bytes(process.stderr)
    row = {'name': name, 'argv': args, 'exit': process.returncode,
           'elapsed_seconds': time.time() - start,
           'stdout_sha256': hashlib.sha256(process.stdout).hexdigest(),
           'stderr_sha256': hashlib.sha256(process.stderr).hexdigest()}
    result['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    if process.returncode:
        raise RuntimeError(name + ': ' + process.stderr.decode(errors='replace')[-5000:])
    return process.stdout


try:
    assert repo.is_dir()
    assert not out.exists(), 'Refusing to replace prior qualification evidence'
    prior = json.loads((root / 'source-prepare-001.json').read_text())
    assert prior['status'] == 'FAIL' and prior['manifest_sha256'] == cfg['manifest_sha256']
    assert prior['source_commit'] == manifest['commit']
    assert prior['error'].startswith('prepare-checkout: error: unable to read sha1 file of ')
    git = ['git', '-c', 'protocol.allow=never', '--no-replace-objects']
    pack = base64.b64decode(cfg['missing_pack_base64'], validate=True)
    assert hashlib.sha256(pack).hexdigest() == cfg['missing_pack_sha256']
    (root / 'native-missing-blobs.pack').write_bytes(pack)
    run('resume-index-missing-blobs', git + ['index-pack', '--stdin', '--strict'], pack)
    raw_commit = run('resume-commit', git + ['cat-file', 'commit', manifest['commit']])
    assert hashlib.sha1(b'commit ' + str(len(raw_commit)).encode() + b'\0' + raw_commit).hexdigest() == manifest['commit']
    headers = raw_commit.split(b'\n\n', 1)[0].decode().splitlines()
    parents = [line[7:] for line in headers if line.startswith('parent ')]
    assert parents == cfg['parents']
    assert [line[5:] for line in headers if line.startswith('tree ')] == [manifest['tree']]
    run('resume-read-tree', git + ['read-tree', manifest['commit']])
    all_paths = run('resume-all-index-paths', git + ['ls-files', '-z'])
    run('resume-skip-all', git + ['update-index', '--skip-worktree', '-z', '--stdin'], all_paths)
    selected = b''.join((row['path'] + '\0').encode() for row in manifest['files'])
    run('resume-selected-active', git + ['update-index', '--no-skip-worktree', '-z', '--stdin'], selected)
    run('resume-checkout', git + ['checkout-index', '--force', '-z', '--stdin'], selected)
    run('resume-detached-head', git + ['update-ref', '--no-deref', 'HEAD', manifest['commit']])
    for row in manifest['files']:
        path = row['path']
        assert not path.startswith('/') and '..' not in Path(path).parts
        target = repo / path
        assert target.is_file() and not target.is_symlink(), path
        raw = target.read_bytes()
        actual = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                  'oid': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}
        assert all(actual[key] == row[key] for key in actual), (path, actual, row)
        assert bool(target.stat().st_mode & 0o111) == (row['mode'] == '100755'), path
    before_status = run('resume-baseline-status', git + ['status', '--porcelain=v1', '--untracked-files=no'])
    assert not before_status, before_status.decode()
    overlay = cfg['overlay']
    assert overlay['path'] == 'codex-rs/hepta-supervisor/tests/authority_distribution.rs'
    target = repo / overlay['path']
    assert hashlib.sha256(target.read_bytes()).hexdigest() == overlay['before_sha256']
    content = base64.b64decode(overlay['content_base64'], validate=True)
    assert hashlib.sha256(content).hexdigest() == overlay['after_sha256']
    target.write_bytes(content)
    changed = run('resume-overlay-paths', git + ['diff', '--name-only', '-z']).split(b'\0')
    assert [path.decode() for path in changed if path] == [overlay['path']]
    run('resume-diff-check', git + ['diff', '--check'])
    run('resume-source-diff', git + ['diff', '--', overlay['path']])
    (root / 'native-candidate-source-manifest.json').write_bytes(manifest_bytes)
    (root / 'overlay-manifest.json').write_text(json.dumps({k: v for k, v in overlay.items() if k != 'content_base64'}, indent=2) + '\n')
    result.update(status='PASS', verified_baseline_files=len(manifest['files']),
                  baseline_bytes=sum(row['bytes'] for row in manifest['files']),
                  overlay_path=overlay['path'], overlay_sha256=overlay['after_sha256'],
                  parents=parents, disk_free=shutil.disk_usage(root).free,
                  finished_at=time.time())
    save()
    print(json.dumps({k: v for k, v in result.items() if k != 'steps'}), flush=True)
except BaseException as error:
    result.update(status='FAIL', error=str(error), finished_at=time.time())
    save()
    print(json.dumps({'status': 'FAIL', 'error': str(error)}), flush=True)
    raise
