from pathlib import Path
import base64
import hashlib
import json
import os
import shutil
import sys
import time
import tomllib

cfg = json.load(sys.stdin)
root = Path('/home/qian-qi/hepta-supervisor-expect-7246-ci-audit')
out = root / 'cargo-cache-prepare-001.json'
cargo_home = root / 'cargo-home'
supplier = Path('/home/qian-qi/.cargo')
assert not cargo_home.exists() and not out.exists()
lock = tomllib.loads((root / 'source/codex-rs/Cargo.lock').read_text())
package = [row for row in lock['package'] if row['name'] == 'tz-rs' and row['version'] == '0.7.3']
assert len(package) == 1 and package[0]['checksum'] == cfg['sha256']
data = base64.b64decode(cfg['crate_base64'], validate=True)
assert len(data) == cfg['bytes'] and hashlib.sha256(data).hexdigest() == cfg['sha256']
cargo_home.mkdir()
(cargo_home / 'registry').mkdir()
counts = {}
for kind in ['index', 'cache', 'src']:
    source = supplier / 'registry' / kind
    destination = cargo_home / 'registry' / kind
    destination.mkdir()
    assert source.is_dir(), source
    count = 0
    for registry in source.iterdir():
        if not registry.is_dir():
            continue
        if kind == 'index':
            (destination / registry.name).symlink_to(registry, target_is_directory=True)
            count += 1
        else:
            own_registry = destination / registry.name
            own_registry.mkdir()
            for entry in registry.iterdir():
                (own_registry / entry.name).symlink_to(entry, target_is_directory=entry.is_dir())
                count += 1
    counts[kind] = count
if (supplier / 'git').is_dir():
    (cargo_home / 'git').symlink_to(supplier / 'git', target_is_directory=True)
config_files = []
for name in ['config', 'config.toml']:
    source = supplier / name
    if source.is_file():
        shutil.copyfile(source, cargo_home / name)
        config_files.append({'name': name, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
installed = []
for registry in (cargo_home / 'registry/cache').iterdir():
    if registry.name.startswith(('index.crates.io-', 'github.com-')):
        target = registry / 'tz-rs-0.7.3.crate'
        if target.exists():
            assert hashlib.sha256(target.read_bytes()).hexdigest() == cfg['sha256']
        else:
            with target.open('xb') as handle:
                handle.write(data)
        installed.append(str(target))
assert installed
result = {'status': 'PASS', 'cargo_home': str(cargo_home), 'borrowed_cache_entries': counts,
          'source_crate_bytes': len(data), 'source_crate_sha256': cfg['sha256'],
          'installed_paths': installed, 'configuration_files': config_files,
          'shared_cache_content_modified': False, 'network_requests': False,
          'constraint': 'Subsequent Cargo commands must remain offline with cache auto-clean disabled; new extraction and global cache metadata belong to this own Cargo home.',
          'finished_at': time.time()}
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
