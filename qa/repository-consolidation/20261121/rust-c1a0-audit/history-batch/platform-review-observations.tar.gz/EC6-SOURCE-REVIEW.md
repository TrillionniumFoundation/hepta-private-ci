# ec6 Windows private-directory backend：限定只读源码审查

## 结论

**`ec6ffaa743f8ef088805a5acee7693969adefe3a` 包含真实的新 Windows 私有目录后端，但不能直接修复当前 `87b1418` 的两个 AuthBus `UnsafeCheckpoint` 失败。** 该分支接入的是 State、Operator 和 Shadow，56 个相对共同祖先的净变更路径没有 AuthBus 或 hepta-evidence。它自己的旧 AuthBus 源码甚至没有 `owner.rs`；旧 `host.rs` 的三条非 Unix 路径仍直接拒绝。

这不是“后端已经完整 squash 到 87，只缺一个调用”的情况：87 中没有新的 `RetainedPrivateDirectory`、`PrivateFileIdentity`、`PrivateSecurityIdentity` 或 `WindowsFileId` 名称，相关新核心文件均不存在。87 已有较旧的 `open_private_state_* -> File` 接口，以及 State 内部的严格身份/ACL 检查函数；这些不能与新封装及消费者接入画等号。本审查没有排除全仓任意名称下的所有功能等价实现。

该分支值得作为独立组件继续审查；本报告**不批准全分支合并，不声明 Windows 通过，不编写新的生产接线，不执行测试或 native jobs**。用户已授权的普通分支审计与合并工作不因此增加“原 owner 独占”之类权限条件。

## 精确身份与范围

| 项目 | 值 |
|---|---|
| 候选 tip | `ec6ffaa743f8ef088805a5acee7693969adefe3a` |
| 父提交 | `33145f99a8da78f62ec53de1cc6c77235a39f80d` |
| 候选 tree | `b09022085b31dd2f66f4c627214c3e4bc0d70213` |
| 当前 ref | `codex/windows-private-directory-backend-20261026` |
| 本次比较的精确源 | `87b141833f2a43e0e87fdb3d4a168e1dacde7a0f`，tree `477005584144e1f9cd9c4e9e280e0a7f7706a487` |
| 共同祖先 | `6d7ed132d72755e1414c96ee239117dc945e670a` |
| 完整候选祖先 / 对 87 新增 | 34,377 / 10 |
| 已知保护集 | 539 refs、1,471 节点；候选完整祖先交集为空 |
| STOP | `d783273c25b3164f5f632482cb7b017fdcb9d756` 不在候选完整祖先中；未打开该对象/后代/补丁 |
| 历史保护缺口 | 原 551st pin 的身份仍未补齐 |

本地 parent graph 闭合；GitHub compare 的十个提交与独立图完全一致。56 个净路径中，27 个在支线新增、29 个修改。对 87 的同名路径比对：**0 个 blob 完全相同、30 个已存在但不同、26 个不存在**。27 份新增文件由完整 compare patch 提取，逐个重新计算 Git blob SHA1；另外获取并核验了 ec6 的 AuthBus `host.rs` 和 `Cargo.toml`，共 29 份候选源码副本。

完整净路径及 blob 对照见 [NET-PATH-IDENTITIES.json](NET-PATH-IDENTITIES.json)。这些是身份对照，不表示全部 56 个产品路径已经完成行为审查。

## 两个当前失败的真实入口

两个测试都建立真实 AuthBus owner，不能将它们改为预期拒绝来声称功能恢复。

| 原测试 | 当前调用链 | 第一处 Windows 拒绝 |
|---|---|---|
| `issuer_retirement_proof_prunes_replay_rows_but_tombstone_prevents_resurrection` | `authbus_recovery_tests.rs:305` 调用 `bootstrap_new`，`:311` unwrap | `owner.rs:110` → `validate_separate_private_parents` 的 `#[cfg(not(unix))]` 分支 `:683–688` |
| `pq_retirement_requires_the_exact_pinned_revoked_key_and_profile` | `authbus_retirement_pq_tests.rs:72` 的首个 Ed25519 分支调用 `bootstrap_new`，`:78` unwrap | 同一父目录拒绝入口；此时尚未执行 `:79–85` 的 ML-DSA bootstrap 分支 |

该拒绝发生在 `prepare_new_database_file` / SQLite 打开之前。上述 fixture 只在 Unix 设置 `0700`；Windows 下临时目录的 ACL 不能凭名称认定为私有。但目前第一处错误无条件由平台分支产生，单改 fixture 无法解除它。

直接源码依据：[87 owner.rs](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/87b141833f2a43e0e87fdb3d4a168e1dacde7a0f/codex-rs/hepta-authbus/src/owner.rs)、[原经典退休测试](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/87b141833f2a43e0e87fdb3d4a168e1dacde7a0f/codex-rs/hepta-evidence/src/authbus_recovery_tests.rs)、[原 PQ 退休测试](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/87b141833f2a43e0e87fdb3d4a168e1dacde7a0f/codex-rs/hepta-evidence/src/authbus_retirement_pq_tests.rs)。这里核验的是调用链；本轮没有再次下载或执行 Windows job。

## ec6 后端实际提供什么

核心实现位于 `codex-rs/utils/path-utils/src/`：

| 源文件 / 入口 | 已读到的具体行为 |
|---|---|
| `private_file_identity_windows.rs` | 读取 volume serial + 完整 128-bit file ID；拒绝非 disk、reparse、零 ID、错误 kind、DeletePending、非一链文件及异常元数据；保留完整安全描述符 |
| `private_file_security_windows.rs` | 使用有效线程/进程 token，验证 owner/user、DACL、ACE/SID 边界；拒绝外来非零 allow ACE、空/非法 DACL、未知 ACE；保留 System/Administrators 和 inherit-only CreatorOwner 的明确边界 |
| `private_artifact_directory_windows.rs` | 只接受 canonical absolute fixed local NTFS 路径；持有祖先；通过原目录句柄执行 NT relative create/open/rename；检查单组件名称、ADS、设备名、大小写替代别名 |
| `RetainedPrivateDirectory::open_existing/create_new` | 现存目录必须通过私有身份检查；新 leaf 以原子私有 descriptor 创建并真实同步父目录；不修 ACL、不收养不兼容目录 |
| `write_new_child/atomic_replace_child` | 独占创建、准确写入/读回、文件与原目录的真实同步、保留身份校验；失败不能推导为成功或自动 replay |
| `PrivateFile` | 不公开 raw handle、`File` 或 `Write`；提供有界读、身份复核和真实 sync 请求；只读构造不能转换为可写目录 |
| `create_or_lock_child/lock_existing_child` | 原生共享限制排除并行 writer/delete，保留锁文件身份；现有合格侧车文件可以重新取得 |

祖先比较检查并保留完整不可变 ID；它不等于“所有祖先目录都具备最终 leaf 的私有 DACL”。目录更换、ACL 变化和预期的子目录时间变化也不能混为一种相等关系。

对 `private_file_security_windows.rs` 的七个顶层 helper，另与 87 当前 State 实现逐函数核对：仅将 `SqliteRecoveryError::Indeterminate` 换为 `indeterminate()` 并忽略空白后，函数体全部相同。这是具体文本转移证据，**不是 AST 等价证明、编译结果或 Windows 执行结果**。见 [SECURITY-BODY-COMPARISON.json](SECURITY-BODY-COMPARISON.json)。

源码入口：[ec6 private_artifacts_windows.rs](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/ec6ffaa743f8ef088805a5acee7693969adefe3a/codex-rs/utils/path-utils/src/private_artifacts_windows.rs)、[ec6 private_file_security_windows.rs](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/ec6ffaa743f8ef088805a5acee7693969adefe3a/codex-rs/utils/path-utils/src/private_file_security_windows.rs)。

## 为什么还不是 AuthBus 接线

ec6 的 `CALLERS.md` 和实际代码只列出 State recovery、Operator acceptance 和 Shadow qualification。对 ec6 精确目录的 API 读取列出 AuthBus 的 22 个源文件，`owner.rs` 不在其中。已核验的 `host.rs` blob 为 `9056fd52bf58e081ebfe997d4935f37531d57272`；它的 `validate_path`、`read_private_file`、`write_private_atomic` 在非 Unix 上仍返回 `UnsafeCheckpoint`，分别位于 `:484–486`、`:534–536`、`:593–599`。AuthBus manifest 也没有 `codex-utils-path` 依赖。

87 中的现有新 owner 则还有以下边界，不能只把父目录检查改为成功：

| 当前入口 | 原合同中必须保留的内容 |
|---|---|
| 父目录分离验证 `:683–688` | 数据库与 checkpoint 独立、私有、canonical 且不能由别名指向同一对象 |
| 写者锁创建 `:655–657`、复核 `:623–625` | 独占新文件、原 owner/pid/双路径 digest payload、跨每次串行变更的身份和准确字节复核 |
| 数据库创建 `:724–726`、文件验证 `:742–744` | 私有新库、DB/WAL/SHM 完整验证、SQLite 所需共享语义与真实同步 |
| 初始 checkpoint `:823–829` | schema/owner/generation/frontier 约束、大小上限、独占创建、父目录 barrier |
| `sync_parent :832–838` | 当前无平台适配的 `File::open(directory).sync_all()` 不能视作新 Windows 可写目录能力 |
| host 的三处非 Unix 分支 | 私有路径/有界完整读取/同目录原子更换、rollback/frontier 与失败后的状态 |

特别是新通用侧车锁不能直接代替 AuthBus lease：`create_or_lock_child` 会重新取得现存合格空侧车，AuthBus 原实现对任何现存锁返回 `WriterLeaseHeld`，还绑定 payload 并有自己的移除生命周期。新 `PrivateFile` 不开放可变 raw `File`，也不能未经设计便满足当前 `AuthorityWriterLease { file: File, path, payload }`。同样，不能把 retained writer 文件句柄的共享模式盲目套到 SQLite DB/WAL。

## 原测试源码与验证边界

候选新增九个 Windows native 测试，名称及源码行保存在 [BACKEND-TEST-INVENTORY.json](BACKEND-TEST-INVENTORY.json)：

1. 私有 roundtrip、真实双同步、只读 custody 和写者排除。
2. 原 retained 目录上的 atomic replace。
3. 外来 read ACE 拒绝，ACL 原样保留。
4. 非法单组件名称与大小写 alias 无副作用。
5. 硬链接拒绝，原对象字节保留。
6. 原目录被替换后拒绝写入。
7. 侧车锁直到 drop 前排除第二写者。
8. DACL 改变后原 custody 失效。
9. reparse/junction 在子操作前拒绝。

collector 源码明确要求九个精确测试身份全部 PASS，且与原 91 个功能结果和六个 legacy 拒绝控制分开。本轮仅审阅这些源码，**未执行 collector、测试、cross-check、编译、formatter 或 Windows job**。文档引用的旧 directory probe 自己保留总体失败；不能借此宣称 ec6 的九项已通过。

## 下一步可审范围

先审一个针对当前源的后端组件及依赖闭包；不要把该支线的 Memory、sandbox 拒绝策略、工作流、Operator 和 Shadow 共 56 路径直接视为一个已 qualified 修复。若之后讨论 AuthBus 适配，应独立核验上述全部父目录、租约、DB/WAL、checkpoint 及 host 合同，再以原经典/PQ 正向退休测试、原 AuthBus owner 的 rollback/路径/租约/并发控制、九个后端控制和受影响消费者的原范围提供精确源结果。fixture 必须确实建立私有 Windows ACL，不能降低原正向断言，也不能用新增拒绝控制抵销失败。

本轮没有读取被拒 d783 的实现或比较其语义，没有制作替代生产补丁。具体 STOP 持续保留；它没有被泛化为对所有 Windows 代码的冻结。

## 证据导航

- [SOURCE-REVIEW.json](SOURCE-REVIEW.json)：完整机器可读判断、调用链、入口缺口与下一步范围。
- [CLOSURE.json](CLOSURE.json)：完整闭包计数、十个新增提交及保护边界。
- [COMPARE-BASE-TO-EC6.json](COMPARE-BASE-TO-EC6.json)：原 API compare，56 路径完整 patch。
- [NET-PATH-IDENTITIES.json](NET-PATH-IDENTITIES.json)：候选与 87 的精确同路径 blob 对照。
- [CANDIDATE-SOURCE-RECEIPTS.json](CANDIDATE-SOURCE-RECEIPTS.json) / [CURRENT-SOURCE-RECEIPTS.json](CURRENT-SOURCE-RECEIPTS.json)：所有本地源码副本的长度、Git blob、SHA256。
- [AUTHBUS-DIRECTORY-AT-EC6.json](AUTHBUS-DIRECTORY-AT-EC6.json)：精确 ec6 的 22 文件清单，证明 `owner.rs` 不在该目录。

root checkout/index、所有 refs、远端、native jobs 均未修改。报告只绑定上述 87 和 ec6 身份，不继承其他 head 的 CI 状态。
