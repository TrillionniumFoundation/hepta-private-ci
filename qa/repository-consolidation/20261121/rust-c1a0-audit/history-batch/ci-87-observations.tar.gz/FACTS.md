# Exact 87 CI：完整 103 checks 与 source coverage 失败

固定 head：`87b141833f2a43e0e87fdb3d4a168e1dacde7a0f`。2026-11-21 14:59:52 UTC 开始一次两页读取，100 + 3 条，103 个独立 check IDs，全部 `head_sha` 匹配。

**68 success、7 failure、17 skipped、1 cancelled、10 in_progress。** 这不是全 CI 终态，不是随后 head 的结果。

## 本轮门禁结果

| Check / job | 结果 | 完成时间 UTC |
|---|---|---|
| Codespell `136874932121` | success | 14:27:28 |
| Blob size `136874932011` | success | 14:35:39 |
| learning.operator deterministic merge `136875657200` | success | 14:56:54 |
| learning.operator exact source `136875657063` | failure | 14:52:42 |
| learning.operator required `136883288039` | failure | 14:57:04 |

## Exact-source 真实失败边界

[原失败 job](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/44913784920/job/136875657063) 的第 6 步 **Exact-source compile, final-use, shadow, revocation and rollback tests** 成功。该步骤原命令包含三包 compile、Bellman 普通及 compatibility-api 测试、两项 Agentd final-use 场景、Shadow lane E、两组严格 Clippy、三包 fmt 和 tracked source 清洁检查。原测试执行计数为 32+5、34+5、1、1、1；这是多次执行，不声称 79 个不同测试身份。

第 7 步 **Independent operator coverage floor** 失败，原命令为：

```sh
cargo llvm-cov --manifest-path codex-rs/Cargo.toml --locked \
  -p codex-hepta-bellman-operator \
  --all-targets \
  --fail-under-lines 85 \
  --json \
  --output-path .hepta-evidence/learning-operator/coverage.json
```

这次覆盖执行的 32 个 lib 测试、5 个 `final_use_v3` 测试全部通过，example 目标 0 测试。14:52:38.3407692 UTC 日志确认报告写出，14:52:39.3145434 UTC 命令返回 1。**原日志没有打印覆盖百分比**。结合失败 step 和原命令，证据指向 85% 行覆盖门槛未满足；不能编造实际百分比，也不能把它写成 Rust 断言或归档空白失败。

第 8–12 步的 safety mutants、bounded performance、implementation map、immutable receipt 和 upload 全部 skipped。因此原源码核心测试/Clippy/fmt 的成功不会补足这些未执行门禁。

## 与 deterministic merge 分开

[deterministic merge job](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/44913784920/job/136875657200) 对同一 source head 的结论为 success。此处没有读取其自建 merge commit 的实际 OID；不得将该通过替换成 exact-source 的 coverage/mutants/performance 通过。

## 覆盖报告保存情况

exact-source 的上传步骤没有 `if: always()`，实际为 skipped。本次对 run `44913784920` artifact 的一页完整读取返回 25/25 条：包含 `learning-operator-merge-87b1418…`，没有 `learning-operator-exact-87b1418…`。因此 runner 内部已经生成的 `coverage.json` 当前不在可见 exact-source artifact 中。没有下载其他 jobs 的未知输出来填补该百分比。

## 其他失败

- Windows Bazel 总结果，以及 shard 2/4、3/4、4/4。
- AppContainer mechanism。
- 上述 learning.operator exact source 与 required。

全部精确 job 链接和运行中检查都保存在 [SUMMARY.json](SUMMARY.json) 与 [CHECK-RUNS-103.json](CHECK-RUNS-103.json)，不重复轮询。

完整 decoded 原日志共 2,393,781 bytes、16,524 行，SHA256 `440b13908c98dc30296e6645c82b41f690050bccb62ae05c3cf4964d7d4f98a3`，无文本归一化。入口：[原日志 gzip](job-136875657063.log.gz)、[原日志 receipt](LOG-RECEIPT.json)、[小段边界摘录](FAILURE-AND-PASS-EXCERPTS.txt)、[原 step 状态](EXACT-SOURCE-JOB-STEPS.json)、[当前 artifact 列表](RUN-ARTIFACTS.json)。

只读调查；没有重跑、取消、新 job、源码修改、阈值/排除/断言修改或 ref 写入。
