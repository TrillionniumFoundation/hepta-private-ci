from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import subprocess

OUT = Path(__file__).resolve().parent
GITDIR = OUT / 'review.git'
TARGET = '87b141833f2a43e0e87fdb3d4a168e1dacde7a0f'
INCOMING = '438a2de93f5fd3bc06f61a0575422dbc4915019d'
BASE = '7ddbfac88525196e7a4b31387ceae194958275f5'
EQUIVALENT = 'a126987b84737dbc2ee2592442a314117bddb4a2'
EXPECTED_TREE = '477005584144e1f9cd9c4e9e280e0a7f7706a487'
env = os.environ.copy()
env['GIT_NO_LAZY_FETCH'] = '1'
env['GIT_OPTIONAL_LOCKS'] = '0'
env['GIT_INDEX_FILE'] = str(OUT / 'resolution.index')

def git(*args, data=None):
    return subprocess.check_output(['git', '--no-replace-objects', '--git-dir=' + str(GITDIR), *args], env=env, input=data, timeout=30)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def headers(oid):
    h = git('cat-file', 'commit', oid).decode().split('\n\n', 1)[0].splitlines()
    return next(x[5:] for x in h if x.startswith('tree ')), [x[7:] for x in h if x.startswith('parent ')]

assert headers(EQUIVALENT) == (headers(INCOMING)[0], [BASE])
assert not git('diff', '--raw', EQUIVALENT, INCOMING)
assert subprocess.run(['git', '--git-dir=' + str(GITDIR), 'merge-base', '--is-ancestor', EQUIVALENT, TARGET], env=env).returncode == 0
metadata = json.loads((OUT / 'METADATA-REVIEW.json').read_text())
assert metadata['protected_intersection'] == metadata['stop_intersection'] == []
lines = (OUT / 'default-merge-02.stdout').read_text().splitlines()
merged_tree = lines[0]
stages = {}
for line in lines[1:]:
    if not line.startswith(('100644 ', '100755 ')) or '\t' not in line:
        continue
    fields, path = line.split('\t', 1)
    mode, oid, stage = fields.split()
    stages.setdefault(path, {})[int(stage)] = {'mode': mode, 'blob': oid}
assert len(stages) == 16
changed = git('diff', '--name-only', TARGET, merged_tree).decode().splitlines()
assert set(changed) == set(stages)

code_reasons = {
    'scripts/hepta-implementation-maps.py': [
        'Preserve the later explicit development/qualification profile parameter and documentation; qualification remains the default.',
        'Preserve rejection of unknown profiles.',
        'Retain the current formatter output for the identical exact-object-ID validation.',
        'Preserve the later development/qualification distinction; clean-candidate validation still applies to qualification.',
        'Keep the current CLI profile option, default and validation; incoming historical version predates this interface.',
        'Retain formatting of the same expected-object CLI validation.',
        'Pass the selected profile through the existing dispatcher rather than removing the later interface.',
    ],
    'scripts/test_hepta_implementation_maps.py': [
        'Keep the current formatting of the same assertion; all 86 incoming test bodies have identical ASTs in the current 88-test file.',
        'Keep the current formatting of the same read_bytes expression; no assertion or source identity check is removed.',
    ],
    'scripts/test_hepta_native_feedback.py': [
        'Keep current formatting of the same engineering-step extraction helper.',
        'Keep current formatting of the same exact-identity step invocation; later workflow-admission and package-scope tests remain intact.',
    ],
    'tools/hepta-engineering-control/control_engineering_v2/__init__.py': [
        'Preserve later exports and current ordering; both historical trust-store/custody names already occur elsewhere in current __all__.',
        'Do not duplicate WorkerProfile; it already occurs once in current __all__.',
        'Preserve the current sorted export list and later heartbeat symbol; historical issue and receipt exports already occur elsewhere.',
        'Preserve later integration observation and current ordering; all historical worker exports already occur elsewhere.',
    ],
    'tools/hepta-engineering-control/control_engineering_v2/product_runtime.py': [
        'Retain later capacity and clock-policy imports required by current admission checks.',
        'Retain the later _admit_new_work call after startup reconciliation and before claim_assignment.',
    ],
}
pattern = re.compile(r'^<<<<<<< ' + TARGET + r'\n(.*?)^=======\n(.*?)^>>>>>>> ' + INCOMING + r'\n', re.M | re.S)
git('read-tree', merged_tree)
ledger = []
json_reviews = []
for path in sorted(stages):
    stage = stages[path]
    assert set(stage) == {1, 2, 3}
    original_merge = git('show', merged_tree + ':' + path)
    text = original_merge.decode('utf-8')
    current = git('cat-file', 'blob', stage[2]['blob'])
    incoming = git('cat-file', 'blob', stage[3]['blob'])
    matches = list(pattern.finditer(text))
    assert matches, path
    if path in code_reasons:
        reasons = code_reasons[path]
        assert len(reasons) == len(matches), (path, len(matches))
    elif path.endswith('/IMPLEMENTATION_MAP.json'):
        reasons = ['Preserve current exact-source bindings, later source observations and recorded gaps; the incoming endpoint is the already-contained PR #1000 tree.'] * len(matches)
    elif path == 'docs/modules/learning.ledger/TECHNICAL.md':
        reasons = ['Retain the later 2026-11-05 acknowledgement and witness-recovery addendum, including its explicit non-activation and no-new-execution limits.'] * len(matches)
    elif path in {'docs/modules/MODULE_DOCS.json', 'qualification/gap-closure/PLAN_AUDIT.json', 'qualification/module-execution-dossiers/DETAILS.json'}:
        reasons = ['Keep the current generated registry/index bindings and later source status. Historical endpoint data remains exactly preserved in the imported branch and its already-contained squash.'] * len(matches)
    else:
        raise AssertionError(path)
    h = []
    for number, (match, reason) in enumerate(zip(matches, reasons), 1):
        h.append({'hunk': number, 'current_bytes': len(match.group(1).encode()), 'incoming_bytes': len(match.group(2).encode()),
                  'current_sha256': sha(match.group(1).encode()), 'incoming_sha256': sha(match.group(2).encode()),
                  'decision': 'retain_reviewed_current_hunk', 'reason': reason})
    resolved = pattern.sub(lambda m: m.group(1), text).encode('utf-8')
    replay_decision = None
    if path == 'scripts/hepta-implementation-maps.py':
        value = resolved.decode()
        check = '    mapping_mode = row.get("mappingSourceIdentityMode", "path_only")\n    if mapping_mode not in {"path_only", "exact_blob"}:\n        raise ValueError(f"unknown mapping source identity mode: {mapping_mode}")\n'
        anchor = '    source = checked_identity(row.get("sourceBase"), candidate)\n'
        assert value.count(check) == 2 and value.count(anchor + check) == 1
        value = value.replace(anchor + check, anchor, 1)
        assert value.count(check) == 1
        resolved = value.encode()
        replay_decision = 'Remove only the replayed duplicate mapping-mode check after checked_identity. The same check already occurs before either profile branch and remains unchanged.'
    elif path == 'scripts/test_hepta_native_feedback.py':
        value = resolved.decode()
        name = 'test_engineering_sandbox_binds_the_actual_matrix_candidate'
        nodes = [n for n in ast.walk(ast.parse(value)) if isinstance(n, ast.FunctionDef) and n.name == name]
        assert len(nodes) == 2 and ast.dump(nodes[0], include_attributes=False) == ast.dump(nodes[1], include_attributes=False)
        lines_value = value.splitlines(keepends=True)
        segment = ''.join(lines_value[nodes[0].lineno - 1:nodes[0].end_lineno])
        assert value.count(segment) == 2 and current.decode().count(segment) == 1
        resolved = value.replace(segment + '\n', '', 1).encode()
        replay_decision = 'Remove only the newly replayed identical test-method duplicate. The existing named method and every original current assertion remain once; the current 24-test roster is unchanged.'
    elif path == 'tools/hepta-engineering-control/control_engineering_v2/__init__.py':
        value = resolved.decode()
        old = '    "WorkerClaim",\n    "WorkerRecoveryReport",\n    "WorkerHeartbeatReceipt",\n'
        new = '    "WorkerClaim",\n    "WorkerHeartbeatReceipt",\n'
        assert value.count(old) == 1 and value.count('    "WorkerRecoveryReport",\n') == 2
        resolved = value.replace(old, new, 1).encode()
        assert resolved.decode().count('    "WorkerRecoveryReport",\n') == 1
        replay_decision = 'Remove only the replayed duplicate WorkerRecoveryReport export. All 126 incoming exports remain in the current 174 unique exports.'
    assert resolved == current, path
    if path.endswith('.json'):
        a, b = json.loads(incoming), json.loads(current)
        json_reviews.append({'path': path, 'incoming_schema': a.get('schema'), 'current_schema': b.get('schema'),
                             'incoming_source_base': a.get('sourceBase'), 'current_source_base': b.get('sourceBase'),
                             'incoming_source_observation': a.get('observedAtHead'), 'current_source_observation': b.get('observedAtHead'),
                             'current_only_top_level_keys': sorted(b.keys() - a.keys()),
                             'incoming_production_implementation': a.get('productionImplementation'), 'current_production_implementation': b.get('productionImplementation')})
    if path.endswith('.py'):
        ast.parse(resolved)
    oid = git('hash-object', '-w', '--stdin', data=resolved).decode().strip()
    assert oid == stage[2]['blob']
    git('update-index', '--add', '--cacheinfo', stage[2]['mode'] + ',' + oid + ',' + path)
    ledger.append({'path': path, 'stages': stage, 'hunks': h, 'automatic_replay_resolution': replay_decision, 'resolved_blob': oid, 'resolved_bytes': len(resolved), 'resolved_sha256': sha(resolved), 'equals_current_blob': True})
resolved_tree = git('write-tree').decode().strip()
assert resolved_tree == EXPECTED_TREE
assert not git('diff', '--raw', TARGET, resolved_tree)
assert not git('diff', '--check', TARGET, resolved_tree)
leaves = git('ls-tree', '-r', '--full-tree', resolved_tree)
result = {
    'reviewer': '/root', 'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'target': TARGET, 'incoming': INCOMING, 'merge_base': BASE, 'already_contained_squash': EQUIVALENT,
    'squash_has_same_parent_as_incoming_chain_base': True, 'squash_and_incoming_complete_trees_equal': True,
    'source_path_count': 55, 'original_endpoint_blobs': 108, 'verified_fetched_missing_blobs': 70,
    'original_net_patch_bytes': (OUT / 'original-net.patch').stat().st_size,
    'original_net_patch_sha256': sha((OUT / 'original-net.patch').read_bytes()),
    'real_default_merge_exit': 1, 'default_merge_conflict_tree': merged_tree,
    'initial_hunk_only_resolution': {'exit_code': 1, 'first_assertion': 'resolved equals current', 'first_file': 'scripts/hepta-implementation-maps.py', 'additional_replays_found_and_reviewed': 3, 'original_extra_diffs_preserved': True},
    'conflicted_files': len(ledger), 'reviewed_hunks': sum(len(r['hunks']) for r in ledger),
    'automatic_nonconflict_changes_from_target': [], 'resolutions': ledger, 'structured_json_review': json_reviews,
    'result_tree': resolved_tree, 'all_leaf_entries': len(leaves.splitlines()), 'leaf_metadata_sha256': sha(leaves),
    'result_equals_current_entire_tree': True, 'ours_strategy_or_option_used': False,
    'all_intermediate_history_payloads_read_claim': False, 'new_ancestor_metadata_count': len(metadata['new_ancestors']),
    'new_tests_executed': False, 'production_code_changed_from_target': False,
    'current_test_roster_or_gate_rules_changed': False,
    'qualification_limit': 'This is endpoint, exact historical-squash and conflict-resolution review. It does not claim a new execution receipt, all intermediate 24 payloads reviewed, full CI qualification, or complete repository source audit.',
    'protection': {'known_protected_nodes': 1471, 'known_current_protected_names': 539, 'incoming_ancestor_intersection': [], 'STOP_ancestor_intersection': [], 'missing_historical_pin_identity_unresolved': True},
    'root_checkout_index_or_refs_changed': False, 'remote_refs_changed': False,
}
(OUT / 'CONFLICT-RESOLUTION-REVIEW.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['result_tree', 'conflicted_files', 'reviewed_hunks', 'all_leaf_entries', 'result_equals_current_entire_tree', 'production_code_changed_from_target']}))
