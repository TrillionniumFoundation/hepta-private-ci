from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess

ROOT = Path('/workspace/scratch/c1a0d7534606')
OUT = ROOT / 'branch-audit/history-batch-87'
GITDIR = OUT / 'sequence.git'
START = '87b141833f2a43e0e87fdb3d4a168e1dacde7a0f'
TREE = '477005584144e1f9cd9c4e9e280e0a7f7706a487'
GROUPS = [
    ('1bc', '1bc77df729081280a17284be3ff52f612f0bbd94', '7b2ec7f7d25517efc8b0023730df9753ec2cb4b2', 'branch-audit/candidate-1bc-on-87/MERGE-REVIEW.json'),
    ('047', '047468e6edd6d7166ed639123d701a26a2568cfd', 'ed43f3ea68a75e044d55f162e5b2d35e1aee8105', 'branch-audit/next-merge-candidates/047468-review/SOURCE-AND-MERGE-REVIEW.json'),
    ('438', '438a2de93f5fd3bc06f61a0575422dbc4915019d', 'b4e88fc0b3f22da9311ed6193b63fe66af8866a0', 'branch-audit/candidate-438-on-87/CONFLICT-RESOLUTION-REVIEW.json'),
    ('a5a', 'a5a5958c3797d281a96fc613827c28404bd404a5', 'ff6e517da9e40649099ccb85dc418f8cfb06883a', 'branch-audit/candidate-a5a-on-87/MERGE-REVIEW.json'),
    ('c6e', 'c6e58e1cf5cbd26f660b2f852884ba2b76dffc7a', '0d117fab5d5f1a0ec28b995c5ae333036e88a9d2', 'branch-audit/next-merge-candidates/c6e58e-review/MERGE-RESULT.json'),
]
OUT.mkdir(exist_ok=True)
if not GITDIR.exists():
    subprocess.run(['git', 'init', '--bare', '--quiet', str(GITDIR)], check=True)
alternates = [ROOT / p for p in [
    'branch-audit/commit-graph.git/objects',
    'audit-repo/.git/objects',
    'branch-audit/candidate-438-on-87/review.git/objects',
    'branch-audit/next-merge-candidates/047468-review/repo/.git/objects',
    'branch-audit/next-merge-candidates/c6e58e-review/repo/.git/objects',
]]
assert all(p.is_dir() for p in alternates)
(GITDIR / 'objects/info/alternates').write_text(''.join(str(p) + '\n' for p in alternates))
env = os.environ.copy()
env.update({'GIT_NO_LAZY_FETCH': '1', 'GIT_OPTIONAL_LOCKS': '0', 'GIT_INDEX_FILE': str(OUT / 'sequence.index'),
            'GIT_AUTHOR_NAME': 'Repository Consolidation Audit', 'GIT_AUTHOR_EMAIL': 'audit@local.invalid',
            'GIT_COMMITTER_NAME': 'Repository Consolidation Audit', 'GIT_COMMITTER_EMAIL': 'audit@local.invalid'})

def command(*args, data=None, check=True):
    p = subprocess.run(['git', '--no-replace-objects', '--git-dir=' + str(GITDIR), *args], input=data, capture_output=True, env=env, timeout=60)
    if check and p.returncode:
        raise RuntimeError((args, p.returncode, p.stderr.decode()))
    return p

def git(*args, data=None):
    return command(*args, data=data).stdout

def digest(data):
    return hashlib.sha256(data).hexdigest()

def commit_data(oid):
    raw = git('cat-file', 'commit', oid)
    head = raw.decode().split('\n\n', 1)[0].splitlines()
    return next(x[5:] for x in head if x.startswith('tree ')), [x[7:] for x in head if x.startswith('parent ')]

def merge(parent, tip, label):
    p = command('merge-tree', '--write-tree', parent, tip, check=False)
    (OUT / (label + '.stdout')).write_bytes(p.stdout)
    (OUT / (label + '.stderr')).write_bytes(p.stderr)
    assert p.returncode in [0, 1], (label, p.returncode, p.stderr.decode())
    lines = p.stdout.decode().splitlines()
    tree = lines[0]
    assert re.fullmatch('[0-9a-f]{40}', tree)
    stages = {}
    for line in lines[1:]:
        if not line.startswith(('100644 ', '100755 ', '120000 ')) or '\t' not in line:
            continue
        fields, path = line.split('\t', 1)
        mode, oid, stage = fields.split()
        stages.setdefault(path, {})[stage] = [mode, oid]
    return {'exit': p.returncode, 'tree': tree, 'stages': stages, 'stdout_sha256': digest(p.stdout)}

def canonical_conflict(data, parent, tip):
    return data.replace(b'<<<<<<< ' + parent.encode() + b'\n', b'<<<<<<< CURRENT\n').replace(b'>>>>>>> ' + tip.encode() + b'\n', b'>>>>>>> INCOMING\n')

receipts = []
parent = START
receipt_path = OUT / 'SEQUENCE-REVIEW.json'
if receipt_path.exists():
    prior_bytes = receipt_path.read_bytes()
    prior = json.loads(prior_bytes)
    assert prior['initial_target'] == START and prior['tree'] == TREE
    receipts = prior['steps']
    assert len(receipts) <= len(GROUPS)
    for step, group in zip(receipts, GROUPS):
        label, tip, reviewed_commit, review_path = group
        assert step['label'] == label and step['reviewed_independent_commit'] == reviewed_commit
        assert step['review_path'] == review_path
        assert step['review_sha256'] == digest((ROOT / review_path).read_bytes())
        assert step['ordered_parents'] == [parent, tip]
        assert commit_data(step['local_commit']) == (TREE, [parent, tip])
        assert digest(git('cat-file', 'commit', step['local_commit'])) == step['raw_commit_sha256']
        parent = step['local_commit']
    assert prior['current_final_local_commit'] == parent
    backup = OUT / ('SEQUENCE-REVIEW-' + str(len(receipts)) + '-steps.json')
    if backup.exists():
        assert backup.read_bytes() == prior_bytes
    else:
        backup.write_bytes(prior_bytes)
for label, tip, reviewed_commit, review_path in GROUPS[len(receipts):]:
    report = (ROOT / review_path).read_bytes()
    assert commit_data(reviewed_commit) == (TREE, [START, tip])
    assert commit_data(parent)[0] == TREE
    old_base = git('merge-base', '--all', START, tip).decode().splitlines()
    new_base = git('merge-base', '--all', parent, tip).decode().splitlines()
    assert old_base == new_base and len(old_base) == 1
    original = merge(START, tip, label + '-independent-default')
    sequential = merge(parent, tip, label + '-sequential-default')
    assert original['exit'] == sequential['exit'] and original['stages'] == sequential['stages']
    difference_paths = git('diff', '--name-only', '--no-renames', original['tree'], sequential['tree']).decode().splitlines()
    assert set(difference_paths) <= set(sequential['stages'])
    for path in sequential['stages']:
        before = git('show', original['tree'] + ':' + path)
        after = git('show', sequential['tree'] + ':' + path)
        assert canonical_conflict(before, START, tip) == canonical_conflict(after, parent, tip), path
    # The same actual three-way inputs produced the same default merge content,
    # except the first-parent labels. Reuse only the independently reviewed file
    # resolutions, including explicitly reviewed automatic replay corrections.
    resolution_paths = git('diff', '--name-only', '--no-renames', original['tree'], reviewed_commit).decode().splitlines()
    current_resolution_paths = git('diff', '--name-only', '--no-renames', sequential['tree'], reviewed_commit).decode().splitlines()
    assert resolution_paths == current_resolution_paths
    git('read-tree', sequential['tree'])
    file_resolutions = []
    for path in resolution_paths:
        entry = git('ls-tree', reviewed_commit, '--', path).decode().strip()
        before_blob = git('rev-parse', sequential['tree'] + ':' + path).decode().strip()
        if entry:
            fields, actual_path = entry.split('\t', 1)
            mode, kind, oid = fields.split()
            assert actual_path == path and kind == 'blob'
            git('update-index', '--add', '--cacheinfo', mode + ',' + oid + ',' + path)
            file_resolutions.append({'path': path, 'default_blob': before_blob, 'reviewed_mode': mode, 'reviewed_blob': oid})
        else:
            git('update-index', '--force-remove', '--', path)
            file_resolutions.append({'path': path, 'default_blob': before_blob, 'reviewed_absent': True})
    result_tree = git('write-tree').decode().strip()
    assert result_tree == TREE
    assert not git('diff', '--raw', parent, result_tree)
    assert not git('diff', '--check', parent, result_tree)
    message = 'Merge reviewed ordinary history ' + tip + '\n\nThe real default merge was rerun against this exact first parent. Original conflict decisions and explicit stale-replay corrections were reused only after three-way identities and normalized default conflict content matched. The complete source tree remains unchanged.\n'
    created = git('commit-tree', result_tree, '-p', parent, '-p', tip, data=message.encode()).decode().strip()
    assert commit_data(created) == (TREE, [parent, tip])
    raw = git('cat-file', 'commit', created)
    (OUT / (label + '-sequence.commit')).write_bytes(raw)
    receipts.append({'label': label, 'local_commit': created, 'ordered_parents': [parent, tip], 'tree': TREE,
                     'reviewed_independent_commit': reviewed_commit, 'review_path': review_path, 'review_sha256': digest(report),
                     'merge_base': old_base, 'independent_default': original, 'sequential_default': sequential,
                     'normalized_default_conflict_content_identical': True, 'file_resolutions': file_resolutions,
                     'full_tree_equals_first_parent': True, 'raw_commit_sha256': digest(raw),
                     'message': message, 'ours_strategy_used': False, 'new_test_execution_claim': False})
    parent = created
    (OUT / 'SEQUENCE-REVIEW.json').write_text(json.dumps({'initial_target': START, 'current_final_local_commit': parent,
        'tree': TREE, 'steps': receipts, 'remote_ref_modified': False, 'root_checkout_modified': False,
        'all_actual_default_merges_executed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
    print(json.dumps({'label': label, 'local_commit': created, 'default_exit': sequential['exit'], 'conflict_files': len(sequential['stages']), 'reviewed_resolution_paths': len(file_resolutions), 'tree': TREE}), flush=True)
