from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess

ROOT = Path('/workspace/scratch/c1a0d7534606')
OUT = ROOT / 'branch-audit/five-group-final-lease'
GITDIR = OUT / 'remote-exact.git'
REMOTE_PATH = ROOT / 'publication-ci-repair/history-batch/REMOTE-MERGE-OBJECTS.json'
LOCAL_PATH = ROOT / 'branch-audit/history-batch-87/SEQUENCE-REVIEW.json'
LEASE_PATH = OUT / 'FINAL-FIVE-GROUP-LEASE-REVIEW.json'
SEQUENCE_PROOF = OUT / 'SEQUENCE-INDEPENDENT-REVIEW.json'
START = '87b141833f2a43e0e87fdb3d4a168e1dacde7a0f'
TREE = '477005584144e1f9cd9c4e9e280e0a7f7706a487'
STOP = 'd783273c25b3164f5f632482cb7b017fdcb9d756'


def sha(data):
    return hashlib.sha256(data).hexdigest()


if not GITDIR.exists():
    subprocess.run(['git', 'init', '--bare', '--quiet', str(GITDIR)], check=True)
(GITDIR / 'objects/info/alternates').write_text(
    str(ROOT / 'branch-audit/history-batch-87/sequence.git/objects') + '\n'
)
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0',
           GIT_INDEX_FILE=str(OUT / 'remote-exact.index'))


def command(*args, check=True):
    p = subprocess.run(
        ['git', '--no-replace-objects', '--git-dir=' + str(GITDIR), *args],
        env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60,
    )
    if check and p.returncode:
        raise RuntimeError((args, p.returncode, p.stderr.decode()))
    return p


def git(*args):
    return command(*args).stdout


def commit(oid):
    raw = git('cat-file', 'commit', oid)
    assert hashlib.sha1(f'commit {len(raw)}\0'.encode() + raw).hexdigest() == oid
    head = raw.split(b'\n\n', 1)[0].decode().splitlines()
    tree = next(x[5:] for x in head if x.startswith('tree '))
    parents = [x[7:] for x in head if x.startswith('parent ')]
    return raw, tree, parents


def normalized(data, parent, tip):
    return data.replace(b'<<<<<<< ' + parent.encode() + b'\n', b'<<<<<<< CURRENT\n').replace(
        b'>>>>>>> ' + tip.encode() + b'\n', b'>>>>>>> INCOMING\n'
    )


remote = json.loads(REMOTE_PATH.read_bytes())
local = json.loads(LOCAL_PATH.read_bytes())
lease = json.loads(LEASE_PATH.read_bytes())
assert remote['initial_target'] == local['initial_target'] == START
assert remote['tree'] == local['tree'] == TREE
assert len(remote['steps']) == len(local['steps']) == 5
refs_before = git('for-each-ref', '--format=%(objectname) %(refname)')
mapping = {r['local_commit']: r['remote_commit'] for r in remote['steps']}
assert len(mapping) == len(set(mapping.values())) == 5
protected = set(json.loads((OUT / 'PROTECTED-KNOWN-DESCENDANTS.json').read_bytes()))
local_ancestors = set(git('rev-list', local['current_final_local_commit']).decode().splitlines())
remote_ancestors = set(git('rev-list', remote['final_remote_merge_commit']).decode().splitlines())
assert {mapping.get(x, x) for x in local_ancestors} == remote_ancestors
assert len(remote_ancestors) == 45038
assert not remote_ancestors.intersection(protected)
assert STOP not in remote_ancestors

steps = []
for r, s in zip(remote['steps'], local['steps']):
    label = r['label']
    assert label == s['label'] and r['local_commit'] == s['local_commit']
    raw, tree, parents = commit(r['remote_commit'])
    assert tree == TREE
    assert parents == [mapping.get(x, x) for x in s['ordered_parents']]
    assert parents == r['ordered_parents'] == [p['sha'] for p in r['remote_metadata']['parents']]
    assert r['remote_metadata']['sha'] == r['remote_commit']
    assert r['remote_metadata']['tree']['sha'] == TREE
    (OUT / f'remote-{label}.commit').write_bytes(raw)
    parent, tip = parents
    assert commit(parent)[1] == TREE
    bases = git('merge-base', '--all', parent, tip).decode().splitlines()
    assert bases == s['merge_base'] and len(bases) == 1
    begin = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cmd = ['merge-tree', '--write-tree', parent, tip]
    p = command(*cmd, check=False)
    finish = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / f'remote-{label}-default.stdout').write_bytes(p.stdout)
    (OUT / f'remote-{label}-default.stderr').write_bytes(p.stderr)
    assert p.returncode == s['sequential_default']['exit'] and p.returncode in (0, 1)
    lines = p.stdout.decode().splitlines()
    default_tree = lines[0]
    assert re.fullmatch('[0-9a-f]{40}', default_tree)
    stages = {}
    for line in lines[1:]:
        if not re.match(r'\d{6} [0-9a-f]{40} [123]\t', line):
            continue
        fields, path = line.split('\t', 1)
        mode, oid, stage = fields.split()
        stages.setdefault(path, {})[stage] = [mode, oid]
    assert stages == s['sequential_default']['stages'] == s['independent_default']['stages']
    differences = git('diff', '--name-only', '--no-renames', s['sequential_default']['tree'], default_tree).decode().splitlines()
    assert set(differences) <= set(stages)
    conflicts = []
    for path in sorted(stages):
        a = git('show', s['sequential_default']['tree'] + ':' + path)
        b = git('show', default_tree + ':' + path)
        na = normalized(a, s['ordered_parents'][0], tip)
        nb = normalized(b, parent, tip)
        assert na == nb, (label, path)
        conflicts.append({'path': path, 'full_normalized_bytes': len(nb), 'full_normalized_sha256': sha(nb)})
    resolution_paths = git('diff', '--name-only', '--no-renames', default_tree, TREE).decode().splitlines()
    assert resolution_paths == [v['path'] for v in s['file_resolutions']]
    assert s['review_sha256'] == sha((ROOT / s['review_path']).read_bytes())
    git('read-tree', default_tree)
    resolutions = []
    for row in s['file_resolutions']:
        path = row['path']
        entry = git('ls-tree', TREE, '--', path).decode().strip()
        before = git('rev-parse', default_tree + ':' + path).decode().strip()
        if row.get('reviewed_absent'):
            assert not entry
            git('update-index', '--force-remove', '--', path)
        else:
            fields, actual = entry.split('\t', 1)
            mode, kind, oid = fields.split()
            assert actual == path and kind == 'blob'
            assert mode == row['reviewed_mode'] and oid == row['reviewed_blob']
            git('update-index', '--add', '--cacheinfo', mode + ',' + oid + ',' + path)
        resolutions.append({**row, 'default_blob': before})
    result = git('write-tree').decode().strip()
    assert result == TREE
    assert not git('diff', '--raw', parent, result)
    assert not git('diff', '--check', parent, result)
    assert not git('ls-files', '--unmerged')
    receipt = {
        'label': label, 'local_commit': s['local_commit'], 'remote_commit': r['remote_commit'],
        'raw_commit_bytes': len(raw), 'raw_commit_sha256': sha(raw), 'raw_commit_oid_verified': True,
        'ordered_parents': parents, 'merge_base': bases, 'command': cmd,
        'started_at_utc': begin, 'finished_at_utc': finish, 'default_exit': p.returncode,
        'default_tree': default_tree, 'stdout_sha256': sha(p.stdout), 'stderr_sha256': sha(p.stderr),
        'conflict_file_count': len(stages), 'conflict_stages': stages,
        'stage_modes_OIDs_identical_to_reviewed_local_execution': True,
        'full_normalized_conflicts': conflicts,
        'all_other_default_tree_entries_equal_reviewed_local_execution': True,
        'resolution_path_count': len(resolution_paths), 'resolutions': resolutions,
        'review_path': s['review_path'], 'review_sha256': s['review_sha256'],
        'result_tree': result, 'result_tree_equals_actual_remote_commit_tree': True,
    }
    steps.append(receipt)
    print(json.dumps({'label': label, 'exit': p.returncode, 'conflict_files': len(stages),
                      'resolutions': len(resolution_paths), 'tree': result}), flush=True)

refs_after = git('for-each-ref', '--format=%(objectname) %(refname)')
assert refs_before == refs_after
inputs = [REMOTE_PATH, LOCAL_PATH, LEASE_PATH, SEQUENCE_PROOF,
          OUT / 'REMOTE-EXACT-METADATA-FETCH.json', Path(__file__)]
report = {
    'schema_version': 1, 'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/branch_protection_audit',
    'verdict': 'verified_five_actual_default_merges_against_literal_GitHub_first_parents',
    'scope': 'Exact GitHub commit metadata, actual merge-tree execution, frozen resolution reuse and tree identity; no product execution or remote ref mutation',
    'inputs': {str(p.relative_to(ROOT)): {'bytes': len(p.read_bytes()), 'sha256': sha(p.read_bytes())} for p in inputs},
    'initial_target': START, 'local_final': local['current_final_local_commit'],
    'remote_final': remote['final_remote_merge_commit'], 'tree': TREE,
    'steps': steps, 'ancestor_count': len(remote_ancestors),
    'ancestor_graph_isomorphic_to_original_local_chain': True,
    'known_protected_ancestor_intersection': sorted(remote_ancestors & protected),
    'STOP_anchor_in_ancestry': False, 'historical_551st_pin_identity_unrecovered': True,
    'coverage_fixed_snapshot_sha256': lease['snapshot_sha256'], 'coverage': lease['coverage'],
    'all_literal_remote_parent_default_merges_executed': True,
    'all_original_reviewed_modes_OIDs_and_full_normalized_conflicts_equal': True,
    'all_reviewed_resolution_path_sets_equal': True,
    'all_result_trees_equal_actual_remote_commit_trees': True,
    'ours_strategy_used': False, 'product_tests_executed': False,
    'remote_ref_update_claim': False, 'own_refs_before_after_equal': refs_before == refs_after,
    'root_checkout_or_other_agent_index_modified': False,
    'immutable_existing_fresh_and_local_sequence_reports_modified': False,
    'limits': [
        'GitHub object existence is not branch publication.',
        'Coverage belongs to the one captured 7831-ref snapshot and does not freeze later refs.',
        'No main or full-CI qualification is implied.',
        'Merkle tree/index verification does not assert that every repository payload blob was downloaded.',
        'Historical intermediate payloads remain subject to the original individual review limitations.',
    ],
}
p = OUT / 'REMOTE-EXACT-PARENT-MERGE-REVIEW.json'
p.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}), flush=True)
