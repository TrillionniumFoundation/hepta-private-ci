#!/usr/bin/env python3
"""Resume two never-executed native test suites after verified owned-target relocation.

The immutable first attempt remains authoritative for its successful Clippy and
real helper builds and its two compilation failures. No passed stage is rerun.
This task uses the unchanged original runner's command/test/format implementations.
Only the target filesystem changes; its logical path and all flags stay identical.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


ROOT = Path('/home/qian-qi/hepta-c1a0-native-20261121-01')
HEAD = '5a42644ff02a511e12ce2f95f1c11f85b709835f'
TREE = 'cf4965757cc8ef01109c06b40ade160f3a6f57bb'
LOGICAL_TARGET = Path('/tmp/hepta-c1a0-native-20261121-01-target')
CANONICAL_TARGET = ROOT / 'target'
OLD = ROOT / 'validation-01'
BASE_RUNNER = ROOT / 'run_native_validation.py'
BASE_RUNNER_SHA256 = 'b8a204ed33848e8f07a470adba720164dd15676cea9f5bd2313895b50664d56c'
RELOCATION = ROOT / 'target-relocation-01/FINAL.json'
RELOCATION_SHA256 = 'edb7eb81f8d56af5b908a76f17d806bc082738249651d5779cdc872f59c851cf'

if hashlib.sha256(BASE_RUNNER.read_bytes()).hexdigest() != BASE_RUNNER_SHA256:
    raise SystemExit('Original runner bytes differ; no recovery dispatched')
spec = importlib.util.spec_from_file_location('original_native_validation', BASE_RUNNER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
require = base.require


def read_json(path: Path):
    return json.loads(path.read_text())


def same_bytes(observed: dict, original: dict):
    return all(observed[k] == original[k] for k in ('path', 'bytes', 'sha256', 'git_blob', 'mode'))


class ResumeRunner(base.FullRunner):
    def __init__(self):
        self.args = argparse.Namespace(
            repo=ROOT / 'repo', target_dir=LOGICAL_TARGET, output_dir=ROOT / 'validation-02',
            expected_head=HEAD, expected_tree=TREE, v8_assets_json=ROOT / 'V8-ASSET-INPUTS.json',
            python_executable=Path('/usr/bin/python3.12'),
            cargo_executable=Path('/home/qian-qi/.cargo/bin/cargo'),
            just_executable=Path('/home/qian-qi/.cargo/bin/just'),
        )
        self.started = time.monotonic()
        self.deadline = self.started + base.BUDGET_SECONDS
        self.repo = self.args.repo.resolve(strict=True)
        # Preserve this exact string in CARGO_TARGET_DIR and runtime helper bindings.
        self.target = LOGICAL_TARGET
        self.canonical_target = self.target.resolve(strict=True)
        self.out = self.args.output_dir
        require(self.repo == ROOT / 'repo', 'unexpected native source path')
        require(self.target.is_symlink() and self.canonical_target == CANONICAL_TARGET,
                'verified original target symlink is absent or changed')
        require(self.canonical_target.stat().st_dev == 66306, 'target is not the verified home device')
        require(not self.canonical_target.is_relative_to(self.repo), 'target is inside source')
        require(not self.out.is_relative_to(self.repo) and not self.out.is_relative_to(self.canonical_target),
                'audit output is inside source or target')
        require(self.out.parent.is_dir(), 'output parent is absent')
        self.out.mkdir(mode=0o700, exist_ok=False)
        self.stages = []
        self.artifacts = {}
        self.controls = None
        self.original_identity = None
        self.assets = {}
        self.env = {}
        self.formatting_started = False
        self.result = {
            'schema_version': 1, 'status': 'running', 'started_at': base.utc_now(),
            'expected_head': HEAD, 'expected_tree': TREE, 'baseline': base.BASELINE,
            'repo': str(self.repo), 'target': str(self.target),
            'target_canonical': str(self.canonical_target), 'target_device': 66306,
            'total_budget_seconds': base.BUDGET_SECONDS, 'progress_seconds': base.PROGRESS_SECONDS,
            'qualification_scope': 'only original Agentd/AuthBus just test and one final fmt plus check',
            'planned_stages': ['03-agentd-just-test', '04-authbus-just-test', '06-final-fmt', '07-final-fmt-check'],
            'prior_attempt': str(OLD), 'prior_attempt_failures_preserved': True,
            'passed_clippy_helpers_and_github_314_tests_rerun': False,
            'resource_plan': {
                'target_relocation_only': True, 'cargo_build_jobs': 4, 'nice': 5,
                'dev_debug': 0, 'test_debug': 0, 'incremental': False,
                'total_budget_seconds': 10800, 'per_command_maximum_seconds': 3600,
                'total_budget_scope': 'new recovery attempt, not the first attempt absolute deadline',
                'initial_recovery_reserve_gib': 12,
                'original_per_stage_minimum_disk_gib': 4,
                'minimum_available_memory_gib': 16,
                'source_profile_deadlines_unchanged': True,
            },
        }
        base.write_json(self.out / 'REQUEST.json', self.result)

    def recovery_preflight(self):
        relocation_identity = base.file_identity(RELOCATION)
        require(relocation_identity['sha256'] == RELOCATION_SHA256, 'terminal relocation receipt changed')
        relocation = read_json(RELOCATION)
        require(relocation['status'] == 'relocated_verified' and relocation['copy_verified']
                and relocation['original_tmp_copy_released'], 'owned target relocation is incomplete')
        require(relocation['canonical_target_after'] == str(self.canonical_target)
                and relocation['original_logical_path_retained'] == str(self.target),
                'relocation receipt paths differ')
        require(relocation['source_manifest']['normalized_manifest_sha256']
                == relocation['destination_manifest']['normalized_manifest_sha256'],
                'complete source/destination manifests differ')
        require(shutil.disk_usage(self.target).free >= 12 * 1024**3,
                'fewer than 12 GiB remain on verified home target; no test dispatch')
        self.preflight()
        old_preflight = read_json(OLD / 'PREFLIGHT.json')
        new_preflight = read_json(self.out / 'PREFLIGHT.json')
        for key in ('source', 'controls', 'tools', 'environment_overrides', 'path_prefixes', 'v8_assets'):
            require(new_preflight[key] == old_preflight[key], f'original {key} changed during recovery')
        previous = read_json(OLD / 'FINAL.json')
        require(previous['status'] == 'failed' and previous['exit_code'] == 1
                and previous['expected_head'] == HEAD and previous['expected_tree'] == TREE
                and previous['source_unchanged'] and not previous['formatting_run'],
                'first attempt does not match this exact terminal recovery')
        stages = {item['stage']: item for item in previous['stages']}
        require(set(stages) == {'00-three-package-strict-clippy', '01-build-codex', '02-build-worker-bins',
                                '03-agentd-just-test', '04-authbus-just-test'},
                'first attempt stage identity differs')
        prior_receipts = {}
        for name, stage in stages.items():
            execution_path = OLD / f'{name}.exec.json'
            execution = read_json(execution_path)
            require(execution == stage['execution_record'], 'first attempt execution/result differs')
            require(execution['before'] == self.original_identity and execution['after'] == self.original_identity,
                    'first attempt source identity differs')
            log = base.file_identity(OLD / execution['log_file'])
            require(log['sha256'] == execution['log_sha256'] and log['bytes'] == execution['log_bytes'],
                    'first attempt full command log changed')
            if name.startswith(('00-', '01-', '02-')):
                require(stage['status'] == 'passed' and execution['status'] == 'passed'
                        and execution['command_exit_code'] == 0 and execution['exit_code'] == 0,
                        'previous passing stage is not passing')
            else:
                require(stage['status'] == 'failed' and execution['command_exit_code'] == 101
                        and execution['observed_passed_tests'] == 0 and execution['observed_failed_tests'] == 0,
                        'recovery would repeat already executed tests')
            prior_receipts[name] = {
                'execution_record_file': base.file_identity(execution_path),
                'status': execution['status'], 'command_exit_code': execution['command_exit_code'],
                'command': execution['command'], 'command_log': log,
                'observed_passed_tests': execution['observed_passed_tests'],
                'observed_failed_tests': execution['observed_failed_tests'],
            }
        base.write_json(self.out / 'REUSED-PASSED-STAGES.json', {
            'source_head': HEAD, 'source_tree': TREE, 'prior_final': base.file_identity(OLD / 'FINAL.json'),
            'original_preflight': base.file_identity(OLD / 'PREFLIGHT.json'),
            'original_runner': base.file_identity(BASE_RUNNER),
            'recovery_runner': base.file_identity(Path(__file__).resolve()),
            'relocation_receipt': relocation_identity, 'prior_stages': prior_receipts,
            'recorded_source_toolchain_flags_controls_and_per_command_deadlines_unchanged': True,
            'unrecorded_ambient_environment_claimed_frozen': False,
            'clippy_and_helper_builds_reexecuted': False,
        })
        runtime = read_json(OLD / 'RUNTIME-HELPERS.json')
        require(runtime['source_head'] == HEAD and runtime['source_tree'] == TREE, 'old helper source differs')
        for name in ('01-build-codex', '02-build-worker-bins'):
            artifact_record = read_json(OLD / f'{name}.ARTIFACTS.json')
            require(artifact_record['source_head'] == HEAD and artifact_record['source_tree'] == TREE
                    and artifact_record['build_finished'] == {'reason': 'build-finished', 'success': True},
                    'original Cargo artifact source/result differs')
            log = prior_receipts[name]['command_log']
            require(same_bytes(log, artifact_record['command_log']), 'Cargo artifact log binding differs')
            for original in artifact_record['artifacts']:
                message = original['compiler_artifact']
                target_name = message['target']['name']
                executable = original['executable']
                require(message['reason'] == 'compiler-artifact' and message['profile']['test'] is False
                        and message['executable'] == executable['path'], 'artifact is not original real helper')
                require(executable == runtime['artifacts_before_test'][target_name], 'runtime artifact binding differs')
                path = Path(executable['path'])
                require(path.is_relative_to(self.target) and path.resolve(strict=True).is_relative_to(self.canonical_target),
                        'runtime helper is outside the verified owned target')
                current = base.file_identity(path, elf=True)
                require(same_bytes(current, executable) and current['elf'] == executable['elf'],
                        'runtime helper content/mode/ELF changed in relocation')
                relocated = relocation['helpers'][target_name]
                require(current['sha256'] == relocated['sha256'] and current['bytes'] == relocated['bytes']
                        and current['device'] == relocated['new_device'] and current['inode'] == relocated['new_inode'],
                        'runtime helper differs from verified relocation inode/content')
                require(target_name not in self.artifacts, 'duplicate helper artifact')
                bound = copy.deepcopy(original)
                bound['original_pre_relocation_executable'] = executable
                bound['executable'] = current
                self.artifacts[target_name] = bound
        require(set(self.artifacts) == {'codex', 'hepta-infer-worker', 'hepta-joint-propose'},
                'exact original three helper artifacts are required')
        bindings = {}
        for name, item in self.artifacts.items():
            for alias in {name, name.replace('-', '_')}:
                bindings[f'CARGO_BIN_EXE_{alias}'] = item['executable']['path']
        require(bindings == runtime['bindings'], 'original helper logical path bindings changed')
        self.env.update(bindings)
        base.write_json(self.out / 'REUSED-RUNTIME-HELPERS.json', {
            'source_head': HEAD, 'source_tree': TREE, 'bindings': bindings,
            'original_runtime_receipt': base.file_identity(OLD / 'RUNTIME-HELPERS.json'),
            'artifacts_before_test': self.verify_artifacts(),
            'artifacts_with_original_compiler_provenance': self.artifacts,
            'selection': 'same successful compiler artifacts from this task; only verified device/inode relocation',
            'helpers_rebuilt': False,
        })
        self.result['recovery_preflight_passed'] = True
        base.emit({'stage': 'recovery-preflight', 'state': 'passed',
                   'disk_free_bytes': shutil.disk_usage(self.target).free,
                   'target_logical': str(self.target), 'target_canonical': str(self.canonical_target)})

    def run(self):
        exit_code = 2
        failures = []
        try:
            os.nice(5)
            self.recovery_preflight()
            for name, package in (('03-agentd-just-test', 'codex-hepta-agentd'),
                                  ('04-authbus-just-test', 'codex-hepta-authbus')):
                self.verify_artifacts()
                try:
                    self.run_stage(name, [str(self.args.just_executable), 'test', '-p', package, '--locked'], self.repo, 1)
                except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, base.AuditFailure) as error:
                    failures.append({'stage': name, 'error': str(error)})
                    base.emit({'stage': name, 'state': 'failed', 'error': str(error)})
                self.result['artifacts_after_test'] = self.verify_artifacts()
            if not failures:
                self.result['formatting'] = self.final_format()
                if self.result['formatting']['status'] != 'passed':
                    failures.append({'stage': 'final-formatting', 'error': 'original formatter/check failed'})
            exit_code = 1 if failures else 0
            self.result['status'] = 'failed' if failures else 'passed'
        except KeyboardInterrupt:
            exit_code = 130
            self.result['status'] = 'interrupted'
            failures.append({'stage': 'runner', 'error': 'Interrupted; original command receipts remain authoritative'})
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, base.AuditFailure) as error:
            exit_code = error.exit_code if isinstance(error, base.AuditFailure) else 2
            self.result['status'] = 'failed'
            failures.append({'stage': 'runner', 'error': str(error)})
        finally:
            try:
                if self.formatting_started:
                    source = {'commit': self.git('rev-parse', 'HEAD'), 'tree': self.git('rev-parse', 'HEAD^{tree}'),
                              'dirty': bool(self.git('status', '--porcelain=v1', '--untracked-files=normal'))}
                    require(source['commit'] == HEAD and source['tree'] == TREE, 'formatter moved frozen source')
                    self.result['source_after'] = source
                    self.result['source_unchanged'] = not source['dirty']
                    self.result['source_unchanged_through_validation'] = True
                else:
                    self.result['source_after'], self.result['controls_after'] = self.source_state()
                    self.result['source_unchanged'] = self.original_identity is not None
            except (OSError, ValueError, subprocess.SubprocessError, base.AuditFailure) as error:
                exit_code = exit_code or 2
                self.result['status'] = 'failed'
                self.result['source_unchanged'] = False
                failures.append({'stage': 'source-postcheck', 'error': str(error)})
            self.result.update({
                'finished_at': base.utc_now(), 'elapsed_seconds': time.monotonic() - self.started,
                'exit_code': exit_code, 'stages': self.stages, 'failures': failures,
                'remote_refs_changed': False, 'source_edits': bool(self.result.get('source_after', {}).get('dirty')),
                'formatting_run': self.formatting_started, 'direct_cargo_test_run': False,
                'tests_run_after_formatting': False,
            })
            base.write_json(self.out / 'FINAL.json', self.result)
            base.emit({'stage': 'complete', 'status': self.result['status'], 'exit_code': exit_code,
                       'head': HEAD, 'tree': TREE, 'output': str(self.out)})
        return exit_code


if __name__ == '__main__':
    os.umask(0o077)
    try:
        raise SystemExit(ResumeRunner().run())
    except (OSError, ValueError, base.AuditFailure) as error:
        base.emit({'status': 'rejected_before_dispatch', 'error': str(error)})
        raise SystemExit(2)
