#!/usr/bin/env python3
"""Build real helper binaries, bind current Cargo artifacts, then run original Agentd tests.

This external audit runner writes only its new output directory and Cargo's declared
target/cache outputs. It does not edit source, refs, tests, profiles or deadlines.
The unchanged repository hepta_ci_exec.py owns command timeout/process boundaries.
An absent, rejected, interrupted or failed result is never a passing qualification.
This continuation uses a new independent target directory; no old target is read or written.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import stat
import struct
import subprocess
import sys
import time
import tomllib


BUDGET_SECONDS = 10800
PROGRESS_SECONDS = 30
TOOLCHAIN = "1.96.0"
BASELINE = "65b720ec799ac278aadcc54c9466b7d17df235c7"
SOURCE_PINS = {
    "AGENTS.md": "c3f80e8386eb170b00af1e21de40d770c4941e464915687e728e2d14a7e79480",
    "justfile": "74f869224eba12fc4212b043428e7f5b35b551d26f5b06161c25d8aca525f124",
    "scripts/hepta_ci_exec.py": "8c8dc75d51de8473a692df91ae4f89491692ef969a32220f4e5d406bb8fe255d",
    "scripts/just-shell.py": "444d6b328d44abf6453b77b6acce2a0c881fc162ff30b20f352c85067797fbe9",
    "scripts/run-nextest.py": "45c4e35d1ff24840d9e1e05331af0b89475bfe1aec3231afc56fecb8cea66127",
    "codex-rs/.config/nextest.toml": "72a4a810750bafa704541b9814a22a080774ab5efd7c135bb197f421ba217860",
    "codex-rs/cli/Cargo.toml": "1816bcd8b45bd0a90ac6ece402d0ef40b1cab52eea0790e1b5e3119d439806e3",
    "codex-rs/hepta-infer-worker-host/Cargo.toml": "6666ca3470a014d33e3b7341d9b63538aed3e43528a13c4b5cc6a61335eaf900",
    "codex-rs/utils/cargo-bin/src/lib.rs": "60ddd03a487b197b0519f2fcee3d228b855b75ecaa0fe8cfd3ad623b1a940b42",
}
EXTRA_CONTROLS = (
    "codex-rs/Cargo.toml",
    "codex-rs/Cargo.lock",
    "codex-rs/rust-toolchain.toml",
    "codex-rs/.cargo/config.toml",
)
ASSET_ENVIRONMENT = {"RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH"}


class AuditFailure(Exception):
    def __init__(self, message: str, exit_code: int = 2):
        super().__init__(message)
        self.exit_code = exit_code if 0 < exit_code < 256 else 1


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AuditFailure(message)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def emit(value: dict) -> None:
    print(json.dumps(value, sort_keys=True), flush=True)


def write_json(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def file_identity(path: Path, *, elf: bool = False) -> dict:
    """Hash an opened regular file and reject replacement/mutation during the read."""
    require(path.is_absolute(), f"file path must be absolute: {path}")
    descriptor = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), f"not a regular file: {path}")
        digest = hashlib.sha256()
        blob = hashlib.sha1(b"blob " + str(before.st_size).encode() + b"\0")
        header = b""
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            if not header:
                header = chunk[:64]
            digest.update(chunk)
            blob.update(chunk)
        after = os.fstat(stream.fileno())
    unchanged = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
    require(unchanged == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            f"file changed while hashing: {path}")
    current = path.stat(follow_symlinks=False)
    require((current.st_dev, current.st_ino) == (before.st_dev, before.st_ino),
            f"file replaced while hashing: {path}")
    result = {"path": str(path), "bytes": before.st_size, "sha256": digest.hexdigest(),
              "git_blob": blob.hexdigest(), "mode": oct(stat.S_IMODE(before.st_mode)),
              "device": before.st_dev, "inode": before.st_ino}
    if elf:
        require(before.st_mode & 0o111 != 0 and os.access(path, os.X_OK), f"not executable: {path}")
        require(len(header) == 64 and header[:4] == b"\x7fELF", f"not an ELF executable: {path}")
        require(header[4:7] == b"\x02\x01\x01", f"not an ELF64 little-endian v1 executable: {path}")
        elf_type, machine = struct.unpack_from("<HH", header, 16)
        require(elf_type in (2, 3), f"ELF type is not EXEC or PIE: {path}")
        require(platform.machine().lower() in {"x86_64", "amd64"} and machine == 62,
                f"artifact is not a native x86_64 ELF executable: {path}")
        result["elf"] = {"class": 64, "byte_order": "little", "type": elf_type, "machine": machine}
    return result


class Runner:
    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.started = time.monotonic()
        self.deadline = self.started + BUDGET_SECONDS
        self.repo = args.repo.resolve(strict=True)
        self.target = args.target_dir.resolve(strict=True)
        self.out = args.output_dir.resolve()
        require(self.repo.is_dir() and self.target.is_dir(), "repo and target must be existing directories")
        require(not self.target.is_relative_to(self.repo), "Cargo target must be outside source")
        require(not self.out.is_relative_to(self.repo) and not self.out.is_relative_to(self.target),
                "audit output must be outside source and Cargo target")
        for value in (args.expected_head, args.expected_tree):
            require(re.fullmatch(r"[0-9a-f]{40}", value) is not None, "full lowercase Git head/tree required")
        require(self.out.parent.is_dir(), "audit output parent must already exist")
        self.out.mkdir(mode=0o700, exist_ok=False)
        self.stages: list[dict] = []
        self.artifacts: dict[str, dict] = {}
        self.controls: dict[str, dict] | None = None
        self.original_identity: dict | None = None
        self.assets: dict = {}
        self.env: dict[str, str] = {}
        self.result = {"schema_version": 1, "status": "running", "started_at": utc_now(),
                       "expected_head": args.expected_head, "expected_tree": args.expected_tree,
                       "baseline": BASELINE, "repo": str(self.repo), "target": str(self.target),
                       "total_budget_seconds": BUDGET_SECONDS, "progress_seconds": PROGRESS_SECONDS,
                       "qualification_scope": "real helper builds, original scoped Agentd/AuthBus just test, and original three-package strict Clippy"}
        write_json(self.out / "REQUEST.json", self.result)

    def git(self, *arguments: str) -> str:
        return subprocess.check_output(["git", "-C", str(self.repo), *arguments], text=True).strip()

    def source_state(self) -> tuple[dict, dict]:
        require(Path(self.git("rev-parse", "--show-toplevel")).resolve() == self.repo, "repo is not its Git root")
        metadata = self.git("cat-file", "-p", "HEAD").split("\n\n", 1)[0].splitlines()
        identity = {"commit": self.git("rev-parse", "HEAD"), "tree": self.git("rev-parse", "HEAD^{tree}"),
                    "parents": [line[7:] for line in metadata if line.startswith("parent ")],
                    "dirty": bool(self.git("status", "--porcelain=v1", "--untracked-files=normal"))}
        require(identity["commit"] == self.args.expected_head and identity["tree"] == self.args.expected_tree,
                "source head/tree differs from the explicit candidate")
        require(not identity["dirty"], "source checkout is dirty")
        controls = {}
        for relative in (*SOURCE_PINS, *EXTRA_CONTROLS):
            path = self.repo / relative
            item = file_identity(path)
            require(item["git_blob"] == self.git("rev-parse", f"HEAD:{relative}"),
                    f"control bytes differ from HEAD: {relative}")
            if relative in SOURCE_PINS:
                require(item["sha256"] == SOURCE_PINS[relative], f"original control changed: {relative}")
            controls[relative] = {k: item[k] for k in ("bytes", "sha256", "git_blob")}
        if self.original_identity is not None:
            require(identity == self.original_identity, "source identity changed during the audit")
            require(controls == self.controls, "source controls changed during the audit")
        return identity, controls

    def prepare_assets(self) -> dict[str, str]:
        supplied = self.args.v8_assets_json
        inherited = sorted(key for key in self.env if key.startswith("RUSTY_V8_") or key == "V8_FROM_SOURCE")
        if supplied is None:
            require(not inherited, "inherited V8 overrides require an explicit reviewed asset manifest")
            return {}
        manifest_path = supplied.resolve(strict=True)
        require(not manifest_path.is_relative_to(self.repo), "asset audit manifest must be outside source")
        manifest = json.loads(manifest_path.read_text())
        require(manifest.get("schema_version") == 1, "unsupported V8 asset manifest schema")
        version = manifest["v8_version"]
        lock = tomllib.loads((self.repo / "codex-rs/Cargo.lock").read_text())
        versions = {p["version"] for p in lock["package"] if p["name"] == "v8"}
        require(versions == {version}, "V8 asset version does not exactly match the locked v8 package")
        expected_keys = {item["environment"] for item in manifest["assets"]}
        require(expected_keys == ASSET_ENVIRONMENT and len(manifest["assets"]) == 2,
                "both explicit V8 archive and bindings are required")
        require(not (set(inherited) - ASSET_ENVIRONMENT), "unreviewed inherited V8 feature/download override")
        self.assets = {"manifest": file_identity(manifest_path), "v8_version": version, "files": []}
        environment = {}
        for item in [*manifest["assets"], manifest["published_checksums"]]:
            path = Path(item["path"])
            require(path.is_absolute() and path.resolve(strict=True) == path,
                    "V8 assets must be explicit canonical local files")
            observed = file_identity(path)
            require(observed["sha256"] == item["sha256"] and observed["bytes"] == item["bytes"],
                    f"V8 asset identity differs: {path}")
            prefix = f"https://github.com/openai/codex/releases/download/rusty-v8-v{version}/"
            require(item["source_url"] == prefix + path.name, "V8 official release source/version differs")
            self.assets["files"].append({**observed, "source_url": item["source_url"]})
            if "environment" in item:
                environment[item["environment"]] = str(path)
        checksums = Path(manifest["published_checksums"]["path"]).read_text().splitlines()
        published = {}
        for line in checksums:
            match = re.fullmatch(r"([0-9a-f]{64})\s+\*?([^/\\\s]+)", line.strip())
            require(match is not None, "unexpected published V8 checksum syntax")
            require(match[2] not in published, "duplicate published V8 checksum filename")
            published[match[2]] = match[1]
        for item in manifest["assets"]:
            require(published.get(Path(item["path"]).name) == item["sha256"],
                    "V8 asset differs from the original published checksum")
        return environment

    def preflight(self) -> None:
        self.original_identity, self.controls = self.source_state()
        self.env = os.environ.copy()
        removed = sorted(key for key in self.env if key.startswith(("CARGO_BIN_EXE_", "NEXTEST_BIN_EXE_")))
        for key in removed:
            del self.env[key]
        require("RUNFILES_MANIFEST_ONLY" not in self.env, "Cargo validation cannot inherit Bazel runfiles mode")
        overrides = {"PYTHONDONTWRITEBYTECODE": "1", "SOURCE_SHA": self.args.expected_head,
                     "TESTED_SHA": self.args.expected_head, "BASE_SHA": BASELINE, "HEPTA_CI_LANE": "source-head",
                     "CARGO_TARGET_DIR": str(self.target), "CARGO_BUILD_JOBS": "4", "CARGO_INCREMENTAL": "0",
                     "CARGO_PROFILE_DEV_DEBUG": "0", "CARGO_PROFILE_TEST_DEBUG": "0", "RUSTUP_TOOLCHAIN": TOOLCHAIN}
        overrides.update(self.prepare_assets())
        self.env.update(overrides)
        # Keep the reviewed root's auxiliary tools; select the declared Cargo shim first.
        prefixes = [str(self.repo.parent / "bin"), str(self.args.cargo_executable.parent)]
        self.env["PATH"] = os.pathsep.join([*prefixes, self.env.get("PATH", "")])
        tools = {}
        for name, path in (("cargo", self.args.cargo_executable), ("just", self.args.just_executable),
                           ("python", self.args.python_executable)):
            require(path.is_absolute() and os.access(path, os.X_OK), f"missing declared executable: {path}")
            tools[name] = {"invoked_path": str(path), "resolved_file": file_identity(path.resolve(strict=True))}
        require(Path(shutil.which("cargo", path=self.env["PATH"]) or "") == self.args.cargo_executable,
                "just/nextest would select a different Cargo executable")
        nextest_path = self.repo.parent / "bin/cargo-nextest"
        require(Path(shutil.which("cargo-nextest", path=self.env["PATH"]) or "") == nextest_path,
                "just/Cargo would select a different third-party nextest executable")
        nextest_identity = file_identity(nextest_path, elf=True)
        require(nextest_identity["sha256"] == "eae075c1f810a15aa3ffa31d774d2a9e3dbbbab3d0a1b8c3abad4f2cdb64c2b3",
                "original native nextest tool identity changed")
        tools["cargo-nextest"] = {"invoked_path": str(nextest_path), "resolved_file": nextest_identity,
                                 "version": "0.9.152", "matches_original_native_helper_tool": True,
                                 "not_claimed_as_ci_pinned_0_9_103": True}
        write_json(self.out / "PREFLIGHT.json", {"source": self.original_identity, "controls": self.controls,
                   "tools": tools, "environment_overrides": overrides, "path_prefixes": prefixes,
                   "discarded_stale_binary_metadata_keys": removed, "v8_assets": self.assets,
                   "disk_free_bytes": shutil.disk_usage(self.target).free,
                   "runner": file_identity(Path(__file__).resolve())})

    def run_stage(self, name: str, command: list[str], cwd: Path, minimum_tests: int) -> Path:
        before, _ = self.source_state()
        require(shutil.disk_usage(self.target).free >= (8 if name in {"00-three-package-strict-clippy", "01-build-codex"} else 4) * 1024**3,
                "fresh owned target has insufficient free disk for this declared stage; no dispatch")
        memory_fields = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
        available_memory = int(memory_fields["MemAvailable"].split()[0]) * 1024
        require(available_memory >= 16 * 1024**3,
                "less than 16 GiB available memory before this Cargo/test stage; no dispatch")
        remaining = min(3600, self.deadline - time.monotonic())
        require(remaining > 0, "total 10800-second audit budget exhausted before dispatch")
        record_path = self.out / f"{name}.exec.json"
        wrapper = [str(self.args.python_executable), str(self.repo / "scripts/hepta_ci_exec.py"),
                   "--timeout-seconds", str(remaining), "--minimum-tests", str(minimum_tests),
                   "--output", str(record_path), "--", *command]
        result = {"stage": name, "status": "running", "started_at": utc_now(), "command": command,
                  "working_directory": str(cwd), "wrapper_argv": wrapper, "before": before,
                  "remaining_task_budget_seconds_at_dispatch": remaining, "minimum_tests": minimum_tests}
        stdout_path = self.out / f"{name}.wrapper.stdout.log"
        stderr_path = self.out / f"{name}.wrapper.stderr.log"
        started = time.monotonic()
        failure = None
        log_path = None
        emit({"stage": name, "state": "starting", "remaining_task_budget_seconds": round(remaining, 3)})
        try:
            with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
                process = subprocess.Popen(wrapper, cwd=cwd, env=self.env, stdout=stdout, stderr=stderr)
                while process.poll() is None:
                    try:
                        process.wait(timeout=PROGRESS_SECONDS)
                    except subprocess.TimeoutExpired:
                        emit({"stage": name, "state": "running", "elapsed_seconds": round(time.monotonic() - started, 1),
                              "remaining_task_budget_seconds": round(max(0, self.deadline - time.monotonic()), 1),
                              "stdout_bytes": stdout_path.stat().st_size, "stderr_bytes": stderr_path.stat().st_size,
                              "disk_free_bytes": shutil.disk_usage(self.target).free})
                result["wrapper_exit_code"] = process.returncode
            require(record_path.is_file(), "repository helper produced no execution record")
            execution = json.loads(record_path.read_text())
            result["execution_record"] = execution
            result["execution_record_file"] = file_identity(record_path)
            require(execution["command"] == command and execution["working_directory"] == str(cwd),
                    "execution record command or working directory differs")
            require(execution["source_sha"] == self.args.expected_head and execution["tested_sha"] == self.args.expected_head
                    and execution["lane"] == "source-head", "execution record source-head binding differs")
            require(execution["before"] == before and execution["after"] == before,
                    "repository helper observed changed source identity")
            filename = execution["log_file"]
            require(isinstance(filename, str) and Path(filename).name == filename, "invalid repository helper log filename")
            log_path = self.out / filename
            log = file_identity(log_path)
            result["command_log"] = log
            require(log["sha256"] == execution["log_sha256"] and log["bytes"] == execution["log_bytes"],
                    "full command log differs from repository execution record")
            if process.returncode != 0 or execution.get("command_exit_code") != 0 or execution.get("status") != "passed":
                raise AuditFailure(f"{name}: original command/helper did not pass", process.returncode or execution.get("exit_code") or 1)
            require(execution["exit_code"] == 0 and not execution["timed_out"] and not execution["output_limit_exceeded"],
                    "repository helper did not finish normally within its original bounds")
            require(execution["minimum_tests"] == minimum_tests and execution["observed_passed_tests"] >= minimum_tests
                    and execution["observed_failed_tests"] == 0, "original test-count guard did not pass")
            result["status"] = "passed"
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, AuditFailure) as error:
            failure = error if isinstance(error, AuditFailure) else AuditFailure(str(error))
            result["status"] = "failed"
            result["error"] = str(error)
        finally:
            result["finished_at"] = utc_now()
            result["elapsed_seconds"] = time.monotonic() - started
            for label, path in (("wrapper_stdout", stdout_path), ("wrapper_stderr", stderr_path)):
                if path.exists():
                    result[label] = file_identity(path)
            try:
                result["after"], _ = self.source_state()
            except (OSError, ValueError, subprocess.SubprocessError, AuditFailure) as error:
                failure = AuditFailure(f"source postcheck failed: {error}")
                result["status"] = "failed"
                result["source_error"] = str(error)
            write_json(self.out / f"{name}.RESULT.json", result)
            self.stages.append(result)
            emit({"stage": name, "state": result["status"], "wrapper_exit_code": result.get("wrapper_exit_code"),
                  "elapsed_seconds": round(result["elapsed_seconds"], 3)})
        if failure is not None:
            raise failure
        require(log_path is not None, "no successful current command log")
        return log_path

    def collect_artifacts(self, name: str, log_path: Path, manifest_relative: str, required_name: str) -> None:
        manifest_path = (self.repo / manifest_relative).resolve(strict=True)
        package_name = tomllib.loads(manifest_path.read_text())["package"]["name"]
        rows = []
        finished = []
        selected = {}
        with log_path.open("rb") as stream:
            for line_number, raw in enumerate(stream, 1):
                try:
                    message = json.loads(raw)
                except (ValueError, UnicodeDecodeError):
                    continue
                if not isinstance(message, dict):
                    continue
                if message.get("reason") == "build-finished":
                    finished.append(message)
                if message.get("reason") != "compiler-artifact":
                    continue
                target = message.get("target", {})
                if "bin" not in target.get("kind", []) or message.get("profile", {}).get("test") is not False:
                    continue
                if not message.get("executable") or not message.get("manifest_path"):
                    continue
                if Path(message["manifest_path"]).resolve(strict=True) != manifest_path:
                    continue
                target_name = target["name"]
                require(re.fullmatch(r"[A-Za-z0-9_-]+", target_name) is not None, "unexpected binary target name")
                require(isinstance(message.get("package_id"), str) and bool(message["package_id"]), "missing Cargo package ID")
                source_path = Path(target["src_path"])
                require(source_path.is_absolute() and source_path.resolve(strict=True).is_relative_to(manifest_path.parent),
                        "selected Cargo binary source is outside its declared package")
                executable = Path(message["executable"])
                require(executable.is_absolute(), "Cargo executable record is not absolute")
                canonical = executable.resolve(strict=True)
                require(canonical == executable and canonical.is_relative_to(self.target),
                        "Cargo executable is not a canonical path inside the declared target")
                require(str(executable) in message.get("filenames", []), "executable is absent from Cargo artifact filenames")
                observed = file_identity(executable, elf=True)
                row = {"stage": name, "line_number": line_number, "compiler_artifact": message,
                       "package_name_from_bound_manifest": package_name, "executable": observed}
                require(target_name not in selected, f"duplicate selected binary artifact: {target_name}")
                selected[target_name] = row
                rows.append(row)
        require(len(finished) == 1 and finished[0].get("success") is True, "current Cargo build-finished success was not observed exactly once")
        require(required_name in selected, f"current Cargo invocation did not report required binary {required_name}")
        for target_name, row in selected.items():
            require(target_name not in self.artifacts, f"binary name collides across selected packages: {target_name}")
            self.artifacts[target_name] = row
        write_json(self.out / f"{name}.ARTIFACTS.json", {"source_head": self.args.expected_head,
                   "source_tree": self.args.expected_tree, "command_log": file_identity(log_path),
                   "manifest": str(manifest_path), "required_binary": required_name,
                   "build_finished": finished[0], "artifacts": rows})

    def verify_artifacts(self) -> dict:
        observed = {}
        for name, item in sorted(self.artifacts.items()):
            current = file_identity(Path(item["executable"]["path"]), elf=True)
            require(current == item["executable"], f"bound helper executable changed after its Cargo record: {name}")
            observed[name] = current
        for item in self.assets.get("files", []):
            current = file_identity(Path(item["path"]))
            require(current["sha256"] == item["sha256"] and current["bytes"] == item["bytes"],
                    f"read-only V8 input changed: {item['path']}")
        return observed

    def run(self) -> int:
        exit_code = 2
        try:
            self.preflight()
            cargo = str(self.args.cargo_executable)
            cwd = self.repo / "codex-rs"
            codex = [cargo, "+1.96.0", "build", "--locked", "-p", "codex-cli", "--bin", "codex", "--message-format=json-render-diagnostics"]
            workers = [cargo, "+1.96.0", "build", "--locked", "-p", "codex-hepta-infer-worker-host", "--bins", "--message-format=json-render-diagnostics"]
            log = self.run_stage("01-build-codex", codex, cwd, 0)
            self.collect_artifacts("01-build-codex", log, "codex-rs/cli/Cargo.toml", "codex")
            log = self.run_stage("02-build-worker-bins", workers, cwd, 0)
            self.collect_artifacts("02-build-worker-bins", log, "codex-rs/hepta-infer-worker-host/Cargo.toml", "hepta-joint-propose")
            before = self.verify_artifacts()
            bindings = {}
            for name, item in sorted(self.artifacts.items()):
                # The underscore alias is accepted by the unchanged cargo-bin helper
                # and survives the original just recipe's POSIX shell environment.
                for alias in {name, name.replace("-", "_")}:
                    key = f"CARGO_BIN_EXE_{alias}"
                    path = item["executable"]["path"]
                    require(key not in bindings or bindings[key] == path, "Cargo binary environment alias collision")
                    bindings[key] = path
            require("CARGO_BIN_EXE_codex" in bindings and "CARGO_BIN_EXE_hepta_joint_propose" in bindings,
                    "required runtime helper bindings are absent")
            self.env.update(bindings)
            write_json(self.out / "RUNTIME-HELPERS.json", {"source_head": self.args.expected_head,
                       "source_tree": self.args.expected_tree, "bindings": bindings, "artifacts_before_test": before,
                       "selection": "only this audit's two successful Cargo compiler-artifact streams; profile.test is false"})
            self.run_stage("03-agentd-just-test", [str(self.args.just_executable), "test", "-p", "codex-hepta-agentd", "--locked"], self.repo, 1)
            self.result["artifacts_after_test"] = self.verify_artifacts()
            require(time.monotonic() <= self.deadline, "task budget elapsed; result cannot be reported passing")
            exit_code = 0
            self.result["status"] = "passed"
        except KeyboardInterrupt:
            exit_code = 130
            self.result["status"] = "interrupted"
            self.result["error"] = "runner interrupted; no external PID kill was issued; helper record remains authoritative"
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, AuditFailure) as error:
            exit_code = error.exit_code if isinstance(error, AuditFailure) else 2
            self.result["status"] = "failed"
            self.result["error"] = str(error)
        finally:
            try:
                self.result["source_after"], self.result["controls_after"] = self.source_state()
                self.result["source_unchanged"] = self.original_identity is not None
            except (OSError, ValueError, subprocess.SubprocessError, AuditFailure) as error:
                exit_code = exit_code or 2
                self.result["status"] = "failed"
                self.result["source_unchanged"] = False
                self.result["source_error"] = str(error)
            self.result.update({"finished_at": utc_now(), "elapsed_seconds": time.monotonic() - self.started,
                                "exit_code": exit_code, "stages": self.stages, "remote_refs_changed": False,
                                "source_edits": False, "formatting_run": False, "direct_cargo_test_run": False})
            write_json(self.out / "FINAL.json", self.result)
            emit({"stage": "complete", "status": self.result["status"], "exit_code": exit_code,
                  "head": self.args.expected_head, "tree": self.args.expected_tree, "output": str(self.out)})
        return exit_code


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--target-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--v8-assets-json", type=Path)
    parser.add_argument("--python-executable", type=Path, default=Path("/usr/bin/python3.12"))
    parser.add_argument("--cargo-executable", type=Path, default=Path("/home/qian-qi/.cargo/bin/cargo"))
    parser.add_argument("--just-executable", type=Path, default=Path("/home/qian-qi/.cargo/bin/just"))
    args = parser.parse_args()
    try:
        return FullRunner(args).run()
    except (OSError, ValueError, AuditFailure) as error:
        emit({"status": "rejected_before_dispatch", "error": str(error)})
        return 2



class FullRunner(Runner):
    def final_format(self) -> dict:
        before, controls = self.source_state()
        self.formatting_started = True
        format_base = "6cbad406a4a203201edc0e103c1377d3664e3fbe"
        records = []
        write_json(self.out / "FORMATTING-BEFORE.json", {"source": before, "controls": controls,
                   "base": format_base, "all_validation_stages_complete": True})
        for name, flags in (("06-final-fmt", []), ("07-final-fmt-check", ["--check"])):
            command = [str(self.args.just_executable), "fmt", "--base", format_base, *flags]
            remaining = min(3600, self.deadline - time.monotonic())
            require(remaining > 0, "original task budget exhausted before final formatter")
            start = time.monotonic()
            record = {"stage": name, "command": command, "started_at": utc_now(),
                      "working_directory": str(self.repo), "timeout_seconds": remaining}
            emit({"stage": name, "state": "starting"})
            stdout = self.out / f"{name}.stdout.log"
            stderr = self.out / f"{name}.stderr.log"
            with stdout.open("xb") as out_stream, stderr.open("xb") as err_stream:
                completed = subprocess.run(command, cwd=self.repo, env=self.env,
                                           stdout=out_stream, stderr=err_stream, timeout=remaining)
            record.update({"exit_code": completed.returncode, "finished_at": utc_now(),
                           "elapsed_seconds": time.monotonic() - start,
                           "stdout": file_identity(stdout), "stderr": file_identity(stderr)})
            write_json(self.out / f"{name}.RESULT.json", record)
            records.append(record)
            emit({"stage": name, "state": "passed" if completed.returncode == 0 else "failed",
                  "exit_code": completed.returncode})
        require(self.git("rev-parse", "HEAD") == self.args.expected_head and
                self.git("rev-parse", "HEAD^{tree}") == self.args.expected_tree,
                "formatter moved the frozen source commit")
        for relative, identity in controls.items():
            observed = file_identity(self.repo / relative)
            require({k: observed[k] for k in ("bytes", "sha256", "git_blob")} == identity,
                    f"formatter unexpectedly changed a validation control: {relative}")
        diff = subprocess.check_output(["git", "-C", str(self.repo), "diff", "--binary", "--full-index", "HEAD"])
        (self.out / "FINAL-FORMAT.diff").write_bytes(diff)
        changed = subprocess.check_output(["git", "-C", str(self.repo), "diff", "--name-only", "-z", "HEAD"])
        paths = [item.decode() for item in changed.split(b"\0") if item]
        index_env = {**self.env, "GIT_INDEX_FILE": str(self.out / "formatted-source.index")}
        subprocess.run(["git", "-C", str(self.repo), "read-tree", "HEAD"], env=index_env, check=True)
        files = []
        for relative in paths:
            path = Path(relative)
            require(not path.is_absolute() and ".." not in path.parts, "invalid formatter output path")
            source = self.repo / relative
            require(source.is_file() and not source.is_symlink(), "formatter removed or replaced a source file")
            row = self.git("ls-tree", "HEAD", "--", relative).split("\t", 1)[0].split()
            require(len(row) == 3 and row[1] == "blob" and row[0] in {"100644", "100755"},
                    "formatter changed an unsupported tracked entry")
            content = source.read_bytes()
            blob = subprocess.check_output(["git", "-C", str(self.repo), "hash-object", "-w", "--stdin"], input=content).decode().strip()
            subprocess.run(["git", "-C", str(self.repo), "update-index", "--cacheinfo", row[0], blob, relative],
                           env=index_env, check=True)
            destination = self.out / "formatted-files" / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(content)
            files.append({"path": relative, "mode": row[0], "before_blob": row[2], "after_blob": blob,
                          "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()})
        worktree_tree = subprocess.check_output(["git", "-C", str(self.repo), "write-tree", "--missing-ok"],
                                                env=index_env).decode().strip()
        result = {"status": "passed" if all(item["exit_code"] == 0 for item in records) else "failed",
                  "before": before, "after_head": self.git("rev-parse", "HEAD"),
                  "after_worktree_tree": worktree_tree, "files": files, "commands": records,
                  "binary_diff": file_identity(self.out / "FINAL-FORMAT.diff"),
                  "tests_run_after_formatting": False, "main_index_and_refs_updated": False}
        write_json(self.out / "FORMATTING-FINAL.json", result)
        return result

    def run(self) -> int:
        exit_code = 2
        failures = []
        self.formatting_started = False
        self.result["planned_stages"] = [
            "00-three-package-strict-clippy", "01-build-codex", "02-build-worker-bins",
            "03-agentd-just-test", "04-authbus-just-test", "06-final-fmt", "07-final-fmt-check",
        ]
        self.result["resource_plan"] = {
            "new_target": True, "cargo_build_jobs": 4, "nice": 5,
            "total_budget_seconds": 10800, "per_command_maximum_seconds": 3600,
            "minimum_disk_before_first_build_gib": 8,
            "minimum_disk_before_later_stages_gib": 4,
            "minimum_available_memory_gib": 16,
            "source_profile_deadlines_unchanged": True,
        }

        def attempt(name, command, cwd, minimum_tests):
            try:
                return self.run_stage(name, command, cwd, minimum_tests)
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, AuditFailure) as error:
                failures.append({"stage": name, "error": str(error)})
                emit({"stage": name, "state": "failed", "error": str(error)})
                return None

        try:
            os.nice(5)
            self.preflight()
            cargo = str(self.args.cargo_executable)
            cwd = self.repo / "codex-rs"
            strict_log = attempt("00-three-package-strict-clippy", [
                cargo, "+1.96.0", "clippy", "--manifest-path", "codex-rs/Cargo.toml", "--locked",
                "-p", "codex-hepta-bellman-operator", "-p", "codex-hepta-agentd",
                "-p", "codex-hepta-shadow-qualification", "--all-targets", "--", "-D", "warnings",
            ], self.repo, 0)
            if strict_log is None:
                raise AuditFailure("Original strict Clippy failed; stop before helpers, tests and final formatting so the coordinator can fix and freeze a new source", 1)
            codex = [cargo, "+1.96.0", "build", "--locked", "-p", "codex-cli", "--bin", "codex", "--message-format=json-render-diagnostics"]
            workers = [cargo, "+1.96.0", "build", "--locked", "-p", "codex-hepta-infer-worker-host", "--bins", "--message-format=json-render-diagnostics"]
            log = attempt("01-build-codex", codex, cwd, 0)
            if log is not None:
                self.collect_artifacts("01-build-codex", log, "codex-rs/cli/Cargo.toml", "codex")
            log = attempt("02-build-worker-bins", workers, cwd, 0)
            if log is not None:
                self.collect_artifacts("02-build-worker-bins", log, "codex-rs/hepta-infer-worker-host/Cargo.toml", "hepta-joint-propose")
            if all(name in self.artifacts for name in ("codex", "hepta-joint-propose")):
                before = self.verify_artifacts()
                bindings = {}
                for name, item in sorted(self.artifacts.items()):
                    for alias in {name, name.replace("-", "_")}:
                        key = f"CARGO_BIN_EXE_{alias}"
                        path = item["executable"]["path"]
                        require(key not in bindings or bindings[key] == path, "Cargo binary environment alias collision")
                        bindings[key] = path
                self.env.update(bindings)
                write_json(self.out / "RUNTIME-HELPERS.json", {
                    "source_head": self.args.expected_head, "source_tree": self.args.expected_tree,
                    "bindings": bindings, "artifacts_before_test": before,
                    "selection": "only this task's successful compiler-artifact streams; profile.test is false",
                })
                attempt("03-agentd-just-test", [str(self.args.just_executable), "test", "-p", "codex-hepta-agentd", "--locked"], self.repo, 1)
                self.result["artifacts_after_test"] = self.verify_artifacts()
            else:
                failures.append({"stage": "03-agentd-just-test", "status": "not_run", "error": "required real same-source helper build did not succeed"})
            attempt("04-authbus-just-test", [str(self.args.just_executable), "test", "-p", "codex-hepta-authbus", "--locked"], self.repo, 1)
            if not failures:
                self.result["formatting"] = self.final_format()
                if self.result["formatting"]["status"] != "passed":
                    failures.append({"stage": "final-formatting", "error": "original formatter or check returned a failure"})
            exit_code = 1 if failures else 0
            self.result["status"] = "failed" if failures else "passed"
        except KeyboardInterrupt:
            exit_code = 130
            self.result["status"] = "interrupted"
            failures.append({"stage": "runner", "error": "Interrupted; original command records retain actual outcomes"})
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, AuditFailure) as error:
            exit_code = error.exit_code if isinstance(error, AuditFailure) else 2
            self.result["status"] = "failed"
            failures.append({"stage": "runner", "error": str(error)})
        finally:
            try:
                if self.formatting_started:
                    source = {"commit": self.git("rev-parse", "HEAD"), "tree": self.git("rev-parse", "HEAD^{tree}"),
                              "dirty": bool(self.git("status", "--porcelain=v1", "--untracked-files=normal"))}
                    require(source["commit"] == self.args.expected_head and source["tree"] == self.args.expected_tree,
                            "final formatter moved the frozen source commit")
                    self.result["source_after"] = source
                    self.result["source_unchanged"] = not source["dirty"]
                    self.result["source_unchanged_through_validation"] = True
                else:
                    self.result["source_after"], self.result["controls_after"] = self.source_state()
                    self.result["source_unchanged"] = self.original_identity is not None
            except (OSError, ValueError, subprocess.SubprocessError, AuditFailure) as error:
                exit_code = exit_code or 2
                self.result["status"] = "failed"
                self.result["source_unchanged"] = False
                failures.append({"stage": "source-postcheck", "error": str(error)})
            self.result.update({
                "finished_at": utc_now(), "elapsed_seconds": time.monotonic() - self.started,
                "exit_code": exit_code, "stages": self.stages, "failures": failures,
                "remote_refs_changed": False, "source_edits": bool(self.result.get("source_after", {}).get("dirty")),
                "formatting_run": self.formatting_started, "direct_cargo_test_run": False,
                "tests_run_after_formatting": False,
            })
            write_json(self.out / "FINAL.json", self.result)
            emit({"stage": "complete", "status": self.result["status"], "exit_code": exit_code,
                  "head": self.args.expected_head, "tree": self.args.expected_tree, "output": str(self.out)})
        return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
