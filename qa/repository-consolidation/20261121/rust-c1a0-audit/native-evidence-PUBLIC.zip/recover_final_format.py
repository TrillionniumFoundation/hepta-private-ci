#!/usr/bin/env python3
"""Install a verified uv asset into our own new tool directory and recover failed fmt only."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback


ROOT = Path('/home/qian-qi/hepta-c1a0-native-20261121-01')
REPO = ROOT / 'repo'
OUT = ROOT / 'format-recovery-01'
TOOLS = ROOT / 'format-tools-uv-0_13_9-01'
HEAD = '5a42644ff02a511e12ce2f95f1c11f85b709835f'
TREE = 'cf4965757cc8ef01109c06b40ade160f3a6f57bb'
FORMAT_BASE = '6cbad406a4a203201edc0e103c1377d3664e3fbe'
BEFORE_WORKTREE = 'f80cd064b5237c75b0703df376344edd17e3a745'
ONLY_CHANGED = 'codex-rs/hepta-authbus/src/owner_tests.rs'
BEFORE_BLOB = '23ff40605963c8ea795fb2613053fbc117db63a0'
BEFORE_DIFF_SHA256 = '4df706d350833debff01c76def70620f49879b0b7075ac3fb6ea111bdedbcb21'
UV_URL = 'https://github.com/astral-sh/uv/releases/download/0.13.9/uv-x86_64-unknown-linux-gnu.tar.gz'
UV_ARCHIVE_BYTES = 17068176
UV_ARCHIVE_SHA256 = 'a7fbaff2b9a271d85c1bdb540941090fd1ce011797b4abeb48e4dcd39c2471d5'
BASE_RUNNER = ROOT / 'run_native_validation.py'
assert hashlib.sha256(BASE_RUNNER.read_bytes()).hexdigest() == 'b8a204ed33848e8f07a470adba720164dd15676cea9f5bd2313895b50664d56c'
spec = importlib.util.spec_from_file_location('original_native_validation', BASE_RUNNER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
require = base.require


def git(*args, raw=False, env=None):
    result = subprocess.check_output(['git', '-C', str(REPO), *args], env=env)
    return result if raw else result.decode().strip()


def source_state():
    require(git('rev-parse', 'HEAD') == HEAD and git('rev-parse', 'HEAD^{tree}') == TREE,
            'native frozen head/tree changed')
    require(not git('diff', '--cached', '--name-only'), 'source main index changed')
    return {'commit': HEAD, 'head_tree': TREE,
            'porcelain': git('status', '--porcelain=v1', '--untracked-files=normal', raw=True).decode(),
            'diff_sha256': hashlib.sha256(git('diff', '--binary', '--full-index', 'HEAD', raw=True)).hexdigest()}


def controls_state():
    old = json.loads((ROOT / 'validation-02/PREFLIGHT.json').read_text())['controls']
    result = {}
    for relative, prior in old.items():
        item = base.file_identity(REPO / relative)
        row = {key: item[key] for key in ('bytes', 'sha256', 'git_blob')}
        require(row == prior, f'original validation control changed: {relative}')
        result[relative] = row
    for relative in ('scripts/format.py', 'scripts/pyproject.toml', 'scripts/uv.lock'):
        item = base.file_identity(REPO / relative)
        require(item['git_blob'] == git('rev-parse', f'HEAD:{relative}'), f'original formatter input changed: {relative}')
        result[relative] = {key: item[key] for key in ('bytes', 'sha256', 'git_blob')}
    return result


def capture_worktree(label, env):
    patch = git('diff', '--binary', '--full-index', 'HEAD', raw=True)
    (OUT / f'{label}.diff').write_bytes(patch)
    paths = [x.decode() for x in git('diff', '--name-only', '-z', 'HEAD', raw=True).split(b'\0') if x]
    index_env = {**env, 'GIT_INDEX_FILE': str(OUT / f'{label}.index')}
    subprocess.run(['git', '-C', str(REPO), 'read-tree', 'HEAD'], env=index_env, check=True)
    files = []
    for relative in paths:
        path = Path(relative)
        require(not path.is_absolute() and '..' not in path.parts, 'unsafe source output path')
        source = REPO / path
        require(source.is_file() and not source.is_symlink(), 'formatter removed or aliased source')
        row = git('ls-tree', 'HEAD', '--', relative).split('\t', 1)[0].split()
        require(len(row) == 3 and row[1] == 'blob' and row[0] in {'100644', '100755'}, 'unsupported formatter output')
        content = source.read_bytes()
        blob = subprocess.check_output(['git', '-C', str(REPO), 'hash-object', '-w', '--stdin'], input=content).decode().strip()
        subprocess.run(['git', '-C', str(REPO), 'update-index', '--cacheinfo', row[0], blob, relative], env=index_env, check=True)
        destination = OUT / f'{label}-files' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
        files.append({'path': relative, 'mode': row[0], 'head_blob': row[2], 'worktree_blob': blob,
                      'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
    tree = git('write-tree', '--missing-ok', env=index_env)
    return {'head': HEAD, 'head_tree': TREE, 'worktree_tree': tree, 'files': files,
            'binary_diff': base.file_identity(OUT / f'{label}.diff'), 'source': source_state(),
            'main_index_and_refs_updated': False}


DOWNLOAD = r'''import hashlib,json,pathlib,sys,urllib.request
url,dest,expected_size,expected_sha=sys.argv[1:]
expected_size=int(expected_size)
digest=hashlib.sha256();count=0
with urllib.request.urlopen(url,timeout=30) as response, pathlib.Path(dest).open('xb') as output:
    print(json.dumps({'http_status':response.status,'response_url':response.url}),flush=True)
    while True:
        data=response.read(1024*1024)
        if not data:break
        count+=len(data)
        if count>expected_size:raise RuntimeError('official asset exceeds pinned size')
        output.write(data);digest.update(data)
if count!=expected_size or digest.hexdigest()!=expected_sha:raise RuntimeError('official asset size/SHA256 mismatch')
print(json.dumps({'bytes':count,'sha256':digest.hexdigest(),'status':'downloaded_verified'}),flush=True)
'''


def run_command(name, command, env, timeout):
    start = time.monotonic()
    record = {'stage': name, 'command': command, 'working_directory': str(REPO),
              'started_at': base.utc_now(), 'timeout_seconds': timeout}
    stdout = OUT / f'{name}.stdout.log'
    stderr = OUT / f'{name}.stderr.log'
    base.emit({'stage': name, 'state': 'starting', 'timeout_seconds': timeout})
    with stdout.open('xb') as out, stderr.open('xb') as err:
        process = subprocess.Popen(command, cwd=REPO, env=env, stdout=out, stderr=err, start_new_session=True)
        while process.poll() is None:
            remaining = timeout - (time.monotonic() - start)
            if remaining <= 0:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                record['timed_out'] = True
                break
            try:
                process.wait(timeout=min(15, remaining))
            except subprocess.TimeoutExpired:
                base.emit({'stage': name, 'state': 'running', 'elapsed_seconds': round(time.monotonic()-start, 1),
                           'stdout_bytes': stdout.stat().st_size, 'stderr_bytes': stderr.stat().st_size})
        record['exit_code'] = process.returncode
    record.update(finished_at=base.utc_now(), elapsed_seconds=time.monotonic()-start,
                  stdout=base.file_identity(stdout), stderr=base.file_identity(stderr))
    base.write_json(OUT / f'{name}.RESULT.json', record)
    base.emit({'stage': name, 'state': 'passed' if process.returncode == 0 else 'failed', 'exit_code': process.returncode})
    return record


def main():
    os.umask(0o077)
    require(OUT.parent == ROOT and TOOLS.parent == ROOT, 'unexpected owned output parent')
    OUT.mkdir(mode=0o700, exist_ok=False)
    TOOLS.mkdir(mode=0o700, exist_ok=False)
    start = time.monotonic()
    final = {'status': 'running', 'started_at': base.utc_now(), 'expected_head': HEAD, 'expected_head_tree': TREE,
             'before_worktree_tree': BEFORE_WORKTREE, 'format_base': FORMAT_BASE,
             'scope': 'repair missing uv, retry only the two failed original formatting commands',
             'tests_executed': False, 'prior_native_failures_preserved': True,
             'system_installation_or_persistent_path_changed': False,
             'official_uv_url': UV_URL, 'uv_archive_bytes': UV_ARCHIVE_BYTES,
             'uv_archive_sha256': UV_ARCHIVE_SHA256, 'asset_download_attempts': 0,
             'maximum_asset_download_attempts': 1,
             'asset_download_timeout_seconds': 90, 'per_format_command_timeout_seconds': 3600,
             'new_tool_directory': str(TOOLS), 'output': str(OUT)}
    base.write_json(OUT / 'REQUEST.json', final)
    env = os.environ.copy()
    exit_code = 2
    try:
        previous = json.loads((ROOT / 'validation-02/FINAL.json').read_text())
        require(previous['expected_head'] == HEAD and previous['expected_tree'] == TREE and previous['exit_code'] == 1,
                'unexpected prior recovery identity or terminal')
        require(len(previous['stages']) == 2 and all(s['status'] == 'passed' and s['execution_record']['command_exit_code'] == 0 for s in previous['stages']),
                'prior original Rust tests have not passed')
        state = source_state()
        require(state['porcelain'] == f' M {ONLY_CHANGED}\n' and state['diff_sha256'] == BEFORE_DIFF_SHA256,
                'source differs from exact previously formatted test fixture')
        require(base.file_identity(REPO / ONLY_CHANGED)['git_blob'] == BEFORE_BLOB, 'formatted fixture blob changed')
        controls = controls_state()
        prior_env = json.loads((ROOT / 'validation-02/PREFLIGHT.json').read_text())
        env.update(prior_env['environment_overrides'])
        env.update(json.loads((ROOT / 'validation-02/REUSED-RUNTIME-HELPERS.json').read_text())['bindings'])
        env['PATH'] = os.pathsep.join([*prior_env['path_prefixes'], os.environ.get('PATH', '')])
        before = capture_worktree('BEFORE', env)
        require(before['worktree_tree'] == BEFORE_WORKTREE, 'actual pre-format worktree tree differs')
        final['before'] = before
        base.write_json(OUT / 'SOURCE-BEFORE.json', {'source': before, 'controls': controls,
                        'prior_native_terminal': base.file_identity(ROOT / 'validation-02/FINAL.json')})
        archive = TOOLS / 'uv-x86_64-unknown-linux-gnu.tar.gz'
        final['asset_download_attempts'] = 1
        download = run_command('00-download-uv', [sys.executable, '-c', DOWNLOAD, UV_URL, str(archive),
                                                str(UV_ARCHIVE_BYTES), UV_ARCHIVE_SHA256], env, 90)
        final['download'] = download
        require(download['exit_code'] == 0 and not download.get('timed_out'), 'single uv asset download failed; no retry')
        archive_identity = base.file_identity(archive)
        require(archive_identity['bytes'] == UV_ARCHIVE_BYTES and archive_identity['sha256'] == UV_ARCHIVE_SHA256,
                'independent uv archive size/SHA256 verification failed')
        bin_dir = TOOLS / 'bin'
        bin_dir.mkdir(mode=0o700)
        uv = bin_dir / 'uv'
        member_name = 'uv-x86_64-unknown-linux-gnu/uv'
        with tarfile.open(archive, 'r:gz') as tar:
            members = [member for member in tar.getmembers() if member.name == member_name]
            require(len(members) == 1 and members[0].isreg() and 0 < members[0].size < 256*1024**2,
                    'uv archive does not contain one bounded regular original uv executable')
            require(not members[0].mode & 0o7000, 'unexpected privileged archive mode')
            source = tar.extractfile(members[0])
            require(source is not None, 'uv archive member cannot be read')
            with source, uv.open('xb') as target:
                shutil.copyfileobj(source, target, 1024*1024)
            require(uv.stat().st_size == members[0].size, 'extracted uv length differs')
        uv.chmod(0o700)
        uv_identity = base.file_identity(uv, elf=True)
        version = subprocess.check_output([str(uv), '--version'], env=env, text=True, timeout=15).strip()
        require(version.split()[:2] == ['uv', '0.13.9'], 'actual uv version differs')
        final['uv'] = {'archive': archive_identity, 'extracted_member': member_name,
                       'executable': uv_identity, 'actual_version': version, 'only_member_extracted': True}
        base.write_json(OUT / 'UV-VERIFIED.json', final['uv'])
        env.update(PATH=os.pathsep.join([str(bin_dir), env['PATH']]),
                   UV_CACHE_DIR=str(TOOLS / 'cache'), UV_PROJECT_ENVIRONMENT=str(TOOLS / 'scripts-venv'))
        require(shutil.which('uv', path=env['PATH']) == str(uv), 'process uv selection differs')
        base.write_json(OUT / 'FORMAT-ENVIRONMENT.json', {
            'recorded_original_overrides': prior_env['environment_overrides'],
            'original_path_prefixes': prior_env['path_prefixes'], 'added_path_prefix': str(bin_dir),
            'uv_cache_dir': env['UV_CACHE_DIR'], 'uv_project_environment': env['UV_PROJECT_ENVIRONMENT'],
            'original_scripts_uv_lock': controls['scripts/uv.lock'],
            'system_or_persistent_environment_changed': False,
        })
        require(source_state() == state and controls_state() == controls, 'source changed during uv preparation')
        records = []
        for name, flags in (('01-original-just-fmt', []), ('02-original-just-fmt-check', ['--check'])):
            record = run_command(name, ['/home/qian-qi/.cargo/bin/just', 'fmt', '--base', FORMAT_BASE, *flags], env, 3600)
            records.append(record)
            final['format_commands'] = records
            # A known network/tool failure is terminal, not a reason to replay the
            # formatter or trigger another implicit dependency download in check.
            require(record['exit_code'] == 0 and not record.get('timed_out'),
                    f'{name} failed; preserve the failure and do not blindly retry')
        require(controls_state() == controls, 'formatter changed original source controls or lockfile')
        final['after'] = capture_worktree('AFTER', env)
        final['controls_after'] = controls_state()
        final['status'] = 'passed'
        exit_code = 0
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, tarfile.TarError, base.AuditFailure) as error:
        final['status'] = 'failed'
        final['error'] = str(error)
        final['exception_type'] = type(error).__name__
        exit_code = 1
        try:
            final['source_on_failure'] = source_state()
            final['after'] = capture_worktree('AFTER', env)
        except Exception as post_error:
            final['postcheck_error'] = str(post_error)
    finally:
        final.update(finished_at=base.utc_now(), elapsed_seconds=time.monotonic()-start, exit_code=exit_code,
                     tests_executed=False, tests_after_formatting=False,
                     remote_refs_changed=False, main_index_changed=False,
                     original_formatter_source_or_scope_changed=False)
        base.write_json(OUT / 'FINAL.json', final)
        base.emit({'stage': 'complete', 'status': final['status'], 'exit_code': exit_code, 'output': str(OUT)})
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
