from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import shutil
import stat
import subprocess
import time

ROOT = Path('/home/qian-qi/hepta-c1a0-native-20261121-01')
REPO = ROOT / 'repo'
SOURCE = Path('/tmp/hepta-c1a0-native-20261121-01-target')
DESTINATION = ROOT / 'target'
RETIRED = Path('/tmp/hepta-c1a0-native-20261121-01-target-relocation-retired-01')
OUT = ROOT / 'target-relocation-01'
HEAD = '5a42644ff02a511e12ce2f95f1c11f85b709835f'
TREE = 'cf4965757cc8ef01109c06b40ade160f3a6f57bb'
RESERVE = 12 * 1024 ** 3
os.umask(0o077)
os.nice(5)
OUT.mkdir(mode=0o700, exist_ok=False)
start = time.monotonic()

def save(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

def emit(value):
    print(json.dumps(value, sort_keys=True), flush=True)

def source_identity():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(REPO), *args], timeout=30).decode().strip()
    identity = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                'dirty': bool(git('status', '--porcelain=v1', '--untracked-files=normal'))}
    assert identity == {'head': HEAD, 'tree': TREE, 'dirty': False}, identity
    return identity

def regular_hash(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as f:
        before = os.fstat(f.fileno())
        assert stat.S_ISREG(before.st_mode)
        digest = hashlib.sha256()
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            digest.update(block)
        after = os.fstat(f.fileno())
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    return digest.hexdigest()

def manifest(root, label):
    entries = {}
    physical = {}
    logical_unique = allocated_unique = regular_files = 0
    pending = [root]
    last_progress = time.monotonic()
    while pending:
        directory = pending.pop()
        for path in sorted(directory.iterdir(), key=lambda p: p.name):
            rel = str(path.relative_to(root))
            s = path.lstat()
            assert s.st_uid == os.getuid(), 'Unexpected owner in this task target: ' + rel
            common = {'mode': oct(stat.S_IMODE(s.st_mode)), 'uid': s.st_uid, 'gid': s.st_gid}
            if stat.S_ISDIR(s.st_mode):
                entries[rel] = {**common, 'type': 'directory'}
                pending.append(path)
            elif stat.S_ISLNK(s.st_mode):
                entries[rel] = {**common, 'type': 'symlink', 'target': os.readlink(path)}
            else:
                assert stat.S_ISREG(s.st_mode), 'Unexpected special entry: ' + rel
                regular_files += 1
                key = (s.st_dev, s.st_ino)
                if key not in physical:
                    physical[key] = {'first': rel, 'sha256': regular_hash(path)}
                    logical_unique += s.st_size
                    allocated_unique += s.st_blocks * 512
                item = physical[key]
                entries[rel] = {**common, 'type': 'file', 'bytes': s.st_size,
                                'sha256': item['sha256'], 'hardlink_first': item['first'],
                                'mtime_ns': s.st_mtime_ns}
            if time.monotonic() - last_progress >= 30:
                emit({'stage': label, 'state': 'running', 'entries': len(entries),
                      'unique_content_bytes_hashed': logical_unique})
                last_progress = time.monotonic()
    payload = json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()
    compressed = gzip.compress(payload, mtime=0)
    (OUT / (label + '.manifest.json.gz')).write_bytes(compressed)
    summary = {'root': str(root), 'device': root.stat().st_dev, 'entries': len(entries),
               'regular_paths': regular_files, 'unique_regular_inodes': len(physical),
               'unique_logical_bytes': logical_unique, 'unique_allocated_bytes': allocated_unique,
               'normalized_manifest_sha256': hashlib.sha256(payload).hexdigest(),
               'compressed_manifest_bytes': len(compressed),
               'compressed_manifest_sha256': hashlib.sha256(compressed).hexdigest()}
    save(label + '.summary.json', summary)
    emit({'stage': label, 'state': 'complete', **summary})
    return entries, summary

result = {'status': 'running', 'started_at': datetime.now(timezone.utc).isoformat(),
          'source_target': str(SOURCE), 'disk_target': str(DESTINATION),
          'retired_owned_copy': str(RETIRED), 'minimum_link_reserve_bytes': RESERVE,
          'original_tmp_copy_released': False, 'copy_verified': False,
          'foreign_files_or_quota_settings_changed': False}
try:
    previous = json.loads((ROOT / 'validation-01/FINAL.json').read_text())
    assert previous['status'] == 'failed' and previous['source_unchanged'] is True
    assert previous['formatting_run'] is False
    assert ROOT.resolve(strict=True) == ROOT and REPO.resolve(strict=True) == REPO
    assert SOURCE.is_dir() and not SOURCE.is_symlink() and SOURCE.resolve(strict=True) == SOURCE
    assert DESTINATION.is_dir() and not DESTINATION.is_symlink() and not list(DESTINATION.iterdir())
    assert not RETIRED.exists() and not RETIRED.is_symlink()
    assert SOURCE.stat().st_dev == 51 and DESTINATION.stat().st_dev == 66306
    result['source_before'] = source_identity()
    source_entries, source_summary = manifest(SOURCE, '01-source')
    free = shutil.disk_usage(DESTINATION).free
    required = source_summary['unique_logical_bytes'] + RESERVE
    assert free >= required, f'Insufficient ext4 free space: {free} < {required}'
    result.update({'source_manifest': source_summary, 'disk_free_before': free,
                   'required_free_before': required, 'tmp_free_before': shutil.disk_usage(SOURCE).free})
    save('PRECHECK.json', result)
    command = ['cp', '--archive', '--sparse=always', str(SOURCE) + '/.', str(DESTINATION)]
    emit({'stage': '02-copy-owned-target', 'state': 'starting', 'command': command})
    copy_start = time.monotonic()
    with (OUT / 'copy.stdout').open('xb') as stdout, (OUT / 'copy.stderr').open('xb') as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr)
        while process.poll() is None:
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                emit({'stage': '02-copy-owned-target', 'state': 'running',
                      'elapsed_seconds': time.monotonic() - copy_start,
                      'disk_free': shutil.disk_usage(DESTINATION).free})
        assert process.returncode == 0, (OUT / 'copy.stderr').read_text()[-4000:]
    result['copy_command'] = command
    result['copy_elapsed_seconds'] = time.monotonic() - copy_start
    destination_entries, destination_summary = manifest(DESTINATION, '03-destination')
    assert destination_entries == source_entries, 'Copied target content, metadata or hardlink relationships differ'
    result['destination_manifest'] = destination_summary
    result['copy_verified'] = True
    assert shutil.disk_usage(DESTINATION).free >= RESERVE, 'Less than 12 GiB remains after the complete verified copy'
    assert source_identity() == result['source_before']
    bindings = json.loads((ROOT / 'validation-01/RUNTIME-HELPERS.json').read_text())
    assert bindings['source_head'] == HEAD and bindings['source_tree'] == TREE
    helpers = {}
    for name, original in bindings['artifacts_before_test'].items():
        old_path = Path(original['path'])
        assert old_path.is_relative_to(SOURCE)
        new_path = DESTINATION / old_path.relative_to(SOURCE)
        old_sha = regular_hash(old_path)
        new_sha = regular_hash(new_path)
        assert old_sha == new_sha == original['sha256']
        assert new_path.stat().st_size == old_path.stat().st_size == original['bytes']
        with new_path.open('rb') as f:
            assert f.read(7) == b'\x7fELF\x02\x01\x01'
        helpers[name] = {'logical_path': str(old_path), 'disk_path': str(new_path),
                         'bytes': original['bytes'], 'sha256': new_sha,
                         'old_device': old_path.stat().st_dev, 'old_inode': old_path.stat().st_ino,
                         'new_device': new_path.stat().st_dev, 'new_inode': new_path.stat().st_ino}
    assert set(helpers) == {'codex', 'hepta-infer-worker', 'hepta-joint-propose'}
    result['helpers'] = helpers
    save('COPY-VERIFIED.json', result)
    # Only the fully verified copy belonging to this task is retired. The old
    # logical target path is retained as an alias to preserve Cargo's paths.
    SOURCE.rename(RETIRED)
    try:
        SOURCE.symlink_to(DESTINATION, target_is_directory=True)
    except Exception:
        if not SOURCE.exists() and not SOURCE.is_symlink():
            RETIRED.rename(SOURCE)
        raise
    assert SOURCE.is_symlink() and SOURCE.resolve(strict=True) == DESTINATION
    for helper in helpers.values():
        assert regular_hash(Path(helper['logical_path'])) == helper['sha256']
    assert RETIRED.is_dir() and not RETIRED.is_symlink() and RETIRED.stat().st_dev == 51
    shutil.rmtree(RETIRED)
    result['original_tmp_copy_released'] = True
    assert not RETIRED.exists()
    assert source_identity() == result['source_before']
    result.update({'status': 'relocated_verified', 'source_after': source_identity(),
                   'disk_free_after': shutil.disk_usage(DESTINATION).free,
                   'tmp_free_after': shutil.disk_usage('/tmp').free,
                   'original_logical_path_retained': str(SOURCE),
                   'canonical_target_after': str(SOURCE.resolve(strict=True)),
                   'source_flags_toolchain_or_deadlines_changed': False})
except Exception as error:
    result['status'] = 'failed'
    result['error'] = repr(error)
finally:
    result.update({'finished_at': datetime.now(timezone.utc).isoformat(),
                   'elapsed_seconds': time.monotonic() - start})
    save('FINAL.json', result)
    emit(result)
raise SystemExit(0 if result['status'] == 'relocated_verified' else 1)
