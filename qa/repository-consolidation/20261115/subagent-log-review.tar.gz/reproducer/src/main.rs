use std::io::{self, Write};
use std::sync::{Arc, Mutex};

#[derive(Clone)]
struct Buffer(Arc<Mutex<Vec<u8>>>);

impl Write for Buffer {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.0.lock().expect("buffer lock").write(bytes)
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

fn communicate() {
    if tracing::enabled!(target: "codex_otel.agent_communication", tracing::Level::INFO) {
        tracing::info!(
            target: "codex_otel.agent_communication",
            kind = "spawn",
            state = "send",
            communication_id = "fixture-id",
            "agent communication"
        );
    }
    tracing::info!(
        target: "codex_otel.agent_communication",
        state = "receive",
        communication_id = "fixture-id",
        "agent communication"
    );
}

fn main() {
    let mode = std::env::args().nth(1).expect("baseline, rebuild-only, or retained-dispatch");
    let output = Arc::new(Mutex::new(Vec::new()));
    let writer = Arc::clone(&output);
    let subscriber = tracing_subscriber::fmt()
        .with_ansi(false)
        .with_max_level(tracing::Level::INFO)
        .with_writer(move || Buffer(Arc::clone(&writer)))
        .finish();
    let _guard = tracing::subscriber::set_default(subscriber);
    let _retained_dispatch = if mode == "retained-dispatch" {
        Some(tracing::Dispatch::new(tracing::subscriber::NoSubscriber::default()))
    } else {
        None
    };
    if mode == "rebuild-only" {
        tracing::callsite::rebuild_interest_cache();
    }

    // Exactly one scoped subscriber exists in baseline mode. Another test's
    // thread first reaches the same callsites without a scoped subscriber.
    // Joining makes this order deterministic without an arbitrary delay.
    std::thread::spawn(communicate).join().expect("first caller");
    communicate();
    let logs = String::from_utf8(output.lock().expect("buffer lock").clone())
        .expect("captured UTF-8");
    let sent = logs.contains("kind=\"spawn\"") && logs.contains("state=\"send\"");
    let received = logs.contains("state=\"receive\"");
    println!("mode={mode} captured_send={sent} captured_receive={received} bytes={}", logs.len());
    print!("{logs}");
    if !sent || !received {
        std::process::exit(12);
    }
}
