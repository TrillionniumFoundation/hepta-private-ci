"""Run only reviewed unit modules from a hash-bound source snapshot."""

import argparse
import hashlib
import importlib
import importlib.metadata
import ipaddress
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import unittest


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def no_external_network(event, args):
    if event not in {"socket.connect", "socket.bind", "socket.getaddrinfo"}:
        return
    address = args[0] if event == "socket.getaddrinfo" else args[1]
    host = address[0] if isinstance(address, tuple) else address
    if event != "socket.getaddrinfo" and not isinstance(address, tuple):
        return  # Local Unix sockets used by fixture owners.
    if host == "localhost":
        return
    try:
        if ipaddress.ip_address(host).is_loopback:
            return
    except ValueError:
        pass
    raise RuntimeError("offline test attempted an external network operation")


def run_one(args, selection):
    item = selection[args.one]
    root = args.root.resolve()
    directory = root / Path(item["path"]).parent
    parents = sorted({str((root / p).parent) for p in item["closure"]})
    sys.path[:0] = [str(directory), str(root), *parents]
    sys.addaudithook(no_external_network)
    started = time.monotonic()
    module = importlib.import_module(Path(item["path"]).stem)
    suite = unittest.defaultTestLoader.loadTestsFromModule(module)
    if "names" in item:
        suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name, module) for name in item["names"])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = {
        "path": item["path"], "tests": result.testsRun,
        "failures": [(str(test), detail) for test, detail in result.failures],
        "errors": [(str(test), detail) for test, detail in result.errors],
        "skipped": [(str(test), reason) for test, reason in result.skipped],
        "elapsed_seconds": time.monotonic() - started,
    }
    save(args.output / f"{args.one:03d}.json", receipt)
    return 0 if result.wasSuccessful() else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--one", type=int)
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()
    selection = json.loads(args.selection.read_text())
    if args.one is not None:
        return run_one(args, selection)
    args.output.mkdir(mode=0o700, parents=True, exist_ok=False)
    files = [p for p in args.root.rglob("*") if p.is_file()]
    before = {str(p.relative_to(args.root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    versions = {}
    for package in ("numpy", "cryptography", "torch", "transformers", "safetensors", "peft", "tokenizers"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    save(args.output / "source-before.json", before)
    env = {name: os.environ[name] for name in ("PATH", "LANG", "LC_ALL", "TMPDIR", "SYSTEMROOT", "COMSPEC", "WINDIR", "LD_LIBRARY_PATH") if name in os.environ}
    env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false", OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", OPENBLAS_NUM_THREADS="2", CUDA_VISIBLE_DEVICES="")
    rows = []
    for index, item in enumerate(selection):
        command = [sys.executable, "-B", str(Path(__file__).resolve()), "--root", str(args.root.resolve()), "--selection", str(args.selection.resolve()), "--output", str(args.output.resolve()), "--one", str(index)]
        started = time.monotonic()
        with (args.output / f"{index:03d}.log").open("wb") as log:
            process = subprocess.Popen(command, cwd=args.root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            timed_out = False
            try:
                code = process.wait(timeout=args.timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait()
        row = {"path": item["path"], "exit_code": code, "timed_out": timed_out, "elapsed_seconds": time.monotonic() - started}
        detail = args.output / f"{index:03d}.json"
        if detail.exists():
            row.update(json.loads(detail.read_text()))
        rows.append(row)
        print(json.dumps({key: row.get(key) for key in ("path", "exit_code", "tests", "timed_out", "elapsed_seconds")}), flush=True)
        save(args.output / "progress.json", rows)
    after = {str(p.relative_to(args.root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in args.root.rglob("*") if p.is_file()}
    summary = {"python": sys.version, "versions": versions, "source_unchanged": before == after, "source_files": len(before), "modules": rows, "tests": sum(row.get("tests", 0) for row in rows), "failures": sum(len(row.get("failures", [])) for row in rows), "errors": sum(len(row.get("errors", [])) for row in rows), "skipped": sum(len(row.get("skipped", [])) for row in rows), "module_nonzero": sum(row["exit_code"] != 0 for row in rows), "research_drivers_executed": False, "external_network_guard": "test process audit hook; reviewed child fixture programs only, not an OS network sandbox"}
    save(args.output / "summary.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k not in {"modules", "versions"}}), flush=True)
    return 0 if before == after and all(row["exit_code"] == 0 for row in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
