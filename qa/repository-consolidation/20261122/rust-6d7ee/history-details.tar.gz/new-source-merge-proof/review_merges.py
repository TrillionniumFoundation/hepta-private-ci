import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


BASE = Path('/workspace/scratch/6d7ee0821539')
REPO = BASE / 'hia-boundary/new-source-history-c9d6'
OUT = BASE / 'hia-boundary/new-source-merge-proof'
SOURCE = 'c9d6cb3bdf89fa9065c25b761686fddc9a616609'
EXPECTED_TREE = '5d45f6370129372cc77294088bdfe7e0b0efc28e'
STOP = 'd783273c25b3164f5f632482cb7b017fdcb9d756'
ENV = os.environ.copy()
ENV['GIT_NO_LAZY_FETCH'] = '1'


def git(*args, env=ENV, input=None):
    return subprocess.check_output(['git', *args], cwd=REPO, env=env, input=input)


def stage_entries(output):
    result = []
    for line in output.decode().splitlines()[1:]:
        match = re.fullmatch(r'(\d{6}) ([0-9a-f]{40}) ([123])\t(.+)', line)
        if match:
            result.append({'mode': match[1], 'blob': match[2], 'stage': int(match[3]), 'path': match[4]})
    return result


source_review = json.loads((OUT / 'SOURCE-REVIEW.json').read_text())
source_leaves = (OUT / 'source-full-leaves.bin').read_bytes()
source_entries = {
    row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].decode()
    for row in source_leaves.split(b'\0') if row
}
protected = set(json.loads((BASE / 'hia-boundary/fresh-protected-nodes.json').read_text()))
steps = [
    ('b40', ['codex-rs/hepta-memory/src/cognitive_store_tests.rs']),
    ('e304', ['codex-rs/cli/Cargo.toml', 'codex-rs/cli/src/codex.rs', 'codex-rs/cli/src/main.rs']),
    ('372', ['scripts/hepta_ci_module_paths.py', 'scripts/test_hepta_ci_module_path_scopes.py']),
]
current = SOURCE
reviews = []

for label, allowed_paths in steps:
    original_dir = BASE / ('integration-' + label + '-proof')
    original = json.loads((original_dir / 'REVIEW.json').read_text())
    incoming = original['incoming']
    command = ['git', 'merge-tree', '--write-tree', '--messages', current, incoming]
    if label == 'b40':
        # The first command was executed separately and returned the expected 1.
        stdout = (OUT / 'b40-default.stdout').read_bytes()
        stderr = (OUT / 'b40-default.stderr').read_bytes()
        returncode = 1
    else:
        process = subprocess.run(command, cwd=REPO, env=ENV, capture_output=True)
        stdout, stderr, returncode = process.stdout, process.stderr, process.returncode
        (OUT / (label + '-default.stdout')).write_bytes(stdout)
        (OUT / (label + '-default.stderr')).write_bytes(stderr)
    assert returncode == 1, (label, returncode, stderr.decode())
    assert not stderr, (label, stderr.decode())
    default_tree = stdout.splitlines()[0].decode()
    assert re.fullmatch('[0-9a-f]{40}', default_tree)
    entries = stage_entries(stdout)
    previous_entries = stage_entries((original_dir / 'default-merge.stdout').read_bytes())
    assert entries == previous_entries, (label, 'conflict stages changed')
    conflicts = sorted({entry['path'] for entry in entries})
    changes = git('diff-tree', '-r', '--no-commit-id', '--name-only', '-z', current, default_tree).decode().strip('\0').split('\0')
    assert set(changes) == set(allowed_paths), (label, changes, allowed_paths)
    assert set(conflicts) <= set(allowed_paths)
    assert len(conflicts) == original['conflict_files']

    blocks = {}
    for path in conflicts:
        content = git('show', default_tree + ':' + path)
        blocks[path] = len(re.findall(rb'^<<<<<<< ', content, flags=re.MULTILINE))
    assert sum(blocks.values()) == original['conflict_blocks'], (label, blocks)
    merge_bases = git('merge-base', '--all', current, incoming).decode().splitlines()
    assert merge_bases == [original['incoming_parent']], (label, merge_bases)
    (OUT / (label + '-default.diff')).write_bytes(git('diff', '--no-ext-diff', '--binary', current, default_tree, '--', *allowed_paths))

    index = OUT / (label + '-resolution.index')
    assert not index.exists(), index
    index_env = dict(ENV, GIT_INDEX_FILE=str(index))
    git('read-tree', default_tree, env=index_env)
    resolutions = []
    for path in allowed_paths:
        listing = git('ls-tree', '-z', current, '--', path)
        assert len([part for part in listing.split(b'\0') if part]) == 1
        header, actual_path = listing.rstrip(b'\0').split(b'\t', 1)
        mode, kind, blob = header.decode().split()
        assert actual_path.decode() == path and kind == 'blob'
        assert header.decode() == source_entries[path]
        git('update-index', '--add', '--cacheinfo', mode, blob, path, env=index_env)
        resolutions.append({'path': path, 'mode': mode, 'source_postimage_blob': blob})
    resolved_tree = git('write-tree', '--missing-ok', env=index_env).decode().strip()
    assert resolved_tree == EXPECTED_TREE, (label, resolved_tree)
    leaves = git('ls-tree', '-r', '-z', '--full-tree', resolved_tree)
    assert leaves == source_leaves, (label, 'full leaf record mismatch')
    assert not git('diff-tree', '-r', '--raw', current, resolved_tree)

    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    message = 'Merge reviewed ordinary history ' + incoming + '\n'
    commit_env = dict(ENV, GIT_AUTHOR_NAME='hepta-rust-audit',
                      GIT_AUTHOR_EMAIL='hepta-rust-audit@users.noreply.github.com',
                      GIT_COMMITTER_NAME='hepta-rust-audit',
                      GIT_COMMITTER_EMAIL='hepta-rust-audit@users.noreply.github.com',
                      GIT_AUTHOR_DATE=timestamp, GIT_COMMITTER_DATE=timestamp)
    commit = git('-c', 'commit.gpgSign=false', 'commit-tree', resolved_tree,
                 '-p', current, '-p', incoming, env=commit_env, input=message.encode()).decode().strip()
    raw_commit = git('cat-file', '-p', commit)
    (OUT / (label + '-local-commit.txt')).write_bytes(raw_commit)
    assert hashlib.sha1(b'commit ' + str(len(raw_commit)).encode() + b'\0' + raw_commit).hexdigest() == commit
    parents = [line[7:] for line in raw_commit.decode().split('\n\n', 1)[0].splitlines() if line.startswith('parent ')]
    assert parents == [current, incoming]
    graph = git('rev-list', '--parents', commit)
    nodes = {line.split()[0] for line in graph.decode().splitlines()}
    graph_parents = {parent for line in graph.decode().splitlines() for parent in line.split()[1:]}
    assert not (graph_parents - nodes)
    assert not (nodes & protected) and STOP not in nodes
    review = {
        'source_head': current, 'source_tree': EXPECTED_TREE, 'incoming': incoming,
        'original_proof_file': str(original_dir / 'REVIEW.json'),
        'original_proof_sha256': hashlib.sha256((original_dir / 'REVIEW.json').read_bytes()).hexdigest(),
        'default_merge_command': command, 'default_merge_exit': returncode,
        'default_tree': default_tree, 'merge_bases': merge_bases,
        'conflict_stage_entries': entries, 'conflict_entries_match_original_proof': True,
        'conflict_files': len(conflicts), 'conflict_blocks': blocks,
        'default_changed_paths': changes, 'allowed_resolution_paths': allowed_paths,
        'automatic_correction_paths': sorted(set(changes) - set(conflicts)),
        'resolutions': resolutions, 'resolved_tree': resolved_tree,
        'full_tree_equal_to_new_source': True, 'full_leaf_count': len(source_entries),
        'full_leaf_records_sha256': hashlib.sha256(leaves).hexdigest(),
        'new_source_all_154_paths_preserved': True,
        'local_merge_commit': commit, 'ordered_parents': parents,
        'local_author_and_committer': {'name': 'hepta-rust-audit', 'email': 'hepta-rust-audit@users.noreply.github.com', 'date': timestamp},
        'local_commit_message': message.rstrip('\n'),
        'ancestry_nodes': len(nodes), 'missing_parent_nodes': 0,
        'known_protected_nodes_checked': len(protected),
        'hia_ancestry_intersection': [], 'stop_ancestry_intersection': [],
        'parent_graph_sha256': hashlib.sha256(graph).hexdigest(),
        'write_tree_missing_ok_for_metadata_merkle_reconstruction_only': True,
        'all_merge_relevant_blobs_present_and_default_merge_completed': True,
        'merge_strategy_override': False, 'new_native_tests': False,
        'remote_mutation': False,
    }
    if label == 'b40':
        migrations = sorted(path for path in source_entries if path.startswith('codex-rs/hepta-memory/migrations/'))
        assert [int(Path(path).name[:4]) for path in migrations] == list(range(1, 20))
        review['migration_versions_verified'] = list(range(1, 20))
        review['resolution_basis'] = original['resolution']
    else:
        review['resolution_basis'] = original['resolutions']
    (OUT / (label + '-REVIEW.json')).write_text(json.dumps(review, indent=2) + '\n')
    reviews.append(review)
    current = commit
    print(json.dumps({'step': label, 'default_tree': default_tree, 'resolved_tree': resolved_tree,
                      'local_merge_commit': commit, 'conflict_files': len(conflicts),
                      'conflict_blocks': sum(blocks.values()), 'ancestry_nodes': len(nodes)}), flush=True)

git('update-ref', 'refs/proof/new-source-three-merges', current)
(OUT / 'final-local-merge.txt').write_text(current + '\n')
final_graph = git('rev-list', '--parents', current)
(OUT / 'final-parent-graph.txt').write_bytes(final_graph)
summary = {'source_commit': SOURCE, 'source_tree': EXPECTED_TREE,
           'final_local_merge_commit': current, 'final_tree': EXPECTED_TREE,
           'ordered_local_merges': [review['local_merge_commit'] for review in reviews],
           'ordered_incoming': [review['incoming'] for review in reviews],
           'full_leaf_count': len(source_entries),
           'full_leaf_records_sha256': hashlib.sha256(source_leaves).hexdigest(),
           'all_new_154_paths_preserved_at_every_step': True,
           'final_ancestry_nodes': reviews[-1]['ancestry_nodes'],
           'final_parent_graph_sha256': hashlib.sha256(final_graph).hexdigest(),
           'known_hia_intersection': [], 'stop_intersection': [],
           'local_repository': str(REPO), 'local_ref': 'refs/proof/new-source-three-merges',
           'proofs': [label + '-REVIEW.json' for label, _ in steps],
           'no_remote_mutation': True, 'no_other_worktree_or_index_mutation': True,
           'qualification_boundary': 'Actual default merge-tree and exact ordered-parent local commits; full metadata leaf equality. No new native tests and no claim that absent promised blobs were hydrated or executed.'}
(OUT / 'REVIEW.json').write_text(json.dumps(summary, indent=2) + '\n')
