from pathlib import Path
import ast,hashlib,json,subprocess,os,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116")
A=T/"audit/ci_audit/windows-appcontainer-probe-v1"
P=A/"proposal"
F=T/"audit/ci_audit/codespell-c0e-fragments-v1"
paths=sorted(P.glob("*.py"))
before={p.name:{"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"ast":ast.dump(ast.parse(p.read_text()),include_attributes=False)} for p in paths}
env=dict(os.environ,PYTHONPATH=str(T/"tools/uv-0.11.3"),UV_PROJECT_ENVIRONMENT=str(F/"formatter-venv"))
prefix=[str(T/"tools/uv-0.11.3/bin/uv"),"run","--frozen","--project",str(F/"proposal/scripts"),"ruff"]
commands=[("ruff-version",[*prefix,"--version"]),("ruff-write",[*prefix,"format",*[str(p) for p in paths]]),("ruff-check",[*prefix,"format","--check",*[str(p) for p in paths]]),("ruff-lint",[*prefix,"check",*[str(p) for p in paths]])]
rows=[]
for name,argv in commands:
 start=time.monotonic();r=subprocess.run(argv,cwd=F/"proposal",env=env,capture_output=True,timeout=60)
 raw=r.stdout+r.stderr;(A/(name+".log")).write_bytes(raw)
 rows.append({"name":name,"argv":argv,"cwd":str(F/"proposal"),"exit_code":r.returncode,"seconds":time.monotonic()-start,"log_sha256":hashlib.sha256(raw).hexdigest(),"log":str(A/(name+".log"))})
 print(json.dumps(rows[-1]),flush=True)
after={}
for p in paths:
 raw=p.read_bytes();compile(raw,str(p),"exec")
 after[p.name]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest(),"lines":len(raw.splitlines()),"ast_unchanged_by_formatter":ast.dump(ast.parse(raw),include_attributes=False)==before[p.name]["ast"]}
receipt={"scope":"Static Python parse, same pinned Ruff toolchain; native Windows API/child execution NOT performed","commands":rows,"before_sha256":{k:v["sha256"] for k,v in before.items()},"after":after,"controls":[{"path":str(F/"proposal"/x),"sha256":hashlib.sha256((F/"proposal"/x).read_bytes()).hexdigest()} for x in ["scripts/pyproject.toml","scripts/uv.lock"]]}
(A/"static-validation.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"after":after,"all_static_commands_passed":all(x["exit_code"]==0 for x in rows)},indent=2))
