import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import traceback
from datetime import datetime, timezone

ROOT = Path(os.environ["GITHUB_WORKSPACE"])
OUT = Path(os.environ["RUNNER_TEMP"]) / "hepta-appcontainer-mechanism"
HEAD = os.environ["EXPECTED_HEAD"]
PINS = {
    ".github/scripts/windows-appcontainer-probe/probe.py": "c6dd142579e20651e73000bc1c7200715e729e0d6336d7d1935d3f877929959b",
    ".github/scripts/windows-appcontainer-probe/win32_api.py": "9a10459b06eb6393f1fd7338ade903193a2382faf07d1cc5d34aacf00e39be8f",
}

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def source_snapshot():
    require(re.fullmatch(r"[0-9a-f]{40}", HEAD) is not None, "Invalid PR head SHA")
    actual = subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
    ).strip()
    require(actual == HEAD, "Checkout must equal PR head, not the merge SHA")
    sources = {
        path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        for path in PINS
    }
    require(sources == PINS, "Reviewed experiment source bytes differ")
    return {"head": actual, "sha256": sources}

OUT.mkdir(exist_ok=False)
stdout_path = OUT / "probe.stdout"
stderr_path = OUT / "probe.stderr"
stdout_path.touch(exist_ok=False)
stderr_path.touch(exist_ok=False)
state = {
    "status": "RUNNING", "expected_head": HEAD,
    "started_at": datetime.now(timezone.utc).isoformat(),
    "windows": platform.win32_ver(), "python": sys.version,
    "scope": "owned mechanism only; original positive tests remain required",
    "production_qualification": False,
    "argv": [sys.executable, "-B", next(iter(PINS)), "--repo", str(ROOT),
             "--source-head", HEAD, "--output", str(OUT / "observation.json")],
}
try:
    require(os.name == "nt", "Native Windows is required")
    state["before"] = source_snapshot()
    with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
        completed = subprocess.run(
            state["argv"], cwd=ROOT, stdout=stdout, stderr=stderr, check=False
        )
    state["exit_code"] = completed.returncode
    state["native_observation_present"] = (OUT / "observation.json").is_file()
    require(completed.returncode == 0, "Native mechanism experiment failed")
    observation = json.loads((OUT / "observation.json").read_text(encoding="utf-8"))
    require(observation.get("source_head") == HEAD, "Native report head differs")
    require(observation.get("all_bounded_hypotheses_passed") is True,
            "Native report did not pass the bounded hypotheses")
    state["status"] = "PASS"
except Exception as error:
    state["status"] = "FAIL"
    state["error"] = {"type": type(error).__name__, "message": str(error)}
    state["error_traceback"] = traceback.format_exc()
finally:
    try:
        state["after"] = source_snapshot()
        require(state.get("before") == state["after"], "Source changed during probe")
        state["source_unchanged"] = True
    except Exception as error:
        state["status"] = "FAIL"
        state["source_unchanged"] = False
        state["source_error"] = {"type": type(error).__name__, "message": str(error)}
    state["finished_at"] = datetime.now(timezone.utc).isoformat()
    with (OUT / "invocation-result.json").open("x", encoding="utf-8") as output:
        json.dump(state, output, indent=2)
        output.write("\n")
    print(json.dumps(state, indent=2))
raise SystemExit(0 if state["status"] == "PASS" else 1)
