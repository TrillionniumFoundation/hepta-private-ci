# Windows AppContainer mechanism proposal, revision 2 — native execution pending

## Status

This is a staged, inactive research proposal against the Windows behavior visible at `c0e525fd94e6eea2957bd1a12764627b86dd71ec`. This revision proposes two Python scripts and one independent job appended to the Windows storage workflow at base blob ecf17089f0313e795d8700c98bdfe553b2ea8d11. All original workflow jobs, production admission conditions, and Rust assertions remain byte-identical. The proposal has not been published. Native Windows execution is **pending**. Python parsing, the repository's pinned Ruff formatter, and Ruff checks are the only completed code checks.

The original Windows positive tests remain failures. A successful run of this experiment would qualify only the explicitly owned objects and command below. It would not qualify the elevated backend, host-wide Root+Read behavior, network routing, registry isolation, arbitrary command compatibility, or cleanup under hostile concurrent filesystem replacement.

## Existing implementation search

The supplied non-HIA frontier contains 128 Windows-named maximal tips. All 128 tree reads succeeded. The scoped search covered 354 distinct source/configuration/documentation blobs below the enumerated Windows sandbox paths. Every blob was available and Git-object verified after 226 missing blob reads were resolved (111 reused immutable readbacks, 115 additional GETs).

Six distinct blobs contain an AppContainer term. Four implement a token-information read or reject an AppContainer base; two emit token-information diagnostics. No creation API or lowbox implementation was found in this source closure. The d5df command-line family shares the FreshManagedBase/full-restriction mechanism blobs with 6cfa. Names and coverage counts do not establish native qualification.

The source scope is explicit in `existing-frontier-all-v1/report.json`; this is not a claim to have searched every file or every differently named branch in the repository. The independent protection receipt confirms all 128 tips are outside the supplied HIA protected ancestry set.

## What already exists and why a mask-only change is insufficient

Current `acl.rs` already grants generic read/write/execute plus child `DELETE`, with no `FILE_DELETE_CHILD` in the writable grant. Its write-deny mask already includes deletion. Setup applies those grants and protected metadata carve-outs. Setup also has an explicit test retaining inherited parent deletion grants.

The full-restriction fixture preserves two counterexamples: a parent grant can authorize deletion of a protected child, and an owned outside file with a NULL DACL can be deleted by the existing restricted-token design. Removing a bit which is already absent from our newly written ACE does not change either access-check premise.

The proposed experiment retains the old Rust four-cell and NULL-DACL tests in place. It adds an independent AppContainer package-side four-cell experiment and a deliberately contaminated parent grant. No refusal is substituted for a successful command.

## Candidate mechanism and executable experiment

Microsoft documents AppContainer as a separate package/capability authorization check combined with the normal user/group check. It also provides a separate named-object namespace. LPAC additionally opts out of the broad ALL APPLICATION PACKAGES principal. These features provide a concrete mechanism to investigate, rather than another restricted-token mask variant.

`win32_api.py` is the ABI adapter and bounded descriptor/token reader. `probe.py` constructs the owned fixtures and their required observations. These are separate review stages; the FFI declarations are mechanical API definitions, while the operation/oracle and cleanup logic are reviewed separately. The proposed CI entry point is an independent mechanism experiment and cannot replace the original positive tests.

For each of regular AppContainer and LPAC, the program:

1. Creates one uniquely named profile. An existing profile is never adopted.
2. Creates a private temporary tree with an explicit user/package ACL, writable workspace, protected metadata, ordinary outside files, and both Medium- and Low-integrity NULL-DACL files.
3. Reads back owner, DACL presence, complete ACE lists, integrity labels, the exact writable mask, and the protected-user deny.
4. Launches the real system `cmd.exe` suspended using `STARTUPINFOEX` and `SECURITY_CAPABILITIES`. No handles or caller environment secrets are inherited. The LPAC case additionally sets ALL_APPLICATION_PACKAGES_POLICY opt-out.
5. Reads the actual child token back and requires the requested package, same user, Low integrity, zero capabilities, and the appropriate LPAC flag.
6. Duplicates that exact token for in-process Win32 operations against owned files. Positive ordinary operations, precise access-denied results, NULL-DACL behavior, the package-side four-cell result, and the parent-deletion counterexample are retained separately.
7. Resumes the actual child. Its fixed batch command creates and deletes ordinary files and a directory, reads the explicitly allowed outside file, attempts outside writes and NULL-DACL deletions, and attempts to remove protected metadata. The parent checks exact retained bytes and child-created markers.
8. Waits for that child for a fixed 5 seconds. Timeout, loader failure, wrong token, setup error, wrong permission error, altered bytes, or failed cleanup remains a failure. There are no retries or non-Windows skips.
9. Closes only owned process/token handles, removes only the owned temporary tree, and deletes only the newly created profile. Failure to revert impersonation terminates the probe process immediately.

The package-SID deny case is deliberately an observation, not assumed to implement the protected-child policy. The required protected-child case uses the normal user deny and a parent package grant without FILE_DELETE_CHILD. An additional parent-grant control must demonstrate the remaining deletion path when that bit is deliberately introduced.

NULL-DACL reads are expected to be denied by the candidate mechanism. That explicitly exposes a compatibility gap with Root+Read; it is not a reason to weaken the existing root-read assertion.

## Minimum production closure still required

| Area                           | Required production work and proof                                                                                                                                                                                                                                                              |
| ------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Base identity                  | Derive the AppContainer from the attested dedicated account, retain original account/token provenance and fail-closed lifecycle checks. A CI-user mechanism experiment is not that proof.                                                                                                       |
| Capability representation      | Current S-1-5-21-style restricting identities cannot be used as arbitrary AppContainer package/capability identities. Preserve distinct filesystem grants and network route identities.                                                                                                         |
| Protected metadata             | Prove both the normal and package-side deletion checks, inherited/explicit parent rights, ownership/WRITE_DAC/WRITE_OWNER, child creation, hard links, reparse targets, and cleanup. Package ACE syntax alone is insufficient.                                                                  |
| Root+Read                      | Finite package ACL grants do not implement arbitrary host-root reads. A controlled read broker or another OS-supported equivalent is needed; its path/handle binding and deny rules must remain the original policy. Do not relabel a subset as Root+Read or grant a broad mutation capability. |
| Executable/runtime loading     | Qualify actual supported commands and dependencies with the new process identity and named-object namespace. The original cmd and UnifiedExec tests remain mandatory.                                                                                                                           |
| Network proxy                  | Preserve actual HTTP/SOCKS routing, per-environment identity, policy denial, revocation, cleanup, and the existing port restrictions. This probe adds no network capabilities, loopback exemptions, WFP changes, or network qualification.                                                      |
| AppContainer ambient authority | Regular AppContainer can match ALL APPLICATION PACKAGES grants. The LPAC case is included so the broad default cannot silently stand in for selected grants.                                                                                                                                    |
| Profile state                  | Treat the unique writable profile as managed temporary state with its own lifecycle and revocation proof. Its implicit writable storage is not automatically part of an arbitrary requested filesystem policy.                                                                                  |

A production patch should not replace `require_elevated_filesystem_isolation()` until this closure and the original positive tests pass on the candidate source.

## Proposed native invocation

After root review, the existing pull-request trigger selects the appended job when either script or the workflow changes. No workflow_dispatch trigger is added. The job sets EXPECTED_HEAD to the pull-request head.sha, checks out that exact commit with credentials persistence disabled, and verifies the actual Git HEAD and two fixed script hashes before and after execution. It sets core.autocrlf=false before checkout. The underlying invocation on that isolated native Windows runner is:

```powershell
python -B .github/scripts/windows-appcontainer-probe/probe.py --repo "$env:GITHUB_WORKSPACE" --source-head "$env:EXPECTED_HEAD" --output "$env:RUNNER_TEMP\hepta-appcontainer-mechanism\observation.json"
```

The runner should retain stdout/stderr and the JSON even on failure, plus the two source hashes, exact HEAD, Windows image/version, Python version, and the unchanged original Rust test receipts. EXPECTED_HEAD must be the pull-request head identity, not GITHUB_SHA, which may identify a synthetic merge. The proposed wrapper retains stdout, stderr, and an invocation-result JSON even after probe or preflight failure. It retains native observation JSON whenever produced; missing native observation is never success. Token-close errors mark the case failed and no longer interrupt the remaining owned fixture/profile cleanup. The listed 5-second child limit belongs only to this new experiment; all existing test deadlines and assertions remain unchanged.

## Primary API references

- [Launch an AppContainer](https://learn.microsoft.com/en-us/windows/win32/secauthz/implementing-an-appcontainer): the dual-principal model and process attributes.
- [AppContainer for legacy apps](https://learn.microsoft.com/en-us/windows/win32/secauthz/appcontainer-for-legacy-applications-): process inheritance and named isolation model.
- [CreateAppContainerProfile](https://learn.microsoft.com/en-us/windows/win32/api/userenv/nf-userenv-createappcontainerprofile): unique per-user profile ownership and SID lifetime.
- [NtCreateLowBoxToken](https://learn.microsoft.com/en-us/windows/win32/secauthz/ntcreatelowboxtoken): a distinct token mechanism, considered but not called by this prototype.
- [UpdateProcThreadAttribute](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute): exact process attribute interface.
- [TOKEN_INFORMATION_CLASS](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ne-winnt-token_information_class): actual child-token readback classes.
- [DuplicateTokenEx](https://learn.microsoft.com/en-us/windows/win32/api/securitybaseapi/nf-securitybaseapi-duplicatetokenex): token duplication and access checks.

The NULL-DACL and inherited-deletion outcome of this prototype remains a native measurement to obtain, not a conclusion inferred solely from these documents.
