from pathlib import Path
import ast, hashlib, json, re, subprocess, tempfile, traceback, types, uuid
import yaml
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116")
D=T/"audit/ci_audit/windows-appcontainer-probe-v2"
P=D/"proposal"
def require(condition,message):
    if not condition: raise RuntimeError(message)
def function(name,source,namespace):
    node=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef) and x.name==name)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),"<actual-source-function>","exec"),namespace)
    return namespace[name]
class Pointer:
    def __init__(self): self.value=None
class FakeApi:
    def __init__(self): self.events=[]
    def CreateAppContainerProfile(self,*args):
        args[-1].value=10
        self.events.append("profile_created")
        return 0
    def sid_text(self,pointer): return "S-1-15-2-1"
    def create_suspended(self,*args):
        return types.SimpleNamespace(hProcess=1,hThread=2,dwProcessId=1234)
    def OpenProcessToken(self,process,access,token):
        token.value=3
        return True
    def checked(self,ok,message): require(ok,message)
    def token_facts(self,token): raise RuntimeError("injected token facts failure")
    def WaitForSingleObject(self,handle,timeout): return 0
    def close(self,handle):
        value=handle.value if isinstance(handle,Pointer) else handle
        self.events.append("close:"+str(value))
        if value==3: raise OSError("injected owned-token close failure")
    def DeleteAppContainerProfile(self,profile):
        self.events.append("profile_deleted")
        return 0
    def FreeSid(self,sid): self.events.append("sid_freed")
def invoke(source,lpac):
    api=FakeApi()
    namespace={
        "uuid":uuid,"PTR":Pointer,"HANDLE":Pointer,"C":types.SimpleNamespace(byref=lambda x:x),
        "Path":Path,"tempfile":types.SimpleNamespace(mkdtemp=lambda **_:str(D/"not-created-fixture")),
        "require":require,"hashlib":hashlib,"CHILD_SCRIPT":b"no child executed",
        "TOKEN_QUERY":8,"TOKEN_DUPLICATE":2,"WAIT_TIMEOUT":258,"traceback":traceback,
        "fixture":lambda *_:{"security":[],"unconfined_controls":[],"workspace":D/"not-created-fixture","operations":[]},
        "cleanup_fixture":lambda *_:api.events.append("fixture_removed"),
    }
    run=function("run_case",source,namespace)
    result=None; raised=None
    try: result=run(api,lpac,"S-1-5-21-1",object())
    except Exception as error: raised={"type":type(error).__name__,"message":str(error)}
    return {"result":result,"raised":raised,"events":api.events}
baseline=(D/"preimages/probe.py").read_text()
candidate=(P/".github/scripts/windows-appcontainer-probe/probe.py").read_text()
cleanup=[]
for lpac in (False,True):
    old=invoke(baseline,lpac); new=invoke(candidate,lpac)
    assert old["raised"]=={"type":"OSError","message":"injected owned-token close failure"}
    assert "fixture_removed" not in old["events"] and "profile_deleted" not in old["events"]
    assert new["raised"] is None and new["result"]["status"]=="failed"
    assert new["result"]["error"]["message"]=="injected token facts failure"
    assert new["result"]["cleanup"]["owned_token_error"]=="injected owned-token close failure"
    assert new["events"][-3:]==["fixture_removed","profile_deleted","sid_freed"]
    json.dumps(new["result"])
    cleanup.append({"lpac":lpac,"baseline":old,"candidate":new})
wf=(P/".github/workflows/ndu-windows-storage-probe.yml").read_text()
base=(D/"preimages/.github/workflows/ndu-windows-storage-probe.yml").read_text()
before=yaml.load(base,Loader=yaml.BaseLoader); after=yaml.load(wf,Loader=yaml.BaseLoader)
job=after["jobs"]["appcontainer-mechanism"]
assert {k:v for k,v in after["jobs"].items() if k!="appcontainer-mechanism"}==before["jobs"]
assert after["permissions"]==before["permissions"]=={"contents":"read"}
assert after["concurrency"]==before["concurrency"]
assert list(after["on"])==list(before["on"])==["pull_request"]
paths=after["on"]["pull_request"]["paths"]
newpaths=[".github/scripts/windows-appcontainer-probe/probe.py",".github/scripts/windows-appcontainer-probe/win32_api.py"]
assert [p for p in paths if p not in newpaths]==before["on"]["pull_request"]["paths"]
assert all(paths.count(p)==1 for p in newpaths)
selectors="".join('      - "'+p+'"\n' for p in newpaths)
fragment=(D/"job-fragment.yml").read_text()
assert wf.removesuffix(fragment).replace(selectors,"")==base
assert job["env"]["EXPECTED_HEAD"]=="$"+"{{ github.event.pull_request.head.sha }}"
assert job["permissions"]=={"contents":"read"} and job["timeout-minutes"]=="10"
assert job["steps"][1]["with"]=={"ref":"$"+"{{ github.event.pull_request.head.sha }}","persist-credentials":"false"}
assert job["steps"][-1]["if"]=="always()"
run=next(s["run"] for s in job["steps"] if s["name"]=="Run exact AppContainer and LPAC mechanism experiment")
inline=run.split("@'\n",1)[1].rsplit("\n'@ | python -B -",1)[0]
ast.parse(inline)
module=ast.parse(inline)
pins=ast.literal_eval(next(n.value for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="PINS" for t in n.targets)))
assert {p:hashlib.sha256((P/p).read_bytes()).hexdigest() for p in newpaths}==pins
guards=[]
with tempfile.TemporaryDirectory(prefix="workflow-source-guard-",dir=D) as td:
    repo=Path(td)
    for p in newpaths:
        q=repo/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((P/p).read_bytes())
    for argv in [["git","init","-q"],["git","add","."],["git","-c","user.name=CI fixture","-c","user.email=fixture.invalid","commit","-qm","owned validation fixture"]]:
        subprocess.run(argv,cwd=repo,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
    ns={"ROOT":repo,"HEAD":head,"PINS":pins,"re":re,"subprocess":subprocess,"hashlib":hashlib,"require":require}
    snapshot=function("source_snapshot",inline,ns)
    assert snapshot()=={"head":head,"sha256":pins};guards.append({"case":"exact_source","result":"PASS"})
    for wrong in ["f"*40,"synthetic-merge"]:
        ns["HEAD"]=wrong
        try: snapshot()
        except RuntimeError as e: guards.append({"case":"wrong_head:"+wrong,"result":"REJECT","error":str(e)})
        else: raise AssertionError("wrong head accepted")
    ns["HEAD"]=head
    for p in newpaths:
        q=repo/p;raw=q.read_bytes();q.write_bytes(raw+b"\n# tampered\n")
        try: snapshot()
        except RuntimeError as e: guards.append({"case":"tampered:"+p,"result":"REJECT","error":str(e)})
        else: raise AssertionError("tampered source accepted")
        q.write_bytes(raw)
    assert snapshot()=={"head":head,"sha256":pins}
report={"native_windows":"PENDING","executed_os":"Linux","scope":"actual Python control function and parsed workflow; no Win32 execution","cleanup_cases":cleanup,"source_guard_cases":guards,"original_jobs_equal":True,"original_jobs_raw_bytes_equal":True,"original_triggers_and_permissions_retained":True,"old_workflow_sha256":hashlib.sha256(base.encode()).hexdigest(),"new_workflow_sha256":hashlib.sha256(wf.encode()).hexdigest(),"fixed_source_pins":pins}
(D/"cleanup-and-workflow-validation.json").write_text(json.dumps(report,indent=2)+"\n")
(D/"workflow-inline-runner.py").write_text(inline+"\n")
print(json.dumps({"validation":str(D/"cleanup-and-workflow-validation.json"),"cleanup_cases":len(cleanup),"source_guard_cases":len(guards),"original_jobs":list(before["jobs"]),"native_windows":"PENDING"},indent=2))
