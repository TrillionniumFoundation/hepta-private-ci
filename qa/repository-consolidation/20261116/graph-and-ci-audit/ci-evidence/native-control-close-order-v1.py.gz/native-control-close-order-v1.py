import socket,errno,platform,json,pathlib,hashlib,sys,time
host=sys.argv[1]
out=pathlib.Path(sys.argv[2])
started=time.monotonic()
records=[]
request=b'{"method":"health"}\n'
reply=b'{"ready":true}\n'
for cell in ("reply_then_peer_closes","reply_then_server_shutdown","peer_closes_before_reply","empty_peer_closes","partial_peer_closes"):
  for trial in range(5):
    client,server=socket.socketpair(socket.AF_UNIX,socket.SOCK_STREAM)
    client.settimeout(0.5);server.settimeout(0.5)
    row={"cell":cell,"trial":trial,"client_received_complete_reply":False,"write_completed":False}
    def outcome(fn):
      try:
        fn()
        return {"ok":True}
      except OSError as e:
        return {"ok":False,"errno":e.errno,"symbol":errno.errorcode.get(e.errno),"message":str(e)}
    try:
      if cell in ("empty_peer_closes","partial_peer_closes"):
        if cell=="partial_peer_closes":client.sendall(b"{")
        client.close()
        data=server.recv(1024)
        row.update({"request_bytes_hex":data.hex(),"bounded_newline_frame":bool(data) and data.endswith(b"\n")})
      else:
        client.sendall(request)
        client.shutdown(socket.SHUT_WR)
        assert server.recv(len(request))==request
        if cell=="peer_closes_before_reply":
          client.close()
          row["write"]=outcome(lambda:server.sendall(reply))
          row["shutdown"]=outcome(lambda:server.shutdown(socket.SHUT_WR))
        else:
          server.sendall(reply)
          row["write_completed"]=True
          got=client.recv(len(reply))
          assert got==reply,got
          row["client_received_complete_reply"]=True
          if cell=="reply_then_peer_closes":
            client.close()
            row["shutdown"]=outcome(lambda:server.shutdown(socket.SHUT_WR))
          else:
            row["shutdown"]=outcome(lambda:server.shutdown(socket.SHUT_WR))
            assert client.recv(1)==b""
            client.close()
    finally:
      client.close();server.close()
    records.append(row)
result={"experiment":"Native AF_UNIX SOCK_STREAM bounded close-order behavior, no repository or Tokio code executed","host":host,"platform":platform.platform(),"python":platform.python_version(),"elapsed_seconds":time.monotonic()-started,"limitations":["Explicit ordering establishes a possible kernel behavior, not frequency or original CI causation.","socketpair uses native AF_UNIX stream transport; it does not execute Agentd/RuntimeTasks or the Tokio reactor."],"records":records}
data=(json.dumps(result,indent=2)+"\n").encode()
with out.open("xb") as f:f.write(data)
summary={}
for row in records:
 key=row["cell"];summary.setdefault(key,[]).append(row.get("shutdown",row.get("bounded_newline_frame")))
print(json.dumps({"artifact":str(out),"sha256":hashlib.sha256(data).hexdigest(),"summary":summary,"elapsed_seconds":result["elapsed_seconds"]},indent=2))
