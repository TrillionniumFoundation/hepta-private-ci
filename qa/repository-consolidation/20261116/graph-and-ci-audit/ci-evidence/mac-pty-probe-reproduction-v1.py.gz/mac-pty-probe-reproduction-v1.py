#!/usr/bin/env python3
"""Owned, bounded macOS PTY protocol reproduction; no repository code changed."""
import errno
import fcntl
import json
import os
from pathlib import Path
import platform
import pty
import re
import select
import signal
import subprocess
import sys
import termios
import time

AUDIT = Path(__file__).resolve().parent
READY = b"__codex_pty_ready__"
PID_MARKER = b"__codex_preserved_py_pid:"
OLD_PROBE = b"print('__codex_pty_ready__')\n"
SPLIT_PROBE = b"print('__codex_pty_' + 'ready__')\n"
GLOBAL_END = time.monotonic() + 55.0

def read_chunk(master, seconds):
    ready, _, _ = select.select([master], [], [], max(0.0, seconds))
    if not ready:
        return None
    try:
        return os.read(master, 8192)
    except OSError as error:
        if error.errno in (errno.EIO, errno.EBADF):
            return b""
        if error.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
            return None
        raise

def echo_without_child(command):
    master, slave = pty.openpty()
    try:
        os.set_blocking(master, False)
        os.write(master, command)
        data = bytearray()
        deadline = time.monotonic() + 0.5
        while time.monotonic() < deadline:
            chunk = read_chunk(master, deadline-time.monotonic())
            if chunk is None or chunk == b"":
                break
            data.extend(chunk)
            if b"\n" in data:
                break
        return {"child_started": False, "echo_hex": bytes(data).hex(),
                "old_contains_predicate": READY in data}
    finally:
        os.close(master)
        os.close(slave)

def attach_controlling_terminal():
    fcntl.ioctl(0, termios.TIOCSCTTY, 0)

def spawn_python(slave, args, preserve):
    # Exclude personal startup hooks; no user startup script is executed.
    env = dict(os.environ)
    env["PYTHONSTARTUP"] = ""
    env.pop("PYTHONPATH", None)
    pass_fds = ()
    extra = []
    if preserve:
        read_fd, write_fd = os.pipe()
        extra = [read_fd, write_fd]
        env["PRESERVED_FD"] = str(write_fd)
        pass_fds = (write_fd,)
    try:
        return subprocess.Popen(
            [sys.executable] + args, stdin=slave, stdout=slave, stderr=slave,
            env=env, close_fds=True, pass_fds=pass_fds,
            start_new_session=True, preexec_fn=attach_controlling_terminal)
    finally:
        for fd in extra:
            os.close(fd)

def cleanup_child(process):
    if process is None:
        return
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=1)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=1)
    else:
        process.wait()

def repl_trial(command, label, trial):
    master, slave = pty.openpty()
    process = None
    started = time.monotonic()
    result = {"probe": label, "trial": trial, "ready_limit_s": 5,
              "pid_limit_s": 2, "exit_limit_s": 5}
    try:
        os.set_blocking(master, False)
        process = spawn_python(slave, [], True)
        os.close(slave)
        slave = -1
        collected = bytearray()
        deadline = min(time.monotonic()+5.0, GLOBAL_END)
        ready = False
        while time.monotonic() < deadline:
            os.write(master, command)
            probe_deadline = min(time.monotonic()+0.250, deadline)
            while time.monotonic() < probe_deadline:
                chunk = read_chunk(master, probe_deadline-time.monotonic())
                if chunk is None:
                    break
                if chunk == b"":
                    result["status"] = "closed_before_ready"
                    return result
                collected.extend(chunk)
                if READY in collected:
                    ready = True
                    break
            if ready:
                break
        result["ready_seen_at_s"] = time.monotonic()-started
        result["ready_bytes_hex"] = bytes(collected).hex()
        result["ready_contains_only_echo"] = ready and not any(
            line.strip() == READY for line in bytes(collected).splitlines())
        if not ready:
            result["status"] = "ready_timeout"
            return result
        os.write(master, b"import os; print('__codex_preserved_py_pid:' + str(os.getpid()))\n")
        pid_output = bytearray()
        deadline = min(time.monotonic()+2.0, GLOBAL_END)
        observed_pid = None
        while time.monotonic() < deadline:
            chunk = read_chunk(master, deadline-time.monotonic())
            if chunk is None:
                break
            if chunk == b"":
                result["status"] = "closed_before_pid"
                break
            pid_output.extend(chunk)
            match = re.search(re.escape(PID_MARKER)+rb"([0-9]+)(?=.)", bytes(pid_output), re.S)
            if match:
                observed_pid = int(match.group(1))
                break
        result["pid_bytes_hex"] = bytes(pid_output).hex()
        result["observed_pid_matches_child"] = observed_pid == process.pid
        if observed_pid is None:
            result.setdefault("status", "pid_timeout")
            return result
        if observed_pid != process.pid:
            result["status"] = "wrong_pid"
            return result
        os.kill(observed_pid, 0)
        os.write(master, b"exit()\n")
        deadline = min(time.monotonic()+5.0, GLOBAL_END)
        while process.poll() is None and time.monotonic() < deadline:
            read_chunk(master, min(0.05, deadline-time.monotonic()))
        result["child_exit_code"] = process.poll()
        result["status"] = "pass" if process.poll() == 0 else "exit_failed_or_timeout"
        return result
    finally:
        result["elapsed_s"] = time.monotonic()-started
        cleanup_child(process)
        os.close(master)
        if slave >= 0:
            os.close(slave)

def discarded_output(preserve):
    master, slave = pty.openpty()
    process = None
    started = time.monotonic()
    result = {"preserved_fd": preserve, "deadline_s": 2, "requested_bytes": 4*1024*1024}
    try:
        os.set_blocking(master, False)
        program = "import signal, sys\nsignal.alarm(10)\nsys.stdout.buffer.write(b'x' * (4 * 1024 * 1024))"
        process = spawn_python(slave, ["-c", program], preserve)
        os.close(slave)
        slave = -1
        total = 0
        deadline = min(time.monotonic()+2.0, GLOBAL_END)
        while time.monotonic() < deadline:
            chunk = read_chunk(master, min(0.05, deadline-time.monotonic()))
            if chunk == b"":
                break
            if chunk is not None:
                total += len(chunk)
        result["discarded_bytes"] = total
        result["child_exit_code"] = process.poll()
        result["status"] = "pass" if total == 4*1024*1024 and process.poll() == 0 else "failed_or_timeout"
        return result
    finally:
        result["elapsed_s"] = time.monotonic()-started
        cleanup_child(process)
        os.close(master)
        if slave >= 0:
            os.close(slave)

def main():
    result = {"platform": platform.platform(), "machine": platform.machine(),
              "python": sys.executable, "python_version": sys.version,
              "scope": "native stdlib PTY protocol; not the Rust Tokio implementation or original CI runner",
              "echo_without_child": {"original": echo_without_child(OLD_PROBE),
                                     "split_literal": echo_without_child(SPLIT_PROBE)}}
    assert result["echo_without_child"]["original"]["old_contains_predicate"]
    assert not result["echo_without_child"]["split_literal"]["old_contains_predicate"]
    result["repl_trials"] = []
    for label, command in [("original", OLD_PROBE), ("split_literal", SPLIT_PROBE)]:
        for index in range(4):
            if time.monotonic()+8 > GLOBAL_END:
                break
            row = repl_trial(command, label, index)
            result["repl_trials"].append(row)
            print(json.dumps({"trial": label, "index": index, "status": row["status"],
                              "echo_only_ready": row.get("ready_contains_only_echo"),
                              "elapsed_s": row["elapsed_s"]}), flush=True)
    result["discarded_output"] = [discarded_output(False), discarded_output(True)]
    output = AUDIT/"mac-pty-probe-reproduction-v1.json"
    with output.open("x") as file:
        json.dump(result, file, indent=2)
        file.write("\n")
    print(json.dumps({"output": str(output), "echo_false_readiness_proven": True,
                      "discarded_output": result["discarded_output"]}, indent=2), flush=True)

if __name__ == "__main__":
    main()
