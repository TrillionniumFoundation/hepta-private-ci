from pathlib import Path
import json,subprocess,os,hashlib,datetime,re,sys
T=Path('/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116');P=T/'audit/branch_inventory';D=P/'taskflow-rustsec-families-4a-v1';G=D/'object-view.git';Q=P/'unified-ten-parent-bb6-v1';Q.mkdir(exist_ok=False);(Q/'build.py').write_text(sys.argv[1])
base='bb6b57c100659d08778ecab34a8ce863725b2dda';expected_base_tree='16ad22c4a40bf6fbbfe295ea3307670b7ddd7cfb';sha=lambda b:hashlib.sha256(b).hexdigest()
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',GIT_AUTHOR_NAME='Repository consolidation audit',GIT_AUTHOR_EMAIL='audit@local.invalid',GIT_COMMITTER_NAME='Repository consolidation audit',GIT_COMMITTER_EMAIL='audit@local.invalid')
def git(*a,input=None,extra=None,check=True):
 return subprocess.run(['git','--git-dir='+str(G),*a],env=env|dict(extra or {}),input=input,capture_output=True,check=check,timeout=180)
def info(ref):
 raw=git('cat-file','commit',ref).stdout;assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==ref
 lines=raw.decode().split('\n\n',1)[0].splitlines();return raw,next(x[5:] for x in lines if x.startswith('tree ')),[x[7:] for x in lines if x.startswith('parent ')]
def trees(ref):
 out={}
 for line in git('ls-tree','-r','-z',ref).stdout.split(b'\0'):
  if not line:continue
  meta,p=line.split(b'\t',1);m,t,s=meta.decode().split();out[p.decode()]={'mode':m,'type':t,'sha':s}
 return out
def delta(a,b):
 out=[]
 for line in git('diff','--raw','--no-abbrev','--no-renames',a,b).stdout.decode().splitlines():
  meta,p=line.split('\t',1);om,m,old,new,status=meta.split();out.append({'path':p,'oldMode':om[1:],'mode':m,'oldBlob':old,'blob':new,'status':status})
 return out
source_paths=[
 P/'small-parent-batch3-65b50-v1/minimal-union-v1/source-plan.json',
 P/'small-parent-batch4-4a-v1/minimal-union-v3/source-plan.json',
 P/'medium-small-families-4a-v1/minimal-union-v3/source-plan.json',
 D/'rustsec-minimal-union-v1/source-plan.json',
 D/'taskflow-minimal-union-v1/source-plan.json']
expected_shas=['770d7df','2967d86f','7e21d750','fc963b88','05b552f3']
sources=[];all_entries={}
for path,prefix in zip(source_paths,expected_shas):
 b=path.read_bytes();assert sha(b).startswith(prefix),(path,sha(b));o=json.loads(b);rows=o.get('entries',o.get('sourceEntries'));assert rows
 sources.append({'path':str(path),'bytes':len(b),'sha256':sha(b),'sourceCount':len(rows),'originalValidation':o.get('validation',o.get('tests',o.get('gates',o.get('commands'))))})
 for e in rows:
  e=dict(e);e['sha']=e.get('postBlob',e.get('sha'));e['postBlob']=e['sha'];e['type']='blob'
  assert e['path'] not in all_entries,e['path'];b=Path(e['sourcePath']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'] and len(b)<=512000
  assert git('hash-object','-w','--stdin',input=b).stdout.decode().strip()==e['sha'];all_entries[e['path']]=e
assert len(all_entries)==20
plans=[
 P/'small-parent-batch3-65b50-v1/ordinary-chain-v1/ordinary-two-merge-plan.json',
 P/'small-parent-batch4-4a-v1/ordinary-chain-v2/ordinary-four-merge-plan.json',
 P/'medium-small-families-4a-v1/ordinary-chain-v1/ordinary-two-merge-plan.json']
descriptors=[];prior_refs=[]
for f in plans:
 b=f.read_bytes();o=json.loads(b);prior_refs.append({'path':str(f),'bytes':len(b),'sha256':sha(b)})
 for st in o['steps']:
  tip=st.get('incomingParent',st.get('secondParent'))
  explicit=st['explicitResolutions']
  reviewed=st.get('reviewedUniqueCommits',st.get('uniqueIncomingCommits'))
  chosen={}
  for r in explicit:
   p=r['path'];entry=r.get('resolved')
   if entry is None:
    entry={'mode':'100644','type':'blob','sha':r['chosenBlob']}
   chosen[p]={'selected':entry,'reason':r.get('reason',r.get('semanticResolution')),'sourcePath':r.get('sourcePath')}
  descriptors.append({'tip':tip,'oldFirstParent':st['firstParent'],'reviewedUnique':reviewed,'explicit':chosen,'originalPlan':prior_refs[-1],'originalStep':st})
rustsec_path=D/'rustsec-ordinary-merge-v1/ordinary-rustsec-merge-plan.json';rustsec_raw=rustsec_path.read_bytes();rs=json.loads(rustsec_raw);rr={'path':str(rustsec_path),'bytes':len(rustsec_raw),'sha256':sha(rustsec_raw)};prior_refs.append(rr)
descriptors.append({'tip':rs['incoming'],'oldFirstParent':rs['base'],'reviewedUnique':rs['historyReview']['uniqueIncomingCommits'],'explicit':{r['path']:{'selected':r['resolved'],'reason':r['semanticResolution'],'sourcePath':r['sourcePath']} for r in rs['explicitResolutions']},'originalPlan':rr,'originalStep':rs})
tf=json.loads(source_paths[-1].read_text());tf_historypath=D/tf['incoming']/'source-history.json';th=json.loads(tf_historypath.read_text())
descriptors.append({'tip':tf['incoming'],'oldFirstParent':tf['base'],'reviewedUnique':th['uniqueCommits'],'explicit':{e['path']:{'selected':{'mode':e['mode'],'type':'blob','sha':e['postBlob']},'reason':tf['semanticResolutions'][e['path']],'sourcePath':e['sourcePath']} for e in tf['entries']},'originalPlan':{'path':str(source_paths[-1]),'bytes':source_paths[-1].stat().st_size,'sha256':sha(source_paths[-1].read_bytes())},'originalStep':{'history':str(tf_historypath),'historySha256':sha(tf_historypath.read_bytes())}})
expected_tips=['5805e37161390382d94de5012ebb58112a19cfae','e21596c5c2e71ace85540865a4d856a3bd7a61d2','25c1bdd55f370722ea9d8d5daca8d015e3b53aae','73e1515f0c6cf4301c2ac36c57f4a1bd09a9f81e','9ef85ce3c4e40d2743c5d8d6c57517a238cc3fb9','b418960debf84fbfe7b0c805205f363c93d4aa9c','dcf71113bf196b7001583d4ad8497c90a70a2241','88994f6bf50e4336beca3d5ce2c760192ea523a6','4729f8a66c884c396e062266ae280a43213546bc','8ac3e707f4522d951a159c54eaa356903cddf2f1'];assert [x['tip'] for x in descriptors]==expected_tips
raw,bt,parents=info(base);assert bt==expected_base_tree and parents==['4a5630661b1fee17582b452520c32fb5805831aa'];(Q/'base-commit.raw').write_bytes(raw)
before_base=trees(base)
for p,e in all_entries.items():assert (before_base.get(p) or {}).get('sha')==e['baseBlob'],p
publication_path=T/'audit/root-proof-checkpoint-20261117T0105-v1/entries.final.json';pub_b=publication_path.read_bytes();assert sha(pub_b)=='fbd92eda07cfcb1441598be94efe8dcb1597b6dc770f2740a9750cdc9d1d8122';pub=json.loads(pub_b);assert len(pub)==156 and len({r['path'] for r in pub})==156
for r in pub:assert before_base[r['path']]=={k:r[k] for k in ['mode','type','sha']}
cls_path=P/'branch_classification.json';cls=json.loads(cls_path.read_text());eligible=[r for r in cls if not r['protected_hia'] and r['name']!='main'];assert len(eligible)==7230
prot_path=P/'fresh-refs-20261117T023410-pre-bb6-lease/fresh-ref-protection.json';prot=json.loads(prot_path.read_text());pins=set(prot['priorAndOriginalProtectedPins'])|set(prot['markers'])|{r['observed_sha'] for r in prot['currentProtectedVector']};assert len(prot['currentProtectedVector'])==123
base_anc=set(git('rev-list',base).stdout.decode().split());assert not base_anc&pins
covered={r['name'] for r in eligible if r['sha'] in base_anc};assert len(covered)==1835;base_covered=covered.copy()
ci_path=T/'audit/ci_audit/hosted-60658ec5/strict-clippy-98-callers-v1/review-source-v2/source-plan.json';ci_raw=ci_path.read_bytes();assert sha(ci_raw)=='fef3249e553752b7d7588d9a1830566a54de138f07e3a63b675344b1a9dee03f';ci=json.loads(ci_raw);ci_inter=sorted(set(all_entries)&{r['path'] for r in ci['entries']})
steps=[];current=base;all_unique=set();touched={};overlaps=[]
for i,desc in enumerate(descriptors,1):
 incoming=desc['tip'];sd=Q/f'{i:02d}-{incoming[:8]}';sd.mkdir();before=trees(current);inc=trees(incoming);old_before=trees(desc['oldFirstParent'])
 actual_unique=git('rev-list','--reverse',current+'..'+incoming).stdout.decode().split()
 assert set(actual_unique)<=set(desc['reviewedUnique']),(incoming,sorted(set(actual_unique)-set(desc['reviewedUnique'])))
 unique_info=[]
 for c in actual_unique:
  cr,ct,cp=info(c);unique_info.append({'sha':c,'tree':ct,'parents':cp,'rawCommitSha256':sha(cr),'parentDeltas':[{'parent':p,'paths':delta(p,c)} for p in cp]})
 all_unique.update(actual_unique)
 mb=git('merge-base',current,incoming).stdout.decode().strip();net=delta(mb,incoming);net_paths={r['path'] for r in net};res_paths=set(desc['explicit']);assert net_paths<=res_paths,(incoming,net_paths-res_paths)
 for p in res_paths:
  assert before.get(p)==old_before.get(p),(incoming,p,before.get(p),old_before.get(p))
 cp=git('merge-tree','--write-tree','--messages',current,incoming,check=False);(sd/'merge-tree.stdout').write_bytes(cp.stdout);(sd/'merge-tree.stderr').write_bytes(cp.stderr);assert cp.returncode in (0,1),(incoming,cp.returncode,cp.stderr.decode())
 preview=cp.stdout.decode().splitlines()[0];assert re.fullmatch('[0-9a-f]{40}',preview);pt=trees(preview);preview_changed={p for p in set(pt)|set(before) if pt.get(p)!=before.get(p)};assert preview_changed<=res_paths,(incoming,preview_changed-res_paths)
 ix={'GIT_INDEX_FILE':str(sd/'private.index')};git('read-tree',preview,extra=ix);resolutions=[]
 for p in sorted(res_paths):
  r=desc['explicit'][p];chosen=r['selected'];assert chosen and chosen['type']=='blob'
  if p in touched:
   overlaps.append({'path':p,'earlierSteps':touched[p].copy(),'currentStep':i,'incoming':incoming,'before':before.get(p),'chosen':chosen,'reason':r['reason'],'unchangedReviewedPreimage':before.get(p)==old_before.get(p)})
  git('update-index','--add','--cacheinfo',chosen['mode'],chosen['sha'],p,extra=ix)
  resolutions.append({'path':p,'mergeBase':trees(mb).get(p),'current':before.get(p),'incoming':inc.get(p),'ordinaryPreview':pt.get(p),'chosen':chosen,'reason':r['reason'],'sourcePath':r['sourcePath'],'reviewedFirstParent':desc['oldFirstParent'],'reviewedPreimage':old_before.get(p),'currentPreimageExactlyMatchesReviewed':True})
  touched.setdefault(p,[]).append(i)
 tree=git('write-tree',extra=ix).stdout.decode().strip();after=trees(tree);changed=sorted(p for p in set(before)|set(after) if before.get(p)!=after.get(p));assert set(changed)<=res_paths
 assert all(before.get(p)==after.get(p) for p in (set(before)|set(after))-res_paths)
 assert all(after[r['path']]=={k:r[k] for k in ['mode','type','sha']} for r in pub)
 for p in changed:
  assert p in all_entries and after[p]['sha']==all_entries[p]['sha'],p
 commit=git('commit-tree',tree,'-p',current,'-p',incoming,input=(f'Audit: ordinary reviewed merge {i:02d} of {incoming}\\n\\nOriginal semantics resolved path by path; native qualification remains pending.\\n').encode()).stdout.decode().strip()
 cr,ct,ps=info(commit);assert ct==tree and ps==[current,incoming];(sd/'local-commit.raw').write_bytes(cr)
 anc=set(git('rev-list',commit).stdout.decode().split());assert not anc&pins
 now_covered={r['name'] for r in eligible if r['sha'] in anc};added=sorted(now_covered-covered)
 step={'order':i,'firstParent':current,'secondParent':incoming,'localCommit':commit,'tree':tree,'previousTree':info(current)[1],'mergeBase':mb,'originalReview':desc['originalPlan'],'originalDetailedStep':desc['originalStep'],'uniqueIncomingCommits':actual_unique,'uniqueCommitParentAndTreeVerification':unique_info,'netIncomingDelta':net,'normalMergePreview':{'exitCode':cp.returncode,'tree':preview,'stdout':str(sd/'merge-tree.stdout'),'stdoutSha256':sha(cp.stdout),'stderr':str(sd/'merge-tree.stderr'),'stderrSha256':sha(cp.stderr),'changedPaths':sorted(preview_changed)},'explicitResolutions':resolutions,'changedEntries':[{'path':p,**after[p],**{k:all_entries[p][k] for k in ['bytes','sha256','sourcePath']},'baseBlob':(before.get(p) or {}).get('sha')} for p in changed],'allOutsideResolvedPathsExactlyRetained':True,'all156PublishedEvidenceEntriesExactlyRetained':True,'protectedIntersections':[],'candidateAncestorCount':len(anc),'newOriginalHeads':added,'covered':len(now_covered),'remaining':7230-len(now_covered),'nativeTestsExecutedInThisPlan':False}
 (sd/'step.json').write_text(json.dumps(step,indent=2)+'\n');steps.append(step);current=commit;covered=now_covered
 print('STEP',i,incoming,commit,tree,'newHeads',len(added),'coverage',len(covered),'newCommits',len(actual_unique),flush=True)
final=trees(current);changed=sorted(p for p in set(final)|set(before_base) if final.get(p)!=before_base.get(p));assert set(changed)==set(all_entries)
assert all(before_base.get(p)==final.get(p) for p in (set(before_base)|set(final))-set(all_entries))
check=git('diff','--check',base,current,check=False);(Q/'git-diff-check.stdout').write_bytes(check.stdout);(Q/'git-diff-check.stderr').write_bytes(check.stderr);assert check.returncode==0
patch=git('diff','--binary','--full-index','--no-ext-diff','--no-textconv',base,current).stdout;(Q/'combined-source20.patch').write_bytes(patch)
protected_receipt={'snapshot':str(prot_path),'sha256':sha(prot_path.read_bytes()),'currentProtectedNames':123,'allCurrentPriorOriginalAndMarkerPins':len(pins),'markers':prot['markers'],'candidate':current,'candidateAncestors':steps[-1]['candidateAncestorCount'],'intersections':[]}
plan={'schemaVersion':1,'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'baseTree':bt,'sourceBase4aEqualExcept156PublishedEvidence':True,'objectDatabase':str(G/'objects'),'orderedIncomingParents':expected_tips,'sourcePlans':sources,'originalIndependentPlans':prior_refs,'steps':steps,'finalLocalCommit':current,'finalTree':info(current)[1],'originalEligibleCount':7230,'originalEligibleClassification':str(cls_path),'originalEligibleClassificationSha256':sha(cls_path.read_bytes()),'publishedBaseCovered':len(base_covered),'newOriginalHeadCount':len(covered-base_covered),'newOriginalHeads':sorted(covered-base_covered),'finalCovered':len(covered),'remaining':7230-len(covered),'uniqueIncomingCommitCount':len(all_unique),'uniqueIncomingCommits':sorted(all_unique),'sourceEntries':list(all_entries.values()),'finalChangedPathCount':len(changed),'finalChangedPaths':changed,'allOtherPathModeTypeObjectEntriesExactlyEqualPublishedBase':True,'publishedEvidence':{'manifest':str(publication_path),'manifestSha256':sha(pub_b),'count':156,'entriesExactlyRetained':[{k:r[k] for k in ['path','mode','type','sha']} for r in pub]},'reviewedCrossStepPathOverlaps':overlaps,'frozenStrict55Intersection':{'manifest':str(ci_path),'sha256':sha(ci_raw),'paths':ci_inter,'status':'No strict55 source was applied or overwritten; root must explicitly replay any overlapping later source if paths are listed.'},'protection':protected_receipt,'validation':{'gitDiffCheckExitCode':0,'changedBlobSizesAllWithinOriginal512000Cap':True,'combinedPatch':{'path':str(Q/'combined-source20.patch'),'bytes':len(patch),'sha256':sha(patch)},'testsRerunForRebase':False,'scopeSpecificProofs':sources,'nativeQualification':'Pending original affected-package and platform gates. No Linux, Windows or Bazel qualification is inferred from graph, format, or Python outcomes.'},'authorityLimit':'The 5805 production signed Aborted terminal state is not implemented or qualified. Digest-only unsigned Abort remains rejected while current signed Committed/RolledBack/fence semantics are preserved; the full historical feature request and conflicts remain in the original parent and review.','publicationStatus':'Local objects only; remote main/integration/HIA refs, PRs and remote objects were not modified. Root maps ordered first parents to its actual candidate and performs required native gates.','mergeMethod':'Every step uses an actual ordinary merge-tree preview, only individually reviewed path resolutions in a unique private index, and a two-parent commit with the original incoming tip. No ours strategy and no whole-tree swap.'}
f=Q/'unified-10-ordinary-merge-plan.json';f.write_text(json.dumps(plan,indent=2)+'\n')
compact={'plan':str(f),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes()),'base':base,'finalCommit':current,'tree':plan['finalTree'],'parents':10,'uniqueIncomingCommits':len(all_unique),'newHeads':len(covered-base_covered),'covered':len(covered),'remaining':7230-len(covered),'changedPaths':len(changed),'evidenceRetained':156,'crossStepOverlaps':[{'path':r['path'],'steps':r['earlierSteps']+[r['currentStep']]} for r in overlaps],'strict55Intersection':ci_inter,'protected123Intersections':[]}
(Q/'result.json').write_text(json.dumps(compact,indent=2)+'\n');print('FINAL',json.dumps(compact,indent=2),flush=True)