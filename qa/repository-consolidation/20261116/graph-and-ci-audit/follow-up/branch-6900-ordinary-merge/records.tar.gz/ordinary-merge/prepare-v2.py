from pathlib import Path
import os,sys,json,hashlib,subprocess,datetime
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");G=T/"safe-evidence-merge";O=T/"audit/root-6900-ordinary-merge-v1";(O/"prepare-v2.py").write_text(sys.argv[1])
current="346483e5a1edf863a71843935b8e0768041f2e6a";incoming="6900ccdef5007b8acd7e6ff7bdc2f85d37b58abd"
N=T/"audit/branch_inventory/medium-family-review"/incoming;W=T/"audit/ci_audit/family-6900-workflow-union-v1"
env=os.environ.copy();env.update(GIT_NO_LAZY_FETCH="1",GIT_NO_REPLACE_OBJECTS="1",GIT_OPTIONAL_LOCKS="0")
def git(*a,input=None):return subprocess.check_output(["git",*a],cwd=G,env=env,input=input)
def vector(ref):
 d={}
 for v in git("ls-tree","-rz",ref).split(b"\0"):
  if not v:continue
  head,p=v.split(b"\t",1);mode,typ,sha=head.decode().split()
  d[os.fsdecode(p)]={"mode":mode,"type":typ,"sha":sha}
 return d
before=vector(current);base=git("rev-parse",current+"^{tree}").decode().strip()
review=json.loads((N/"semantic-source-and-history-review-v1.json").read_bytes())
mp=N/"minimal-union-v3/proposal-manifest.json";assert hashlib.sha256(mp.read_bytes()).hexdigest()=="8f0a4fedb8af12d6a6ed029660b5ec1e3b825a214968027466fab3f89e8f0bde"
wp=W/"proposal-manifest.json";assert hashlib.sha256(wp.read_bytes()).hexdigest()=="831d93ff56808ce317a35c4279da4f93087fa742e02f69b6f7218704ef0d582b"
m=json.loads(mp.read_bytes());w=json.loads(wp.read_bytes())
supervisor={"codex-rs/hepta-supervisor/tests/restart_budget_recovery.rs":"75431770e05206d9a0334cb100589fd5eafcf6a3","codex-rs/hepta-supervisor/tests/signed_intent_recovery.rs":"324cdb834ee56bb92001ec2ed4d8e5126c4ded90"}
entries=[]
for e in m["source_changes"]:
 if e["path"] in supervisor:
  assert before[e["path"]]["sha"]==supervisor[e["path"]];continue
 entries.append({"path":e["path"],"baseBlob":e["preimage"],"postBlob":e["sha"],"bytes":e["bytes"],"sha256":e["sha256"],"sourcePath":e["source_path"],"reason":e["semantics"]})
for e in w["entries"]:
 entries.append({k:e[k] for k in ["path","baseBlob","postBlob","bytes","sha256","sourcePath"]}|{"reason":("Preserve the exact current architecture workflow and add only the signed_intent_recovery lifecycle command; 5993-only additions remain deferred." if e["path"].endswith("hepta-architecture-convergence.yml") else e["purpose"])})
assert len(entries)==7
for e in entries:
 old=before.get(e["path"]);assert (old["sha"] if old else None)==e["baseBlob"],e["path"]
 raw=Path(e["sourcePath"]).read_bytes();assert len(raw)==e["bytes"] and hashlib.sha256(raw).hexdigest()==e["sha256"],e["path"]
 oid=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest();assert oid==e["postBlob"]
 assert git("hash-object","-w","--stdin",input=raw).decode().strip()==oid
 e["mode"]=old["mode"] if old else "100644";e["type"]="blob"
 p=O/"files"/e["path"];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
desired={e["path"]:e for e in entries}
preview=(O/"ordinary-merge-preview.stdout").read_bytes()
preview_tree=preview.splitlines()[0].decode();auto=vector(preview_tree)
conflicts=sorted({l.split(b"\t",1)[1].decode() for l in preview.splitlines() if b"\t" in l and l.startswith(b"100")})
merge_base=json.loads((O/"ordinary-merge-preview.json").read_bytes())["mergeBase"]
net=set(os.fsdecode(p) for p in git("diff","--no-renames","--name-only","-z",merge_base,incoming).split(b"\0") if p)
assert net=={e["path"] for e in review["source_paths"]} and len(net)==25
allowed_evolved={"codex-rs/Cargo.lock":"1b063684453163ce7a48d416692667e4bdde7fc4",**supervisor}
resolutions=[]
for e in review["source_paths"]:
 p=e["path"];old=e["current"];cur=before.get(p)
 if cur!=old:
  assert p in allowed_evolved and cur["sha"]==allowed_evolved[p],{"unexpectedCurrentEvolution":p,"old":old,"current":cur}
 post=({"mode":desired[p]["mode"],"type":"blob","sha":desired[p]["postBlob"]} if p in desired else cur)
 reason=e["reason"]
 if p in supervisor:reason+=" Already integrated into the nine-source Supervisor repair at 3c99; keep those strengthened exact-attempt assertions. Original full package: 136 passed, one original ignored child fixture."
 if p=="codex-rs/Cargo.lock":reason+=" Preserve the subsequently merged Matrix SDK codex-utils-path dependency and all other current lock entries."
 if p in desired:reason=desired[p]["reason"]
 resolutions.append({"path":p,"reviewDecision":e["decision"],"reason":reason,"mergeBaseBlob":e["base"],"incomingBlob":e["incoming"],"reviewCurrent":old,"actualCurrent":cur,"automaticPreview":auto.get(p),"final":post,"wasConflict":p in conflicts,"action":"explicit_reviewed_union" if p in desired else ("preserve_prior_verified_union" if p in supervisor else e["decision"])})
assert len(conflicts)==14 and set(conflicts)<=net
index=O/"private.index";assert not index.exists();env["GIT_INDEX_FILE"]=str(index)
git("read-tree",base)
for e in entries:git("update-index","--add","--cacheinfo",e["mode"]+","+e["postBlob"]+","+e["path"])
tree=git("write-tree","--missing-ok").decode().strip();after=vector(tree)
outside=sorted(p for p in before.keys()|after.keys() if p not in desired and before.get(p)!=after.get(p));assert not outside
auto_delta=sorted(p for p in auto.keys()|after.keys() if auto.get(p)!=after.get(p));assert set(auto_delta)<=net
history=git("rev-list",current+".."+incoming).decode().splitlines();assert len(history)==33
for marker in ["f02bb9f3344cdff4e361cca4353540ca0193bd21","3aa1f85ba90c79d220a5cadf2261def176892867"]:
 for ref in [current,incoming]:
  q=subprocess.run(["git","merge-base","--is-ancestor",marker,ref],cwd=G,env=env)
  assert q.returncode==1,{"protectedMarker":marker,"parent":ref,"returncode":q.returncode}
record={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"current":current,"incoming":incoming,"mergeBase":merge_base,"baseTree":base,"expectedTree":tree,"entries":entries,"netIncomingPaths":25,"explicitResolutions":resolutions,"ordinaryPreviewTree":preview_tree,"ordinaryConflictPaths":conflicts,"automaticPreviewDelta":auto_delta,"retainedUniqueHistory":history,"retainedUniqueCommitCount":len(history),"allOutsideSevenPathsModeTypeOidIdentical":True,"protectedMarkersAbsentFromBothParents":True,"noSharedIndexHeadOrWorkingTreeMutation":True,"noRemoteRefMutation":True}
(O/"tree-plan.json").write_text(json.dumps(record,indent=2)+"\n")
fresh=T/"audit/branch_inventory/fresh-publication-refs-after-hia-1953/fresh-ref-protection.json";fj=json.loads(fresh.read_bytes())
print(json.dumps({"plan":str(O/"tree-plan.json"),"planSha256":hashlib.sha256((O/"tree-plan.json").read_bytes()).hexdigest(),"tree":tree,"entries":len(entries),"history":len(history),"conflicts":len(conflicts),"evolved":[e["path"] for e in resolutions if e["actualCurrent"]!=e["reviewCurrent"]],"autoDeltaPaths":auto_delta,"freshProtectionKeys":list(fj)}),flush=True)
