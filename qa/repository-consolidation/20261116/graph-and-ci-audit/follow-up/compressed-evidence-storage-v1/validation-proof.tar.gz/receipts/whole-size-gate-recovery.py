from pathlib import Path
import subprocess,json,hashlib,os,time,base64,datetime
T=Path('/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116');A=T/'audit/ci_audit/codespell-c0e-fragments-v1';G=A/'object-repository'
env=os.environ.copy();env['GIT_NO_LAZY_FETCH']='1'
def git(*args,input=None,check=True):
 r=subprocess.run(['git','-C',str(G),*args],input=input,capture_output=True,check=check,env=env)
 return r.stdout
parenttree=git('write-tree','--missing-ok').decode().strip()
assert parenttree=='7173fea69989266fa75dee1ee85e7b76d8fc4177',parenttree
plan=json.loads((A/'tree-entry-plan-final.json').read_text())
rows=[]
for e in plan['entries']:
 sha=e['postBlob']
 if sha:
  raw=Path(e['sourcePath']).read_bytes()
  actual=git('hash-object','-w','--stdin',input=raw).decode().strip();assert actual==sha
  rows.append(e.get('mode','100644')+' '+sha+'\t'+e['path']+'\0')
 else:rows.append('0 '+'0'*40+'\t'+e['path']+'\0')
git('update-index','-z','--index-info',input=''.join(rows).encode())
tree=git('write-tree','--missing-ok').decode().strip()
base='285e971b3af3a93a79169b56a42263069e473057'
diff=git('diff-tree','-r','--no-commit-id','--raw','-z','--no-renames',base,tree)
tokens=diff.split(b'\0');changed=[];i=0
while i<len(tokens) and tokens[i]:
 fields=tokens[i].decode().split();path=tokens[i+1].decode();i+=2
 if fields[4]!='D':changed.append({'path':path,'blob':fields[3]})
shas=sorted({x['blob'] for x in changed})
check=git('cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(shas)+'\n').encode()).decode().splitlines()
missing=[line.split()[0] for line in check if line.endswith(' missing')]
(A/'whole-size-changed-blob-preflight.json').write_text(json.dumps({'parentTree':parenttree,'candidateTree':tree,'changedEntries':len(changed),'uniqueChangedBlobs':len(shas),'missingChangedBlobs':missing,'assemblyMissingOkIsNotGateBypass':True},indent=2)+'\n')
print('ASSEMBLED',tree,'changed',len(changed),'missing',len(missing),flush=True)
assert len(missing)<=80, 'bounded hydration requires review'
hydrated=[]
for sha in missing:
 r=subprocess.run(['gh','api','repos/TrillionniumFoundation/hepta-private-ci/git/blobs/'+sha],capture_output=True,check=True,timeout=120)
 o=json.loads(r.stdout);assert o['sha']==sha and o['encoding']=='base64'
 raw=base64.b64decode(o['content']);assert len(raw)==o['size']
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
 assert git('hash-object','-w','--stdin',input=raw).decode().strip()==sha
 hydrated.append({'blob':sha,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(A/'whole-size-changed-blob-hydration.json').write_text(json.dumps(hydrated,indent=2)+'\n')
controls=[]
for rel in ['scripts/check_blob_size.py','.github/blob-size-allowlist.txt']:
 raw=git('show','c0e525fd94e6eea2957bd1a12764627b86dd71ec:'+rel);p=A/'gate-controls'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 controls.append({'path':rel,'blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'sha256':hashlib.sha256(raw).hexdigest()})
assert controls[0]['blob']=='1627511aaf298126141f96517e2a243908174351'
assert controls[1]['blob']=='dd0524aa0d704a9231d6db0ba38fc4d8a50e7736'
argv=['/usr/bin/python3',str(A/'gate-controls/scripts/check_blob_size.py'),'--base',base,'--head',tree,'--allowlist',str(A/'gate-controls/.github/blob-size-allowlist.txt')]
start=time.time();r=subprocess.run(argv,cwd=G,env=env,capture_output=True,timeout=180)
(A/'original-whole-blob-gate.log').write_bytes(r.stdout+r.stderr)
receipt={'base':base,'reviewedParentSourceTree':parenttree,'candidateTree':tree,'candidateSourceCommit':'59a450cc7b33a2f8d833043cc093b7fc92f2b7ab','carrierPlanSha256':hashlib.sha256((A/'tree-entry-plan-final.json').read_bytes()).hexdigest(),'argv':argv,'cwd':str(G),'controls':controls,'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'logSha256':hashlib.sha256(r.stdout+r.stderr).hexdigest(),'noMaximumOverride':True,'allChangedBlobsMaterializedBeforeGate':True,'remoteRefChanges':False}
(A/'original-whole-blob-gate-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));print((r.stdout+r.stderr).decode('utf-8','replace')[-3000:])
