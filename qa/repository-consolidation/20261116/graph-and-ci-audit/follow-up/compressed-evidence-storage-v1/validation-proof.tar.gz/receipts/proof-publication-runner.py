from pathlib import Path
import json,hashlib,gzip,tarfile,io,subprocess,os,time,datetime,base64
T=Path('/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116');A=T/'audit/ci_audit/codespell-c0e-fragments-v1';P=A/'proposal';V=A/'combined-validation-scope';O=A/'proof-publication';O.mkdir(exist_ok=False)
prefix='qa/repository-consolidation/20261116/graph-and-ci-audit/follow-up/compressed-evidence-storage-v1/'
gate=json.loads((A/'original-whole-blob-gate-attempt2-receipt.json').read_text());assert gate['exitCode']==0
spell=json.loads((A/'hardening-v2/combined-codespell-receipt.json').read_text());assert spell['exitCode']==0 and spell['changedPathCount']==1051
strict=json.loads((A/'hardening-v2/strict-rejection-final.json').read_text());assert strict['actualCliCases']==13 and strict['allRejectedBeforeDestinationCreation']
plan=json.loads((A/'entry-manifest.json').read_text());assert plan['entryCount']==107 and plan['allObjectsPostAndGetVerified']
members={}
for p in A.iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl','.log','.stdout','.stderr','.patch','.txt','.py'}:
  members['receipts/'+p.name]=p.read_bytes()
for sub in ['hardening-v2','suffix-probe']:
 for p in (A/sub).iterdir():
  if p.is_file() and (sub!='suffix-probe' or p.name.endswith(('.stdout','.stderr','.json'))):
   members['receipts/'+sub+'/'+p.name]=p.read_bytes()
for rel in ['scripts/check_blob_size.py','.github/blob-size-allowlist.txt']:
 members['original-gate-controls/'+rel]=(A/'gate-controls'/rel).read_bytes()
for e in plan['entries']:
 if e['postBlob'] and not e['path'].endswith('.gz'):
  members['proposed-text/'+e['path']]=Path(e['sourcePath']).read_bytes()
members['hosted-original/job-133543726413.log']=(T/'audit/ci_audit/hosted-c0e525f-v1/job-133543726413.log').read_bytes()
members['root-overlay/source-plan.json']=(T/'audit/root-c0e-ci-and-exec-source-v1/source-plan.json').read_bytes()
checks=[]
for name,raw in sorted(members.items()):
 checks.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'schema_version':1,'preserved_member_count':len(checks),'members':checks,'scope':'Exact original failure, carrier proposal, source/control inputs, restoration and strict rejection receipts, original maintenance and size gates. Native Rust qualification is outside this storage change.'}
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tf:
 for name,raw in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  tf.addfile(info,io.BytesIO(raw))
tarraw=buf.getvalue();packed=gzip.compress(tarraw,compresslevel=9,mtime=0)
assert len(packed)<=500000,(len(packed),'needs independent bounded carriers')
assert gzip.decompress(packed)==tarraw
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)),mode='r:') as tf:
 restored={m.name:tf.extractfile(m).read() for m in tf if m.isfile()}
assert restored==members
(O/'validation-proof.tar.gz').write_bytes(packed)
summary={
 'schema_version':1,
 'published_source_head':'c0e525fd94e6eea2957bd1a12764627b86dd71ec',
 'reviewed_source_parent':'59a450cc7b33a2f8d833043cc093b7fc92f2b7ab',
 'carrier_source_tree':gate['candidateTree'],
 'carrier_entry_manifest_sha256':hashlib.sha256((A/'entry-manifest.json').read_bytes()).hexdigest(),
 'carrier_plan_sha256':hashlib.sha256((A/'tree-entry-plan-final.json').read_bytes()).hexdigest(),
 'change':{'entries':107,'new_or_modified':59,'deleted_physical_fragment_names':48,'independent_gzip_carriers':49,'archive_groups':9,'original_fragment_count':48,'max_carrier_bytes':480168,'old_archive_and_fragment_bytes_preserved':True,'historical_compressed_metadata_unchanged':True,'two_historical_cell_xz_fragments_unchanged':True,'active_index_inverse_objects_equal':True},
 'validation':{
  'original_hosted_failure':{'job_id':133543726413,'findings':224,'failed_fragment_paths':5,'preserved':True},
  'original_local_failure':{'changed_path_count':1036,'exit_code':65,'findings':224,'inputs_unchanged':True},
  'suffix_only_counterexample':{'original_and_renamed_findings':39,'both_exit_codes':65,'conclusion':'The file content detector, rather than the filename suffix, determines text classification.'},
  'final_original_codespell':{'changed_path_count':1051,'exit_code':0,'elapsed_seconds':spell['elapsedSeconds'],'includes_all_binary_paths':True,'unchanged_skip_config_and_custody':True,'scope':'Every added or modified path from7e through the reviewed nine source changes and the carrier proposal.'},
  'positive_restore':{'original_fragments':48,'original_archives':9,'exact_bytes':True,'destination_mode':'0700'},
  'strict_rejection':{'actual_cli_cases':13,'all_rejected_before_destination_creation':True,'budget_checked_before_decoding':True,'source_symlink_boundary':'Static paths are checked. No claim of directory descriptor isolation against concurrent hostile replacement.'},
  'formatters':{'prettier':'3.5.3 with original repository config','ruff':'0.15.13 from frozen scripts project','passed':True},
  'original_size_gate':{'base':gate['base'],'head_tree':gate['candidateTree'],'default_max_bytes':512000,'exit_code':0,'elapsed_seconds':gate['elapsedSeconds'],'controls_unchanged':True,'first_missing_object_attempt_preserved':True,'bounded_recovery_baseline_blobs':3},
  'scope_limit':'These checks establish lossless storage, parser rejection, and the stated maintenance gates. They do not establish native platform, sandbox, security, or scientific qualification.'},
 'proof':{'path':prefix+'validation-proof.tar.gz','bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'uncompressed_tar_sha256':hashlib.sha256(tarraw).hexdigest(),'members':len(members),'all_member_bytes_read_back_equal':True},
 'remote_refs_changed':False
}
summary_path=O/'validation-summary.json';summary_path.write_text(json.dumps(summary,indent=2)+'\n')
prettier=['/usr/bin/node',str(T/'audit/branch_inventory/prettier-dist-3.5.3/bin/prettier.cjs'),'--config',str(V/'.prettierrc.toml'),'--write',str(summary_path)]
fmt=subprocess.run(prettier,capture_output=True,check=True);(A/'proof-prettier-write.log').write_bytes(fmt.stdout+fmt.stderr)
fmtcheck=subprocess.run(prettier[:-2]+['--check',str(summary_path)],capture_output=True)
(A/'proof-prettier-check.log').write_bytes(fmtcheck.stdout+fmtcheck.stderr);assert fmtcheck.returncode==0
extra=[]
for name in ['validation-proof.tar.gz','validation-summary.json']:
 raw=(O/name).read_bytes();rel=prefix+name;q=V/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 extra.append({'path':rel,'mode':'100644','type':'blob','baseBlob':None,'postBlob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'sourcePath':str(O/name),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
prefixargs=spell['argv'][:spell['argv'].index('--skip')+2]
original_paths=spell['argv'][len(prefixargs):];argv=prefixargs+sorted(original_paths+['./'+x['path'] for x in extra])
assert len(argv)-len(prefixargs)==1053
env=os.environ.copy();env['PYTHONPATH']=str(T/'audit/branch_inventory/codespell_vendor')
before={p:hashlib.sha256((V/p.removeprefix('./')).read_bytes()).hexdigest() for p in argv[len(prefixargs):]}
start=time.time();r=subprocess.run(argv,cwd=V,env=env,capture_output=True)
after={p:hashlib.sha256((V/p.removeprefix('./')).read_bytes()).hexdigest() for p in argv[len(prefixargs):]}
rec={'argv':argv,'cwd':str(V),'pythonpath':env['PYTHONPATH'],'source_scope':summary['carrier_source_tree'],'added_proof_entries':extra,'changedPathCount':1053,'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'inputsUnchanged':before==after,'stdoutSha256':hashlib.sha256(r.stdout).hexdigest(),'stderrSha256':hashlib.sha256(r.stderr).hexdigest(),'scope':'1051 exact candidate paths plus the two proof artifacts. The later receipt itself is checked separately.'}
(A/'proof-codespell-1053-receipt.json').write_text(json.dumps(rec,indent=2)+'\n');(A/'proof-codespell-1053.stdout').write_bytes(r.stdout);(A/'proof-codespell-1053.stderr').write_bytes(r.stderr)
assert r.returncode==0 and before==after,(r.returncode,r.stdout.decode()[:1000])
receipt_bytes=gzip.compress((json.dumps(rec,indent=2)+'\n').encode(),compresslevel=9,mtime=0)
name='validation-publication-check.json.gz';(O/name).write_bytes(receipt_bytes)
rel=prefix+name;q=V/rel;q.write_bytes(receipt_bytes)
receipt_spell=subprocess.run(prefixargs+['./'+rel],cwd=V,env=env,capture_output=True);assert receipt_spell.returncode==0
extra.append({'path':rel,'mode':'100644','type':'blob','baseBlob':None,'postBlob':hashlib.sha1(b'blob '+str(len(receipt_bytes)).encode()+b'\0'+receipt_bytes).hexdigest(),'sourcePath':str(O/name),'bytes':len(receipt_bytes),'sha256':hashlib.sha256(receipt_bytes).hexdigest()})
receipts=[]
for e in extra:
 raw=Path(e['sourcePath']).read_bytes();assert len(raw)<=500000
 payload=json.dumps({'encoding':'base64','content':base64.b64encode(raw).decode()}).encode()
 post=json.loads(subprocess.run(['gh','api','--method','POST','repos/TrillionniumFoundation/hepta-private-ci/git/blobs','--input','-'],input=payload,capture_output=True,check=True,timeout=120).stdout)
 assert post['sha']==e['postBlob']
 get=json.loads(subprocess.run(['gh','api','repos/TrillionniumFoundation/hepta-private-ci/git/blobs/'+e['postBlob']],capture_output=True,check=True,timeout=120).stdout)
 assert get['sha']==e['postBlob'] and base64.b64decode(get['content'])==raw
 receipts.append({'path':e['path'],'blob':e['postBlob'],'bytes':len(raw),'sha256':e['sha256'],'postSucceeded':True,'getByteIdentity':True})
(O/'github-object-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
delivery={'source_entry_manifest':str(A/'entry-manifest.json'),'source_entry_manifest_sha256':summary['carrier_entry_manifest_sha256'],'source_entry_count':107,'proof_entry_count':len(extra),'entries':extra,'all_post_get_verified':True,'source_plus_two_proof_codespell_exit':0,'receipt_artifact_original_codespell_exit':0,'original_size_gate_candidate':gate['candidateTree'],'original_size_gate_exit':0,'remote_ref_changes':False}
delivery_path=O/'entry-manifest.json';delivery_path.write_text(json.dumps(delivery,indent=2)+'\n')
print('DELIVERY',str(delivery_path),hashlib.sha256(delivery_path.read_bytes()).hexdigest(),json.dumps({'proof_bytes':len(packed),'member_count':len(members),'entries':extra}),flush=True)
