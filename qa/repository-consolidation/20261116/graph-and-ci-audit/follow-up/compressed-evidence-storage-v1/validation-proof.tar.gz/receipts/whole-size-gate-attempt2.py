from pathlib import Path
import subprocess,json,hashlib,os,time,base64
T=Path('/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116');A=T/'audit/ci_audit/codespell-c0e-fragments-v1';G=A/'object-repository'
env=os.environ.copy();env['GIT_NO_LAZY_FETCH']='1'
def git(*args,input=None):return subprocess.run(['git','-C',str(G),*args],input=input,capture_output=True,check=True,env=env).stdout
old=json.loads((A/'original-whole-blob-gate-receipt.json').read_text());base=old['base'];tree=old['candidateTree']
tokens=git('diff-tree','-r','--no-commit-id','--raw','-z','--no-renames',base,tree).split(b'\0')
shas=set()
for i in range(0,len(tokens)-1,2):
 if not tokens[i]:break
 f=tokens[i].decode().split()
 if f[4] in ('A','M') and f[2]!='0'*40:shas.add(f[2])
checks=git('cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(sorted(shas))+'\n').encode()).decode().splitlines()
missing=[x.split()[0] for x in checks if x.endswith(' missing')]
pre={'uniqueBasePreimages':len(shas),'missingBasePreimages':missing,'candidateTree':tree,'reason':'Original numstat gate needs modified-file baseline bytes as well as all final changed blobs.'}
(A/'whole-size-base-preflight.json').write_text(json.dumps(pre,indent=2)+'\n')
print('BASE PREFLIGHT',json.dumps(pre),flush=True)
if len(missing)>16:raise SystemExit('bounded preimage hydration stopped before downloads')
hydrated=[]
for sha in missing:
 r=subprocess.run(['gh','api','repos/TrillionniumFoundation/hepta-private-ci/git/blobs/'+sha],capture_output=True,check=True,timeout=120)
 o=json.loads(r.stdout);assert o['sha']==sha and o['encoding']=='base64'
 raw=base64.b64decode(o['content']);assert len(raw)==o['size']
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
 assert git('hash-object','-w','--stdin',input=raw).decode().strip()==sha
 hydrated.append({'blob':sha,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(A/'whole-size-base-hydration.json').write_text(json.dumps(hydrated,indent=2)+'\n')
start=time.time();r=subprocess.run(old['argv'],cwd=G,env=env,capture_output=True,timeout=180)
log=r.stdout+r.stderr;(A/'original-whole-blob-gate-attempt2.log').write_bytes(log)
rec=dict(old);rec.update({'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'logSha256':hashlib.sha256(log).hexdigest(),'allModifiedBaseBlobsMaterialized':True,'priorAttemptPreserved':'original-whole-blob-gate-receipt.json'})
(A/'original-whole-blob-gate-attempt2-receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec));print(log.decode('utf8','replace')[-3000:])
files=[]
for p in A.iterdir():
 if p.is_file():files.append({'path':p.name,'bytes':p.stat().st_size})
for sub in ['hardening-v2','suffix-probe']:
 for p in (A/sub).iterdir():
  if p.is_file():files.append({'path':str(p.relative_to(A)),'bytes':p.stat().st_size})
(A/'proof-input-candidates.json').write_text(json.dumps(files,indent=2)+'\n')
print('PROOF CANDIDATES',json.dumps(files),flush=True)
