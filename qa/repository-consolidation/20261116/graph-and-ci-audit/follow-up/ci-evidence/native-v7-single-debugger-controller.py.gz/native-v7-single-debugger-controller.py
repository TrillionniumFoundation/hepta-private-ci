import os,sys,json,time,hashlib,subprocess,selectors,re,datetime,resource,signal
from pathlib import Path
root=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116")
folder=root/"audit/root-provider-gdb-v7-single"
folder.mkdir(exist_ok=False)
binary=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116/target/debug/deps/codex_hepta_agentd-18503a34bdded8f4")
test="runtime::tests::circuit_task_ingress::q24_tests::model_selection_owner::original::evaluation_provider::original_evaluation_provider_releases_actual_b_and_retention_only_after_consumption"
expected="d77e1b8ec317552af1c46114ac5d8c6eb0dde81f8cec2f738c6362775784eb8d"
def sha(path):
 h=hashlib.sha256()
 with path.open("rb")as f:
  for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
 return h.hexdigest()
assert sha(binary)==expected
source_inventory=json.loads((root/"audit/native-v7-input-sources.json").read_text())
source_changed_before=[name for name,digest in source_inventory.items() if sha(root/"repo-clean"/name)!=digest]
assert not source_changed_before,source_changed_before
env=os.environ.copy();env["RUST_MIN_STACK"]="8388608";env["RUST_BACKTRACE"]="1"
master,slave=os.openpty();tty=os.ttyname(slave)
log=(folder/"gdb-symbol-backtraces.log").open("x")
events=(folder/"events.jsonl").open("x")
def event(kind,**kw):
 d={"kind":kind,"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"monotonic":time.monotonic(),**kw}
 events.write(json.dumps(d,separators=(",",":"))+"\n");events.flush()
 return d
command=["/usr/bin/gdb","--nx","--nh","--quiet","--interpreter=mi2"]
p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,cwd=root/"repo-clean/codex-rs/hepta-agentd",start_new_session=True,bufsize=0)
os.set_blocking(p.stdout.fileno(),False);os.set_blocking(master,False)
sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ,"gdb");sel.register(master,selectors.EVENT_READ,"inferior")
buf=b"";responses={};stopped=False;exited=False;inferior_pid=None;discarded=0;token=0
event("invocation",gdb_command=command,binary=str(binary),binary_sha256=expected,binary_size=binary.stat().st_size,test_argv=["--exact",test,"--nocapture"],cwd=str(root/"repo-clean/codex-rs/hepta-agentd"),environment_overrides={"RUST_MIN_STACK":"8388608","RUST_BACKTRACE":"1"},rlimit_stack=list(resource.getrlimit(resource.RLIMIT_STACK)),source_inventory_sha256=sha(root/"audit/native-v7-input-sources.json"),qualification=False,observer_effects="Debugger stops perturb elapsed deadlines; this is a diagnostic child, not a qualification run. Inferior stdout/stderr are discarded, never recorded.")
def line_in(line):
 global stopped,exited,inferior_pid
 text=line.decode(errors="replace")
 # Only GDB records and symbolic backtraces are retained; inferior output is on a separate PTY and discarded.
 log.write(text+"\n");log.flush()
 m=re.match(r"(\d+)\^(.*)",text)
 if m:responses[int(m.group(1))]=m.group(2)
 if text.startswith("*stopped"):
  stopped=True;event("inferior_stopped",record=text)
  if 'reason="exited' in text:exited=True
 if text.startswith("*running"):stopped=False
 if text.startswith("=thread-group-started"):
  m=re.search(r'pid="(\d+)"',text)
  if m:inferior_pid=int(m.group(1));event("owned_inferior",pid=inferior_pid)
 if text.startswith("=thread-group-exited"):exited=True;event("inferior_exited",record=text)
def pump(timeout=0.1):
 global buf,discarded
 for key,_ in sel.select(timeout):
  try:data=os.read(key.fileobj.fileno()if hasattr(key.fileobj,"fileno")else key.fileobj,65536)
  except (BlockingIOError,OSError):continue
  if not data:continue
  if key.data=="inferior":discarded+=len(data);continue
  buf+=data
  while b"\n"in buf:
   line,buf=buf.split(b"\n",1);line_in(line.rstrip(b"\r"))
def cmd(value,limit=20):
 global token
 token+=1;n=token;event("gdb_command",token=n,command=value)
 p.stdin.write((str(n)+value+"\n").encode());p.stdin.flush()
 until=time.monotonic()+limit
 while n not in responses:
  if p.poll()is not None:raise RuntimeError("gdb exited before command response")
  if time.monotonic()>until:raise TimeoutError("gdb command response deadline: "+value)
  pump(0.1)
 return responses.pop(n)
def console(value,limit=20):return cmd("-interpreter-exec console "+json.dumps(value),limit)
def proc_snapshot():
 if not inferior_pid:return None
 path=Path("/proc")/str(inferior_pid);rows=[]
 try:
  for t in (path/"task").iterdir():
   try:
    s=(t/"stat").read_text();pre,tail=s.rsplit(") ",1);f=tail.split()
    rows.append({"tid":int(t.name),"name":pre.split("(",1)[1],"state":f[0],"utime_ticks":int(f[11]),"stime_ticks":int(f[12]),"wchan":(t/"wchan").read_text().strip()})
   except OSError:pass
  return {"pid":inferior_pid,"threads":rows}
 except OSError:return {"pid":inferior_pid,"missing":True}
started=None;failure=None;stops=[];setup_started=time.monotonic()
try:
 for c in ["set pagination off","set confirm off","set print frame-arguments none","set print entry-values no","set print address off","set auto-load python-scripts off","set auto-load local-gdbinit off","set debuginfod enabled off","set disable-randomization off","handle SIGINT stop print nopass"]:
  result=console(c);assert result.startswith("done"),(c,result)
 assert cmd("-gdb-set mi-async on").startswith("done")
 assert cmd("-inferior-tty-set "+json.dumps(tty)).startswith("done")
 assert cmd("-file-exec-and-symbols "+json.dumps(str(binary)),limit=45).startswith("done")
 assert cmd("-exec-arguments --exact "+test+" --nocapture").startswith("done")
 result=cmd("-exec-run");assert result.startswith("running"),result
 started=time.monotonic();event("execution_started",max_wall_seconds=60,snapshot_schedule_seconds=[8,20,35,50])
 for elapsed_target in [8,20,35,50]:
  while time.monotonic()<started+elapsed_target and not exited:pump(0.1)
  if exited:break
  before=time.monotonic();event("sample_pre_interrupt",elapsed=before-started,proc=proc_snapshot())
  cmd("-exec-interrupt --all")
  until=time.monotonic()+8
  while not stopped and not exited and time.monotonic()<until:pump(0.1)
  if exited:break
  if not stopped:raise TimeoutError("owned inferior did not stop")
  event("symbolic_backtrace_start",elapsed=time.monotonic()-started)
  result=console("thread apply all bt 12",limit=15)
  event("symbolic_backtrace_end",elapsed=time.monotonic()-started,response=result)
  stops.append({"scheduled_elapsed":elapsed_target,"pause_seconds":time.monotonic()-before})
  cmd("-exec-continue")
 while started and time.monotonic()<started+60 and not exited:pump(0.1)
 if not exited:
  event("diagnostic_deadline",elapsed=time.monotonic()-started,proc=proc_snapshot())
  cmd("-exec-interrupt --all")
  until=time.monotonic()+5
  while not stopped and not exited and time.monotonic()<until:pump(0.1)
  if not exited:console("kill",limit=10)
 cmd("-gdb-exit",limit=5)
except Exception as e:
 failure={"type":type(e).__name__,"message":str(e)};event("controller_error",**failure)
finally:
 if p.poll()is None:
  try:
   console("kill",limit=5)
   cmd("-gdb-exit",limit=5)
  except Exception:pass
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
 for _ in range(3):pump(0)
 event("finished",controller_failure=failure,gdb_exit=p.returncode,owned_pid=inferior_pid,execution_elapsed_seconds=None if started is None else time.monotonic()-started,discarded_inferior_output_bytes=discarded,stops=stops)
 log.close();events.close();sel.close();os.close(master);os.close(slave)
 after=sha(binary)
 source_changed_after=[name for name,digest in source_inventory.items() if sha(root/"repo-clean"/name)!=digest]
 owned_pid_absent=inferior_pid is None or not (Path("/proc")/str(inferior_pid)).exists()
 receipt={"schema":"hepta.provider-gdb-diagnostic.v7-single","qualification":False,"source_commit":"095fb1d50cc9ac7e53ea5027cf3cfdd2c86b2feb","source_inputs_unchanged":not source_changed_after,"changed_sources":source_changed_after,"owned_pid_absent_after_cleanup":owned_pid_absent,"binary":str(binary),"binary_sha256_before":expected,"binary_sha256_after":after,"binary_unchanged":after==expected,"source_inventory_sha256":sha(root/"audit/native-v7-input-sources.json"),"test":test,"stack_bytes":8388608,"gdb_command":command,"owned_inferior_pid":inferior_pid,"gdb_exit":p.returncode,"controller_failure":failure,"interrupt_pauses":stops,"discarded_inferior_output_bytes":discarded,"observer_effects":["Debugger interrupts stop all inferior threads and can consume existing deadline budget.","GDB symbol loading and scheduling add overhead.","This is not a PASS/FAIL qualification result; libtest has no nextest watchdog here and the controller bounds only this diagnostic child.","No arguments, locals, raw frames or payload values were requested; frame-arguments none and entry-values no were set.","Inferior stdout/stderr were discarded."],"files":[{"path":str(q.relative_to(root)),"bytes":q.stat().st_size,"sha256":sha(q)}for q in (folder/"gdb-symbol-backtraces.log",folder/"events.jsonl")]}
 with (folder/"receipt.json").open("x")as f:f.write(json.dumps(receipt,indent=2)+"\n")
 print(json.dumps(receipt),flush=True)
