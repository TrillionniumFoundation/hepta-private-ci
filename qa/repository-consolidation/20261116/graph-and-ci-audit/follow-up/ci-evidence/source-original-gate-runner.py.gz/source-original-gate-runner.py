import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116/ci-callers-format")
AUDIT = ROOT.parent / "audit/ci_audit/callers-format-v1"
NAME = sys.argv[1]
COMMANDS = {
    "full-b4": ["/usr/bin/python3", "-B", "-m", "unittest", "discover", "-s", "qa/b4-no-bypass"],
    "caller-cli": ["/usr/bin/python3", "-B", "scripts/verify_hepta_callers.py"],
}
command = COMMANDS[NAME]
closure = json.loads((AUDIT / "candidate-closure-v2-before-gates.json").read_text())
expected = json.loads((AUDIT / closure["inputs_file"]).read_text())
def snapshot():
    return {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in expected}
before = snapshot()
assert before == expected
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip() == closure["source_commit"]
started = time.time()
invocation = {
    "schema": "hepta.caller-storage-source-gate.v1",
    "name": NAME,
    "argv": command,
    "cwd": str(ROOT),
    "source_commit": closure["source_commit"],
    "source_tree": closure["source_tree"],
    "candidate_tree": closure["candidate_tree"],
    "input_count": len(expected),
    "inputs_file": closure["inputs_file"],
    "inputs_sha256": closure["inputs_sha256"],
    "started_unix": started,
    "retries": 0,
}
(AUDIT / f"{NAME}-invocation.json").write_text(json.dumps(invocation, indent=2) + "\n")
print(json.dumps({"started": NAME, "candidate_tree": closure["candidate_tree"], "inputs": len(expected)}), flush=True)
environment = os.environ.copy()
environment["PYTHONDONTWRITEBYTECODE"] = "1"
log_path = AUDIT / f"{NAME}.log"
with log_path.open("wb") as log:
    result = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
finished = time.time()
after = snapshot()
unchanged = after == before
raw_log = log_path.read_bytes()
receipt = {
    **invocation,
    "finished_unix": finished,
    "elapsed_seconds": finished - started,
    "command_exit_code": result.returncode,
    "inputs_unchanged": unchanged,
    "changed_inputs": [path for path in before if before[path] != after[path]],
    "log_sha256": hashlib.sha256(raw_log).hexdigest(),
    "log_bytes": len(raw_log),
    "status": "PASS" if result.returncode == 0 and unchanged else "FAIL",
}
if NAME == "caller-cli" and result.returncode == 0:
    proof = json.loads(raw_log)
    receipt["proof_status"] = proof["status"]
    receipt["proof_fields"] = {key: value for key, value in proof.items() if key != "boundaries"}
    receipt["boundaries"] = len(proof["boundaries"])
(AUDIT / f"{NAME}-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({key: value for key, value in receipt.items() if key != "proof_fields"}), flush=True)
if NAME == "full-b4" or result.returncode:
    print(raw_log.decode(errors="replace")[-6000:], flush=True)
sys.exit(0 if receipt["status"] == "PASS" else 1)
