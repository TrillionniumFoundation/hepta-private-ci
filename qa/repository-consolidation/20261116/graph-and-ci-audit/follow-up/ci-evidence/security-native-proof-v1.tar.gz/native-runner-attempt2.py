from pathlib import Path
import os,json,subprocess,time,datetime,hashlib,shutil,sys,tomllib
root=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116")
repo=root/"security-validation";audit=root/"audit/rust_review/security-validation-v1"
run_audit=audit/"attempt-2"
run_audit.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def write_json(path,value):
 with path.open("x")as f:json.dump(value,f,indent=2);f.write("\n")
manifest=json.loads((audit/"native-source-manifest.json").read_text())
materialization=json.loads((audit/"materialization-receipt.json").read_text())
source_plan=json.loads((audit/"source-kit-plan.json").read_text())
plan=json.loads((audit/"test-plan.json").read_text())
expected={p:r["sha256"]for p,r in manifest["inputs"].items()}
expected.update({f["path"]:f["sha256"]for f in source_plan["files"]})
expected.update(plan["control_inputs"])
def verify():
 differences=[]
 for path,digest in expected.items():
  target=repo/path
  actual=sha(target.read_bytes())if target.is_file()and not target.is_symlink()else None
  if actual!=digest:differences.append({"path":path,"expected":digest,"actual":actual})
 return differences
assert not verify()
for p in Path("/proc").iterdir():
 if not p.name.isdigit():continue
 try:
  comm=(p/"comm").read_text().strip()
  assert comm not in {"cargo","rustc","cargo-nextest","nextest","just","clippy-driver"},(p.name,comm)
 except OSError:pass
env=os.environ.copy()
unexpected={k:v for k,v in env.items()if v and(k in {"RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS"}or k.startswith("CARGO_PROFILE_"))}
assert not unexpected,unexpected
nextest_dir=audit/"tools/nextest-0.9.137"
uvdir=audit/"tools/uv-0.11.3"
env["PATH"]=str(nextest_dir)+":"+str(uvdir/"bin")+":"+env["PATH"]
env["PYTHONPATH"]=str(uvdir)
env.update(plan["environment"])
versions={}
for name,args in [("rustc",["rustc","--version"]),("nextest",["cargo","nextest","--version"]),("just",["just","--version"]),("uv",["uv","--version"])]:
 p=subprocess.run(args,cwd=repo/"codex-rs",env=env,capture_output=True,text=True,timeout=15)
 assert p.returncode==0,(name,p.stderr)
 versions[name]=p.stdout.strip()
assert versions["rustc"].startswith("rustc 1.96.0")and versions["nextest"].startswith("cargo-nextest 0.9.137")and versions["uv"].startswith("uv 0.11.3")
cargo_path=repo/"codex-rs/app-server-test-client/Cargo.toml"
assert tomllib.loads(cargo_path.read_text())["dev-dependencies"]["pretty_assertions"]=={"workspace":True}
static={"client_cargo_blob":blob(cargo_path.read_bytes()),"pretty_assertions_existing_dev_dependency":True,"protocol_account_blob":blob((repo/"codex-rs/app-server-protocol/src/protocol/v2/account.rs").read_bytes()),"protocol_rpc_blob":blob((repo/"codex-rs/app-server-protocol/src/rpc.rs").read_bytes()),"five_auth_diagnostics_tests":(repo/"codex-rs/app-server-test-client/src/auth_diagnostics_tests.rs").read_text().count("#[test]")==5}
assert static["client_cargo_blob"]=="901afb70d00f16e004913c764337d92afc82808b"and static["protocol_account_blob"]=="017f022efa63cb6e1610fae8687d338d0e3bfadb"and static["protocol_rpc_blob"]=="23920864dd3fc7e09a64fc46909ef598f6f3b7ae"and static["five_auth_diagnostics_tests"]
invocation={"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"host":"rog","cwd":str(repo),"candidate":plan["candidate"],"candidate_tree":plan["candidate_tree"],"native_manifest_sha256":plan["native_manifest_sha256"],"native_count":7751,"all_expected_input_hashes_match":True,"versions":versions,"nextest_executable":shutil.which("cargo-nextest",path=env["PATH"]),"nextest_executable_sha256":sha((nextest_dir/"cargo-nextest").read_bytes()),"uv_executable":str(uvdir/"bin/uv"),"environment":{k:env[k]for k in plan["environment"]},"pythonpath":str(uvdir),"test_plan":plan["test_plan"],"static_preflight":static,"source_control_input_count":len(expected)}
write_json(run_audit/"native-invocation.json",invocation)
stages=["fmt","scoped-fix","cli-login-focused","client-auth-focused","both-libraries-full"]
results=[]
for stage,args in zip(stages,plan["test_plan"]):
 assert not verify(),("source changed before",stage)
 started=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
 print(json.dumps({"stage":stage,"state":"starting","argv":args,"utc":utc}),flush=True)
 logpath=run_audit/(stage+".log")
 with logpath.open("xb")as log:
  process=subprocess.Popen(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  write_json(run_audit/(stage+"-process.json"),{"pid":process.pid,"argv":args,"start_utc":utc,"log":str(logpath)})
  code=process.wait()
 differences=verify()
 result={"stage":stage,"argv":args,"started_utc":utc,"exit":code,"elapsed_seconds":time.monotonic()-started,"log":str(logpath),"log_bytes":logpath.stat().st_size,"log_sha256":sha(logpath.read_bytes()),"input_differences":differences,"exact_candidate_unchanged":not differences}
 write_json(run_audit/(stage+"-receipt.json"),result)
 results.append(result)
 print(json.dumps({"stage":stage,"state":"finished","exit":code,"seconds":result["elapsed_seconds"],"changed_inputs":len(differences),"log_bytes":result["log_bytes"]}),flush=True)
 if differences or(code!=0 and stage in {"fmt","scoped-fix"}):
  write_json(run_audit/"native-results-paused.json",{"candidate":plan["candidate"],"results":results,"reason":"source changed or formatting/clippy gate failed; inspect before proceeding"})
  sys.exit(code if code else 1)
write_json(run_audit/"native-results.json",{"candidate":plan["candidate"],"tree":plan["candidate_tree"],"native_inputs":7751,"results":results,"all_pass":all(r["exit"]==0 for r in results),"all_inputs_unchanged":not verify()})
sys.exit(0 if all(r["exit"]==0 for r in results)else 1)
