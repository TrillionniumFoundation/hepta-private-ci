from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");P=T/"audit/branch_inventory";R=T/"safe-evidence-merge";D=P/"fresh-publication-refs-after-cell";D.mkdir(exist_ok=True);V=D/"commit-graph-viewer.git";E=D/"empty-hooks";E.mkdir(exist_ok=True)
env=dict(os.environ,GIT_NO_LAZY_FETCH="1",GIT_OPTIONAL_LOCKS="0")
def cmd(argv,input=None,timeout=180):return subprocess.check_output(argv,input=input,stderr=subprocess.PIPE,env=env,timeout=timeout)
def git(*args,input=None,timeout=180):return cmd(["git","--git-dir",str(V),*args],input,timeout)
if not V.exists():
 cmd(["git","init","--bare","--quiet","--template="+str(E),str(V)])
 (V/"objects/info/alternates").write_text(str(R/".git/objects")+"\n"+str(T/"ci-callers-format/.git/objects")+"\n")
 git("config","core.hooksPath",str(E))
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
raw=cmd(["git","ls-remote","--heads","https://github.com/TrillionniumFoundation/hepta-private-ci.git"],timeout=180)
observed=datetime.datetime.now(datetime.timezone.utc).isoformat();(D/"refs.tsv").write_bytes(raw);refs={}
for line in raw.decode().splitlines():
 sha,name=line.split("\t");assert re.fullmatch("[0-9a-f]{40}",sha) and name.startswith("refs/heads/");name=name[len("refs/heads/"):];assert name not in refs;refs[name]=sha
prior_path=P/"publication/graph-and-ci-audit/follow-up/branch-prepublication-20261116T145506Z.json";prior=json.loads(prior_path.read_text());prior_raw=gzip.decompress((P/"publication/graph-and-ci-audit/follow-up/branch-prepublication-refs-20261116T145506Z.tsv.gz").read_bytes())
prior_refs={line.split("\t")[1][len("refs/heads/"):]:line.split("\t")[0] for line in prior_raw.decode().splitlines()}
original=json.loads((P/"branch_classification.json").read_text());original_refs={r["name"]:r["sha"] for r in original};prior_protected={r["name"]:r for r in prior["current_protected_vector"]};original_protected={r["name"]:r["sha"] for r in original if r["protected_hia"]}
added=sorted(set(refs)-set(prior_refs));removed=sorted(set(prior_refs)-set(refs));changed=[{"name":name,"old_sha":prior_refs[name],"new_sha":refs[name]} for name in sorted(set(refs)&set(prior_refs)) if refs[name]!=prior_refs[name]]
roots=sorted(set(refs.values()));result=git("cat-file","--batch-check=%(objectname) %(objecttype)",input=("\n".join(roots)+"\n").encode()).decode().splitlines();missing=[line.split()[0] for line in result if line.endswith(" missing")];assert len(result)==len(roots)
print(json.dumps({"observed_utc":observed,"heads":len(refs),"added_since_prior":len(added),"removed_since_prior":len(removed),"changed_since_prior":len(changed),"missing_commit_roots":len(missing)}),flush=True)
markers=["f02bb9f3344cdff4e361cca4353540ca0193bd21","3aa1f85ba90c79d220a5cadf2261def176892867"];candidate="15287f0562e251250f5553d603b66c9a8f81ecde"
fetch=None
if missing:
 negotiation=[]
 for sha in sorted(set(markers+["732e934ba496d90fbe042b8d41d479ef901643e5","7e04259b85ee2d3c31182c6b4be8b6a3ace29fc0"]+[r["observed_sha"] for r in prior_protected.values()])):
  p=subprocess.run(["git","--git-dir",str(V),"cat-file","-e",sha+"^{commit}"],env=env,capture_output=True)
  if p.returncode==0:negotiation.append(sha)
 argv=["git","--git-dir",str(V),"-c","protocol.version=2","-c","fetch.negotiationAlgorithm=skipping","fetch","--quiet","--no-tags","--no-write-fetch-head","--no-auto-maintenance","--filter=tree:0"]+["--negotiation-tip="+s for s in negotiation]+["--stdin","https://github.com/TrillionniumFoundation/hepta-private-ci.git"]
 start=time.monotonic();p=subprocess.run(argv,input=("\n".join(missing)+"\n").encode(),env=env,capture_output=True,timeout=300);(D/"graph-fetch.stderr").write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()
 fetch={"requested_unknown_roots":missing,"negotiation_roots":negotiation,"seconds":round(time.monotonic()-start,3),"returncode":p.returncode,"filter":"tree:0","depth_used":False,"refspec_destinations":False,"write_fetch_head":False}
 print("FRESH_GRAPH_FETCH_COMPLETE",len(missing),fetch["seconds"],flush=True)
assert not (V/"shallow").exists()
graph_roots=sorted(set(roots+[candidate,*markers]));graph=git("rev-list","--topo-order","--reverse","--parents","--stdin",input=("\n".join(graph_roots)+"\n").encode(),timeout=180)
masks={}
for line in graph.decode().splitlines():
 items=line.split();sha=items[0];mask=sum(1<<i for i,x in enumerate(markers) if x==sha)
 for parent in items[1:]:mask|=masks[parent]
 masks[sha]=mask
candidate_ancestry=set(git("rev-list",candidate).decode().splitlines());vector=[]
for name,sha in sorted(refs.items()):
 by_old=name in original_protected or name in prior_protected
 by_marker=bool(masks[sha]);by_new_name=name not in original_refs and "hia" in name.lower()
 if not (by_old or by_marker or by_new_name):continue
 old=prior_protected.get(name,{}).get("observed_sha") or original_protected.get(name)
 descends=None
 if old:
  p=subprocess.run(["git","--git-dir",str(V),"merge-base","--is-ancestor",old,sha],env=env,capture_output=True,timeout=30);assert p.returncode in (0,1),p.stderr.decode();descends=p.returncode==0
 vector.append({"name":name,"observed_sha":sha,"original_sha":original_protected.get(name),"prior_protected_sha":old,"protected_marker_ancestors":[m for i,m in enumerate(markers) if masks[sha]&(1<<i)],"protected_by_prior_name":by_old,"protected_by_new_hia_name":by_new_name,"new_since_original_snapshot":name not in original_refs,"descends_prior_protected":descends,"head_in_candidate_ancestry":sha in candidate_ancestry})
protected_names={r["name"] for r in vector};collisions=[r for r in vector if r["head_in_candidate_ancestry"]];assert not (set(markers)&candidate_ancestry)
compressed=gzip.compress(raw,mtime=0);assert len(compressed)<=500000;(D/"refs.tsv.gz").write_bytes(compressed)
receipt={"started_utc":started,"observed_utc":observed,"verified_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head_count":len(refs),"protected_count":len(vector),"original_snapshot_heads":len(original_refs),"original_protected_count":len(original_protected),"prior_snapshot_heads":len(prior_refs),"prior_protected_count":len(prior_protected),"prior_snapshot_observed_utc":prior["observed_utc"],"main":{"expected":"732e934ba496d90fbe042b8d41d479ef901643e5","observed":refs.get("main"),"matches":refs.get("main")=="732e934ba496d90fbe042b8d41d479ef901643e5"},"integration":{"branch":"integration/hepta-single-main-20261113-ab5b","expected":"7e04259b85ee2d3c31182c6b4be8b6a3ace29fc0","observed":refs.get("integration/hepta-single-main-20261113-ab5b"),"matches":refs.get("integration/hepta-single-main-20261113-ab5b")=="7e04259b85ee2d3c31182c6b4be8b6a3ace29fc0"},"candidate":candidate,"candidate_tree":git("rev-parse",candidate+"^{tree}").decode().strip(),"markers":markers,"protected_marker_ancestors_of_candidate":[],"candidate_protected_collisions":collisions,"current_protected_vector":vector,"new_since_prior":[{"name":name,"sha":refs[name],"protected":name in protected_names} for name in added],"removed_since_prior":[{"name":name,"old_sha":prior_refs[name],"was_protected":name in prior_protected} for name in removed],"changed_since_prior":[{**r,"protected_now":r["name"] in protected_names} for r in changed],"new_non_protected_heads":[{"name":name,"sha":refs[name]} for name in added if name not in protected_names],"removed_since_original":[{"name":name,"old_sha":original_refs[name]} for name in sorted(set(original_refs)-set(refs))],"changed_since_original":[{"name":name,"old_sha":original_refs[name],"new_sha":refs[name],"protected_now":name in protected_names} for name in sorted(set(original_refs)&set(refs)) if original_refs[name]!=refs[name]],"raw_refs":{"path":"refs.tsv.gz","raw_bytes":len(raw),"raw_sha256":hashlib.sha256(raw).hexdigest(),"gzip_bytes":len(compressed),"gzip_sha256":hashlib.sha256(compressed).hexdigest(),"round_trip_verified":gzip.decompress(compressed)==raw},"graph":{"roots":graph_roots,"sha256":hashlib.sha256(graph).hexdigest(),"commit_count":len(masks),"fetch":fetch},"remote_ref_mutations":0,"shared_repository_fetches":0,"rule":"Preserve every prior protected name, all current descendants of either HIA marker, and conservatively new HIA-named heads. No ref was changed, reset or deleted; external advances and deletions are recorded as observed."}
(D/"fresh-ref-protection.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({k:v for k,v in receipt.items() if k in {"observed_utc","verified_utc","head_count","protected_count","main","integration","candidate","candidate_protected_collisions","new_since_prior","removed_since_prior","changed_since_prior","new_non_protected_heads"}}),flush=True)

