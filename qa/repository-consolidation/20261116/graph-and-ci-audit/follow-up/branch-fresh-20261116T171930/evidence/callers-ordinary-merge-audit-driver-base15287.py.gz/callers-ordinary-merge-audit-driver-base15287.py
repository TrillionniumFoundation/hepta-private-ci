from pathlib import Path
import datetime,hashlib,json,os,re,subprocess
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");P=T/"audit/branch_inventory";D=P/"manifest-only-review/00aef9bd81a9f01b26523e6600d7d797f0810067";R=T/"safe-evidence-merge";V=P/"cell-source-object-viewer.git"
base="15287f0562e251250f5553d603b66c9a8f81ecde";tip=D.name;env=dict(os.environ,GIT_NO_LAZY_FETCH="1",GIT_OPTIONAL_LOCKS="0")
def git(*args,input=None,extra=None):
 e=dict(env);e.update(extra or {});return subprocess.check_output(["git","-C",str(R),*args],input=input,env=e,stderr=subprocess.PIPE,timeout=90)
old_base="89e6d75fae09d3b2f6d395cd77e37d967d95c126"
for path in ["CALLERS.toml","scripts/hepta_callers_manifest_parts/part-0000.toml.gz","codex-rs/hepta-agentd/src/circuit_learning_read_capability.rs","codex-rs/hepta-agentd/src/circuit_learning_read_service.rs"]:
 assert git("rev-parse",old_base+":"+path)==git("rev-parse",base+":"+path),path
semantic=json.loads((D/"exact-unique-guard-delta-retention.json").read_text());assert semantic["all_unique_incoming_guard_entries_exactly_retained"] and semantic["all_other_incoming_row_fields_unchanged"]
full=json.loads((D/"full-semantic-comparison.json").read_text());assert full["unique_commits"]==[tip] and full["unique_commit_path_delta"]=="M\tCALLERS.toml\n"
q=subprocess.run(["git","-C",str(R),"merge-tree","--write-tree","--messages",base,tip],capture_output=True,env=env,timeout=120)
(D/"ordinary-merge-preview-base15287.stdout").write_bytes(q.stdout);(D/"ordinary-merge-preview-base15287.stderr").write_bytes(q.stderr)
assert q.returncode==1,(q.returncode,q.stderr.decode());lines=q.stdout.decode().splitlines();tree=lines[0].strip();assert re.fullmatch("[0-9a-f]{40}",tree)
stages=[]
for line in lines[1:]:
 m=re.fullmatch(r"([0-7]{6}) ([0-9a-f]{40}) ([123])\t(.+)",line)
 if m:stages.append({"mode":m[1],"sha":m[2],"stage":int(m[3]),"path":m[4]})
assert {r["path"] for r in stages}=={"CALLERS.toml"} and len(stages)==3,stages
base_tree=git("rev-parse",base+"^{tree}").decode().strip();carrier=git("rev-parse",base+":CALLERS.toml").decode().strip()
index=D/"ordinary-merge-resolution-index-base15287";assert not index.exists();extra={"GIT_INDEX_FILE":str(index)}
git("read-tree",tree,extra=extra);git("update-index","--cacheinfo","100644",carrier,"CALLERS.toml",extra=extra)
resolved=git("write-tree","--missing-ok",extra=extra).decode().strip();index.unlink();assert resolved==base_tree
author={"GIT_AUTHOR_NAME":"Repository Consolidation Audit","GIT_AUTHOR_EMAIL":"audit@hepta.invalid","GIT_COMMITTER_NAME":"Repository Consolidation Audit","GIT_COMMITTER_EMAIL":"audit@hepta.invalid"}
message=b"Merge retained original pidfd parameter guards\n\nReview the complete unique CALLERS change: both new full function-order entries are already exact in the decoded current manifest. Preserve its 1645 boundaries, 819 protected-file rows, existing stronger checks, and bounded lossless carrier. Resolve only CALLERS.toml; preserve the original incoming tip as second parent.\n"
commit=git("commit-tree",resolved,"-p",base,"-p",tip,input=message,extra=author).decode().strip()
head_header=git("cat-file","commit",commit).decode().split("\n\n",1)[0].splitlines();assert [l[7:] for l in head_header if l.startswith("parent ")]==[base,tip]
assert git("diff","--name-only","-z",base,commit)==b""
ancestry=set(git("rev-list",commit).decode().splitlines());before=set(git("rev-list",base).decode().splitlines());branches=json.loads((P/"branch_classification.json").read_text())
eligible=[r for r in branches if r["name"]!="main" and not r["protected_hia"]];added=[r for r in eligible if r["sha"] in ancestry and r["sha"] not in before];assert len(added)==2
protected=[r["sha"] for r in branches if r["protected_hia"]]
protection=json.loads((P/"fresh-publication-refs-after-cell/fresh-ref-protection.json").read_text())
protected.extend(r["observed_sha"] for r in protection["current_protected_vector"]);protected+=["f02bb9f3344cdff4e361cca4353540ca0193bd21","3aa1f85ba90c79d220a5cadf2261def176892867"];assert not set(protected)&ancestry
carrier_paths=["CALLERS.toml"]+[p for p in git("ls-tree","-r","--name-only",base,"--","scripts/hepta_callers_manifest_parts").decode().splitlines()]
carrier_proof=[{"path":p,"blob":git("rev-parse",base+":"+p).decode().strip(),"after_blob":git("rev-parse",commit+":"+p).decode().strip()} for p in carrier_paths];assert all(r["blob"]==r["after_blob"] for r in carrier_proof)
def receipt(name):
 p=D/name;raw=p.read_bytes();return {"path":str(p),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
plan={"observed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"baseline_local_commit":base,"baseline_server_equivalent":base,"baseline_tree":base_tree,"original_tip":tip,"merge_base":git("merge-base",base,tip).decode().strip(),"ordinary_preview_tree":tree,"ordinary_preview_exit":q.returncode,"conflict_stages":stages,"resolution":"The only conflict is physical CALLERS.toml. Its two unique incoming function-order guard entries exactly equal their current decoded entries. Preserve the entire current decoded object and bounded index/parts byte-for-byte, including unrelated newer guards; no other path changes.","local_merge_commit":commit,"parents":[base,tip],"resolved_tree":resolved,"tree_entries":[],"all_source_configuration_and_audit_paths_identical":True,"decoded_manifest_counts":{"boundary":1645,"protected_file":819},"carrier_paths":carrier_proof,"complete_unique_incoming_commits":[tip],"complete_unique_semantic_delta_proof":receipt("exact-unique-guard-delta-retention.json"),"full_semantic_comparison":receipt("full-semantic-comparison.json"),"original_patch":receipt("incoming-unique-commit.patch"),"source_guard_actual_blob_proof":receipt("current-guard-retention-proof.json"),"additional_original_heads":added,"retained_original_heads":sum(r["sha"] in ancestry for r in eligible),"remaining_original_heads":sum(r["sha"] not in ancestry for r in eligible),"protected_original_heads":63,"protected_snapshot_heads":protection["protected_count"],"protected_snapshot_utc":protection["observed_utc"],"protected_ancestry_collisions":[],"native_tests_not_rerun_reason":"No source, manifest, data, or configuration byte changes: the whole resolved tree equals the already audited baseline. This is an ordinary parent-preserving merge after explicit one-conflict semantic review.","root_followup_requirement":"Root may replay against its newer reviewed head only after rechecking the two decoded guard entries, full index/part identities, and ordinary merge conflict set. Preserve all newer source and audit paths.","remote_ref_changes":0}
(D/"ordinary-merge-plan-base15287.json").write_text(json.dumps(plan,indent=2)+"\n");print(json.dumps({"plan":receipt("ordinary-merge-plan-base15287.json"),"commit":commit,"tree":resolved,"parents":[base,tip],"additional_heads":len(added),"retained":plan["retained_original_heads"],"remaining":plan["remaining_original_heads"],"conflicts":stages}),flush=True)

