from pathlib import Path
import gzip, hashlib, io, json, os, subprocess, tarfile, time
T=Path('/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116')
N=T/'audit/ci_audit/hosted-60658ec5/strict-clippy-98-callers-v1/native-4a-source'
O=T/'audit/ci_audit/strict55-windows2-bb6-proof-publication-v2'
O.mkdir(exist_ok=False)
previous=T/'audit/ci_audit/strict55-windows2-bb6-proof-publication-v1'
old_readme=(previous/'README.md').read_bytes()
old_clause=b'and requires source tree 1094c6a81d4e647767e670ef861ee75e9f1030a4.'
new_clause=b'with a fingerprint derived from audited source tree 1094c6a81d4e647767e670ef861ee75e9f1030a4. The active checks retain all 37 source pins and the exact normalized lock comparison.'
assert old_readme.count(old_clause)==1
new_readme=old_readme.replace(old_clause,new_clause)
(O/'README.md').write_bytes(new_readme)
baseline=json.loads((previous/'repository-entry-candidates-before-gates.json').read_text())
for row in baseline['entries']:
 if row['path'].endswith('/README.md'):row['source_path']=str(O/'README.md')
(O/'repository-entry-candidates-before-gates.json').write_text(json.dumps(baseline,indent=2)+'\n')
G=O/'gates';G.mkdir()
(G/'README-original-v1.md').write_bytes(old_readme)
(G/'previous-publication-gates.tar.gz').write_bytes((previous/'publication-gates.tar.gz').read_bytes())
(G/'previous-entry-candidates.json').write_bytes((previous/'repository-entry-candidates.json').read_bytes())
(G/'documentation-correction.json').write_text(json.dumps({'reason':'1094 is the reviewed fingerprint source tree; workflow enforcement is all37 exact pins and one normalized lock fingerprint, not a whole-tree equality check.','oldClause':old_clause.decode(),'correctedClause':new_clause.decode(),'oldSha256':hashlib.sha256(old_readme).hexdigest(),'newSha256':hashlib.sha256(new_readme).hexdigest(),'allMainCarriersAndManifestUnchanged':True},indent=2)+'\n')

env=os.environ.copy();env['PYTHONPATH']=str(T/'audit/branch_inventory/codespell_vendor');env['PYTHONDONTWRITEBYTECODE']='1'
prefix=json.loads((T/'audit/ci_audit/c2d-evidence-original-gates-v1/codespell-result.json').read_text())['argv'][:8]
pc=['/usr/bin/node',str(T/'audit/branch_inventory/prettier-dist-3.5.3/bin/prettier.cjs'),'--config',str(N/'.prettierrc.toml'),'--ignore-path',str(N/'.prettierignore')]
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def run(label,argv):
 start=time.monotonic()
 with (G/(label+'.stdout')).open('xb') as out,(G/(label+'.stderr')).open('xb') as err:
  p=subprocess.run(argv,cwd=N,env=env,stdout=out,stderr=err,timeout=120)
 r={'argv':argv,'cwd':str(N),'environmentOverrides':{'PYTHONPATH':env['PYTHONPATH'],'PYTHONDONTWRITEBYTECODE':'1'},'exitCode':p.returncode,'seconds':time.monotonic()-start,'stdout':{'path':str(G/(label+'.stdout')),'sha256':sha((G/(label+'.stdout')).read_bytes())},'stderr':{'path':str(G/(label+'.stderr')),'sha256':sha((G/(label+'.stderr')).read_bytes())}}
 (G/(label+'-result.json')).write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'phase':label,'exitCode':p.returncode}),flush=True)
 return r
initial=(O/'README.md').read_bytes()
fmt=run('prettier-initial',pc+['--check',str(O/'README.md')])
if fmt['exitCode']:
 (G/'README-before-format.md').write_bytes(initial)
 assert run('prettier-format-owned-readme',pc+['--write',str(O/'README.md')])['exitCode']==0
 assert run('prettier-final',pc+['--check',str(O/'README.md')])['exitCode']==0
plan=json.loads((O/'repository-entry-candidates-before-gates.json').read_text())
for e in plan['entries']:
 p=Path(e['source_path']);b=p.read_bytes()
 if p.name=='README.md':e.update(sha=oid(b),sha256=sha(b),bytes=len(b))
 else:assert len(b)==e['bytes'] and sha(b)==e['sha256'] and oid(b)==e['sha']
before={x['source_path']:sha(Path(x['source_path']).read_bytes()) for x in plan['entries']}
cs=run('codespell-all39',prefix+[x['source_path'] for x in plan['entries']])
assert cs['exitCode']==0
assert before=={p:sha(Path(p).read_bytes()) for p in before}
(G/'inputs.json').write_text(json.dumps({'count':len(before),'hashes':before,'unchanged':True,'readonlyConfigFiles':{str(N/x):sha((N/x).read_bytes()) for x in ['.codespellignore','.codespellrc','.prettierrc.toml','.prettierignore']},'toolVersions':{'Codespell':'2.4.3','Prettier':'3.5.3'}},indent=2)+'\n')
buf=io.BytesIO();members=[]
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for p in sorted(G.iterdir()):
  b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(b))
  members.append({'path':p.name,'sourcePath':str(p),'bytes':len(b),'sha256':sha(b)})
 p=Path(__file__);b=p.read_bytes();i=tarfile.TarInfo('run-publication-gates.py');i.size=len(b);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(b));members.append({'path':i.name,'sourcePath':str(p),'bytes':len(b),'sha256':sha(b)})
raw=buf.getvalue();z=gzip.compress(raw,compresslevel=9,mtime=0)
p=O/'publication-gates.tar.gz';p.write_bytes(z);assert len(z)<500000
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z)),mode='r:') as tar:
 for m in members:assert tar.extractfile(m['path']).read()==Path(m['sourcePath']).read_bytes()
entry={'path':str(Path(plan['entries'][0]['path']).parent/'publication-gates.tar.gz'),'source_path':str(p),'mode':'100644','type':'blob','sha':oid(z),'sha256':sha(z),'bytes':len(z)}
plan['entries'].append(entry);plan['count']=len(plan['entries']);plan['gate_proof_originals']=members
allBefore={x['source_path']:sha(Path(x['source_path']).read_bytes()) for x in plan['entries']}
cs2=run('codespell-final-all40',prefix+[x['source_path'] for x in plan['entries']])
assert cs2['exitCode']==0 and allBefore=={p:sha(Path(p).read_bytes()) for p in allBefore}
plan.update(original_codespell_exit_code=0,original_prettier_exit_code=0,all_publication_inputs_unchanged=True,final_codespell_receipt=str(G/'codespell-final-all40-result.json'),maximum_blob_bytes=max(x['bytes'] for x in plan['entries']))
out=O/'repository-entry-candidates.json';out.write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'entries':len(plan['entries']),'bytes':sum(x['bytes'] for x in plan['entries']),'maxBlob':plan['maximum_blob_bytes'],'manifestPath':str(out),'manifestBytes':out.stat().st_size,'manifestSha256':sha(out.read_bytes()),'gateArchiveBytes':len(z),'gateArchiveSha256':sha(z),'originals':plan['original_count']}),flush=True)
