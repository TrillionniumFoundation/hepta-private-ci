from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");P=T/"audit/branch_inventory";R=T/"safe-evidence-merge";D=P/"fresh-publication-refs-before-darwin";D.mkdir(exist_ok=True);V=D/"commit-graph-viewer.git";E=D/"empty-hooks";E.mkdir(exist_ok=True)
env=dict(os.environ,GIT_NO_LAZY_FETCH="1",GIT_OPTIONAL_LOCKS="0")
def cmd(argv,input=None,timeout=180):return subprocess.check_output(argv,input=input,stderr=subprocess.PIPE,env=env,timeout=timeout)
def git(*args,input=None,timeout=180):return cmd(["git","--git-dir",str(V),*args],input,timeout)
if not V.exists():
 cmd(["git","init","--bare","--quiet","--template="+str(E),str(V)])
 (V/"objects/info/alternates").write_text(str(R/".git/objects")+"\n"+str(T/"ci-callers-format/.git/objects")+"\n"+str(P/"fresh-publication-refs-after-cell/commit-graph-viewer.git/objects")+"\n")
 git("config","core.hooksPath",str(E))
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
raw=cmd(["git","ls-remote","--heads","https://github.com/TrillionniumFoundation/hepta-private-ci.git"],timeout=180)
observed=datetime.datetime.now(datetime.timezone.utc).isoformat();(D/"refs.tsv").write_bytes(raw);refs={}
for line in raw.decode().splitlines():
 sha,name=line.split("\t");assert re.fullmatch("[0-9a-f]{40}",sha) and name.startswith("refs/heads/");name=name[len("refs/heads/"):];assert name not in refs;refs[name]=sha
prior_path=P/"fresh-publication-refs-after-cell/fresh-ref-protection.json";prior=json.loads(prior_path.read_text());prior_raw=(P/"fresh-publication-refs-after-cell/refs.tsv").read_bytes()
prior_refs={line.split("\t")[1][len("refs/heads/"):]:line.split("\t")[0] for line in prior_raw.decode().splitlines()}
original=json.loads((P/"branch_classification.json").read_text());original_refs={r["name"]:r["sha"] for r in original};prior_protected={r["name"]:r for r in prior["current_protected_vector"]};original_protected={r["name"]:r["sha"] for r in original if r["protected_hia"]}
added=sorted(set(refs)-set(prior_refs));removed=sorted(set(prior_refs)-set(refs));changed=[{"name":name,"old_sha":prior_refs[name],"new_sha":refs[name]} for name in sorted(set(refs)&set(prior_refs)) if refs[name]!=prior_refs[name]]
markers=["f02bb9f3344cdff4e361cca4353540ca0193bd21","3aa1f85ba90c79d220a5cadf2261def176892867"];candidate="3d6d17adfa92757085a371d67cd269e043d8dbed"
roots=sorted(set(refs.values()));object_roots=sorted(set(roots+[candidate,*markers]));result=git("cat-file","--batch-check=%(objectname) %(objecttype)",input=("\n".join(object_roots)+"\n").encode()).decode().splitlines();missing=[line.split()[0] for line in result if line.endswith(" missing")];assert len(result)==len(object_roots)
print(json.dumps({"observed_utc":observed,"heads":len(refs),"added_since_prior":len(added),"removed_since_prior":len(removed),"changed_since_prior":len(changed),"missing_commit_roots":len(missing)}),flush=True)
fetch=None
if missing:
 negotiation=[]
 for sha in sorted(set(markers+["732e934ba496d90fbe042b8d41d479ef901643e5","7e04259b85ee2d3c31182c6b4be8b6a3ace29fc0"]+[r["observed_sha"] for r in prior_protected.values()])):
  p=subprocess.run(["git","--git-dir",str(V),"cat-file","-e",sha+"^{commit}"],env=env,capture_output=True)
  if p.returncode==0:negotiation.append(sha)
 argv=["git","--git-dir",str(V),"-c","protocol.version=2","-c","fetch.negotiationAlgorithm=skipping","fetch","--quiet","--no-tags","--no-write-fetch-head","--no-auto-maintenance","--filter=tree:0"]+["--negotiation-tip="+s for s in negotiation]+["--stdin","https://github.com/TrillionniumFoundation/hepta-private-ci.git"]
 start=time.monotonic();p=subprocess.run(argv,input=("\n".join(missing)+"\n").encode(),env=env,capture_output=True,timeout=300);(D/"graph-fetch.stderr").write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()
 fetch={"requested_unknown_roots":missing,"negotiation_roots":negotiation,"seconds":round(time.monotonic()-start,3),"returncode":p.returncode,"filter":"tree:0","depth_used":False,"refspec_destinations":False,"write_fetch_head":False}
 print("FRESH_GRAPH_FETCH_COMPLETE",len(missing),fetch["seconds"],flush=True)
assert not (V/"shallow").exists()
raw_commit=git("cat-file","commit",candidate);assert hashlib.sha1(("commit "+str(len(raw_commit))+"\\0").encode().replace(b"\\0",b"\x00")+raw_commit).hexdigest()==candidate
(D/"candidate.git-commit").write_bytes(raw_commit)
candidate_headers=raw_commit.split(b"\n\n",1)[0].decode().splitlines();candidate_tree=[s.split()[1] for s in candidate_headers if s.startswith("tree ")][0];candidate_parents=[s.split()[1] for s in candidate_headers if s.startswith("parent ")]
assert candidate_parents==["d8b24300d190bef3d3c9d94765b256412e3fb867"],candidate_parents
assert candidate_tree.startswith("2df942"),candidate_tree
graph_roots=sorted(set(roots+[candidate,*markers]));graph=git("rev-list","--topo-order","--reverse","--parents","--stdin",input=("\n".join(graph_roots)+"\n").encode(),timeout=180)
(D/"augmented-graph.parents").write_bytes(graph)
remote_graph=git("rev-list","--topo-order","--reverse","--parents","--stdin",input=("\n".join(roots)+"\n").encode(),timeout=180);(D/"remote-graph.parents").write_bytes(remote_graph);remote_commits={line.split()[0] for line in remote_graph.decode().splitlines()}
masks={}
for line in graph.decode().splitlines():
 items=line.split();sha=items[0];mask=sum(1<<i for i,x in enumerate(markers) if x==sha)
 for parent in items[1:]:mask|=masks[parent]
 masks[sha]=mask
candidate_ancestry=set(git("rev-list",candidate).decode().splitlines());(D/"candidate-ancestry.txt").write_text("\n".join(sorted(candidate_ancestry))+"\n");vector=[]
for name,sha in sorted(refs.items()):
 by_old=name in original_protected or name in prior_protected
 by_marker=bool(masks[sha]);by_new_name=name not in original_refs and "hia" in name.lower()
 if not (by_old or by_marker or by_new_name):continue
 old=prior_protected.get(name,{}).get("observed_sha") or original_protected.get(name)
 descends=None
 if old:
  p=subprocess.run(["git","--git-dir",str(V),"merge-base","--is-ancestor",old,sha],env=env,capture_output=True,timeout=30);assert p.returncode in (0,1),p.stderr.decode();descends=p.returncode==0
 vector.append({"name":name,"observed_sha":sha,"original_sha":original_protected.get(name),"prior_protected_sha":old,"protected_marker_ancestors":[m for i,m in enumerate(markers) if masks[sha]&(1<<i)],"protected_by_prior_name":by_old,"protected_by_new_hia_name":by_new_name,"new_since_original_snapshot":name not in original_refs,"descends_prior_protected":descends,"head_in_candidate_ancestry":sha in candidate_ancestry})
protected_names={r["name"] for r in vector};collisions=[r for r in vector if r["head_in_candidate_ancestry"]];assert not (set(markers)&candidate_ancestry);assert not collisions
original_eligible=[r for r in original if not r["protected_hia"] and r["name"]!="main"];original_retained=[{"name":r["name"],"sha":r["sha"]} for r in original_eligible if r["sha"] in candidate_ancestry];original_pending=[{"name":r["name"],"sha":r["sha"]} for r in original_eligible if r["sha"] not in candidate_ancestry]
(D/"original-eligible-coverage.json").write_text(json.dumps({"candidate":candidate,"original_eligible_count":len(original_eligible),"retained_count":len(original_retained),"pending_count":len(original_pending),"retained":original_retained,"pending":original_pending},indent=2)+"\n")
assert len(original_retained)==1796 and len(original_pending)==5434,(len(original_retained),len(original_pending))
compressed=gzip.compress(raw,mtime=0);assert len(compressed)<=500000;(D/"refs.tsv.gz").write_bytes(compressed)
receipt={"started_utc":started,"observed_utc":observed,"verified_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head_count":len(refs),"protected_count":len(vector),"original_snapshot_heads":len(original_refs),"original_protected_count":len(original_protected),"prior_snapshot_heads":len(prior_refs),"prior_protected_count":len(prior_protected),"prior_snapshot_observed_utc":prior["observed_utc"],"main":{"expected":"732e934ba496d90fbe042b8d41d479ef901643e5","observed":refs.get("main"),"matches":refs.get("main")=="732e934ba496d90fbe042b8d41d479ef901643e5"},"integration":{"branch":"integration/hepta-single-main-20261113-ab5b","expected":"7e04259b85ee2d3c31182c6b4be8b6a3ace29fc0","observed":refs.get("integration/hepta-single-main-20261113-ab5b"),"matches":refs.get("integration/hepta-single-main-20261113-ab5b")=="7e04259b85ee2d3c31182c6b4be8b6a3ace29fc0"},"candidate":candidate,"candidate_tree":candidate_tree,"candidate_parents":candidate_parents,"original_eligible_count":len(original_eligible),"original_retained_count":len(original_retained),"original_pending_count":len(original_pending),"markers":markers,"protected_marker_ancestors_of_candidate":[],"candidate_protected_collisions":collisions,"current_protected_vector":vector,"new_since_prior":[{"name":name,"sha":refs[name],"protected":name in protected_names} for name in added],"removed_since_prior":[{"name":name,"old_sha":prior_refs[name],"was_protected":name in prior_protected} for name in removed],"changed_since_prior":[{**r,"protected_now":r["name"] in protected_names} for r in changed],"new_non_protected_heads":[{"name":name,"sha":refs[name]} for name in added if name not in protected_names],"removed_since_original":[{"name":name,"old_sha":original_refs[name]} for name in sorted(set(original_refs)-set(refs))],"changed_since_original":[{"name":name,"old_sha":original_refs[name],"new_sha":refs[name],"protected_now":name in protected_names} for name in sorted(set(original_refs)&set(refs)) if original_refs[name]!=refs[name]],"raw_refs":{"path":"refs.tsv.gz","raw_bytes":len(raw),"raw_sha256":hashlib.sha256(raw).hexdigest(),"gzip_bytes":len(compressed),"gzip_sha256":hashlib.sha256(compressed).hexdigest(),"round_trip_verified":gzip.decompress(compressed)==raw},"graph":{"provenance":"Augmented local analysis includes the unpublished candidate and HIA markers; it is not the published remote-ref closure.","roots":graph_roots,"roots_sha256":hashlib.sha256(("\n".join(graph_roots)+"\n").encode()).hexdigest(),"sha256":hashlib.sha256(graph).hexdigest(),"commit_count":len(masks),"edge_count":sum(len(line.split())-1 for line in graph.decode().splitlines()),"fetch":fetch},"remote_graph":{"provenance":"Exact closure of unique commit heads observed by ls-remote at observed_utc only.","roots":roots,"roots_sha256":hashlib.sha256(("\n".join(roots)+"\n").encode()).hexdigest(),"sha256":hashlib.sha256(remote_graph).hexdigest(),"commit_count":len(remote_commits),"edge_count":sum(len(line.split())-1 for line in remote_graph.decode().splitlines())},"candidate_only_commits":sorted(set(masks)-remote_commits),"prior_snapshot":{"proof_path":str(prior_path),"proof_sha256":hashlib.sha256(prior_path.read_bytes()).hexdigest(),"refs_sha256":hashlib.sha256(prior_raw).hexdigest()},"remote_ref_mutations":0,"shared_repository_fetches":0,"rule":"Preserve every prior protected name, all current descendants of either HIA marker, and conservatively new HIA-named heads. No ref was changed, reset or deleted; external advances and deletions are recorded as observed."}
(D/"fresh-ref-protection.json").write_text(json.dumps(receipt,indent=2)+"\n")
assert receipt["main"]["matches"] and receipt["integration"]["matches"],"Publication lease assumptions changed"
print(json.dumps({k:v for k,v in receipt.items() if k in {"observed_utc","verified_utc","head_count","protected_count","main","integration","candidate","candidate_protected_collisions","new_since_prior","removed_since_prior","changed_since_prior","new_non_protected_heads","candidate_tree","candidate_parents","original_eligible_count","original_retained_count","original_pending_count"}}),flush=True)

