from pathlib import Path
import hashlib,importlib.util,json,sys,traceback
D=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116/audit/branch_inventory/aggregate-review/cell-history-custody-v1")
S=D/"repository-files/qa/repository-consolidation/20261116/cell-history-custody"
sys.path.insert(0,str(S))
spec=importlib.util.spec_from_file_location("independent_existing_sibling_fixture",S/"test_restore.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
case=module.HistoryCustodyTests();case.setUp()
try:
 document=case.current_input_document()
 before=module.restore.verify(case.repository,document,case.head,directory=case.metadata,current_inputs=True)
 path="qa/stem-bakeoff/evidence/fixture/README.md";old=(case.repository/path).read_bytes()
 new=old.replace(b"Original",b"Modified");assert old!=new and len(old)==len(new)
 before_paths=case.command("ls-tree","-r","--name-only",case.head).decode().splitlines()
 (case.repository/path).write_bytes(new);case.command("add","--",path);case.command("commit","--quiet","-m","change only an existing current sibling")
 new_head=case.command("rev-parse","HEAD").decode().strip();new_paths=case.command("ls-tree","-r","--name-only",new_head).decode().splitlines();assert new_paths==before_paths
 delta=case.command("diff","--name-status",case.head,new_head).decode().strip();assert delta=="M\t"+path
 rejected=None
 try:module.restore.verify(case.repository,document,new_head,directory=case.metadata,current_inputs=True)
 except ValueError as error:rejected=str(error)
 assert rejected is not None and "closure" in rejected.lower(),rejected
 target=case.root/"must-not-be-created";assert not target.exists()
 proof={"kind":"independent existing-sibling mutation check, separate from the frozen 11-test suite","restore_source":{"path":str(S/"restore.py"),"sha256":hashlib.sha256((S/"restore.py").read_bytes()).hexdigest()},"fixture_source":{"path":str(S/"test_restore.py"),"sha256":hashlib.sha256((S/"test_restore.py").read_bytes()).hexdigest()},"original_history_commit":case.original,"maintained_baseline_head":case.head,"mutated_head":new_head,"baseline_verify_passed":True,"mutated_path":path,"before":module.restore.identity(old),"after":module.restore.identity(new),"same_length_mutation":True,"same_repository_path_set":True,"git_name_status":delta,"api":"restore.verify(repository, document, new_head, directory=metadata, current_inputs=True)","rejected":True,"exception_type":"ValueError","exception":rejected,"restoration_called_after_rejection":False,"output_directory_created":False,"remote_refs_touched":False,"frozen_payload_files_changed":False,"result":"PASS"}
 (D/"existing-current-sibling-mutation-proof.json").write_text(json.dumps(proof,indent=2)+"\n")
 print(json.dumps(proof),flush=True)
finally:case.doCleanups()

