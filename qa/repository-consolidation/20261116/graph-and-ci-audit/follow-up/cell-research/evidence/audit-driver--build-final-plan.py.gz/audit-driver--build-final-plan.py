from pathlib import Path
import collections,datetime,hashlib,json,os,subprocess
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");P=T/"audit/branch_inventory";D=P/"aggregate-review/cell-history-custody-v1";R=T/"safe-evidence-merge";env=dict(os.environ,GIT_NO_LAZY_FETCH="1",GIT_OPTIONAL_LOCKS="0")
base="eef0975f9235f3ff7de1c3c02e6d6d80146af98b";published="7e04259b85ee2d3c31182c6b4be8b6a3ace29fc0";head="89e6d75fae09d3b2f6d395cd77e37d967d95c126"
def git(*args):return subprocess.check_output(["git","--git-dir",str(P/"cell-source-object-viewer.git"),*args],env=env,stderr=subprocess.PIPE,timeout=120)
def digest(p):
 raw=p.read_bytes();return {"path":str(p),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def tree(sha):
 result={}
 for row in git("ls-tree","-r","-z",sha).split(b"\0"):
  if row:
   meta,path=row.split(b"\t",1);mode,kind,oid=meta.decode().split();result[path.decode()]={"mode":mode,"type":kind,"sha":oid}
 return result
old=tree(base);current=tree(head)
removed=sorted(set(old)-set(current));changed=[p for p in old if p in current and old[p]!=current[p]];assert not removed
assert sorted(changed)==[".github/workflows/hepta-shared-stem-bakeoff-shadow.yml","qa/stem-bakeoff/real_encoder.py"],changed
native=[p for p in set(old)|set(current) if p.startswith("codex-rs/") and old.get(p)!=current.get(p)];assert not native
ci=json.loads((T/"audit/root-ci-source-batch1-v3/commit-receipt.json").read_text())["source_files"]
ci_proof=[]
for r in ci:
 assert current[r["path"]]["sha"]==r["postBlob"]==old[r["path"]]["sha"]
 ci_proof.append({"path":r["path"],"blob":r["postBlob"],"unchanged":True})
retained=set(git("rev-list",published).decode().splitlines());final=set(git("rev-list",head).decode().splitlines())
branches=json.loads((P/"branch_classification.json").read_text());eligible=[r for r in branches if r["name"]!="main" and not r["protected_hia"]]
before=[r for r in eligible if r["sha"] in retained];after=[r for r in eligible if r["sha"] in final];additional=[r for r in after if r["sha"] not in retained];assert len(additional)==61 and len(after)==1794,(len(additional),len(after))
protection_path=P/"publication/graph-and-ci-audit/follow-up/branch-prepublication-20261116T145506Z.json";protection=json.loads(protection_path.read_text())
vectors=protection["current_protected_vector"];assert len(vectors)==84
markers=["f02bb9f3344cdff4e361cca4353540ca0193bd21","3aa1f85ba90c79d220a5cadf2261def176892867"]
protected_old=[r for r in branches if r["protected_hia"]];assert len(protected_old)==63
protected_shas={r["sha"] for r in protected_old}|set(markers)
for r in vectors:
 protected_shas.add(r["observed_sha"])
 if r.get("original_sha"):protected_shas.add(r["original_sha"])
assert not (protected_shas&final),sorted(protected_shas&final)
merge=json.loads((D/"two-ordinary-merge-preliminary-plan.json").read_text());maintenance=json.loads((D/"representation-maintenance-plan.json").read_text())
steps=[]
for row in merge["steps"]+[{"sequence":3,"first_parent":maintenance["parent"],"local_commit":head,"resolved_tree":maintenance["tree"]}]:
 sha=row["local_commit"];header=git("cat-file","commit",sha).decode().split("\n\n",1)[0].splitlines();parents=[line[7:] for line in header if line.startswith("parent ")];actual_tree=next(line[5:] for line in header if line.startswith("tree "))
 expected=[row["first_parent"]]+([row["original_incoming_parent"]] if "original_incoming_parent" in row else [])
 assert parents==expected and actual_tree==row["resolved_tree"]
 a=tree(parents[0]);b=tree(sha);entries=[];detail=[]
 for path in sorted(set(a)|set(b)):
  if a.get(path)==b.get(path):continue
  e={"path":path,**b[path]} if path in b else {"path":path,"mode":a[path]["mode"],"type":a[path]["type"],"sha":None}
  entries.append(e);detail.append({"path":path,"before":a.get(path),"after":b.get(path)})
 steps.append({**row,"parents":parents,"tree":actual_tree,"base_tree":git("rev-parse",parents[0]+"^{tree}").decode().strip(),"tree_entries":entries,"changed_paths":detail,"changed_path_count":len(entries),"intermediate_not_for_ref_publication":row["sequence"]<3})
incoming=[r["original_incoming_parent"] for r in merge["steps"]]
unique={sha:set(git("rev-list",sha,"--not",base).decode().splitlines()) for sha in incoming}
assert all(sets<=final for sets in unique.values())
unique_union=set().union(*unique.values())
asset_doc=json.loads((D/"repository-files/qa/repository-consolidation/20261116/cell-history-custody/MANIFEST.json").read_text())
assert set(maintenance["removed_paths"])=={r["path"] for r in asset_doc["assets"]}
new_payload=json.loads((D/"nine-payload-immutable-blob-receipt.json").read_text());assert len(new_payload["entries"])==9 and all(r["remote_bytes_equal"] for r in new_payload["entries"])
gates={}
for name in ("whole-checkpoint-original-size","final-cell-original-codespell","final-cell-prettier"):
 r=json.loads((D/(name+".json")).read_text());assert r["returncode"]==0
 gates[name]={"returncode":0,"seconds":r["seconds"],"receipt":digest(D/(name+".json"))}
gates["whole-checkpoint-original-size"]["actual_reported_paths"]=sum(line.startswith("- ") for line in (D/"whole-checkpoint-original-size.stdout").read_text().splitlines())
proof={"base":base,"candidate":head,"candidate_tree":maintenance["tree"],"original_base_path_count":len(old),"current_path_count":len(current),"removed_original_base_paths":removed,"changed_original_base_paths":changed,"new_paths":len(set(current)-set(old)),"native_rust_tree_equal":not native,"native_rust_path_count":sum(p.startswith("codex-rs/") for p in old),"root_five_ci_paths":ci_proof,"original_branch_snapshot":digest(P/"branch_classification.json"),"eligible_original_heads":len(eligible),"retained_before":len(before),"retained_after":len(after),"additional_retained_heads":len(additional),"pending_original_heads_after":len(eligible)-len(after),"additional_retained_vector":additional,"protected_original_heads":len(protected_old),"known_current_protected_heads":len(vectors),"protected_unique_sha_count":len(protected_shas),"protected_marker_shas":markers,"protected_sha_intersection_with_final_ancestry":[],"protected_snapshot_observed_utc":protection["observed_utc"],"protected_snapshot_source":digest(protection_path),"live_ref_read_required_before_final_branch_retirement":True,"incoming_unique_commits_relative_to_eef":{sha:len(s) for sha,s in unique.items()},"incoming_unique_commits_union":len(unique_union),"all_original_incoming_commits_retained":True,"incoming_unique_commits_intersection":len(set.intersection(*unique.values())),"git_parent_and_tree_readback_verified":True,"remote_ref_changes_by_agent":0}
(D/"final-source-ancestry-and-protection-proof.json").write_text(json.dumps(proof,indent=2)+"\n")
plan={"schema_version":1,"repository":"TrillionniumFoundation/hepta-private-ci","observed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base_server_commit":base,"base_server_tree":git("rev-parse",base+"^{tree}").decode().strip(),"final_local_commit":head,"final_tree":maintenance["tree"],"steps":steps,"payload_blobs":new_payload["entries"],"custody_asset_count":169,"custody_asset_bytes":asset_doc["asset_total_bytes"],"current_input_roots":asset_doc["current_inputs"],"current_input_reader_proof":digest(D/"current-v3-real-input-reader-proof.json"),"transformers_backend_review":digest(D/"pinned-transformers-audio-backend-source-review.json"),"einsum_semantic_review":digest(D/"einsum-alpha-rename-proof.json"),"native_source_and_graph_proof":digest(D/"final-source-ancestry-and-protection-proof.json"),"gates":gates,"publication_instructions":"Create trees against each previous exact tree, then commits preserving ordered original parents. The first two trees contain original oversized assets; move no refs to intermediate commits. Publish only the final bounded maintenance tree, with any separately reviewed root source overlays and append-only audit evidence preserving this plan. Root owns every remote ref operation.","ready_for_root_review":True,"qualification":"Current source and input/custody tests passed. Original fixture tests include tiny local models/updates; no real checkpoint download, GPU or research training. This does not assert native research quality or global remaining-branch completion."}
target=D/"cell-two-family-publication-plan.json";target.write_text(json.dumps(plan,indent=2)+"\n")
print(json.dumps({"plan":digest(target),"base":base,"final_local_commit":head,"final_tree":maintenance["tree"],"step_counts":[r["changed_path_count"] for r in steps],"additional_heads":len(additional),"retained":len(after),"remaining":len(eligible)-len(after),"unique_incoming_history":{sha:len(s) for sha,s in unique.items()},"unique_union":len(unique_union),"size_paths":gates["whole-checkpoint-original-size"]["actual_reported_paths"],"existing_changed":changed,"protected":len(vectors)}),flush=True)

