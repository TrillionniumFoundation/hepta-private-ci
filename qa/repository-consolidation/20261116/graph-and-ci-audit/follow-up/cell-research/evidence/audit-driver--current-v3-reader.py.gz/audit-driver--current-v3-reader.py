from pathlib import Path,PurePosixPath
import hashlib,io,json,os,shutil,sys,tarfile,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");P=T/"audit/branch_inventory";D=P/"aggregate-review/cell-history-custody-v1";W=D/"merged-source/qa/stem-bakeoff";I=D/"restored-current-inputs-v1/qa/stem-bakeoff/evidence/20261024-cell-parameter-field-v3";O=D/"actual-current-v3-reader"
assert not O.exists();O.mkdir()
manifest_path=I/"raw-evidence-manifest.json";manifest=json.loads(manifest_path.read_text())
assert manifest["archive_bytes"]==45289220 and manifest["part_count"]==87 and manifest["file_count"]==3092
joined=io.BytesIO();part_receipts=[]
for record in manifest["parts"]:
 rel=PurePosixPath(record["path"]);assert not rel.is_absolute() and ".." not in rel.parts
 p=I/str(rel);assert not p.is_symlink()
 data=p.read_bytes();assert len(data)==record["bytes"] and hashlib.sha256(data).hexdigest()==record["sha256"]
 assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==record["git_blob_sha1"]
 joined.write(data);part_receipts.append(record)
raw=joined.getvalue();assert len(raw)==manifest["archive_bytes"] and hashlib.sha256(raw).hexdigest()==manifest["archive_sha256"]
wanted={r["path"]:r for r in manifest["files"] if r["path"] in {"raw/features/features.npz","raw/features/plan.json","raw/features/report.json"}}
assert len(wanted)==3 and sum(r["bytes"] for r in wanted.values())<2_000_000
features=O/"features";features.mkdir()
seen=set()
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:xz") as archive:
 for member in archive:
  if member.name not in wanted:continue
  assert member.name not in seen and member.isfile() and not member.issym() and not member.islnk()
  r=wanted[member.name];assert member.size==r["bytes"]
  data=archive.extractfile(member).read(r["bytes"]+1);assert len(data)==r["bytes"] and hashlib.sha256(data).hexdigest()==r["sha256"]
  target=features/PurePosixPath(member.name).name
  with target.open("xb") as stream:stream.write(data)
  seen.add(member.name)
assert seen==set(wanted)
assert (features/"report.json").read_bytes()==(I/"features/report.json").read_bytes()
data_dir=O/"data";data_dir.mkdir()
for name in ("data_receipt.json","train_labels.json","sources.json","predictors.json"):
 shutil.copyfile(I/"data"/name,data_dir/name)
shutil.copyfile(I/"protocol.json",O/"protocol.json")
before={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in W.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
sys.path.insert(0,str(W));import numpy as np
import cell_field_action_io as reader
reads=[]
def audit(event,args):
 if event=="open" and args and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0]))
  if path.name in {"validation_labels.json","final_labels.json"}:raise PermissionError("Withheld labels are not input-reader evidence")
  if path.is_relative_to(O):reads.append(str(path.relative_to(O)))
sys.addaudithook(audit)
started=time.monotonic();loaded=reader.load_inputs(data_dir,features,O/"protocol.json")
projected,q=reader.project(loaded["features"],loaded["plan"]);splits=reader.split_arrays(projected,loaded["labels"])
assert loaded["features"].shape==(624,384) and np.isfinite(loaded["features"]).all()
assert set(splits)==reader.TRAIN_ROLES and np.isfinite(projected).all()
assert len(loaded["sources"])==624
after={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in W.rglob("*") if p.is_file() and "__pycache__" not in p.parts};assert before==after
receipt={"head":"89e6d75fae09d3b2f6d395cd77e37d967d95c126","maintained_entrypoint":str(W/"cell_field_action_io.py"),"entrypoint_sha256":hashlib.sha256((W/"cell_field_action_io.py").read_bytes()).hexdigest(),"archive_manifest_sha256":hashlib.sha256(manifest_path.read_bytes()).hexdigest(),"archive_sha256":manifest["archive_sha256"],"verified_original_parts":87,"verified_original_archive_bytes":len(raw),"selected_regular_members":list(wanted.values()),"archive_executed":False,"old_source_loaded":False,"input_root":str(O),"actual_calls":["cell_field_action_io.load_inputs(data, features, protocol)","cell_field_action_io.project(features, plan)","cell_field_action_io.split_arrays(projected, train_labels)"],"passed":True,"numpy":np.__version__,"seconds":round(time.monotonic()-started,3),"input_hashes":loaded["input_hashes"],"input_open_paths":sorted(set(reads)),"features_shape":list(loaded["features"].shape),"projected_shape":list(projected.shape),"train_role_shapes":{k:[list(a.shape) for a in v] for k,v in splits.items()},"source_files_unchanged":len(before),"withheld_labels_present_in_reader_root":False,"real_checkpoint_downloaded":False,"gpu_used":False,"training_updates":0,"qualification_claim":False}
(D/"current-v3-real-input-reader-proof.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)

