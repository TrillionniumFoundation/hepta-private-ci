from pathlib import Path
import base64,concurrent.futures,datetime,hashlib,json,subprocess,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");D=T/"audit/branch_inventory/aggregate-review/cell-history-custody-v1"
plan=json.loads((D/"representation-maintenance-plan.json").read_text());endpoint="repos/TrillionniumFoundation/hepta-private-ci/git/blobs"
def run(entry):
 raw=Path(entry["source_path"]).read_bytes()
 assert len(raw)==entry["bytes"] and hashlib.sha256(raw).hexdigest()==entry["sha256"]
 assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==entry["sha"]
 payload=json.dumps({"content":base64.b64encode(raw).decode(),"encoding":"base64"}).encode()
 start=time.monotonic();post=subprocess.run(["gh","api","--method","POST",endpoint,"--input","-"],input=payload,capture_output=True,timeout=180)
 assert post.returncode==0,post.stderr.decode()
 created=json.loads(post.stdout);assert created["sha"]==entry["sha"]
 get=subprocess.run(["gh","api",endpoint+"/"+entry["sha"]],capture_output=True,timeout=180);assert get.returncode==0,get.stderr.decode()
 result=json.loads(get.stdout);assert result["sha"]==entry["sha"] and result["encoding"]=="base64" and result["size"]==len(raw)
 actual=base64.b64decode(result["content"]);assert actual==raw
 receipt={**entry,"post_sha":created["sha"],"get_sha":result["sha"],"remote_bytes_equal":True,"remote_sha256":hashlib.sha256(actual).hexdigest(),"seconds":round(time.monotonic()-start,3),"url":created.get("url")}
 print(json.dumps({"path":entry["path"],"sha":entry["sha"],"verified":True}),flush=True);return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(run,plan["entries"]))
document={"observed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"immutable_blobs_only":True,"remote_refs_updated":False,"candidate_tree":plan["tree"],"entries":rows}
(D/"nine-payload-immutable-blob-receipt.json").write_text(json.dumps(document,indent=2)+"\n")
print("NINE_POST_GET_COMPLETE",len(rows),flush=True)

