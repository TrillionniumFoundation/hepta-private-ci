from pathlib import Path
import hashlib,importlib.metadata,inspect,json,sys
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");P=T/"audit/branch_inventory";D=P/"aggregate-review/cell-history-custody-v1";W=D/"merged-source/qa/stem-bakeoff"
sys.path.insert(0,str(W))
from real_encoder import attention_implementation
from transformers import EmbeddingGemma2Config, EmbeddingGemma2TextConfig, Gemma4AudioConfig
from transformers.configuration_utils import PreTrainedConfig
from transformers.models.gemma4.modeling_gemma4 import Gemma4AudioModel
from transformers.modeling_utils import PreTrainedModel
dispatch=attention_implementation("embeddinggemma2_740m","text_audio")
config=EmbeddingGemma2Config(text_config=EmbeddingGemma2TextConfig(),audio_config=Gemma4AudioConfig(),vision_config=None)
config._attn_implementation=dispatch
assert config._attn_implementation=="sdpa"
assert config.text_config._attn_implementation=="sdpa"
assert config.audio_config._attn_implementation=="eager"
assert "audio_config" in config.sub_configs
assert Gemma4AudioModel._supports_sdpa is False
assert Gemma4AudioModel._supports_flash_attn is False
assert Gemma4AudioModel._supports_flex_attn is False
records=[]
for label,thing,selected in [
 ("config_dict_dispatch",PreTrainedConfig,[(585,606)]),
 ("from_pretrained_argument",PreTrainedModel,[(4210,4235)]),
 ("embeddinggemma2_config",EmbeddingGemma2Config,None),
 ("gemma4_audio_backend",Gemma4AudioModel,[(1880,1902)])]:
 p=Path(inspect.getfile(thing));raw=p.read_bytes();lines=raw.decode().splitlines()
 if selected is None:
  source,start=inspect.getsourcelines(thing);selected=[(start,start+len(source)-1)]
 excerpts=[{"first_line":a,"last_line":b,"source":"\n".join(lines[a-1:b])+"\n"} for a,b in selected]
 records.append({"label":label,"file":str(p),"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw),"excerpts":excerpts})
assert importlib.metadata.version("transformers")=="5.20.2"
r={"transformers_version":"5.20.2","requirements_file":str(W/"requirements-real.txt"),"requirements_sha256":hashlib.sha256((W/"requirements-real.txt").read_bytes()).hexdigest(),"source_records":records,"current_real_encoder_blob":"fa51e7531ed2531df83a6b199a80268422c3a50f","requested_dispatch":dispatch,"actual_config_dispatch":{"main":config._attn_implementation,"text_config":config.text_config._attn_implementation,"audio_config":config.audio_config._attn_implementation},"config_only_probe_passed":True,"existing_tiny_model_regression":{"module":"test_real_audio_backend","test":"test_real_audio_tower_load_uses_eager_without_changing_text_attention","receipt":"current-original-torch-tests-v2.json","included_in_test_real_family_51_passed":True,"scope":"Original tiny local saved model exercises AutoModel.from_config, FrozenRealEncoder/from_pretrained, audio tower finite output and text readback; no downloaded research checkpoint."},"real_checkpoint_downloaded":False,"gpu_used":False,"research_training_executed":False,"conclusion":"Pinned Transformers explicitly accepts the per-subconfig dictionary. EmbeddingGemma2 uses audio_config of Gemma4AudioConfig. Gemma4AudioModel declares chunked local attention eager-only and rejects SDPA support; root/text SDPA remains unchanged."}
(D/"pinned-transformers-audio-backend-source-review.json").write_text(json.dumps(r,indent=2)+"\n")
proof=D/"einsum-alpha-rename-proof.json";old=proof.read_bytes();archive=D/"einsum-alpha-rename-proof.initial-pending.json"
if not archive.exists():archive.write_bytes(old)
j=json.loads(old);numeric=json.loads((D/"einsum-alpha-numeric-proof.json").read_text());assert len(numeric["subscript_bijection_exact_equality"])==5 and all(row["residual_equal"] and row["logit_equal"] for row in numeric["subscript_bijection_exact_equality"])
j["numerical_and_existing_test_validation"]={"status":"passed","numeric_receipt":"einsum-alpha-numeric-proof.json","numpy":"2.2.6","shape_cases":5,"exact_array_equal_for_both_contractions":True,"original_15_module_receipt":"current-merged-source-original-tests.json","original_15_module_tests":74,"original_15_module_result":"PASS","separate_shared_feature_tests":{"tests":14,"result":"PASS","receipt":"current-original-torch-tests-v2.json"},"separate_test_real_family":{"tests":51,"result":"PASS","receipt":"current-original-torch-tests-v2.json"},"unique_total_not_asserted":"The groups overlap and are not summed as distinct tests.","scope":"Original local tiny fixtures ran; no real checkpoint download, GPU, or research training."}
proof.write_text(json.dumps(j,indent=2)+"\n")
print(json.dumps({"source_proof":str(D/"pinned-transformers-audio-backend-source-review.json"),"source_files":[{"label":x["label"],"file":x["file"],"sha256":x["sha256"]} for x in records],"probe":r["actual_config_dispatch"],"updated_einsum_proof":str(proof)}),flush=True)

