from pathlib import Path,PurePosixPath
import hashlib,io,json,os,shutil,sys,tarfile,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");P=T/"audit/branch_inventory";D=P/"aggregate-review/cell-history-custody-v1";W=D/"merged-source/qa/stem-bakeoff";I=D/"restored-current-inputs-v1/qa/stem-bakeoff/evidence/20261024-cell-parameter-field-v2";O=D/"actual-current-v2-reader"
assert not O.exists();O.mkdir()
manifest_path=I/"archive-parts.json";manifest=json.loads(manifest_path.read_text()); members=json.loads((I/"archive-members.json").read_text())
assert manifest["bytes"]==27684232 and len(manifest["parts"])==53
joined=io.BytesIO();part_receipts=[]
for record in manifest["parts"]:
 rel=PurePosixPath(record["path"]);assert not rel.is_absolute() and ".." not in rel.parts
 p=I/str(rel);assert not p.is_symlink()
 data=p.read_bytes();assert len(data)==record["bytes"] and hashlib.sha256(data).hexdigest()==record["sha256"]
 assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==record["git_blob_sha1"]
 joined.write(data);part_receipts.append(record)
raw=joined.getvalue();assert len(raw)==manifest["bytes"] and hashlib.sha256(raw).hexdigest()==manifest["sha256"]
wanted={path:{"path":path,**row} for path,row in members.items() if path in {"features/features.npz","features/plan.json","features/report.json"}}
assert len(wanted)==3 and sum(r["bytes"] for r in wanted.values())<2_000_000
features=O/"features";features.mkdir()
seen=set()
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:xz") as archive:
 for member in archive:
  if member.name not in wanted:continue
  assert member.name not in seen and member.isfile() and not member.issym() and not member.islnk()
  r=wanted[member.name];assert member.size==r["bytes"]
  data=archive.extractfile(member).read(r["bytes"]+1);assert len(data)==r["bytes"] and hashlib.sha256(data).hexdigest()==r["sha256"]
  target=features/PurePosixPath(member.name).name
  with target.open("xb") as stream:stream.write(data)
  seen.add(member.name)
assert seen==set(wanted)
assert (features/"report.json").read_bytes()==(I/"features/report.json").read_bytes()
data_dir=O/"data";data_dir.mkdir()
for name in ("data_receipt.json","train_labels.json","sources.json","predictors.json"):
 shutil.copyfile(I/"data"/name,data_dir/name)
shutil.copyfile(I/"protocol.json",O/"protocol.json")
before={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in W.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
sys.path.insert(0,str(W));import numpy as np
import cell_field_retention_run as reader
from real_cell_features import predictor_rows
reads=[]
def audit(event,args):
 if event=="open" and args and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0]))
  if path.name in {"validation_labels.json","final_labels.json"}:raise PermissionError("Withheld labels are not input-reader evidence")
  if path.is_relative_to(O):reads.append(str(path.relative_to(O)))
sys.addaudithook(audit)
started=time.monotonic(); plan, protocol_hash, data_receipt, labels, sources, matrix, feature_report = reader._inputs(data_dir,features,O/"protocol.json")
rows=predictor_rows(json.loads((data_dir/"predictors.json").read_bytes())["rows"])
assert [r["source_id"] for r in rows]==[r["source_id"] for r in sources]
assert hashlib.sha256((data_dir/"predictors.json").read_bytes()).hexdigest()==feature_report["plan"]["predictors_sha256"]
projected,q=reader._project(matrix,plan);splits=reader._split_arrays(projected,labels)
assert matrix.shape==(480,384) and np.isfinite(matrix).all()
assert set(splits)=={"old_train","old_probe","current_train","current_probe"} and np.isfinite(projected).all()
assert len(sources)==480
loaded={"features":matrix,"input_hashes":{str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest() for p in O.rglob("*") if p.is_file()}}
after={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in W.rglob("*") if p.is_file() and "__pycache__" not in p.parts};assert before==after
receipt={"head":"89e6d75fae09d3b2f6d395cd77e37d967d95c126","maintained_entrypoint":str(W/"cell_field_retention_run.py"),"entrypoint_sha256":hashlib.sha256((W/"cell_field_retention_run.py").read_bytes()).hexdigest(),"archive_manifest_sha256":hashlib.sha256(manifest_path.read_bytes()).hexdigest(),"archive_sha256":manifest["sha256"],"verified_original_parts":53,"verified_original_archive_bytes":len(raw),"selected_regular_members":list(wanted.values()),"archive_executed":False,"old_source_loaded":False,"input_root":str(O),"actual_calls":["cell_field_retention_run._inputs(data, features, protocol)","real_cell_features.predictor_rows(original_predictor_payload)","cell_field_retention_run._project(features, plan)","cell_field_retention_run._split_arrays(projected, train_labels)"],"passed":True,"numpy":np.__version__,"seconds":round(time.monotonic()-started,3),"input_hashes":loaded["input_hashes"],"input_open_paths":sorted(set(reads)),"features_shape":list(loaded["features"].shape),"projected_shape":list(projected.shape),"train_role_shapes":{k:[list(a.shape) for a in v] for k,v in splits.items()},"source_files_unchanged":len(before),"withheld_labels_present_in_reader_root":False,"real_checkpoint_downloaded":False,"gpu_used":False,"training_updates":0,"qualification_claim":False}
(D/"current-v2-real-input-reader-proof.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)

