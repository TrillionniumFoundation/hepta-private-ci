from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116")
P=T/"audit/branch_inventory";D=P/"aggregate-review/cell-history-custody-v1";R=T/"safe-evidence-merge";G=D/"gate-projection";F=D/"repository-files";V=P/"cell-source-object-viewer.git"
head="89e6d75fae09d3b2f6d395cd77e37d967d95c126";base="eef0975f9235f3ff7de1c3c02e6d6d80146af98b"
env=dict(os.environ,GIT_NO_LAZY_FETCH="1",GIT_OPTIONAL_LOCKS="0",PYTHONDONTWRITEBYTECODE="1",GIT_ALTERNATE_OBJECT_DIRECTORIES=str(T/"ci-callers-format/.git/objects"))
def git(*args):return subprocess.check_output(["git","-C",str(R),*args],env=env)
def blob(oid):return subprocess.check_output(["git","--git-dir",str(V),"cat-file","blob",oid],env=env)
def gh(data):return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
paths=sorted(filter(None,git("diff","--no-renames","--diff-filter=ACMRT","--name-only","-z",base,head).decode().split("\0")))
entries={}
raw=git("ls-tree","-r","-z",head,"--",*paths)
for row in raw.split(b"\0"):
 if not row:continue
 meta,name=row.split(b"\t",1);mode,kind,oid=meta.decode().split()
 assert kind=="blob" and mode=="100644",(name,mode,kind)
 entries[name.decode()]=oid
assert set(entries)==set(paths)
for path,oid in entries.items():
 p=G/path
 if not p.exists() or gh(p.read_bytes())!=oid:
  data=blob(oid);assert gh(data)==oid;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 assert gh(p.read_bytes())==oid
# Configuration is byte-exact and has no new ignore rule.
policy={}
for path,expected in (("scripts/check_blob_size.py","1627511aaf298126141f96517e2a243908174351"),(".github/blob-size-allowlist.txt","dd0524aa0d704a9231d6db0ba38fc4d8a50e7736")):
 current=(R/path).read_bytes();assert gh(current)==expected
 for commit in (base,head):
  got=git("rev-parse",commit+":"+path).decode().strip();assert got==expected,(path,commit,got)
 policy[path]={"git_blob":expected,"sha256":hashlib.sha256(current).hexdigest()}
for path in (".codespellrc",".codespellignore",".prettierrc.toml",".prettierignore"):
 oid=git("rev-parse",base+":"+path).decode().strip();assert git("rev-parse",head+":"+path).decode().strip()==oid
 p=G/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(blob(oid));policy[path]={"git_blob":oid,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
(D/"final-maintenance-policy-identity.json").write_text(json.dumps(policy,indent=2)+"\n")
prefix=json.loads((P/"original_codespell_new_paths_result.json").read_text())["argv_prefix"]
commands=[
 ("whole-checkpoint-original-size",["/usr/bin/python3","scripts/check_blob_size.py","--base","285e971b3af3a93a79169b56a42263069e473057","--head",head,"--allowlist",".github/blob-size-allowlist.txt"],R,env),
 ("final-cell-original-codespell",prefix+["./"+p for p in paths],G,dict(env,PYTHONPATH=str(P/"codespell_vendor"))),
 ("final-cell-prettier",["node",str(P/"prettier-dist-3.5.3/bin/prettier.cjs"),"--config",str(G/".prettierrc.toml"),"--check",".github/workflows/hepta-shared-stem-bakeoff-shadow.yml","qa/repository-consolidation/20261116/cell-history-custody/MANIFEST.json","qa/repository-consolidation/20261116/cell-history-custody/README.md","qa/stem-bakeoff/HISTORY_CUSTODY_20261116.md"],G,env)
]
def run(item):
 name,argv,cwd,localenv=item;start=time.monotonic();r=subprocess.run(argv,cwd=cwd,env=localenv,capture_output=True,timeout=900)
 for suffix,data in (("stdout",r.stdout),("stderr",r.stderr)):(D/(name+"."+suffix)).write_bytes(data)
 receipt={"base":base,"head":head,"argv":argv,"cwd":str(cwd),"returncode":r.returncode,"seconds":round(time.monotonic()-start,3),"materialized_changed_paths":len(paths),"sha256_of_final_path_oid_map":hashlib.sha256(json.dumps(entries,sort_keys=True,separators=(",",":")).encode()).hexdigest(),"policy_identity_receipt":"final-maintenance-policy-identity.json","stdout":r.stdout.decode(),"stderr":r.stderr.decode()}
 (D/(name+".json")).write_text(json.dumps(receipt,indent=2)+"\n")
 print(json.dumps({"name":name,"returncode":r.returncode,"seconds":receipt["seconds"],"scope":len(paths),"stdout":r.stdout.decode()[-5000:],"stderr":r.stderr.decode()[-2000:]}),flush=True)
 return r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:codes=list(executor.map(run,commands))
print("ALL_FINAL_GATES",codes,flush=True)
raise SystemExit(any(codes))

