import sys
sys.dont_write_bytecode=True
from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116");P=T/"audit/branch_inventory";D=P/"fresh-publication-refs-after-hia-1953";D.mkdir()
OLD=P/"fresh-publication-refs-before-checkpoint-1900";ROOT=T/"audit/root-fresh-refs-20261116T1953"
V=D/"commit-viewer.git";E=D/"empty-hooks";E.mkdir()
env=dict(os.environ,GIT_NO_LAZY_FETCH="1",GIT_OPTIONAL_LOCKS="0")
def run(argv,input=None,timeout=120):
 return subprocess.run(argv,input=input,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,check=True).stdout
run(["git","init","--bare","--quiet","--template="+str(E),str(V)])
(V/"objects/info/alternates").write_text(str(T/"safe-evidence-merge/.git/objects")+"\n"+str(OLD/"commit-graph-viewer.git/objects")+"\n")
def git(*args,input=None,timeout=120):return run(["git","--git-dir",str(V),*args],input,timeout)
git("config","core.hooksPath",str(E))
raw=(ROOT/"refs.raw").read_bytes();comparison=json.loads((ROOT/"comparison.json").read_text())
assert hashlib.sha256(raw).hexdigest()==comparison["refsSha256"]=="0ef3a425593592f3f05ca55dc3faaf4ee51d16b0a347ed9bec8c0121d5f27803"
(D/"refs.raw").write_bytes(raw);(D/"root-comparison.json").write_bytes((ROOT/"comparison.json").read_bytes())
def parse_refs(raw):
 result={}
 for line in raw.decode().splitlines():
  sha,name=line.split("\t");assert re.fullmatch("[0-9a-f]{40}",sha) and name.startswith("refs/heads/")
  name=name[len("refs/heads/"):];assert name not in result;result[name]=sha
 return result
refs=parse_refs(raw);prior_raw=(OLD/"refs.tsv").read_bytes();prior_refs=parse_refs(prior_raw);prior=json.loads((OLD/"fresh-ref-protection.json").read_text())
added=sorted(set(refs)-set(prior_refs));removed=sorted(set(prior_refs)-set(refs))
changed=[{"name":n,"before":prior_refs[n],"after":refs[n]} for n in sorted(refs) if n in prior_refs and refs[n]!=prior_refs[n]]
assert not added and not removed
assert len(changed)==2
hia_name="codex/hia-union29-20261116-a90d";old_hia="a7a08eae570640c70dd902f81690eaf9d077d649";new_hia="16d52179819a0ad1994b67a422ebbd09b8f07bc2"
assert refs[hia_name]==new_hia and prior_refs[hia_name]==old_hia
assert refs["main"]=="732e934ba496d90fbe042b8d41d479ef901643e5"
assert refs["integration/hepta-single-main-20261113-ab5b"]=="c0e525fd94e6eea2957bd1a12764627b86dd71ec"
argv=["git","--git-dir",str(V),"-c","protocol.version=2","-c","fetch.negotiationAlgorithm=skipping","fetch","--quiet","--no-tags","--no-write-fetch-head","--no-auto-maintenance","--filter=tree:0","--negotiation-tip="+old_hia,"--stdin","https://github.com/TrillionniumFoundation/hepta-private-ci.git"]
start=time.monotonic();r=subprocess.run(argv,input=(new_hia+"\n").encode(),env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
(D/"fetch.stdout").write_bytes(r.stdout);(D/"fetch.stderr").write_bytes(r.stderr)
fetch={"argv":argv,"requested_commit":new_hia,"negotiation_commit":old_hia,"returncode":r.returncode,"seconds":time.monotonic()-start,"shared_repository_fetches":0,"refspec_destinations":False,"write_fetch_head":False}
(D/"fetch.json").write_text(json.dumps(fetch,indent=2)+"\n");assert r.returncode==0,r.stderr.decode();assert not(V/"shallow").exists()
print(json.dumps({"single_hia_delta_fetch":fetch}),flush=True)
candidate="59a450cc7b33a2f8d833043cc093b7fc92f2b7ab";markers=prior["markers"]
remote_roots=sorted(set(refs.values()));roots=sorted(set(remote_roots+[candidate,*markers]))
raw_graph=git("rev-list","--topo-order","--reverse","--parents","--stdin",input=("\n".join(roots)+"\n").encode())
remote_graph=git("rev-list","--topo-order","--reverse","--parents","--stdin",input=("\n".join(remote_roots)+"\n").encode())
(D/"augmented-graph.parents").write_bytes(raw_graph);(D/"remote-graph.parents").write_bytes(remote_graph)
def parent_map(raw):
 result={}
 for line in raw.decode().splitlines():
  values=line.split();assert values[0] not in result;result[values[0]]=values[1:]
 return result
m=parent_map(raw_graph);rm=parent_map(remote_graph);om=parent_map((OLD/"augmented-graph.parents").read_bytes())
assert not(set(om)-set(m))
assert all(m[k]==v for k,v in om.items())
def canonical(m):return ("".join(" ".join([k,*m[k]])+"\n" for k in sorted(m))).encode()
def identity(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def ancestry(sha):
 seen=set();queue=[sha]
 while queue:
  value=queue.pop()
  if value in seen:continue
  seen.add(value);queue.extend(m[value])
 return seen
ca=ancestry(candidate)
vector=[];original=json.loads((P/"branch_classification.json").read_text());original_refs={x["name"]:x for x in original}
prior_protected={x["name"]:x for x in prior["current_protected_vector"]}
masks={}
for line in raw_graph.decode().splitlines():
 a=line.split();mask=sum(1<<i for i,x in enumerate(markers) if x==a[0])
 for parent in a[1:]:mask|=masks[parent]
 masks[a[0]]=mask
for name,sha in sorted(refs.items()):
 by_prior=name in prior_protected
 by_marker=bool(masks[sha])
 by_new_name=name not in original_refs and "hia" in name.lower()
 if not(by_prior or by_marker or by_new_name):continue
 previous=prior_protected.get(name,{}).get("observed_sha")
 vector.append({"name":name,"observed_sha":sha,"prior_sha":previous,"original_sha":original_refs.get(name,{}).get("sha") if original_refs.get(name,{}).get("protected_hia") else None,"protected_by_prior_name":by_prior,"protected_by_new_hia_name":by_new_name,"protected_marker_ancestors":[x for i,x in enumerate(markers) if masks[sha]&(1<<i)],"descends_prior_protected":previous in ancestry(sha) if previous else None,"head_in_candidate_ancestry":sha in ca})
assert len(vector)==87
assert not(set(markers)&ca) and not any(x["head_in_candidate_ancestry"] for x in vector)
assert not any(x["observed_sha"] in ca for x in prior_protected.values())
eligible=[x for x in original if not x["protected_hia"] and x["name"]!="main"]
retained=[x["name"] for x in eligible if x["sha"] in ca];pending=[x["name"] for x in eligible if x["sha"] not in ca]
assert len(retained)==1796 and len(pending)==5434
new_hia_anc=ancestry(new_hia);old_hia_anc=ancestry(old_hia);hia_delta=sorted(new_hia_anc-old_hia_anc)
assert old_hia in new_hia_anc and len(hia_delta)==2
raw_commits={}
for sha in sorted(set(hia_delta+[candidate,"c0e525fd94e6eea2957bd1a12764627b86dd71ec"])):
 raw_commit=git("cat-file","commit",sha)
 assert hashlib.sha1(b"commit "+str(len(raw_commit)).encode()+b"\0"+raw_commit).hexdigest()==sha
 path=D/"raw-commits"/(sha+".commit");path.parent.mkdir(exist_ok=True);path.write_bytes(raw_commit)
 raw_commits[sha]={"path":str(path),**identity(raw_commit)}
delta={"schema_version":1,"prior_observed_utc":prior["observed_utc"],"observed_utc":comparison["utc"],"prior_parent_map":{"path":str(OLD/"augmented-graph.parents"),**identity((OLD/"augmented-graph.parents").read_bytes()),"canonical":identity(canonical(om))},"prior_published_graph_delta":{"path":str(OLD/"graph-delta.json"),**identity((OLD/"graph-delta.json").read_bytes())},"added_parent_rows":[[k,*m[k]] for k in sorted(set(m)-set(om))],"removed_parent_rows":[],"changed_existing_parent_rows":[],"remote_roots":remote_roots,"augmented_roots":roots,"remote_canonical_parent_map":identity(canonical(rm)),"augmented_canonical_parent_map":identity(canonical(m)),"remote_raw_walk":identity(remote_graph),"augmented_raw_walk":identity(raw_graph),"candidate_only_commits":sorted(set(m)-set(rm)),"restoration":"Verify the immutable prior parent map, retain every original row and append only the listed rows, then sort by commit SHA. Verify the resulting canonical hash. Walk the exact remote roots to reproduce and verify the published closure. Unpublished candidate-only objects are not counted as remote ancestors."}
(D/"graph-delta.json").write_text(json.dumps(delta,indent=2)+"\n")
receipt={"schema":"hepta.branch-protection.fresh-delta.v1","observed_utc":comparison["utc"],"verified_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"raw_refs_source":str(ROOT/"refs.raw"),"raw_refs":identity(raw),"root_comparison_source":str(ROOT/"comparison.json"),"root_comparison":identity((ROOT/"comparison.json").read_bytes()),"head_count":len(refs),"protected_count":len(vector),"main":refs["main"],"integration":refs["integration/hepta-single-main-20261113-ab5b"],"candidate":candidate,"candidate_tree":git("rev-parse",candidate+"^{tree}").decode().strip(),"candidate_parents":m[candidate],"candidate_ancestry_count":len(ca),"original_eligible_count":len(eligible),"original_retained_count":len(retained),"original_pending_count":len(pending),"protected_markers":markers,"candidate_marker_intersection":[],"candidate_current_protected_intersection":[],"candidate_prior_protected_intersection":[],"current_protected_vector":vector,"added_refs":[],"removed_refs":[],"changed_since_1900":changed,"external_changes":[x for x in changed if x["name"]!= "integration/hepta-single-main-20261113-ab5b"],"hia_progress":{"name":hia_name,"prior_sha":old_hia,"current_sha":new_hia,"descends_prior":True,"new_commit_count":len(hia_delta),"new_commits":[{"sha":x,"parents":m[x]} for x in hia_delta],"protected_marker_ancestors":[x for x in markers if x in new_hia_anc]},"remote_graph":{"roots_count":len(remote_roots),"roots_sha256":identity(("\n".join(remote_roots)+"\n").encode())["sha256"],"commits":len(rm),"edges":sum(len(v) for v in rm.values()),"canonical":identity(canonical(rm))},"augmented_graph":{"roots_count":len(roots),"roots_sha256":identity(("\n".join(roots)+"\n").encode())["sha256"],"commits":len(m),"edges":sum(len(v) for v in m.values()),"canonical":identity(canonical(m))},"candidate_only_commits":sorted(set(m)-set(rm)),"prior_snapshot":{"path":str(OLD/"fresh-ref-protection.json"),**identity((OLD/"fresh-ref-protection.json").read_bytes())},"raw_commits":raw_commits,"remote_ref_writes":0,"shared_repository_mutations":0,"fetch":fetch,"rule":"Keep all prior protected names and marker descendants; source inspection and data transfer do not merge, reset or delete protected histories."}
(D/"fresh-ref-protection.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({k:receipt[k] for k in ["observed_utc","head_count","protected_count","main","integration","candidate","candidate_tree","candidate_parents","original_retained_count","original_pending_count","external_changes","hia_progress","remote_graph","augmented_graph","candidate_only_commits"]}),flush=True)
print(json.dumps({"proof":str(D/"fresh-ref-protection.json"),**identity((D/"fresh-ref-protection.json").read_bytes()),"graph_added_rows":len(delta["added_parent_rows"])}),flush=True)
