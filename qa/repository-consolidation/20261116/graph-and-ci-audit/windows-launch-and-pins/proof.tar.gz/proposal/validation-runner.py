from pathlib import Path
import ast,hashlib,json,os,subprocess,time
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116")
D=T/"audit/ci_audit/hosted-60658ec5/creation-and-source-pin-repair-v1"
G=T/"safe-evidence-merge";R=T/"ci-callers-format";head="60658ec54cf7f857197733fecf455ba44fecd3d4"
C=T/"audit/ci_audit/codespell-c0e-fragments-v1/proposal"
env=os.environ.copy();env["GIT_NO_LAZY_FETCH"]="1"
api=D/"source/.github/scripts/windows-appcontainer-probe/win32_api.py"
workflows=[D/"source/.github/workflows/ndu-windows-storage-probe.yml",D/"source/.github/workflows/hepta-windows-federation-revoke.yml"]
controls=[]
for p in ["scripts/pyproject.toml","scripts/uv.lock",".codespellrc",".codespellignore",".prettierrc.toml"]:
 expected=subprocess.check_output(["git","-C",str(G),"show",head+":"+p],env=env)
 actual=(C/p if p!=".prettierrc.toml" else R/p).read_bytes();assert actual==expected,p
 controls.append({"path":p,"sourcePath":str(C/p if p!=".prettierrc.toml" else R/p),"sha256":hashlib.sha256(actual).hexdigest()})
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [api,*workflows]}
receipts=[]
def run(label,argv,cmd_env=None,cwd=C):
 started=time.monotonic()
 proc=subprocess.run(argv,cwd=cwd,env=cmd_env or env,capture_output=True)
 (D/(label+".stdout")).write_bytes(proc.stdout);(D/(label+".stderr")).write_bytes(proc.stderr)
 receipt={"label":label,"argv":argv,"cwd":str(cwd),"exit_code":proc.returncode,"seconds":time.monotonic()-started,"stdout_sha256":hashlib.sha256(proc.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(proc.stderr).hexdigest()}
 (D/(label+"-receipt.json")).write_text(json.dumps(receipt,indent=2)+"\n");receipts.append(receipt)
 print(json.dumps(receipt))
 if proc.returncode:raise SystemExit(proc.returncode)
uenv=env.copy();uenv["PYTHONPATH"]=str(T/"tools/uv-0.11.3")
uv=str(T/"tools/uv-0.11.3/bin/uv")
run("original-ruff-format-check",[uv,"run","--frozen","--project","scripts","ruff","format","--check",str(api)],uenv)
run("scoped-ruff-check",[uv,"run","--frozen","--project","scripts","ruff","check",str(api)],uenv)
run("original-prettier-check",["/usr/bin/node",str(T/"audit/branch_inventory/prettier-dist-3.5.3/bin/prettier.cjs"),"--config",str(R/".prettierrc.toml"),"--check",*[str(p) for p in workflows]])
prefix=json.loads((T/"audit/ci_audit/hosted-7e04259-fixes-v3/scoped-codespell-receipt.json").read_text())["argv"][:8]
cenv=env.copy();cenv["PYTHONPATH"]=str(T/"audit/branch_inventory/codespell_vendor")
run("original-scoped-codespell",[*prefix,*[str(p) for p in [api,*workflows]]],cenv)
# Neither formatter nor check mutates the proposal; tests run after these checks.
assert before=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [api,*workflows]}
run("actual-launch-method-call-capture",["/usr/bin/python3","-B",str(D/"actual-launch-method-call-capture.py")],env,D)
after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [api,*workflows]}
assert before==after
result={"baseCommit":head,"scope":"Original scoped Ruff formatter and Codespell; exact two YAML Prettier; Linux call-capture regression only. Original whole-repository just fmt and native Windows remain pending.","commands":receipts,"controls":controls,"before":before,"after":after,"source_inputs_unchanged":before==after}
(D/"validation-result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"result":str(D/"validation-result.json"),"sha256":hashlib.sha256((D/"validation-result.json").read_bytes()).hexdigest()}))
