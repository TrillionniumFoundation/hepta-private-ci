"""Execute the actual launch method with captured API calls, not native Win32."""
import ctypes
import importlib.util
import json
from pathlib import Path, PureWindowsPath
from types import SimpleNamespace
import sys

D = Path(__file__).parent
API = ".github/scripts/windows-appcontainer-probe/win32_api.py"
LOCAL = r"C:\Users\fixture\AppData\Local"
CWD = PureWindowsPath(r"C:\fixture\workspace")
SYSTEM = r"C:\Windows\System32"

def exercise(source, lpac, local_value, fail_create=False):
    spec = importlib.util.spec_from_file_location("capture_api", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    events = []
    state = {"error": 0}
    class CtypesProxy:
        def __getattr__(self, name):
            return getattr(ctypes, name)
        def get_last_error(self):
            return state["error"]
    module.C = CtypesProxy()
    module.Path = PureWindowsPath
    env = {"UNRELATED_SECRET": "never-pass-this-sentinel", "PATH": "not-inherited"}
    if local_value is not None:
        env["LOCALAPPDATA"] = local_value
    module.os = SimpleNamespace(environ=env)
    api = module.Api.__new__(module.Api)
    expected_count = 2 if lpac else 1
    attributes = []
    def initialize(buffer, count, flags, size):
        assert count == expected_count and flags == 0
        if buffer is None:
            size._obj.value = 128
            state["error"] = 122
            events.append("attribute_size")
            return False
        assert len(buffer) == 128
        events.append("attribute_initialize")
        return True
    def update(buffer, flags, attribute, value, size, previous, returned):
        assert flags == 0 and previous is None and returned is None
        if attribute == 0x20009:
            cap = ctypes.cast(value, ctypes.POINTER(module.SecurityCapabilities)).contents
            assert cap.AppContainerSid == 0x1234
            assert cap.Capabilities is None and cap.CapabilityCount == 0 and cap.Reserved == 0
            assert size == ctypes.sizeof(module.SecurityCapabilities)
        elif attribute == 0x2000F:
            assert lpac and ctypes.cast(value, ctypes.POINTER(module.DWORD)).contents.value == 1
            assert size == ctypes.sizeof(module.DWORD)
        else:
            raise AssertionError("unexpected process attribute")
        attributes.append(attribute)
        return True
    def get_system(buffer, maximum):
        assert maximum == 32768
        buffer.value = SYSTEM
        return len(SYSTEM)
    def create(application, command, process_security, thread_security, inherit,
               flags, environment, cwd, startup, process):
        events.append("CreateProcessW")
        assert application == str(PureWindowsPath(SYSTEM) / "cmd.exe")
        assert command.value == f'"{application}" /d /s /c child-probe.cmd'
        assert process_security is None and thread_security is None and inherit is False
        assert flags == 0x80000 | 0x4 | 0x08000000 | 0x400
        assert cwd == str(CWD)
        info = ctypes.cast(startup, ctypes.POINTER(module.StartupInfoEx)).contents
        assert info.StartupInfo.cb == ctypes.sizeof(module.StartupInfoEx)
        assert info.StartupInfo.lpDesktop is None and info.StartupInfo.dwFlags == 0
        assert info.lpAttributeList is not None
        assert attributes == ([0x20009, 0x2000F] if lpac else [0x20009])
        raw = "".join(environment[:])
        assert raw.endswith("\0\0")
        values = raw.rstrip("\0").split("\0")
        pairs = dict(v.split("=", 1) for v in values)
        assert len(values) == len(pairs)
        assert list(pairs) == sorted(pairs, key=str.casefold)
        assert "LOCALAPPDATA" in pairs, "explicit launch environment omits LOCALAPPDATA"
        assert pairs == {
            "ComSpec": application, "LOCALAPPDATA": LOCAL,
            "SystemRoot": r"C:\Windows", "TEMP": str(CWD), "TMP": str(CWD),
            "windir": r"C:\Windows",
        }
        assert "never-pass-this-sentinel" not in raw and "PATH=" not in raw
        state["captured_keys"] = list(pairs)
        if fail_create:
            state["error"] = 5
            return False
        process._obj.hProcess = 111
        process._obj.hThread = 222
        process._obj.dwProcessId = 333
        process._obj.dwThreadId = 444
        return True
    api.InitializeProcThreadAttributeList = initialize
    api.UpdateProcThreadAttribute = update
    api.GetSystemDirectoryW = get_system
    api.CreateProcessW = create
    api.DeleteProcThreadAttributeList = lambda unused: events.append("attribute_delete")
    result = None
    error = None
    try:
        result = api.create_suspended(0x1234, CWD, lpac)
    except Exception as exc:
        error = {"type": type(exc).__name__, "message": str(exc), "errno": getattr(exc, "errno", None)}
    assert events[-1] == "attribute_delete"
    return {"error": error, "events": events, "keys": state.get("captured_keys"), "returned_process": result is not None}

results = {"scope": "Linux call-capture execution of the complete actual create_suspended method; PureWindowsPath and Win32 boundary functions are substitutes. This is not Windows ABI, process creation, token, ACL or isolation qualification.",
           "baseline": [], "candidate": []}
for lpac in [False, True]:
    row = exercise(D / "preimages" / API, lpac, LOCAL)
    assert row["error"] and row["error"]["type"] == "AssertionError"
    assert row["error"]["message"] == "explicit launch environment omits LOCALAPPDATA"
    results["baseline"].append({"lpac": lpac, "expected_regression_failure": True, **row})
    row = exercise(D / "source" / API, lpac, LOCAL)
    assert row["error"] is None and row["returned_process"]
    results["candidate"].append({"case": "exact_whitelist_and_call_shape", "lpac": lpac, "passed": True, **row})
    for name, value in [("missing", None), ("empty", ""), ("relative", "Local"),
                        ("drive_relative", r"C:Local"), ("embedded_nul", LOCAL + "\0ignored")]:
        row = exercise(D / "source" / API, lpac, value)
        assert row["error"] and row["error"]["type"] == "RuntimeError"
        assert row["error"]["message"] == "LOCALAPPDATA must identify an absolute profile path"
        assert "CreateProcessW" not in row["events"] and not row["returned_process"]
        results["candidate"].append({"case": name, "lpac": lpac, "passed": True, **row})
    row = exercise(D / "source" / API, lpac, LOCAL, fail_create=True)
    assert row["error"] and row["error"]["type"] == "OSError" and row["error"]["errno"] == 5
    assert not row["returned_process"]
    results["candidate"].append({"case": "create_error_propagates_and_attributes_freed", "lpac": lpac, "passed": True, **row})
results["counts"] = {"baseline_expected_failures": len(results["baseline"]), "candidate_passed": len(results["candidate"])}
(D / "actual-launch-method-call-capture-results.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results["counts"]))
