"""Parallel schedule of the unmodified, complete repository caller verifier."""
from pathlib import Path
import concurrent.futures
import hashlib
import importlib.util
import json
import multiprocessing
import os
import sys
import time
import traceback

BASE = Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116")
ROOT = BASE / "authority-review"
AUDIT = BASE / "audit/rust_review"
SPEC = importlib.util.spec_from_file_location(
    "parallel_original_verify_hepta_callers", ROOT / "scripts/verify_hepta_callers.py"
)
PROOF = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = PROOF
SPEC.loader.exec_module(PROOF)
START = time.monotonic()
MANIFEST_BYTES = (ROOT / "CALLERS.toml").read_bytes()
DATA = PROOF._load_manifest(ROOT / "CALLERS.toml")
SOURCE_ROOTS = PROOF._string_tuple(DATA, "source_roots")
IGNORED = PROOF._string_tuple(DATA, "ignored_path_fragments")
FILES = PROOF._source_files(ROOT, SOURCE_ROOTS)
BOUNDARIES = PROOF._boundary_rows(DATA)
INVENTORY = PROOF._verify_privileged_inventory(DATA, BOUNDARIES)
assert len(BOUNDARIES) == 1645
assert len(FILES) == 7504
assert len(DATA["protected_file"]) == 819
assert len({boundary.identifier for boundary in BOUNDARIES}) == len(BOUNDARIES)
assert set(INVENTORY) == {boundary.identifier for boundary in BOUNDARIES}
SOURCE_INDEX = {}
FILE_HASHES = {}
for path in FILES:
    relative = path.relative_to(ROOT).as_posix()
    raw = path.read_bytes()
    FILE_HASHES[relative] = hashlib.sha256(raw).hexdigest()
    SOURCE_INDEX[relative] = PROOF._strip_cfg_test_items(
        PROOF._strip_rust_non_code(raw.decode("utf-8"))
    )
FIELDS_BY_RECEIVER_TYPE = {}
GROUPS = {}
for index, boundary in enumerate(BOUNDARIES):
    key = boundary.receiver_type or ("untyped", index)
    GROUPS.setdefault(key, []).append(index)
GROUP_LIST = sorted(GROUPS.values(), key=lambda group: (-len(group), group[0]))
indices = [index for group in GROUP_LIST for index in group]
assert len(indices) == len(set(indices)) == len(BOUNDARIES)
assert sorted(indices) == list(range(len(BOUNDARIES)))
INPUT = {
    "base_commit": "285e971b3af3a93a79169b56a42263069e473057",
    "manifest_sha256": hashlib.sha256(MANIFEST_BYTES).hexdigest(),
    "verifier_sha256": hashlib.sha256((ROOT / "scripts/verify_hepta_callers.py").read_bytes()).hexdigest(),
    "rust_files": FILE_HASHES,
    "boundary_ids": [row.identifier for row in BOUNDARIES],
    "privileged_inventory": list(INVENTORY),
    "protected_paths": [row["path"] for row in DATA["protected_file"]],
    "workers": 6,
    "groups": len(GROUP_LIST),
}
(AUDIT / "parallel-caller-proof-inputs.json").write_text(json.dumps(INPUT, indent=2) + "\n")
print(json.dumps({"phase":"indexed", "rust_files":len(FILES),
                  "boundaries":len(BOUNDARIES), "groups":len(GROUP_LIST),
                  "workers":6, "elapsed_seconds":time.monotonic()-START}), flush=True)

def verify_group(group):
    outcomes = []
    for index in group:
        boundary = BOUNDARIES[index]
        started = time.monotonic()
        outcome = {"index":index, "id":boundary.identifier}
        try:
            outcome["result"] = PROOF._verify_boundary(
                ROOT, boundary, SOURCE_INDEX, IGNORED,
                fields_by_receiver_type=FIELDS_BY_RECEIVER_TYPE,
            )
        except Exception as error:
            outcome["exception"] = {
                "type":type(error).__name__, "message":str(error),
                "traceback":traceback.format_exc(),
            }
        outcome["elapsed_seconds"] = time.monotonic()-started
        outcomes.append(outcome)
    return outcomes

OUTCOMES = {}
with (AUDIT / "parallel-caller-proof-boundaries.jsonl").open("w") as ledger:
    with concurrent.futures.ProcessPoolExecutor(
        max_workers=6, mp_context=multiprocessing.get_context("fork")
    ) as pool:
        pending = {pool.submit(verify_group, group): group for group in GROUP_LIST}
        milestone = 0
        for future in concurrent.futures.as_completed(pending):
            group = pending[future]
            try:
                outcomes = future.result()
            except BaseException as error:
                outcomes = [{
                    "index":index, "id":BOUNDARIES[index].identifier,
                    "exception":{"type":type(error).__name__,
                                 "message":str(error),
                                 "traceback":traceback.format_exc()},
                    "elapsed_seconds":None,
                } for index in group]
            assert sorted(o["index"] for o in outcomes) == sorted(group)
            for outcome in outcomes:
                index = outcome["index"]
                assert index not in OUTCOMES
                assert outcome["id"] == BOUNDARIES[index].identifier
                OUTCOMES[index] = outcome
                ledger.write(json.dumps(outcome) + "\n")
            ledger.flush()
            if len(OUTCOMES) >= milestone + 100:
                milestone = len(OUTCOMES)
                print(json.dumps({"phase":"boundaries", "checked":len(OUTCOMES),
                                  "total":len(BOUNDARIES),
                                  "exceptions":sum("exception" in o for o in OUTCOMES.values()),
                                  "elapsed_seconds":time.monotonic()-START}), flush=True)
assert set(OUTCOMES) == set(range(len(BOUNDARIES)))
assert len({o["id"] for o in OUTCOMES.values()}) == len(BOUNDARIES)
FAILURES = [OUTCOMES[index] for index in range(len(BOUNDARIES))
            if "exception" in OUTCOMES[index]]
PROTECTED = []
PROTECTED_ERROR = None
try:
    PROTECTED = PROOF._verify_protected_files(ROOT, DATA)
except Exception as error:
    PROTECTED_ERROR = {"type":type(error).__name__, "message":str(error),
                       "traceback":traceback.format_exc()}
AFTER_HASHES = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in PROOF._source_files(ROOT, SOURCE_ROOTS)}
UNCHANGED = (AFTER_HASHES == FILE_HASHES
             and (ROOT / "CALLERS.toml").read_bytes() == MANIFEST_BYTES
             and hashlib.sha256((ROOT / "scripts/verify_hepta_callers.py").read_bytes()).hexdigest()
                 == INPUT["verifier_sha256"])
SUMMARY = {
    "schema":"hepta.complete-parallel-caller-proof-run.v1",
    "status":"PASS" if not FAILURES and PROTECTED_ERROR is None and UNCHANGED else "FAIL",
    "schedule":"six workers; unchanged verifier functions; each receiver group on one worker",
    "boundaries_expected":len(BOUNDARIES), "boundaries_checked":len(OUTCOMES),
    "no_skipped_or_duplicate_boundaries":True,
    "rust_files":len(FILES), "protected_files":len(PROTECTED),
    "privileged_inventory_entries":len(INVENTORY),
    "inputs_unchanged":UNCHANGED, "elapsed_seconds":time.monotonic()-START,
    "failures":FAILURES, "protected_error":PROTECTED_ERROR,
    "manifest_sha256":INPUT["manifest_sha256"],
    "verifier_sha256":INPUT["verifier_sha256"],
}
if SUMMARY["status"] == "PASS":
    receipt = {
        "schema":"hepta.caller-proof-receipt.v2",
        "status":"PASS_HEPTA_CALLER_CLOSED_SET",
        "boundaries":[OUTCOMES[index]["result"] for index in range(len(BOUNDARIES))],
        "privilegedInventory":list(INVENTORY),
        "protectedFiles":PROTECTED,
        "rustFilesScanned":len(FILES),
        "authorityGranted":False,
    }
    destination = AUDIT / "parallel-full-caller-proof.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    SUMMARY["proof_receipt"] = str(destination)
    SUMMARY["proof_receipt_sha256"] = hashlib.sha256(destination.read_bytes()).hexdigest()
(AUDIT / "parallel-full-caller-proof.receipt.json").write_text(json.dumps(SUMMARY, indent=2) + "\n")
print(json.dumps(SUMMARY, indent=2), flush=True)
raise SystemExit(0 if SUMMARY["status"] == "PASS" else 1)
