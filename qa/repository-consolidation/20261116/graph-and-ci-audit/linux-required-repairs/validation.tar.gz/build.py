from pathlib import Path
import hashlib,json,io,gzip,tarfile,subprocess,os,difflib,copy,time,ast
T=Path("/home/qian-qi/hepta-rust-consolidation-59d82a47a690-20261116")
D=T/"audit/ci_audit/c0e-linux-required-review-v1"
P=T/"audit/ci_audit/linux-required-publication-v1"
P.mkdir(exist_ok=True)
files={};excluded=[]
def sha(data):return hashlib.sha256(data).hexdigest()
def file_sha(p):
 h=hashlib.sha256()
 with p.open("rb") as stream:
  for data in iter(lambda:stream.read(1024*1024),b""):h.update(data)
 return h.hexdigest()
for group in ["bazel-native-app-server-v1","tui-theme-revision-v1","guardian-routing-v1"]:
 for p in sorted((D/group).rglob("*")):
  if not p.is_file():continue
  name=p.relative_to(D).as_posix()
  if p.name in ["fixture-tests","link-map.txt"]:
   excluded.append({"path":str(p),"bytes":p.stat().st_size,"sha256":file_sha(p),"reason":"Generated binary or verbose linker map retained in the owned work directory. Original compiler/test output and complete input/link inventories are included."})
  else:files[name]=p.read_bytes()
# Preserve all source preimages, including the workflow whose original bytes live in the source snapshot.
G=T/"safe-evidence-merge";env=dict(os.environ,GIT_NO_LAZY_FETCH="1")
base="30b1a37edec209465863948144c017348e09b5ee"
raw=subprocess.check_output(["git","-C",str(G),"cat-file","blob",base],env=env)
assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==base
files["bazel-native-app-server-v1/preimages/.github/workflows/bazel.yml"]=raw
for rel in [".prettierrc.toml",".codespellrc",".codespellignore","codex-rs/rustfmt.toml"]:
 p=T/"ci-callers-format"/rel;files["original-controls/"+rel]=p.read_bytes()
# Exact original command/config selection used for this publication's spelling check.
p=T/"audit/ci_audit/hosted-7e04259-fixes-v3/scoped-codespell-receipt.json"
files["original-controls/scoped-codespell-receipt.json"]=p.read_bytes()
files["excluded-generated-artifacts.json"]=(json.dumps(excluded,indent=2)+"\n").encode()
members=[]
tar_bytes=io.BytesIO()
with tarfile.open(fileobj=tar_bytes,mode="w",format=tarfile.PAX_FORMAT) as archive:
 for name,data in sorted(files.items()):
  member=tarfile.TarInfo(name);member.size=len(data);member.mtime=0;member.mode=0o644;member.uid=0;member.gid=0;member.uname="";member.gname=""
  archive.addfile(member,io.BytesIO(data));members.append({"path":name,"bytes":len(data),"sha256":sha(data)})
groups=[];restored_inputs={"audit.tar":tar_bytes.getvalue()}
for name in ["job-133544269765.log","job-133544269753.log"]:
 restored_inputs[name]=(T/"audit/ci_audit/hosted-c0e525f-v2"/name).read_bytes()
for restored_name,raw in restored_inputs.items():
 group_id="audit" if restored_name=="audit.tar" else restored_name.removesuffix(".log")
 chunks=[]
 def split(value):
  encoded=gzip.compress(value,compresslevel=9,mtime=0)
  if len(encoded)>480000 or len(value)>8*1024*1024:
   half=len(value)//2;assert half>0;split(value[:half]);split(value[half:]);return
  chunks.append((value,encoded))
 split(raw)
 parts=[]
 for index,(value,encoded) in enumerate(chunks):
  name=f"{group_id}.part{index:03d}.gz";(P/name).write_bytes(encoded)
  assert gzip.decompress(encoded)==value
  parts.append({"index":index,"path":name,"bytes":len(encoded),"sha256":sha(encoded),"raw_bytes":len(value),"raw_sha256":sha(value)})
 assert b"".join(gzip.decompress((P[p["path"]).read_bytes()) for p in parts)==raw
 groups.append({"id":group_id,"restored_name":restored_name,"raw_bytes":len(raw),"sha256":sha(raw),"parts":parts})
manifest={
 "schema_version":1,"source_tree":"287374b63ee68a43d4aab7597eea5c90ea67195c","original_hosted_head":"c0e525fd94e6eea2957bd1a12764627b86dd71ec",
 "groups":groups,"members":members,
 "source_proposals":{"bazel":1,"tui":2,"guardian":5},
 "scope":{"bazel":"Original command-vector proof and static workflow checks; no successful new Bazel run claimed.","tui":"Two explicit Rust paths formatted with the original config. Full just fmt/fix and native TUI tests pending.","guardian":"Actual complete original support modules: baseline 15/15, corrected candidate 19/19. Complete Core consumer E2E and musl pending.","dependency_inventory":"Third support attempt pins 494 library/proc-macro artifacts, including all 311 rlibs in the prior actual link map; only build-script fingerprints were not executed.","original_failures":"Original hosted GNU and musl logs, first candidate compile failure, and incomplete second-attempt dependency inventory are preserved."},
 "excluded_generated_artifacts":excluded,
 "recovery":"Each physical carrier is an independent gzip member. Decode parts in index order, concatenate raw bytes, verify group SHA256 and every archive member. No carrier is a bare fragment of a gzip stream."
}
(P/"proof-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
(P/"restore.py").write_text(RESTORE_SOURCE)
readme="""# GNU and musl CI repair evidence

This package preserves three reviewed proposals against source tree 287374b63ee68a43d4aab7597eea5c90ea67195c and the original failed jobs at c0e525fd94e6eea2957bd1a12764627b86dd71ec. It does not claim that the new complete CI matrix has passed.

## Changes and validation

| Proposal | Evidence | Still pending |
| --- | --- | --- |
| Bazel workflow, one file | Four actual Bash target-selection cases; original Prettier and Codespell checks. The app-server targets retain their existing assertions and move to the native Linux step. | The new hosted Bazel jobs. |
| TUI rendering, two files | Invalidate the completed prefix when the syntax theme revision changes. The new regression keeps the original tests and snapshots. All 501 TUI Rust source files match the pinned tree; every construction uses the existing constructor. | Complete native TUI tests and original package commands. Two explicit rustfmt checks are not the full formatter gate. |
| Guardian test fixtures, five files | The actual original streaming server and ResponseMock passed 15 tests. The candidate passed all 19 tests, including four real TCP regressions. All six original event bodies, old assertions, and budgets remain. | The complete Core consumer test and musl qualification. The 19 support tests are not Core E2E. |

Guardian validation retains its first candidate compile failure. The second successful test run had two renamed transitive libraries missing from its initial input inventory. The third run resolved that gap and passed with 494 library and macro artifacts pinned before and after execution. All 311 cached libraries in the prior actual link map are covered. Compiler and test output, exact commands, source copies, complete input lists, and both old and corrected receipts are included.

The original GNU and musl job logs remain complete, including failures unrelated to these proposals. No old failure is replaced by a success claim. Full test binaries and the large verbose linker maps remain in the owned work directory with hashes listed in the manifest; the complete actual input and linked-library inventories are included in this package.

## Recover the original bytes

Every physical part is a complete, independent gzip member. Decode each group's parts in index order and concatenate the decoded bytes. The manifest binds each compressed part, each decoded part, each complete group, and every member of the audit archive.

FENCEsh
python3 restore.py recovered
mkdir recovered/audit
tar -xf recovered/audit.tar -C recovered/audit
FENCE

The restore script checks sizes, order, hashes, gzip termination, safe archive members, and the exact archive member set before creating the new destination. It refuses an existing destination and statically rejects source symlinks. It does not claim directory-descriptor protection against concurrent hostile filesystem replacement.

The restored audit contains the full patches, source preimages and proposed bytes, failed and successful local logs, exact tool invocations, the original formatter and spelling controls, source retention proofs, and dependency manifests. The hosted logs are restored separately. No branch, pull request, or CI run is modified by this package.
"""
(P/"README.md").write_text(readme.replace("FENCE",chr(96)*3))
ast.parse(RESTORE_SOURCE)
print(json.dumps({"publication":str(P),"archive_members":len(members),"groups":[{"name":g["restored_name"],"raw_bytes":g["raw_bytes"],"parts":len(g["parts"])} for g in groups],"carriers":[{"path":p["path"],"bytes":p["bytes"]} for g in groups for p in g["parts"]],"excluded_generated_count":len(excluded)},indent=2))
