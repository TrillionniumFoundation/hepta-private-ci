## Current Rust consolidation checkpoint — 2026-11-16

Current candidate: `ca1ae598efb77b552df3897b8debc0441bc7bd90`, exact tree `719b00c26df134153495f77c5001f57541f6f4ba`. This supersedes the earlier source head below; required hosted CI and the native owner suite must be read on this new candidate.

This update publishes the reviewed Rust integration, retains original branch-tip parents, repairs composed Agentd Dataset/dispatch/Artifact-writer/resident-learning/fencing APIs, and integrates the Cell cost-accounting and Git-attribution regression changes. Native formatter output was applied exactly. Original failures and immutable artifacts remain retained.

Before publication, all **50 protected HIA/dependent branch refs** matched the independent protection snapshot. None was moved, merged, or deleted. The 7,280-ref snapshot contains 7,229 nonprotected non-main names; the reviewed local source includes **1,687** of those original heads by ancestry. **5,542** remain outside it and need further source review; ancestry is not a claim of whole-repository qualification.

Validation so far: exact native active-source closure, clean `just fmt`, original Cargo manifest semantics **11/11**, focused Cell Python behavior **64/64** (zero skipped), branch-retirement regressions **17/17**, Codespell custody **9/9** plus 12 actual hashes, 245 workflow YAML parses, workflow Prettier, readiness checks and **11** readiness semantic tests, and Bazel lint-policy regressions **16/16**. The native Rust build/owner tests are active; full required hosted checks are pending.

Windows admission remains fail-closed for unsafe legacy/elevated modes. The latest retained ACL/MIC experiment is **16/17 with a real counterexample**, and is not promoted to production qualification. No threshold, assertion, or protection was bypassed to publish this source.

`main` remains `732e934ba496d90fbe042b8d41d479ef901643e5`. No remote branch was deleted; fresh analysis found zero nonprotected heads currently contained in `main`.

### Earlier checkpoint (historical source and evidence)

## Current integration checkpoint — partial

The reviewed integration branch is published at `8576cdb382d6d49cfccb45d0b07e651fc7aa474e`. This checkpoint preserves ordinary parent histories and the original source/evidence bytes. The requested full audit, merge to main and retirement of the other Rust branches are still in progress.

### Scope and exclusions

- The frozen inventory contains 7,256 branches: main, 34 newly added HIA branches, and 7,221 other candidates.
- This checkpoint contains the histories of **850 / 7,221** candidate branch names, plus main. The count measures ancestry, not semantic or test approval.
- All 34 new HIA tips are excluded, including four whose names do not contain “HIA”. No excluded HIA ref was modified or merged, and no branch was deleted in this pass.
- Main remains `732e934ba496d90fbe042b8d41d479ef901643e5`. A fresh live inventory and exact-tip ancestry checks are required before branch retirement.

See the [complete frozen manifest and exclusion policy](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/8576cdb382d6d49cfccb45d0b07e651fc7aa474e/qa/repository-consolidation/20261115/README.md), [HIA exclusions](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/8576cdb382d6d49cfccb45d0b07e651fc7aa474e/qa/repository-consolidation/20261115/hia-exclusions.json), and [current ancestry receipt](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/8576cdb382d6d49cfccb45d0b07e651fc7aa474e/qa/repository-consolidation/20261115/progress-before-publication.json).

### Reviewed changes in this publication

This publication adds 48 commits after the previous `9b8de495` checkpoint, retaining every ordered parent relationship.

- Merge the continuous-time credit implementation alongside the existing online-prefix API, and preserve the reviewed NDU/PRED/PERC research histories.
- Validate cached replay result hashes, child exit status and unchanged source closure before accepting a replay receipt; retain original archives and all historical evidence.
- Fix per-reference image-dimension validation in the independent scorer and enforce the actual hard deadline during worker IPC. Related regression checks are recorded with their source scope.
- Correct Windows tests that explicitly expect legacy/disabled refusal to select the corresponding route. Preserve all refusal assertions and the entire elevated delete-permission matrix.
- Add a narrow elevated-token candidate excluding ambient Logon/Everyone alternatives while retaining the dedicated user, capabilities, network marker and original permissions matrix. **Its actual Windows boundary result is pending; this is not a claim that deletion isolation is fixed.**
- Prepare and verify the real CLI helper where the failing shared-framework test requires it; retain strict helper/source verification.
- Preserve oversized evidence losslessly as ordered parts within the original blob limit. Historical source/workflow limitations remain explicit.

Detailed reviews and source-specific checks: [checkpoint](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/8576cdb382d6d49cfccb45d0b07e651fc7aa474e/qa/repository-consolidation/20261115/checkpoint-02.md), [follow-up](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/8576cdb382d6d49cfccb45d0b07e651fc7aa474e/qa/repository-consolidation/20261115/checkpoint-02-followup.md), and [small-history audit](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/8576cdb382d6d49cfccb45d0b07e651fc7aa474e/qa/repository-consolidation/20261115/legacy-small).

### Observed validation and limits

- The full initial ordinary merge-tree matrix covers all 2,276 maximal unmerged non-HIA tips: 261 clean textual results and 2,015 real conflicts; no missing-object case is counted as a clean merge.
- A dependency-equipped host executed the reviewed legacy Python archive: **655 tests, 651 passed, 4 skipped** because native binaries were not supplied. [Exact source/log hashes, versions and skipped tests](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/8576cdb382d6d49cfccb45d0b07e651fc7aa474e/qa/repository-consolidation/20261115/legacy-python-native-environment.json).
- The repository’s original formatter passed on the published Rust source, including the elevated-token candidate, with an empty diff.
- Original blob-size limits, source-boundary checks and required CI checks have not been relaxed. The earlier three-archive repair passed the unmodified blob-policy CLI.
- The current full Rust/native qualification is not complete. The preceding helper build failed during crate download before the planned neuron test run; a fresh source-pinned attempt is running. HCSN full-workspace dependency resolution remains blocked by registry timeouts, and the original lockfile is unchanged.
- Learning and HCSN production merges are being integrated in the next checkpoint; their independent diagnostic results are not qualification of this published head.

### Remaining work

Complete the remaining source/history review and conflicts, integrate the reviewed Learning/HCSN work, resolve the real Windows deletion boundary and communication failures, validate the complete Cargo/Bazel lock state, investigate the strict namespace/real-encoder failures and outstanding CodeQL details, and pass **CI required** and **Architecture required** on the eventual combined head before merging to main and verified cleanup.

The previous long PR description is preserved verbatim in [pr-body-before-update.md](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/8576cdb382d6d49cfccb45d0b07e651fc7aa474e/qa/repository-consolidation/20261115/pr-body-before-update.md). Its historical head-specific claims do not apply to this checkpoint.
