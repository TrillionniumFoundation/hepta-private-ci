from collections import deque
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile

audit = Path('/workspace/scratch/a28fa6a6513a/audit')
previous = json.loads((audit / 'hia-boundary-before-next-batch.json').read_text())
delta = json.loads((audit / 'refs-before-batch-write.json').read_text())
snapshot = audit / 'refs-before-batch-write.tsv'
assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == delta['sha256']
refs = {ref[11:]: sha for sha, ref in (line.split('\t') for line in snapshot.read_text().splitlines())}
assert len(refs) == delta['count'] == 7593
old_graph = json.loads((audit / 'frontier/parents_for_analysis.json').read_text())
sources = {sha: 'frontier/parents_for_analysis.json' for sha in old_graph}
def add(sha, parents, source):
    if sha in old_graph:
        assert old_graph[sha] == parents, sha
    else:
        old_graph[sha] = parents
        sources[sha] = source
for item in json.loads((audit / 'new_graph_edges_all.json').read_text()):
    add(item['sha'], item['parents'], 'new_graph_edges_all.json')
previous_graph = json.loads((audit / 'refs-before-next-batch-hia-proof.json').read_text())
for sha, parents in previous_graph['actual_parent_edges'].items():
    add(sha, parents, 'refs-before-next-batch-hia-proof.json')
known_before = set(old_graph)
new = {}
for filename in sorted(audit.glob('refs-before-batch-write-commit-objects-*.json')):
    for item in json.loads(filename.read_text()):
        parents = [p['sha'] for p in item['parents']]
        add(item['sha'], parents, filename.name)
        new[item['sha']] = parents
missing = sorted({parent for parents in new.values() for parent in parents} - known_before - set(new))
assert not missing and len(new) == 9
roots = [x['sha'] for x in previous['graph_roots']]
anchor = previous['retained_graph_anchor']['sha']
boundaries = set(roots + [anchor])
comparisons = json.loads((audit / 'refs-before-batch-write-root-comparisons.json').read_text())
assert len(comparisons) == 18
by_tip = {}
for item in comparisons:
    c = item['comparison']; ancestor = c['merge_base_commit']['sha'] == item['root']
    assert ancestor == (c['status'] in ['ahead', 'identical'])
    by_tip.setdefault(item['tip'], {})[item['root']] = {'ancestor': ancestor, 'status': c['status'], 'ahead_by': c['ahead_by'], 'behind_by': c['behind_by'], 'merge_base': c['merge_base_commit']['sha'], 'url': item['url']}
assert all(set(v) == boundaries for v in by_tip.values())

def path_to_boundary(start):
    queue = deque([(start, [start])]); seen = set()
    while queue:
        sha, path = queue.popleft()
        if sha in boundaries: return path
        if sha in seen: continue
        seen.add(sha)
        for parent in old_graph.get(sha, []): queue.append((parent, path + [parent]))
    return None

protected = {item['name']: dict(item) for item in previous['protected_branches']}
changes = []
for ref, sha in delta['new'].items():
    name = ref[11:]; proof = by_tip[sha]
    is_hia = any(x['ancestor'] for x in proof.values())
    assert is_hia
    path = path_to_boundary(sha); assert path
    record = {'name': name, 'sha': sha, 'reasons': ['real_parent_path_to_HIA_boundary_and_independent_root_comparisons'], 'ancestry_path': path}
    protected[name] = record
    changes.append({'name': name, 'type': 'new_protected', 'sha': sha, 'ancestry_path': path, 'root_and_anchor_comparisons': proof})
for ref, move in delta['moved'].items():
    name = ref[11:]; sha = move['after']; proof = by_tip[sha]
    is_hia = any(x['ancestor'] for x in proof.values())
    if name in protected:
        assert protected[name]['sha'] == move['before'] and is_hia
        path = path_to_boundary(sha); assert path
        protected[name] = {**protected[name], 'sha': sha, 'previous_sha': move['before'], 'ancestry_path': path, 'observed_external_fast_forward': True}
        assert new[sha] == [move['before']]
        changes.append({'name': name, 'type': 'moved_protected', **move, 'ancestry_path': path, 'root_and_anchor_comparisons': proof})
    else:
        assert not is_hia
        chain = [sha]
        while chain[-1] != move['before']:
            parents = new[chain[-1]]; assert len(parents) == 1
            chain.append(parents[0]); assert len(chain) < 20
        changes.append({'name': name, 'type': 'moved_ordinary_pending_source_review', **move, 'sole_parent_path_to_previous_verified_tip': chain, 'root_and_anchor_comparisons': proof})
assert len(protected) == 368
for name, item in protected.items(): assert refs[name] == item['sha']
ordinary = {name: sha for name, sha in refs.items() if name not in protected and name != 'main'}
assert len(ordinary) == 7224
protected_bytes = ''.join(f"{protected[name]['sha']}\t{name}\n" for name in sorted(protected)).encode()
ordinary_bytes = ''.join(f'{ordinary[name]}\t{name}\n' for name in sorted(ordinary)).encode()
(audit / 'protected-hia-refs-before-batch-write.tsv').write_bytes(protected_bytes)
(audit / 'ordinary-refs-before-batch-write.tsv').write_bytes(ordinary_bytes)

tip = '7fd4b93c6fd917ad5e07115a6b2a929ea62b8964'
qualified = '1b16225d7d09c15c0d326d9abc0b088bf4cb67e1'
candidate_heads = ['770179d123b879355b53db1d75f8f9f301280d3e', '307dced98e8b40c1e8321a357e1af1cde3400fef', '60eb1a36e4e59291698a9652e9d5276d957f6678', 'd5af612c3c04f9bd7f4555411edb94341fe4553a', '0e378dd351e0fca99d32f67613639b37c85605da', tip, qualified]
env = os.environ.copy(); env['GIT_NO_LAZY_FETCH'] = '1'
git = ['git', '--git-dir', '/tmp/hepta-a28-7fd-merge.git']
def cmd(*args): return subprocess.check_output(git + list(args), env=env).decode().strip()
union = set(cmd('rev-list', *candidate_heads).splitlines())
protected_tips = {item['sha'] for item in protected.values()}
assert not union.intersection(protected_tips | boundaries)
source_ancestry = set(cmd('rev-list', qualified).splitlines())
assert not source_ancestry.intersection(protected_tips | boundaries)
source_added = set(cmd('rev-list', tip, '^770179d123b879355b53db1d75f8f9f301280d3e').splitlines())
assert source_added == {tip}
covered_by_union = {name: sha for name, sha in ordinary.items() if sha in union}
covered_by_qualified = {name: sha for name, sha in ordinary.items() if sha in source_ancestry}
candidate_checks = {
    'snapshot_sha256': delta['sha256'], 'protected_count': 368, 'candidate_heads': candidate_heads,
    'union_ancestor_commit_count': len(union), 'union_protected_tip_intersection': [], 'union_hia_root_or_anchor_intersection': [],
    'ordinary_names_contained_by_union': len(covered_by_union),
    'union_scope': 'Ancestry union of proposed branch heads, not a claim that the combined candidate has been constructed or qualified.',
    'qualified_7fd_merge': {'sha': qualified, 'source_branch_new_history': sorted(source_added), 'ordinary_names_contained': len(covered_by_qualified), 'protected_tip_intersection': [], 'hia_root_or_anchor_intersection': []},
}
(audit / 'refs-before-batch-write-candidate-hia-checks.json').write_text(json.dumps(candidate_checks, indent=2) + '\n')
path_edges = {}
for item in changes:
    path = item.get('ancestry_path', item.get('sole_parent_path_to_previous_verified_tip', []))
    for sha in path[:-1]: path_edges[sha] = old_graph[sha]
closure = {
    'new_commit_parent_records': new, 'new_commit_count': len(new),
    'known_parent_boundaries': sorted({p for parents in new.values() for p in parents if p not in new}),
    'known_parent_evidence_sources': {p: sources[p] for p in sorted({p for parents in new.values() for p in parents if p not in new})},
    'missing_new_commit_parents': [],
    'real_parent_edges_for_changed_tip_paths': path_edges,
    'no_artificial_anchor_parent_edges': True,
    'previous_complete_boundary': 'refs-before-next-batch-hia-proof.json',
}
(audit / 'refs-before-batch-write-incremental-hia-proof.json').write_text(json.dumps(closure, indent=2) + '\n')
summary = {
    'repository': previous['repository'], 'snapshot': snapshot.name, 'captured_at_utc': delta['captured_at_utc'], 'snapshot_sha256': delta['sha256'],
    'branch_count': 7593, 'protected_count': 368, 'ordinary_count': 7224, 'main': {'name': 'main', 'sha': refs['main']},
    'previous_boundary': 'hia-boundary-before-next-batch.json', 'previous_protected_count': 366,
    'new_protected_count': 2, 'new_ordinary_count': 0, 'moved_protected_count': 3, 'moved_ordinary_count': 1, 'deleted_count': 0,
    'protected_branches': [protected[name] for name in sorted(protected)],
    'changes': changes, 'graph_roots': previous['graph_roots'], 'retained_graph_anchor': previous['retained_graph_anchor'],
    'incremental_parent_proof': 'refs-before-batch-write-incremental-hia-proof.json',
    'candidate_checks': 'refs-before-batch-write-candidate-hia-checks.json',
    'tsv_sha256': {'protected': hashlib.sha256(protected_bytes).hexdigest(), 'ordinary': hashlib.sha256(ordinary_bytes).hexdigest()},
    'our_hia_ref_writes': 0, 'this_audit_remote_writes': 0,
}
(audit / 'hia-boundary-before-batch-write.json').write_text(json.dumps(summary, indent=2) + '\n')
compact = {k: v for k, v in summary.items() if k != 'protected_branches'}
(audit / 'hia-boundary-before-batch-write-compact.json').write_text(json.dumps(compact, indent=2) + '\n')

# Keep this incremental publication archive below the requested512000byte blob bound.
names = ['refs-before-batch-write.json', 'protected-hia-refs-before-batch-write.tsv', 'hia-boundary-before-batch-write-compact.json', 'refs-before-batch-write-incremental-hia-proof.json', 'refs-before-batch-write-candidate-hia-checks.json', 'refs-before-batch-write-root-comparisons.json', 'finalize-batch-write-boundary.py']
names += [p.name for p in sorted(audit.glob('refs-before-batch-write-commit-objects-*.json'))]
members = {name: (audit / name).read_bytes() for name in names}
members['refs-before-batch-write.tsv.gz'] = gzip.compress(snapshot.read_bytes(), mtime=0)
index = {'snapshot_sha256': delta['sha256'], 'members': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(members.items())], 'ordinary_tsv_reconstruction': 'Decompress exact snapshot, normalize refs/heads/, exclude main and the complete protected TSV. The resulting7224lines equal ordinary-refs-before-batch-write.tsv with the hash in compact summary.'}
members['index.json'] = (json.dumps(index, indent=2) + '\n').encode()
archive = audit / 'refs-before-batch-write-hia-evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, data in sorted(members.items()):
                assert len(data) < 512000, (name, len(data))
                info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0; info.uid = info.gid = 0; info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
assert archive.stat().st_size < 512000
artifact = {'file': str(archive), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(members)}
(audit / 'refs-before-batch-write-hia-evidence-archive.json').write_text(json.dumps(artifact, indent=2) + '\n')
print(json.dumps({'protected': len(protected), 'ordinary': len(ordinary), 'tsv_sha256': summary['tsv_sha256'], 'candidate_checks': candidate_checks, 'artifact': artifact}, indent=2))
