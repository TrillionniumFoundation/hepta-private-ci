from pathlib import Path
import os,sys,subprocess,json,hashlib,time,re,shutil
ROOT=Path('/home/qian-qi/hepta-a28-passive-audit');SNAP=ROOT/'snapshot';REPO=ROOT/'objects.git';OUT=ROOT/'quality-checks';OUT.mkdir(exist_ok=True)
HEAD='770179d123b879355b53db1d75f8f9f301280d3e'
files=json.loads((ROOT/'file-manifest.json').read_text());env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env.pop('GIT_NO_LAZY_FETCH',None)
report={'base':HEAD,'started':time.time(),'python':sys.version,'checks':[]}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 config=[]
 for path in ['.codespellrc','.codespellignore','.github/workflows/codespell.yml','.github/codespell-custody.json']:
  r=subprocess.run(['git','-C',str(REPO),'show',HEAD+':'+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=60);assert r.returncode==0,r.stderr
  dest=SNAP/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(r.stdout)
  config.append({'path':path,'sha256':hashlib.sha256(r.stdout).hexdigest()})
 workflow=(SNAP/'.github/workflows/codespell.yml').read_text();skipline=next(x.strip()[6:]for x in workflow.splitlines()if x.strip().startswith('skip: '))
 custody=json.loads((SNAP/'.github/codespell-custody.json').read_text());skipline=skipline.replace('$'+'{{ steps.custody.outputs.skip }}',','.join('./'+p for p in sorted(custody['files'])))
 package=OUT/'codespell-package'
 cmd=[sys.executable,'-m','pip','install','--target',str(package),'--cache-dir',str(OUT/'pip-cache'),'codespell==2.4.3']
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=180)
 (OUT/'install.stdout').write_bytes(r.stdout);(OUT/'install.stderr').write_bytes(r.stderr)
 report['install_returncode']=r.returncode;save()
 if r.returncode:raise RuntimeError('codespell install failed')
 env['PYTHONPATH']=str(package)
 version=subprocess.run([sys.executable,'-m','codespell_lib','--version'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=30)
 report.update(config=config,version=version.stdout.decode().strip(),skip=skipline);save()
 assert report['version']=='2.4.3'
 for label in ['d5af612','21df047']:
  rows=[x for x in files if x['branch']==label and x['net_addition']]
  before={x['path']:hashlib.sha256((SNAP/x['path']).read_bytes()).hexdigest()for x in rows}
  assert all(before[x['path']]==x['sha256']for x in rows)
  cmd=[sys.executable,'-m','codespell_lib','--count','--ignore-words','.codespellignore','--skip',skipline,*[x['path']for x in rows]]
  t=time.monotonic();r=subprocess.run(cmd,cwd=SNAP,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=180)
  (OUT/(label+'.stdout')).write_bytes(r.stdout);(OUT/(label+'.stderr')).write_bytes(r.stderr)
  after={x['path']:hashlib.sha256((SNAP/x['path']).read_bytes()).hexdigest()for x in rows}
  assert after==before
  result={'branch':label,'exit_code':r.returncode,'seconds':time.monotonic()-t,'files':len(rows),'utf8_files':sum(x['utf8']for x in rows),'command_prefix':cmd[:8],'file_args':[x['path']for x in rows],'input_hashes_unchanged':True,'stdout_bytes':len(r.stdout),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_bytes':len(r.stderr),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
  report['checks'].append(result);save()
 report.update(status='complete',finished=time.time());save();print(json.dumps({**report,'checks':[{k:v for k,v in x.items()if k!='file_args'}for x in report['checks']]}))
except BaseException as e:
 report.update(status='failed',error=repr(e),finished=time.time());save();raise

