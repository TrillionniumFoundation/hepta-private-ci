# PTY closed-receiver drain optimization

The final patch adds five lines to `codex-rs/utils/pty/src/unix_io.rs`. A closed output receiver causes the reader to continue draining without allocating discarded messages or polling a send that cannot succeed. EOF/EIO, interrupted-read retry, the normal bounded sender path, child lifetime, and all existing tests are unchanged.

This transplants only the production part of ordinary commit 8075eb3. Its two diagnostic-only lines require an older diagnostics subsystem and are not imported. No parent from that branch is attached. Its 268 outstanding commits and extensive merge conflicts still require separate reconciliation. Both a911 and b748 lack the optimization.

## Original project verification

On macOS 26.6.2 ARM64 with Rust 1.96.0, the original `just test --offline --locked -p codex-utils-pty --no-tests fail --retries 0` command passed all 30 original cases before and after the patch. Both runs had zero skips and zero retries; the complete case-name sets match. The dropped-receiver case retains its 4 MiB output, 2-second wait, 10-second child alarm, and zero exit-code assertion.

The original `just fmt` completed after testing and did not change the tested source bytes. No tests ran afterward. Final Git readback confirms only five added lines in one tracked file. All 13,832 selected source files were verified against authentic a911 Git blobs, including one symlink checked as link bytes.

The original Intel CI failure remains unqualified because the ARM64 baseline already passed. No measured performance claim is inferred.

`pty-closed-receiver-drain.patch` is final. `qualification.json` binds outcomes, source hashes, tool versions, and platform limits. `native-originals/` contains exact remote file bytes. `native-probes/` retains preparation failures, source provenance, and durable job receipts. `native-pty-originals.tar.gz` and `evidence-manifest.json` preserve all evidence.
