# Core Guardian fixture 修复资格报告

## 可合入结果

基于 `a91102d3639a5a1f02394bfc0331611e9ab101a1`，最终补丁仅修改两个 Core integration-test 文件。Network race 的诊断控制重现原断言失败，修复后两种时序全部通过；multimodal 的16种原参数情况全部通过，且同一测试binary中的注册数从32修正为16，原16个唯一测试名字集合完全相同。

- 最终补丁：`evidence/finalization-v2/guardian-core-fixtures.final.patch`，SHA256 `dedbc664b85b1027e566335a74710009d14db0c5ce778c04166330805f03c743`，8624 bytes。
- 独立补丁：同目录 `guardian-network-routing.final.patch` 与 `guardian-multimodal-registration.final.patch`。
- `just fix -p codex-core --offline --locked`：exit0。
- `just fmt`：exit0。`git diff --check`：exit0。
- 格式化后没有再次运行测试。`evidence/tested-to-formatted.json` 与两个 `.diff` 记录测试源码到最终源码的全部差别。
- 生产源码、依赖和锁文件均0修改；原fd5 checkout未修改；本子任务GitHub refs写入0，HIA branches未修改。

## 1. Network：请求次序假设产生竞态

旧fixture按HTTP到达顺序发出三个响应：父会话启动exec、预期给Guardian的deny、父会话done。exec初次yield为1秒；若Python启动或网络请求稍晚，父会话会先请求后续响应，消耗了原本给Guardian的deny并结束。原断言得到空trigger列表。

诊断red保持原fixture和exact-trigger断言，仅在原命令前添加2秒启动延迟。真实原生测试在1.415秒于原 `network_approval.rs:1876` 失败，actual `[]`、expected原callID及完整命令，exit100。原始记录在 `evidence/network-red-green-v2/red-delayed-original/tests.log`。

最终fixture使用已有request-identity routing helper；父会话末次响应需等待原exec的真实终态，随后才释放。新增的AfterInitialYield情况由文件gate确保父会话已经收到初次yield，再让子进程发出网络请求。两种情况都要求精确3个模型请求和原callID/完整命令的精确Guardian trigger。整个原review和父turn完成共用10秒预算。

已核实a911 `unified_exec/async_watcher.rs` 的ExecCommandEnd等待进程退出、输出drain及network-denial monitor结束；它不是初次yield的返回事件。process_manager另一条End路径也仅适用于已退出的短进程。

| 情况 | 结果 | 单项用时 |
|---|---|---:|
| 原fixture +2秒启动延迟，诊断red | 原空trigger断言失败 | 1.415 s |
| 修复，Immediate | PASS | 0.436 s |
| 修复，AfterInitialYield | PASS | 1.557 s |

## 2. Multimodal：参数测试被重复注册

原attribute顺序是tokio::test在16条test_case之前。锁定源 `tokio-macros 2.7.2` 会先把async函数改为同步wrapper并添加test属性；`test-case-core 3.4.0` 保留已有属性，看到同步wrapper后再次添加同一个test属性。每个参数情况因此被同一binary注册两次。宏源路径、文件SHA及带行号片段保存在 `evidence/macro-provenance/`。

同一冻结的Core harness实际执行 `--list`，获得32条注册、16个唯一名字、每个恰好2次；并非跨target日志合并。同事也在原musl shard观察到同名case一次ok、一次FAILED。

最终变更只把一条tokio::test属性移到原16条test_case之后。16个参数向量、名字、原函数body逐字节一致；8MiB附近的坏图负例、有效图像、原10秒预算及全部privacy/image/fallback断言完整保留。重新构建的harness再次实际 `--list`：16条注册、原16个唯一名字、每个恰好1次。对应前后binary SHA与集合在两个registration报告中。

完整16case以 `just test --offline --locked -p codex-core -E 'test(code_mode_node_repl_text_evidence_is_visible_only_to_guardian)' --no-tests fail --retries 0 --test-threads 1` 实际执行，汇总10.850秒，16/16 PASS。

| 原序号 | 原参数情况 | 单项用时 | 结果 |
|---:|---|---:|---|
| 1 | `disabled` | 0.575 s | PASS |
| 2 | `manually_enabled_text_only` | 0.594 s | PASS |
| 3 | `manually_enabled_multimodal` | 1.303 s | PASS |
| 4 | `required_model_forces_multimodal` | 0.591 s | PASS |
| 5 | `text_fallback_without_image_support` | 0.580 s | PASS |
| 6 | `text_fallback_without_context_bound` | 0.574 s | PASS |
| 7 | `text_fallback_with_insufficient_context` | 0.596 s | PASS |
| 8 | `images_resume_after_prompt_pressure` | 0.614 s | PASS |
| 9 | `cua_disabled` | 0.592 s | PASS |
| 10 | `cua_manually_enabled_text_only` | 0.642 s | PASS |
| 11 | `cua_manually_enabled_multimodal` | 1.312 s | PASS |
| 12 | `cua_required_model_forces_multimodal` | 0.551 s | PASS |
| 13 | `cua_text_fallback_without_image_support` | 0.560 s | PASS |
| 14 | `cua_text_fallback_without_context_bound` | 0.575 s | PASS |
| 15 | `cua_text_fallback_with_insufficient_context` | 0.576 s | PASS |
| 16 | `cua_images_resume_after_prompt_pressure` | 0.594 s | PASS |

## 3. 完整环境记录与保留的失败

使用ROG原生Linux/GNU，独立路径 `/home/qian-qi/hepta-a28-core-audit/repo`，共享target正常排队，jobs2、debug0、incremental0、offline/locked。没有终止持锁Rust进程。V8版本150.4.0使用既有archive及binding，完整显式环境在invocation/report中。

初始scoped core测试缺少test_stdio_server的binary metadata，属于setup失败；补齐stdio后仍缺少可用CodeMode host metadata，出现0Guardian请求的早期断言。即便helper已经编译，POSIX just-shell调用sh仍会丢弃带连字符的 `CARGO_BIN_EXE_codex-code-mode-host`。后续probe实际证明该key为null，而cargo-bin已有支持的下划线别名保留。最终资格使用冻结的真实stdio与CodeMode host二进制及下划线别名。两份helper的构建来源、源码路径、文件SHA均保留。

所有这些setup失败的原始日志与报告保存在 `evidence/baseline-tests/`、`evidence/baseline-with-helper/`、`evidence/multimodal-real-helpers/`。初始报告器自身的regex异常也记录在recovered-report说明，原始测试日志完整保留。

共享target中的stdio executable曾被另一构建替换，启动前SHA检查明确阻止了使用不匹配artifact；该停止的stderr保留在 `evidence/shared-helper-sha-guard.json`。之后采用专属regular-file helper副本。

为使新增的16case资格先于lint/format，创建了明确的pre-lint目录前置条件，保存在 `evidence/finalization/PAUSED-before-lint.json`。旧runner实际在原case的setup断言失败时提前退出，没有执行fix/fmt；新的独立源码步骤完成16case和注册集合检查后才执行最终fix/fmt。没有修改运行中的请求，也没有用未知效果替代已知执行。

## 4. 测试与格式化对照

| 文件 | 测试时SHA256 | 最终SHA256 | 对照 |
|---|---|---|---|
| code_mode.rs | `cbe0e322b9a6b3a3a804d1f1810adb9e5baa5c3afe1ebb14b4cc650b8e09cd84` | `cbe0e322b9a6b3a3a804d1f1810adb9e5baa5c3afe1ebb14b4cc650b8e09cd84` | 字节完全相同 |
| network_approval.rs | `f2fef13a524e041bd9eb9f200f03f4211da2c8f5e95dbf9efaf2ba785bc0ccfc` | `cfd9384fc9119d72db531bc6a4e487ecf6439772294266c04cc1ff16c35ed4ab` | 仅rustfmt对同一表达式的行和块布局调整 |

`final-source/`可由最终patch从保留的a911 baseline直接apply，已静态核对最终两个文件SHA与原生最终报告完全一致。

## 5. 适用范围

这份证据确认两个测试fixture修复及其原生资格。原musl CI显示first Guardian在父turn后8.505秒、second在9.434秒，接近原10秒预算；修正重复注册消除了已证实的重复工作，但发布候选仍须完成该候选exact-head required CI，才能认定全部平台时序和集成门槛闭合。本子任务没有执行main merge或branch retirement。
