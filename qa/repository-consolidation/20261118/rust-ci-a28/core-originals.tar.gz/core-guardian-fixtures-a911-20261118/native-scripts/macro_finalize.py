import os,subprocess,json,hashlib,time,shutil,base64,collections,shlex
from pathlib import Path
out=Path('/home/qian-qi/hepta-a28-core-audit');source=out/'repo';run=out/'multimodal-registration-fixed';run.mkdir()
assert (out/'multimodal-real-helpers/report.json').is_file()
assert (out/'finalization/PAUSED-before-lint.json').is_file()
assert not (out/'finalization/fix.log').exists()
assert not (out/'finalization/fmt.log').exists()
helpers=json.loads((out/'helper-bundle/report.json').read_text())
before_registration=json.loads((out/'harness-registration-before/report.json').read_text())['harnesses'][0]
assert helpers['exit_code']==0
code_path=source/'codex-rs/core/tests/suite/code_mode.rs';before=code_path.read_bytes()
assert hashlib.sha256(before).hexdigest()=='28d631913b9cbcdabe37f6f0ec7f4f3400c65a9905d5124f2407aa2ea8c60b5b'
assert hashlib.sha256((source/'codex-rs/core/tests/suite/network_approval.rs').read_bytes()).hexdigest()=='f2fef13a524e041bd9eb9f200f03f4211da2c8f5e95dbf9efaf2ba785bc0ccfc'
patch=base64.b64decode('LS0tIGEvY29kZXgtcnMvY29yZS90ZXN0cy9zdWl0ZS9jb2RlX21vZGUucnMKKysrIGIvY29kZXgtcnMvY29yZS90ZXN0cy9zdWl0ZS9jb2RlX21vZGUucnMKQEAgLTQ0MzEsNyArNDQzMSw2IEBACiB9CiAKICNbY2ZnX2F0dHIod2luZG93cywgaWdub3JlID0gIm5vIGV4ZWNfY29tbWFuZCBvbiBXaW5kb3dzIildCi0jW3Rva2lvOjp0ZXN0KGZsYXZvciA9ICJtdWx0aV90aHJlYWQiLCB3b3JrZXJfdGhyZWFkcyA9IDIpXQogI1t0ZXN0X2Nhc2UoIm5vZGVfcmVwbCIsIGZhbHNlLCBmYWxzZSwgZmFsc2UsIE5vbmU7ICJkaXNhYmxlZCIpXQogI1t0ZXN0X2Nhc2UoIm5vZGVfcmVwbCIsIHRydWUsIGZhbHNlLCBmYWxzZSwgTm9uZTsgIm1hbnVhbGx5X2VuYWJsZWRfdGV4dF9vbmx5IildCiAjW3Rlc3RfY2FzZSgibm9kZV9yZXBsIiwgdHJ1ZSwgdHJ1ZSwgZmFsc2UsIE5vbmU7ICJtYW51YWxseV9lbmFibGVkX211bHRpbW9kYWwiKV0KQEAgLTQ0NDgsNiArNDQ0Nyw3IEBACiAjW3Rlc3RfY2FzZSgiY3VhX3JlcGwiLCB0cnVlLCB0cnVlLCBmYWxzZSwgU29tZSgidW5ib3VuZGVkIik7ICJjdWFfdGV4dF9mYWxsYmFja193aXRob3V0X2NvbnRleHRfYm91bmQiKV0KICNbdGVzdF9jYXNlKCJjdWFfcmVwbCIsIHRydWUsIHRydWUsIGZhbHNlLCBTb21lKCJzbWFsbCIpOyAiY3VhX3RleHRfZmFsbGJhY2tfd2l0aF9pbnN1ZmZpY2llbnRfY29udGV4dCIpXQogI1t0ZXN0X2Nhc2UoImN1YV9yZXBsIiwgdHJ1ZSwgdHJ1ZSwgZmFsc2UsIFNvbWUoImxhcmdlX3Byb21wdCIpOyAiY3VhX2ltYWdlc19yZXN1bWVfYWZ0ZXJfcHJvbXB0X3ByZXNzdXJlIildCisjW3Rva2lvOjp0ZXN0KGZsYXZvciA9ICJtdWx0aV90aHJlYWQiLCB3b3JrZXJfdGhyZWFkcyA9IDIpXQogYXN5bmMgZm4gY29kZV9tb2RlX25vZGVfcmVwbF90ZXh0X2V2aWRlbmNlX2lzX3Zpc2libGVfb25seV90b19ndWFyZGlhbigKICAgICByZXBsX3NlcnZlcjogJidzdGF0aWMgc3RyLAogICAgIGVuaGFuY2VkX3RyYW5zY3JpcHRzOiBib29sLAo=')
(run/'attribute-order.patch').write_bytes(patch)
subprocess.run(['git','apply','--check','-'],input=patch,cwd=source,check=True)
subprocess.run(['git','apply','-'],input=patch,cwd=source,check=True)
after=code_path.read_bytes()
assert hashlib.sha256(after).hexdigest()=='cbe0e322b9a6b3a3a804d1f1810adb9e5baa5c3afe1ebb14b4cc650b8e09cd84'
name='async fn code_mode_node_repl_text_evidence_is_visible_only_to_guardian('
def block(data):
 text=data.decode();fn=text.index(name);start=text.rfind('#[cfg_attr',0,fn)
 return [s for s in text[start:fn].splitlines() if s.startswith('#[test_case(')],text[fn:].encode()
old_cases,old_body=block(before);new_cases,new_body=block(after)
assert len(old_cases)==16 and old_cases==new_cases and old_body==new_body
cache=Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
env=dict(os.environ,PATH=str(cache/'tools-native/bin')+':/home/qian-qi/.cargo/bin:'+str(cache/'dependency-evidence/tools')+':'+os.environ['PATH'],CARGO_TARGET_DIR=str(cache/'target-native'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
for line in (cache/'native-v8.env').read_text().splitlines():
 key,value=line.split('=',1);assert key in ['RUSTY_V8_ARCHIVE','RUSTY_V8_SRC_BINDING_PATH'];assert Path(value).is_file();env[key]=value
for name,row in helpers['helpers'].items():
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
 env['CARGO_BIN_EXE_'+name]=row['path']
 env['CARGO_BIN_EXE_'+name.replace('-','_')]=row['path']
probe_code='import os,json; print(json.dumps({k:os.environ.get(k) for k in ["CARGO_BIN_EXE_codex-code-mode-host","CARGO_BIN_EXE_codex_code_mode_host","CARGO_BIN_EXE_test_stdio_server"]}))'
probe=subprocess.run(['sh','-cu',shlex.join(['/usr/bin/python3','-c',probe_code])],env=env,capture_output=True,text=True,check=True)
probe_env=json.loads(probe.stdout)
assert probe_env['CARGO_BIN_EXE_codex_code_mode_host']==helpers['helpers']['codex-code-mode-host']['path']
assert probe_env['CARGO_BIN_EXE_test_stdio_server']==helpers['helpers']['test_stdio_server']['path']
cmd=['/home/qian-qi/.cargo/bin/just','test','--offline','--locked','-p','codex-core','-E','test(code_mode_node_repl_text_evidence_is_visible_only_to_guardian)','--no-tests','fail','--retries','0','--test-threads','1']
report={'head':'a91102d3639a5a1f02394bfc0331611e9ab101a1','source':str(source),'command':cmd,'patch_sha256':hashlib.sha256(patch).hexdigest(),'before_source_sha256':hashlib.sha256(before).hexdigest(),'test_source_sha256':hashlib.sha256(after).hexdigest(),'unchanged_parameter_rows':old_cases,'parameter_rows_identical':True,'function_body_byte_identical':True,'body_and_following_code_sha256':hashlib.sha256(old_body).hexdigest(),'original_deadline_seconds':10,'oversized_invalid_image_bytes':8*1024*1024-24,'production_file_changes':0,'shell_helper_env_probe':probe_env,'helpers':helpers['helpers'],'disk_free_before':shutil.disk_usage(source).free}
(run/'invocation.json').write_text(json.dumps(report,indent=2)+'\n')
(run/'phase.json').write_text(json.dumps({'phase':'testing_all_16_original_parameter_cases'})+'\n')
start=time.monotonic();log=run/'tests.log'
with log.open('xb') as f: result=subprocess.run(cmd,cwd=source/'codex-rs',env=env,stdout=f,stderr=subprocess.STDOUT)
data=log.read_bytes();lines=data.decode(errors='replace').splitlines()
report.update({'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(data).hexdigest(),'log_bytes':len(data),'summaries':[s for s in lines if 'Summary' in s],'results':[s for s in lines if any(t in s for t in ['PASS [','FAIL [','panicked at','error[','error:'])][:80]})
(run/'test-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
shared=Path(before_registration['shared_artifact']);dst=run/shared.name
stat_before=shared.stat();shutil.copyfile(shared,dst);dst.chmod(0o755);stat_after=shared.stat()
assert (stat_before.st_ino,stat_before.st_size,stat_before.st_mtime_ns)==(stat_after.st_ino,stat_after.st_size,stat_after.st_mtime_ns)
listing=subprocess.run([str(dst),'--list'],capture_output=True,text=True,timeout=30)
(run/'harness-list.txt').write_text(listing.stdout);(run/'harness-list.stderr').write_text(listing.stderr)
prefix='suite::code_mode::code_mode_node_repl_text_evidence_is_visible_only_to_guardian::'
counts=dict(collections.Counter(s for s in listing.stdout.splitlines() if s.startswith(prefix)))
coverage={'frozen_harness':str(dst),'binary_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'list_exit_code':listing.returncode,'before_multiplicity':before_registration['case_multiplicity'],'after_multiplicity':counts,'case_set_unchanged':set(counts)==set(before_registration['case_multiplicity']),'unique_cases':len(counts),'total_registrations':sum(counts.values())}
(run/'registration-report.json').write_text(json.dumps(coverage,indent=2)+'\n')
assert listing.returncode==0 and coverage['case_set_unchanged'] and len(counts)==16 and all(n==1 for n in counts.values())
assert hashlib.sha256(code_path.read_bytes()).hexdigest()==report['test_source_sha256']
if result.returncode:
 (run/'phase.json').write_text(json.dumps({'phase':'tests_failed_no_formatter_run'})+'\n');raise SystemExit(result.returncode)
assert any('16 tests run: 16 passed' in s for s in report['summaries']), 'all 16 unique cases must actually execute and pass'
final=out/'finalization-v2';final.mkdir();(run/'phase.json').write_text(json.dumps({'phase':'all_16_and_registration_passed_linting'})+'\n')
expected_changed=['codex-rs/core/tests/suite/code_mode.rs','codex-rs/core/tests/suite/network_approval.rs']
assert subprocess.check_output(['git','diff','--name-only'],cwd=source,text=True).splitlines()==expected_changed
steps=[]
for label,cmd in [('fix',['/home/qian-qi/.cargo/bin/just','fix','-p','codex-core','--offline','--locked']),('fmt',['/home/qian-qi/.cargo/bin/just','fmt'])]:
 logfile=final/(label+'.log')
 with logfile.open('xb') as f: res=subprocess.run(cmd,cwd=source/'codex-rs',env=env,stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':label,'command':cmd,'exit_code':res.returncode,'log_sha256':hashlib.sha256(logfile.read_bytes()).hexdigest(),'log_bytes':logfile.stat().st_size})
 if label=='fix':
  changed=subprocess.check_output(['git','diff','--name-only'],cwd=source,text=True).splitlines();unrelated=[p for p in changed if p not in expected_changed]
  if unrelated:
   (final/'unrelated-baseline-lint-changes-not-included.patch').write_bytes(subprocess.check_output(['git','diff','--']+unrelated,cwd=source))
   subprocess.run(['git','restore','--source=HEAD','--']+unrelated,cwd=source,check=True)
   steps[-1]['unrelated_lint_files_restored_from_HEAD']=unrelated
check=subprocess.run(['git','diff','--check'],cwd=source,capture_output=True,text=True)
combined=subprocess.check_output(['git','diff','--']+expected_changed,cwd=source)
(final/'guardian-core-fixtures.final.patch').write_bytes(combined)
(final/'guardian-network-routing.final.patch').write_bytes(subprocess.check_output(['git','diff','--',expected_changed[1]],cwd=source))
(final/'guardian-multimodal-registration.final.patch').write_bytes(subprocess.check_output(['git','diff','--',expected_changed[0]],cwd=source))
finished={'steps':steps,'diff_check_exit_code':check.returncode,'diff_check_output':check.stdout+check.stderr,'final_source_hashes':{p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in expected_changed},'patch_sha256':hashlib.sha256(combined).hexdigest(),'patch_bytes':len(combined),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=source,text=True),'no_tests_after_fix_or_fmt':True,'production_file_changes':0,'disk_free_after':shutil.disk_usage(source).free}
(final/'report.json').write_text(json.dumps(finished,indent=2)+'\n');(run/'phase.json').write_text(json.dumps({'phase':'complete','final_report':str(final/'report.json')})+'\n');print(json.dumps(finished,indent=2),flush=True)
