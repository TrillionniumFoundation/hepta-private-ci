import os,subprocess,json,hashlib,time,shutil
from pathlib import Path
out=Path('/home/qian-qi/hepta-a28-core-audit');source=out/'repo';run=out/'multimodal-real-helpers';run.mkdir()
helper_report=out/'helper-bundle/report.json';network_report=out/'network-red-green-v2/report.json'
(run/'phase.json').write_text(json.dumps({'phase':'waiting_for_network_tests_and_frozen_helpers'})+'\n')
deadline=time.monotonic()+3300
while not (helper_report.is_file() and network_report.is_file()):
 if time.monotonic()>deadline: raise TimeoutError('prerequisite reports did not complete')
 time.sleep(2)
helpers=json.loads(helper_report.read_text());network=json.loads(network_report.read_text())
assert helpers['exit_code']==0
assert network['green']['exit_code']==0, 'network patch must pass before qualification'
expected={'codex-rs/core/tests/suite/code_mode.rs':'28d631913b9cbcdabe37f6f0ec7f4f3400c65a9905d5124f2407aa2ea8c60b5b','codex-rs/core/src/guardian/review_session.rs':'b89ba0957ffd901be96535ec9150ff6f3cfd98c82fb60cdf42d03137c5ab2d38'}
for name,digest in expected.items(): assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
cache=Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
env=dict(os.environ,PATH=str(cache/'tools-native/bin')+':/home/qian-qi/.cargo/bin:'+str(cache/'dependency-evidence/tools')+':'+os.environ['PATH'],CARGO_TARGET_DIR=str(cache/'target-native'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
for line in (cache/'native-v8.env').read_text().splitlines():
 key,value=line.split('=',1);assert key in ['RUSTY_V8_ARCHIVE','RUSTY_V8_SRC_BINDING_PATH'];assert Path(value).is_file();env[key]=value
for name,row in helpers['helpers'].items():
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
 env['CARGO_BIN_EXE_'+name]=row['path']
cmd=['/home/qian-qi/.cargo/bin/just','test','--offline','--locked','-p','codex-core','-E','test(code_mode_node_repl_text_evidence_is_visible_only_to_guardian::test_case_3_manually_enabled_multimodal)','--no-tests','fail','--retries','0','--test-threads','1']
report={'command':cmd,'source':str(source),'head':network['green']['head'],'original_multimodal_and_guardian_hashes':expected,'helpers':helpers['helpers'],'network_report':str(network_report),'test_or_production_changes_for_multimodal':0,'original_deadline_seconds':10,'disk_free_before':shutil.disk_usage(source).free}
(run/'invocation.json').write_text(json.dumps(report,indent=2)+'\n');(run/'phase.json').write_text(json.dumps({'phase':'testing_original_multimodal'})+'\n')
start=time.monotonic();log=run/'tests.log'
with log.open('xb') as f: result=subprocess.run(cmd,cwd=source/'codex-rs',env=env,stdout=f,stderr=subprocess.STDOUT)
data=log.read_bytes();lines=data.decode(errors='replace').splitlines()
report.update({'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(data).hexdigest(),'log_bytes':len(data),'summaries':[s for s in lines if 'Summary' in s],'results':[s for s in lines if any(t in s for t in ['PASS [','FAIL [','panicked at','error[','error:'])][:50]})
(run/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if result.returncode:
 (run/'phase.json').write_text(json.dumps({'phase':'test_failed_no_fix_or_fmt_run'})+'\n');raise SystemExit(result.returncode)
final=out/'finalization';final.mkdir();(run/'phase.json').write_text(json.dumps({'phase':'lint_and_format_after_tests'})+'\n')
expected_changed=['codex-rs/core/tests/suite/network_approval.rs']
assert subprocess.check_output(['git','diff','--name-only'],cwd=source,text=True).splitlines()==expected_changed
steps=[]
for name,cmd in [('fix',['/home/qian-qi/.cargo/bin/just','fix','-p','codex-core','--offline','--locked']),('fmt',['/home/qian-qi/.cargo/bin/just','fmt'])]:
 logfile=final/(name+'.log')
 with logfile.open('xb') as f: res=subprocess.run(cmd,cwd=source/'codex-rs',env=env,stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':name,'command':cmd,'exit_code':res.returncode,'log_sha256':hashlib.sha256(logfile.read_bytes()).hexdigest(),'log_bytes':logfile.stat().st_size})
 if name=='fix':
  changed=subprocess.check_output(['git','diff','--name-only'],cwd=source,text=True).splitlines()
  unrelated=[p for p in changed if p not in expected_changed]
  if unrelated:
   (final/'unrelated-fix-changes-not-included.patch').write_bytes(subprocess.check_output(['git','diff','--']+unrelated,cwd=source))
   subprocess.run(['git','restore','--source=HEAD','--']+unrelated,cwd=source,check=True)
   steps[-1]['unrelated_baseline_lint_files_restored_from_HEAD']=unrelated
check=subprocess.run(['git','diff','--check'],cwd=source,capture_output=True,text=True)
patch=subprocess.check_output(['git','diff','--']+expected_changed,cwd=source)
(final/'guardian-network-routing.final.patch').write_bytes(patch)
finished={'steps':steps,'diff_check_exit_code':check.returncode,'diff_check_output':check.stdout+check.stderr,'final_source_hashes':{p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in expected_changed},'patch_sha256':hashlib.sha256(patch).hexdigest(),'patch_bytes':len(patch),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=source,text=True),'no_tests_after_fix_or_fmt':True,'production_file_changes':0,'disk_free_after':shutil.disk_usage(source).free}
(final/'report.json').write_text(json.dumps(finished,indent=2)+'\n');(run/'phase.json').write_text(json.dumps({'phase':'complete','final_report':str(final/'report.json')})+'\n');print(json.dumps(finished,indent=2),flush=True)
