import os,subprocess,json,hashlib,time,tomllib,shutil
from pathlib import Path
out=Path('/home/qian-qi/hepta-a28-core-audit');source=out/'repo';run=out/'helper-bundle';run.mkdir()
cache=Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
env=dict(os.environ,PATH=str(cache/'tools-native/bin')+':/home/qian-qi/.cargo/bin:'+os.environ['PATH'],CARGO_TARGET_DIR=str(cache/'target-native'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
v8=next(row['version'] for row in tomllib.loads((source/'codex-rs/Cargo.lock').read_text())['package'] if row['name']=='v8')
for line in (cache/'native-v8.env').read_text().splitlines():
 key,value=line.split('=',1);assert key in ['RUSTY_V8_ARCHIVE','RUSTY_V8_SRC_BINDING_PATH'];assert ('rusty-v8-'+v8+'-') in value and Path(value).is_file();env[key]=value
build=['/home/qian-qi/.cargo/bin/cargo','build','--offline','--locked','-p','codex-rmcp-client','--bin','test_stdio_server','-p','codex-code-mode-host','--bin','codex-code-mode-host','--message-format=json']
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'source':str(source),'build_command':build,'env':{k:v for k,v in env.items() if k.startswith(('CARGO_','RUSTY_V8'))},'disk_free_before':shutil.disk_usage(source).free}
(run/'invocation.json').write_text(json.dumps(report,indent=2)+'\n')
start=time.monotonic()
with (run/'build.jsonl').open('xb') as f, (run/'build.stderr').open('xb') as err: result=subprocess.run(build,cwd=source/'codex-rs',env=env,stdout=f,stderr=err)
report.update({'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})
if result.returncode:
 (run/'report.json').write_text(json.dumps(report,indent=2)+'\n');raise SystemExit(result.returncode)
artifacts={}
for line in (run/'build.jsonl').read_text().splitlines():
 try: row=json.loads(line)
 except ValueError: continue
 if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name') in ['test_stdio_server','codex-code-mode-host'] and row.get('executable'): artifacts[row['target']['name']]=row
assert len(artifacts)==2
helpers={}
for name,row in artifacts.items():
 src=Path(row['executable']);dst=run/name;shutil.copyfile(src,dst);dst.chmod(0o755)
 helpers[name]={'path':str(dst),'shared_artifact':str(src),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'package_id':row['package_id'],'source_path':row['target']['src_path'],'bytes':dst.stat().st_size}
report.update({'helpers':helpers,'disk_free_after':shutil.disk_usage(source).free,'isolation':'dedicated regular-file executable copies; no live shared-target binary paths used for test dispatch'})
(run/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
