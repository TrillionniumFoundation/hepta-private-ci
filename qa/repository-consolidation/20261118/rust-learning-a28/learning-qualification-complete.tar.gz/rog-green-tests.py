from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/home/qian-qi/hepta-a28-learning-handoff')
repo = root / 'repo'
git = ['/usr/bin/git', '-C', str(repo)]
prior = json.loads((root / 'red-tests/result.json').read_text())
assert prior['exit_code'] == 100
assert '4 tests run: 0 passed, 4 failed' in (root / 'red-tests/tests.stderr.log').read_text()
assert prior['source_hashes_before'] == prior['source_hashes_after']
assert prior['manifest_hashes_before'] == prior['manifest_hashes_after']
assert not prior['git_status_tracked']
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == prior['head']
out = root / 'green-tests'
out.mkdir(exist_ok=False)
with (out / 'prepare.log').open('w') as log:
    subprocess.run(git + ['checkout', '--detach', '--force', '076b20004f7ba6d7653dc41e61edaffd05424925'], check=True, stdout=log, stderr=subprocess.STDOUT)
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
tree = subprocess.check_output(git + ['rev-parse', 'HEAD^{tree}'], text=True).strip()
assert head == '076b20004f7ba6d7653dc41e61edaffd05424925'
assert tree == 'd99c989476007ed4ead3b65a54eaa4df95b03321'
for ancestor in ['342b284c1514da3d3d8b6451b6bd3fb6edfc783a', '307dced98e8b40c1e8321a357e1af1cde3400fef']:
    subprocess.run(git + ['merge-base', '--is-ancestor', ancestor, head], check=True)
expected_blobs = {
    'codex-rs/hepta-agentd/src/learning_iteration.rs': '5b4b07bf3ba605a72da401649e1fb49e40a5f550',
    'codex-rs/hepta-agentd/src/learning_iteration_delivery_runtime_tests.rs': '0aec98de405cfb0123838d78cbf4c5f273acfce8',
    'codex-rs/hepta-agentd/src/learning_iteration_handoff_tests.rs': '3f8c2fc74cf17b8b74afb3fd7fa20f5ccd41a499',
}
for path, expected in expected_blobs.items():
    assert subprocess.check_output(git + ['hash-object', '--', path], text=True).strip() == expected
cache = Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
env = os.environ.copy()
env.update(prior['env'])
env['PATH'] = str(cache / 'tools-native/bin') + ':/home/qian-qi/.cargo/bin:' + env.get('PATH', '')
argv = ['/home/qian-qi/.cargo/bin/just', 'test', '--offline', '--locked', '-p', 'codex-hepta-agentd', '-E', 'test(learning_iteration)', '--no-tests', 'fail', '--retries', '0']
paths = list(prior['source_hashes_before'])
manifests = list(prior['manifest_hashes_before'])
sha = lambda p: hashlib.sha256((repo / p).read_bytes()).hexdigest()
source_before = {p: sha(p) for p in paths}
for path in paths[1:]:
    assert source_before[path] == prior['source_hashes_after'][path]
record = {
    'stage': 'behavioral_green_full_learning_iteration_scope',
    'base': prior['base'],
    'head': head,
    'tree': tree,
    'original_true_merge': '7277a9f43f9dded6ba7997dfa265da40022d96ba',
    'original_true_merge_parents': ['342b284c1514da3d3d8b6451b6bd3fb6edfc783a', '307dced98e8b40c1e8321a357e1af1cde3400fef'],
    'argv': argv,
    'env': prior['env'],
    'source_blobs_before': expected_blobs,
    'source_hashes_before': source_before,
    'manifest_hashes_before': {p: sha(p) for p in manifests},
    'started_unix': time.time(),
    'qualification_scope': 'All learning_iteration related tests including all four new handoff cases; original cancel, expiry, ownership and readback gates unchanged. Full original caller verifier runs on an independent exact same green commit.',
}
(out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
with (out / 'tests.stdout.log').open('w') as stdout, (out / 'tests.stderr.log').open('w') as stderr:
    result = subprocess.run(argv, cwd=repo / 'codex-rs', env=env, stdout=stdout, stderr=stderr)
record.update({
    'exit_code': result.returncode,
    'finished_unix': time.time(),
    'source_hashes_after': {p: sha(p) for p in paths},
    'manifest_hashes_after': {p: sha(p) for p in manifests},
    'git_status_tracked': subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True),
})
for stream in ['stdout', 'stderr']:
    p = out / ('tests.' + stream + '.log')
    record[stream] = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'head': head, 'exit_code': result.returncode, 'stdout': record['stdout'], 'stderr': record['stderr']}))
raise SystemExit(result.returncode)
