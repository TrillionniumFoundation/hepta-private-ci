from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/home/qian-qi/hepta-a28-learning-handoff')
repo = root / 'repo'
git = ['/usr/bin/git', '-C', str(repo)]
prior = json.loads((root / 'original-tests/result.json').read_text())
assert prior['exit_code'] == 101
assert 'could not compile' in (root / 'original-tests/tests.stderr.log').read_text()
assert prior['git_status_tracked'] == ''
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == prior['head']
assert not subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True)
bundle = root / 'learning-fixture-compatible.bundle'
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == '6e67ec857893cea3ec82a5c40354c887fa1f8946f1607b9a7324a309399e0300'
out = root / 'red-tests'
out.mkdir(exist_ok=False)
with (out / 'prepare.log').open('w') as log:
    for argv in [
        git + ['bundle', 'verify', str(bundle)],
        git + ['fetch', str(bundle), 'refs/heads/learning-handoff-green-compatible:refs/heads/learning-handoff-green-compatible', 'refs/heads/learning-handoff-red-compatible:refs/heads/learning-handoff-red-compatible'],
        git + ['checkout', '--detach', '--force', '4ef74b6599fe9b7435185751fed05bccf7a9a822'],
    ]:
        log.write(json.dumps({'argv': argv}) + '\n')
        log.flush()
        subprocess.run(argv, check=True, stdout=log, stderr=subprocess.STDOUT)
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
tree = subprocess.check_output(git + ['rev-parse', 'HEAD^{tree}'], text=True).strip()
assert head == '4ef74b6599fe9b7435185751fed05bccf7a9a822'
assert tree == 'ffe9d0e3cba5bb989b82e2bb856aac7b9d6d9050'
cache = Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
env = os.environ.copy()
env.update(prior['env'])
env['PATH'] = str(cache / 'tools-native/bin') + ':/home/qian-qi/.cargo/bin:' + env.get('PATH', '')
argv = prior['argv']
paths = list(prior['source_hashes_before'])
manifests = list(prior['manifest_hashes_before'])
sha = lambda p: hashlib.sha256((repo / p).read_bytes()).hexdigest()
source_before = {p: sha(p) for p in paths}
assert source_before['codex-rs/hepta-agentd/src/learning_iteration.rs'] == prior['source_hashes_before']['codex-rs/hepta-agentd/src/learning_iteration.rs']
assert source_before['codex-rs/hepta-agentd/src/learning_iteration_handoff_tests.rs'] == 'f9d46b0cefc014d32e76700b2366635178a56e294214c4cc65a75f71f6df96c8'
record = {
    'stage': 'behavioral_red_current_fixture_signatures_original_production',
    'base': prior['base'],
    'head': head,
    'tree': tree,
    'argv': argv,
    'env': prior['env'],
    'source_hashes_before': source_before,
    'manifest_hashes_before': {p: sha(p) for p in manifests},
    'started_unix': time.time(),
    'fixture_compatibility': '13 Result calls propagated, 4 test signatures return anyhow::Result, count comments retained; no production/deadline/cancel/assertion change.',
}
(out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
with (out / 'tests.stdout.log').open('w') as stdout, (out / 'tests.stderr.log').open('w') as stderr:
    result = subprocess.run(argv, cwd=repo / 'codex-rs', env=env, stdout=stdout, stderr=stderr)
record.update({
    'exit_code': result.returncode,
    'finished_unix': time.time(),
    'source_hashes_after': {p: sha(p) for p in paths},
    'manifest_hashes_after': {p: sha(p) for p in manifests},
    'git_status_tracked': subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True),
})
for stream in ['stdout', 'stderr']:
    p = out / ('tests.' + stream + '.log')
    record[stream] = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'head': head, 'exit_code': result.returncode, 'stdout': record['stdout'], 'stderr': record['stderr']}))
raise SystemExit(result.returncode)
