from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path('/home/qian-qi/hepta-a28-learning-handoff')
repo = root / 'repo'
source = Path('/home/qian-qi/hepta-a28-notes-merge/repo')
bundle = root / 'learning-history-complete.bundle'
out = root / 'original-tests'
out.mkdir(exist_ok=False)
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == 'bf750da43b7978bc99dcfd0837f73032eaafc97383590bb76be24ad74361cc37'
assert not repo.exists()
git = ['/usr/bin/git', '-C', str(repo)]
with (out / 'prepare.log').open('w') as log:
    commands = [
        ['/usr/bin/git', 'clone', '--shared', '--no-checkout', str(source), str(repo)],
        git + ['config', 'remote.origin.url', 'https://github.com/TrillionniumFoundation/hepta-private-ci.git'],
        git + ['config', 'remote.origin.promisor', 'true'],
        git + ['config', 'remote.origin.partialclonefilter', 'blob:none'],
        git + ['sparse-checkout', 'init', '--cone'],
        git + ['sparse-checkout', 'set', '.github', 'scripts', 'tools', 'patches', 'bazel', 'codex-rs', 'qa/b4', 'third_party', 'sdk', 'docs/modules', 'qualification/neuron-v13-generation'],
        git + ['bundle', 'verify', str(bundle)],
        git + ['fetch', str(bundle), 'refs/heads/learning-handoff-candidate:refs/heads/learning-handoff-candidate', 'refs/heads/learning-handoff-red-fixture:refs/heads/learning-handoff-red-fixture'],
        git + ['checkout', '--detach', '--force', '784665d0168c84f475098ba53ac2fb18c576e835'],
    ]
    for argv in commands:
        log.write(json.dumps({'argv': argv}) + '\n')
        log.flush()
        subprocess.run(argv, check=True, stdout=log, stderr=subprocess.STDOUT)
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
tree = subprocess.check_output(git + ['rev-parse', 'HEAD^{tree}'], text=True).strip()
assert head == '784665d0168c84f475098ba53ac2fb18c576e835'
assert tree == 'f206e51617d63ca809987e9bfff12fe4834f8f1d'
assert not subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True)
cache = Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
selected = {
    'CARGO_TARGET_DIR': str(cache / 'target-native'),
    'CARGO_BUILD_JOBS': '2',
    'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_NET_OFFLINE': 'true',
    'PYTHONDONTWRITEBYTECODE': '1',
}
for line in (cache / 'native-v8.env').read_text().splitlines():
    if not line:
        continue
    key, value = line.split('=', 1)
    assert key in ('RUSTY_V8_ARCHIVE', 'RUSTY_V8_SRC_BINDING_PATH') and Path(value).is_file()
    selected[key] = value
env = os.environ.copy()
env.update(selected)
env['PATH'] = str(cache / 'tools-native/bin') + ':/home/qian-qi/.cargo/bin:' + env.get('PATH', '')
lock = cache / 'target-native/debug/.cargo-lock'
lock_observation = {'path': str(lock), 'exists': lock.exists()}
if lock.exists():
    stat = lock.stat()
    identity = f'{os.major(stat.st_dev):02x}:{os.minor(stat.st_dev):02x}:{stat.st_ino}'
    lock_observation.update({'file_identity': identity, 'matching_proc_locks': [line for line in Path('/proc/locks').read_text().splitlines() if identity in line]})
argv = ['/home/qian-qi/.cargo/bin/just', 'test', '--offline', '--locked', '-p', 'codex-hepta-agentd', '-E', 'test(learning_iteration_tests::recovery_tests::delivery_runtime_tests::handoff_tests)', '--no-tests', 'fail', '--retries', '0']
paths = ['codex-rs/hepta-agentd/src/learning_iteration.rs', 'codex-rs/hepta-agentd/src/learning_iteration_delivery_runtime_tests.rs', 'codex-rs/hepta-agentd/src/learning_iteration_handoff_tests.rs']
manifests = ['CALLERS.toml', 'scripts/hepta_callers_manifest_parts/part-0000.toml.gz']
sha = lambda p: hashlib.sha256((repo / p).read_bytes()).hexdigest()
record = {
    'stage': 'original_branch_test_fixture_compile_baseline',
    'base': '342b284c1514da3d3d8b6451b6bd3fb6edfc783a',
    'head': head,
    'tree': tree,
    'argv': argv,
    'env': selected,
    'source_hashes_before': {p: sha(p) for p in paths},
    'manifest_hashes_before': {p: sha(p) for p in manifests},
    'native_v8_env_sha256': hashlib.sha256((cache / 'native-v8.env').read_bytes()).hexdigest(),
    'cache_lock_observation': lock_observation,
    'cache_disk_free_bytes': shutil.disk_usage(cache).free,
    'started_unix': time.time(),
    'interpretation': 'Original historical tests use old fixture Result signatures; compilation failure is preserved separately and is not behavioral RED evidence.',
}
(out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
with (out / 'tests.stdout.log').open('w') as stdout, (out / 'tests.stderr.log').open('w') as stderr:
    result = subprocess.run(argv, cwd=repo / 'codex-rs', env=env, stdout=stdout, stderr=stderr)
record.update({
    'exit_code': result.returncode,
    'finished_unix': time.time(),
    'source_hashes_after': {p: sha(p) for p in paths},
    'manifest_hashes_after': {p: sha(p) for p in manifests},
    'git_status_tracked': subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True),
})
for stream in ['stdout', 'stderr']:
    p = out / ('tests.' + stream + '.log')
    record[stream] = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'head': head, 'exit_code': result.returncode, 'stdout': record['stdout'], 'stderr': record['stderr']}))
raise SystemExit(result.returncode)
