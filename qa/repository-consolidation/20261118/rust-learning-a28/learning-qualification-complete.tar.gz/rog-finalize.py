from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile
import time

root = Path('/home/qian-qi/hepta-a28-learning-handoff')
repo = root / 'repo'
git = ['/usr/bin/git', '-C', str(repo)]
green = json.loads((root / 'green-tests/result.json').read_text())
red = json.loads((root / 'red-tests/result.json').read_text())
original = json.loads((root / 'original-tests/result.json').read_text())
callers = json.loads((root / 'green-callers/result.json').read_text())
assert original['exit_code'] == 101 and red['exit_code'] == 100
assert green['exit_code'] == 0 and callers['exit_code'] == 0
assert green['head'] == callers['head'] == '076b20004f7ba6d7653dc41e61edaffd05424925'
assert green['source_hashes_before'] == green['source_hashes_after'] == callers['source_hashes_before'] == callers['source_hashes_after']
assert green['manifest_hashes_before'] == green['manifest_hashes_after'] == callers['manifest_hashes_before'] == callers['manifest_hashes_after']
assert not green['git_status_tracked'] and not callers['git_status_tracked']
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == green['head']
out = root / 'fmt'
out.mkdir(exist_ok=False)
paths = list(green['source_hashes_before'])
manifests = list(green['manifest_hashes_before'])
sha = lambda p: hashlib.sha256((repo / p).read_bytes()).hexdigest()
source_before = {p: sha(p) for p in paths}
assert source_before == green['source_hashes_after']
for path in paths:
    snapshot = out / 'source-before' / path
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes((repo / path).read_bytes())
tested_patch = subprocess.check_output(git + ['diff', '--no-ext-diff', '--no-textconv', '--no-renames', green['base'], 'HEAD', '--'] + paths)
(out / 'tested-net.patch').write_bytes(tested_patch)
env = os.environ.copy()
cache = Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
env['PATH'] = str(cache / 'tools-native/bin') + ':/home/qian-qi/.cargo/bin:' + env.get('PATH', '')
env['PYTHONDONTWRITEBYTECODE'] = '1'
argv = ['/home/qian-qi/.cargo/bin/just', 'fmt', '--base', green['base']]
record = {
    'stage': 'required_post_qualification_formatter',
    'head': green['head'],
    'base': green['base'],
    'argv': argv,
    'source_hashes_before': source_before,
    'manifest_hashes_before': {p: sha(p) for p in manifests},
    'started_unix': time.time(),
    'scope': 'Focused supervised handoff fix plus four regression cases and current Result fixture adaptation; no unrelated Clippy changes.',
    'tests_after_formatting': False,
}
(out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
    result = subprocess.run(argv, cwd=repo / 'codex-rs', env=env, stdout=stdout, stderr=stderr)
changed = subprocess.check_output(git + ['diff', '--name-only', '--no-renames'], text=True).splitlines()
fmt_patch = subprocess.check_output(git + ['diff', '--no-ext-diff', '--no-textconv', '--no-renames', 'HEAD', '--'] + paths)
(out / 'formatter-only.patch').write_bytes(fmt_patch)
final_patch = subprocess.check_output(git + ['diff', '--no-ext-diff', '--no-textconv', '--no-renames', green['base'], '--'] + paths)
(out / 'formatted-net.patch').write_bytes(final_patch)
record.update({
    'exit_code': result.returncode,
    'finished_unix': time.time(),
    'source_hashes_after': {p: sha(p) for p in paths},
    'manifest_hashes_after': {p: sha(p) for p in manifests},
    'source_git_blobs_after': {p: subprocess.check_output(git + ['hash-object', '--', p], text=True).strip() for p in paths},
    'git_status_tracked': subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True),
    'formatter_changed_paths': changed,
    'unexpected_changed_paths': sorted(set(changed) - set(paths)),
    'formatter_only_patch_sha256': hashlib.sha256(fmt_patch).hexdigest(),
    'formatted_net_patch_sha256': hashlib.sha256(final_patch).hexdigest(),
})
record['source_unchanged'] = record['source_hashes_before'] == record['source_hashes_after']
record['manifest_unchanged'] = record['manifest_hashes_before'] == record['manifest_hashes_after']
for path in paths:
    snapshot = out / 'source-after' / path
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes((repo / path).read_bytes())
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')

members = []
for directory in ['original-tests', 'red-tests', 'green-tests', 'green-callers', 'fmt']:
    for path in sorted((root / directory).rglob('*')):
        if path.is_file() and not path.is_symlink():
            members.append(path)
members.extend([root / 'operation.json', root / 'learning-fixture-compatible.bundle'])
index = {
    'green_commit': green['head'],
    'green_tree': green['tree'],
    'original_compile_exit_code': original['exit_code'],
    'behavior_red_exit_code': red['exit_code'],
    'green_exit_code': green['exit_code'],
    'full_callers': callers['verification'],
    'formatter_exit_code': result.returncode,
    'source_unchanged_by_formatter': record['source_unchanged'],
    'manifest_unchanged': record['manifest_unchanged'],
    'complete_history_input_bundle': {
        'path': str(root / 'learning-history-complete.bundle'),
        'bytes': 1295821,
        'sha256': 'bf750da43b7978bc99dcfd0837f73032eaafc97383590bb76be24ad74361cc37',
        'retained_locally': '/workspace/scratch/a28fa6a6513a/audit/frontier/learning-handoff/learning-history-complete.bundle',
    },
    'members': [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(members)],
}
index_path = root / 'learning-evidence-index.json'
index_path.write_text(json.dumps(index, indent=2) + '\n')
members.append(index_path)
archive = root / 'learning-validation-originals.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for path in sorted(members):
                data = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to(root)))
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
summary = {
    'archive': str(archive),
    'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'members': len(members),
    'formatter_exit_code': result.returncode,
    'source_unchanged': record['source_unchanged'],
    'manifest_unchanged': record['manifest_unchanged'],
    'formatter_changed_paths': changed,
    'unexpected_changed_paths': record['unexpected_changed_paths'],
    'source_git_blobs_after': record['source_git_blobs_after'],
}
(root / 'learning-validation-archive.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
raise SystemExit(0 if result.returncode == 0 and record['manifest_unchanged'] and not record['unexpected_changed_paths'] else 1)
