from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/home/qian-qi/hepta-a28-learning-handoff')
source = root / 'repo'
repo = root / 'caller-repo'
out = root / 'green-callers'
out.mkdir(exist_ok=False)
assert not repo.exists()
git = ['/usr/bin/git', '-C', str(repo)]
with (out / 'prepare.log').open('w') as log:
    for argv in [
        ['/usr/bin/git', 'clone', '--shared', '--no-checkout', str(source), str(repo)],
        git + ['config', 'remote.origin.url', 'https://github.com/TrillionniumFoundation/hepta-private-ci.git'],
        git + ['config', 'remote.origin.promisor', 'true'],
        git + ['config', 'remote.origin.partialclonefilter', 'blob:none'],
        git + ['sparse-checkout', 'init', '--cone'],
        git + ['sparse-checkout', 'set', '.github', 'scripts', 'tools', 'patches', 'bazel', 'codex-rs', 'qa/b4', 'third_party', 'sdk', 'docs/modules', 'qualification/neuron-v13-generation'],
        git + ['checkout', '--detach', '--force', '076b20004f7ba6d7653dc41e61edaffd05424925'],
    ]:
        log.write(json.dumps({'argv': argv}) + '\n')
        log.flush()
        subprocess.run(argv, check=True, stdout=log, stderr=subprocess.STDOUT)
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
tree = subprocess.check_output(git + ['rev-parse', 'HEAD^{tree}'], text=True).strip()
assert head == '076b20004f7ba6d7653dc41e61edaffd05424925'
assert tree == 'd99c989476007ed4ead3b65a54eaa4df95b03321'
expected_blobs = {
    'codex-rs/hepta-agentd/src/learning_iteration.rs': '5b4b07bf3ba605a72da401649e1fb49e40a5f550',
    'codex-rs/hepta-agentd/src/learning_iteration_delivery_runtime_tests.rs': '0aec98de405cfb0123838d78cbf4c5f273acfce8',
    'codex-rs/hepta-agentd/src/learning_iteration_handoff_tests.rs': '3f8c2fc74cf17b8b74afb3fd7fa20f5ccd41a499',
}
for path, expected in expected_blobs.items():
    assert subprocess.check_output(git + ['hash-object', '--', path], text=True).strip() == expected
manifests = ['CALLERS.toml', 'scripts/hepta_callers_manifest_parts/part-0000.toml.gz']
sha = lambda p: hashlib.sha256((repo / p).read_bytes()).hexdigest()
argv = ['/usr/bin/python3', str(repo / 'scripts/verify_hepta_callers.py'), 'verify', '--root', str(repo)]
record = {
    'stage': 'full_original_callers_on_exact_green_candidate',
    'head': head,
    'tree': tree,
    'argv': argv,
    'source_blobs_before': expected_blobs,
    'source_hashes_before': {p: sha(p) for p in expected_blobs},
    'manifest_hashes_before': {p: sha(p) for p in manifests},
    'started_unix': time.time(),
    'isolation': 'Independent exact GREEN checkout; no mutation of the concurrently running behavioral RED source or shared Cargo target.',
}
(out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
    result = subprocess.run(argv, cwd=repo, env=env, stdout=stdout, stderr=stderr)
record.update({
    'exit_code': result.returncode,
    'finished_unix': time.time(),
    'source_hashes_after': {p: sha(p) for p in expected_blobs},
    'manifest_hashes_after': {p: sha(p) for p in manifests},
    'git_status_tracked': subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True),
})
for stream in ['stdout', 'stderr']:
    p = out / (stream + '.log')
    record[stream] = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
if result.returncode == 0:
    receipt = json.loads((out / 'stdout.log').read_text())
    record['verification'] = {'status': receipt['status'], 'rustFilesScanned': receipt['rustFilesScanned'], 'boundaries': len(receipt['boundaries']), 'protectedFiles': len(receipt['protectedFiles'])}
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'head': head, 'exit_code': result.returncode, 'verification': record.get('verification'), 'stdout': record['stdout'], 'stderr': record['stderr']}))
raise SystemExit(result.returncode)
