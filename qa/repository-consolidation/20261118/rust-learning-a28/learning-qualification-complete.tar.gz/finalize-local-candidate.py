from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

audit = Path('/workspace/scratch/a28fa6a6513a/audit')
out = audit / 'frontier/learning-handoff'
bare = audit / 'frontier/notes-merge-sim.git'
base = '342b284c1514da3d3d8b6451b6bd3fb6edfc783a'
tested = '076b20004f7ba6d7653dc41e61edaffd05424925'
incoming = '307dced98e8b40c1e8321a357e1af1cde3400fef'
current = '770179d123b879355b53db1d75f8f9f301280d3e'
authbus = '09483d18b1188d7d6c4f6843b64f9da2533a9f6c'
fmt = json.loads((out / 'validation-originals/fmt/result.json').read_text())
env = os.environ.copy()
env['GIT_NO_LAZY_FETCH'] = '1'
env['GIT_INDEX_FILE'] = str(out / 'formatted.index')
env['GIT_AUTHOR_NAME'] = env['GIT_COMMITTER_NAME'] = 'Repository consolidation audit'
env['GIT_AUTHOR_EMAIL'] = env['GIT_COMMITTER_EMAIL'] = 'consolidation-audit@localhost'
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S+0000')
env['GIT_AUTHOR_DATE'] = env['GIT_COMMITTER_DATE'] = stamp

def git(*args, input=None, check=True):
    return subprocess.run(['git', '--git-dir', str(bare), *args], input=input, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=check)

def text(*args):
    return git(*args).stdout.decode().strip()

def commit(tree, parents, message):
    args = ['commit-tree', tree]
    for parent in parents:
        args.extend(['-p', parent])
    return git(*args, input=(message + '\n').encode()).stdout.decode().strip()

def ancestor(a, b):
    result = git('merge-base', '--is-ancestor', a, b, check=False)
    assert result.returncode in (0, 1), result.stderr.decode()
    return result.returncode == 0

assert fmt['exit_code'] == 0 and fmt['manifest_unchanged']
assert fmt['head'] == tested and fmt['tests_after_formatting'] is False
paths = list(fmt['source_git_blobs_after'])
changed_path = 'codex-rs/hepta-agentd/src/learning_iteration_handoff_tests.rs'
assert fmt['formatter_changed_paths'] == [changed_path]
before = (out / 'validation-originals/fmt/source-before' / changed_path).read_bytes()
after = (out / 'validation-originals/fmt/source-after' / changed_path).read_bytes()
old_line = b'async fn detached_learning_submit_still_cancels_and_recovers_without_new_work() -> anyhow::Result<()> {\n'
new_line = b'async fn detached_learning_submit_still_cancels_and_recovers_without_new_work() -> anyhow::Result<()>\n{\n'
assert before.count(old_line) == 1 and before.replace(old_line, new_line) == after
git('read-tree', tested)
for path, expected in fmt['source_git_blobs_after'].items():
    data = (out / 'validation-originals/fmt/source-after' / path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == fmt['source_hashes_after'][path]
    blob = git('hash-object', '-w', '--stdin', input=data).stdout.decode().strip()
    assert blob == expected
    git('update-index', '--add', '--cacheinfo', f'100644,{blob},{path}')
formatted_tree = text('write-tree')
formatted = commit(formatted_tree, [tested], 'Format qualified learning handoff regression tests\n\nOriginal learning scope passed 165 tests and full caller verification passed before formatting. The only formatter change places a long test signature brace on the following line. No tests were run after formatting.')
git('update-ref', 'refs/a28-learning/formatted-v1', formatted, '0' * 40)

# Import only the parent's explicitly shared local authbus merge commit object.
# Its parents and tree are already present in the shared read-only object graph.
authbus_object = subprocess.check_output(['git', '--git-dir', '/tmp/hepta-a28-authbus-merge.git', 'cat-file', 'commit', authbus], env=env)
assert git('hash-object', '-w', '-t', 'commit', '--stdin', input=authbus_object).stdout.decode().strip() == authbus
assert text('rev-parse', authbus + '^{tree}') == text('rev-parse', current + '^{tree}')

protected_lines = (audit / 'protected-hia-refs-before-publication.tsv').read_text().splitlines()
protected_tips = set()
for line in protected_lines:
    parts = line.split('\t')
    shas = [part for part in parts if len(part) == 40 and all(c in '0123456789abcdef' for c in part)]
    assert len(shas) == 1
    protected_tips.add(shas[0])
assert len(protected_lines) == 356
roots = ['f02bb9f3344cdff4e361cca4353540ca0193bd21', '3aa1f85ba90c79d220a5cadf2261def176892867', '8347769bab248a287efa2e4e82f667b55a0f29bc']
joins = []
for label, onto in [('770', current), ('authbus', authbus)]:
    merge = git('merge-tree', '--write-tree', '--messages', onto, formatted, check=False)
    (out / f'join-{label}-merge-tree.raw').write_bytes(merge.stdout)
    (out / f'join-{label}-merge-tree.stderr').write_bytes(merge.stderr)
    assert merge.returncode == 0, merge.stdout.decode() + merge.stderr.decode()
    tree = merge.stdout.splitlines()[0].decode()
    changed = text('diff-tree', '--no-commit-id', '--name-only', '-r', '--no-renames', onto + '^{tree}', tree).splitlines()
    assert sorted(changed) == sorted(paths), changed
    incoming_blobs = {path: text('rev-parse', tree + ':' + path) for path in paths}
    assert incoming_blobs == fmt['source_git_blobs_after']
    unchanged_baseline = {
        path: {'base': text('rev-parse', base + ':' + path), 'onto': text('rev-parse', onto + ':' + path)}
        for path in paths if path != changed_path
    }
    assert all(record['base'] == record['onto'] for record in unchanged_baseline.values())
    join = commit(tree, [onto, formatted], 'Merge qualified learning handoff history\n\nUse the original clean three-way merge. Preserve the accepted handoff production fix, all four regression cases, current Result fixture compatibility and post-qualification formatting.')
    git('update-ref', f'refs/a28-learning/join-{label}-v1', join, '0' * 40)
    assert ancestor(incoming, join) and ancestor(onto, join)
    introduced = text('rev-list', formatted, '^' + onto).splitlines()
    assert not set(introduced).intersection(protected_tips)
    hia_ancestors = {root: ancestor(root, join) for root in roots}
    assert not any(hia_ancestors.values())
    joins.append({
        'onto': onto, 'commit': join, 'tree': tree, 'parents': [onto, formatted],
        'merge_base': text('merge-base', onto, formatted),
        'original_merge_tree_exit': merge.returncode,
        'changed_paths': changed, 'source_blobs': incoming_blobs,
        'unchanged_existing_learning_baseline': unchanged_baseline,
        'introduced_learning_history': introduced,
        'protected_tip_intersection': [], 'hia_root_or_anchor_ancestors': hia_ancestors,
        'incoming_branch_is_ancestor': True,
    })
assert joins[0]['tree'] == joins[1]['tree']
proof = {
    'repository': str(bare), 'base': base, 'incoming': incoming,
    'original_true_merge': '7277a9f43f9dded6ba7997dfa265da40022d96ba',
    'tested_green': tested, 'formatted_commit': formatted, 'formatted_tree': formatted_tree,
    'formatter_only_semantics': 'The only edit moves the opening brace of one test function signature to its own line. Exact byte replacement checked; all other bytes identical.',
    'formatter_only_patch_sha256': fmt['formatter_only_patch_sha256'],
    'tests_after_formatting': False, 'final_source_blobs': fmt['source_git_blobs_after'],
    'final_source_sha256': fmt['source_hashes_after'],
    'protected_inventory_refs': len(protected_lines),
    'protected_inventory_sha256': hashlib.sha256((audit / 'protected-hia-refs-before-publication.tsv').read_bytes()).hexdigest(),
    'joins': joins,
}
(out / 'qualified-join-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
