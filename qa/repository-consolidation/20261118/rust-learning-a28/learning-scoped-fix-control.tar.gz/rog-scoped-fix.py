from pathlib import Path
import difflib
import hashlib
import json
import os
import subprocess
import time

root = Path('/home/qian-qi/hepta-a28-learning-handoff')
repo = root / 'repo'
out = root / 'scoped-fix'
out.mkdir(exist_ok=False)
git = ['/usr/bin/git', '-C', str(repo)]
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
assert head == '076b20004f7ba6d7653dc41e61edaffd05424925'
fmt = json.loads((root / 'fmt/result.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
learning_paths = list(fmt['source_hashes_after'])
for path in learning_paths:
    assert sha((repo / path).read_bytes()) == fmt['source_hashes_after'][path]
tracked_before = subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True)
assert tracked_before == ' M codex-rs/hepta-agentd/src/learning_iteration_handoff_tests.rs\n', tracked_before
package = repo / 'codex-rs/hepta-agentd'
files = sorted(path for path in package.rglob('*.rs') if path.is_file())
source_before = {str(path.relative_to(repo)): sha(path.read_bytes()) for path in files}
saved_before = {path: (repo / path).read_bytes() for path in learning_paths}
manifest_paths = ['CALLERS.toml', 'scripts/hepta_callers_manifest_parts/part-0000.toml.gz', 'codex-rs/Cargo.toml', 'codex-rs/Cargo.lock', 'codex-rs/hepta-agentd/Cargo.toml']
manifest_before = {path: sha((repo / path).read_bytes()) for path in manifest_paths}
env = os.environ.copy()
cache = Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
env.update({
    'PATH': str(cache / 'tools-native/bin') + ':/home/qian-qi/.cargo/bin:' + env.get('PATH', ''),
    'CARGO_TARGET_DIR': str(cache / 'target-native'), 'CARGO_BUILD_JOBS': '2',
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_NET_OFFLINE': 'true', 'PYTHONDONTWRITEBYTECODE': '1',
    'RUSTY_V8_ARCHIVE': '/tmp/codex-package/rusty-v8-150.4.0-x86_64-unknown-linux-gnu/librusty_v8_ptrcomp_sandbox_release_x86_64-unknown-linux-gnu.a.gz',
    'RUSTY_V8_SRC_BINDING_PATH': '/tmp/codex-package/rusty-v8-150.4.0-x86_64-unknown-linux-gnu/src_binding_ptrcomp_sandbox_release_x86_64-unknown-linux-gnu.rs',
})
argv = ['/home/qian-qi/.cargo/bin/just', 'fix', '--offline', '--locked', '-p', 'codex-hepta-agentd']
record = {'stage': 'scoped_clippy_fix_after_parent_maintenance_request', 'head': head, 'argv': argv, 'started_unix': time.time(), 'source_hashes_before': source_before, 'learning_hashes_before': {p: source_before[p] for p in learning_paths}, 'manifest_hashes_before': manifest_before, 'tracked_status_before': tracked_before, 'tests_after_maintenance': False, 'scope': 'Only original just fix recipe scoped to codex-hepta-agentd. Existing shared native target, V8 archive and two-job settings. No other package fixes.'}
(out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
with (out / 'fix.stdout.log').open('w') as stdout, (out / 'fix.stderr.log').open('w') as stderr:
    result = subprocess.run(argv, cwd=repo / 'codex-rs', env=env, stdout=stdout, stderr=stderr)
record['fix_exit_code'] = result.returncode
record['fix_finished_unix'] = time.time()
record['source_hashes_after_fix'] = {str(path.relative_to(repo)): sha(path.read_bytes()) for path in files}
(out / 'after-fix.json').write_text(json.dumps(record, indent=2) + '\n')
fmt_argv = ['/home/qian-qi/.cargo/bin/just', 'fmt', '--base', '342b284c1514da3d3d8b6451b6bd3fb6edfc783a']
record['fmt_argv'] = fmt_argv
with (out / 'fmt.stdout.log').open('w') as stdout, (out / 'fmt.stderr.log').open('w') as stderr:
    formatted = subprocess.run(fmt_argv, cwd=repo / 'codex-rs', env=env, stdout=stdout, stderr=stderr)
after = {str(path.relative_to(repo)): sha(path.read_bytes()) for path in files}
changed = [path for path in source_before if source_before[path] != after[path]]
patches = []
for path in changed:
    before = saved_before.get(path)
    if before is None:
        before = subprocess.check_output(git + ['cat-file', 'blob', head + ':' + path])
    assert sha(before) == source_before[path]
    for stage, data in [('source-before', before), ('source-after', (repo / path).read_bytes())]:
        destination = out / stage / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    patches += list(difflib.unified_diff(before.decode().splitlines(True), (repo / path).read_text().splitlines(True), fromfile='before/' + path, tofile='after/' + path))
(out / 'maintenance-only.patch').write_text(''.join(patches))
(out / 'post-maintenance-vs-tested-head.patch').write_bytes(subprocess.check_output(git + ['diff', '--no-ext-diff', '--no-textconv', '--no-renames', head]))
tracked_after = subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True)
changed_tracked_paths = subprocess.check_output(git + ['diff', '--name-only', '--no-renames', head], text=True).splitlines()
record.update({'fmt_exit_code': formatted.returncode, 'finished_unix': time.time(), 'source_hashes_after': after, 'learning_hashes_after': {p: after[p] for p in learning_paths}, 'manifest_hashes_after': {p: sha((repo / p).read_bytes()) for p in manifest_paths}, 'maintenance_changed_paths': changed, 'changed_paths_outside_scoped_package': [p for p in changed_tracked_paths if not p.startswith('codex-rs/hepta-agentd/')], 'tracked_status_after': tracked_after, 'source_unchanged_by_maintenance': source_before == after})
record['manifest_unchanged'] = record['manifest_hashes_before'] == record['manifest_hashes_after']
record['logs'] = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(out.glob('*.log'))}
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['head', 'fix_exit_code', 'fmt_exit_code', 'maintenance_changed_paths', 'changed_paths_outside_scoped_package', 'source_unchanged_by_maintenance', 'manifest_unchanged', 'logs']}))
raise SystemExit(result.returncode if result.returncode else (formatted.returncode if formatted.returncode else (0 if record['manifest_unchanged'] and not record['changed_paths_outside_scoped_package'] else 2)))
