# Independent candidate review — a28

Source review: PASS for the five staged source files at source tree `bbfba28957c237aee67e1beb44991ff8ede53350`. This is a source-scoped review, not whole-repository or hosted-CI approval.

## Ancestry and scope

Observed HEAD `a91102d3639a5a1f02394bfc0331611e9ab101a1`, MERGE_HEAD `59d05538c9a2be1d1240e328648935832fac7cf4`, MERGE_MODE `no-ff`, no unmerged index entries, and no unstaged tracked changes. I copied the index read-only and independently reconstructed the same source tree in my isolated object database. Only five source paths differ from the first parent.

The merge adds exactly `59b8195015b76a633dcaf04b34ffa79baa3a8ce2` and `59d05538c9a2be1d1240e328648935832fac7cf4` to the first-parent ancestry. The 40,856 ancestor union contains none of the 349 protected HIA/Cell tips, either HIA root, or the Cell anchor. No remote reference was modified by this reviewer.

## Source checks

The two Python repairs track the actual physical replay helpers and bounded verified-image memo. The mutation helpers still remove required markers and require the original source verifier to reject them. They preserve stable file reads, full image identity, anchor/record equality, replay binding/checksum/rollback rejection, poison behavior, and exact cursor restoration. Two additional negative cases require exact memo binding/minimum anchor/full bytes and bounded retention. CALLERS.toml and the verifier are unchanged.

The MODULE annotation selects the already locked sha2 0.10.9 package and adds only `-Copt-level=3`, matching Cargo development configuration. Hash algorithm, crate version/features, signature and ownership checks, physical validation, and all deadlines are unchanged. This is not proof of the original 500 ms NextUse diagnostic passing.

Notes rechecks the same original absolute deadline after each RPC await and before adopting either result. It uses the existing strict budget predicate. Ready-after-deadline results become Unknown(DeadlineElapsed), while identity, proof, pagination limits, and original caller boundaries remain unchanged. Both source files exactly match the incoming ordinary commit.

## Verification binding

The complete original B4 discovery on a911 plus the two Python changes passed 1,347 tests in 583.147 s, no skips/failures/errors. The separate five-file Notes source snapshot passed its 26 affected source-guard cases in 100.639 s. All five source hashes remained identical after root's formatting. These completed runs were not rerun. The original incomplete-fixture failure is retained separately.

The source review does not assert Notes native runtime qualification, which is owned by branch_inventory. It does not transfer the digest/evaluation targets' component passes to NextUse, Core, Windows, macOS, or whole-repository approval.

## Evidence packing

The two previously detected extra final newline bytes were corrected precisely: digest-and-execution-tests-v3.log is 44,989 bytes with SHA256 bde27f72241e5e63ababed459f8554525a1d7f6f24c8890b53df8a151ef24b5b; inflated actual-sha2-aquery.json.gz is 30,082 bytes with SHA256 eabc35715817c310779e73cc3e9ef32fdfd105f356f720dbcec17fa54cec1841. Earlier Bazel attempts and the incomplete-fixture B4 log are present. Archive-level member verification will be recorded separately once root finishes packaging.

## macOS follow-up boundaries

The actual Intel failures are PTY dropped-output-receiver draining and Core multi_agents send_input_accepts_structured_items; the latter is not an app-server package failure. The diagnostic PTY branch preserves evidence but is not itself a runtime fix. The ordinary 8075eb3 tip has a relevant closed-receiver optimization, but its 268 unmerged commits cause 194 native merge conflict messages against a911 and 217 against b748; it cannot be represented as a seven-line historical merge. Complete merge outputs, all-commit postimage inventory, and the HIA exclusion proof are retained under ../pty-merge-review/.

The separately reviewed a3bf4c9 Core timing change affects a different wait_agent test, so it does not establish a fix for structured input. An independent five-line PTY production transplant is now under qualification and does not attach the 268-commit ancestry.
