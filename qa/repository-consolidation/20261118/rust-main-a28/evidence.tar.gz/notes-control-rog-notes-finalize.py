from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile
import time

root = Path('/home/qian-qi/hepta-a28-notes-merge')
repo = root / 'repo'
git = ['/usr/bin/git', '-C', str(repo)]
green = json.loads((root / 'green-tests-v2/result.json').read_text())
red = json.loads((root / 'red-tests/result.json').read_text())
if any(item['exit_code'] != 0 for item in green['results']):
    raise SystemExit('GREEN/caller prerequisite failed')
if red['exit_code'] != 100:
    raise SystemExit('RED prerequisite failed')
if green['source_hashes_before'] != green['source_hashes_after']:
    raise SystemExit('Tests altered source')
if green['manifest_hashes_before'] != green['manifest_hashes_after']:
    raise SystemExit('Caller manifest changed')
if green['git_status_tracked']:
    raise SystemExit('Tracked changes before formatting')
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
if head != '195eafed0540025a2ed590fa8b8b2441644bd952':
    raise SystemExit('Unexpected merge candidate')
out = root / 'fmt'
out.mkdir(exist_ok=False)
paths = list(green['source_hashes_after'])
manifest_paths = list(green['manifest_hashes_after'])
sha256 = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source_before = {p: sha256(repo / p) for p in paths}
manifest_before = {p: sha256(repo / p) for p in manifest_paths}
if source_before != green['source_hashes_after']:
    raise SystemExit('Source no longer equals tested bytes')
env = os.environ.copy()
cache = Path('/home/qian-qi/work/hepta-consolidate-4be89e6b')
env['PATH'] = str(cache / 'tools-native/bin') + ':/home/qian-qi/.cargo/bin:' + env.get('PATH', '')
env['PYTHONDONTWRITEBYTECODE'] = '1'
argv = ['/home/qian-qi/.cargo/bin/just', 'fmt', '--base', 'a91102d3639a5a1f02394bfc0331611e9ab101a1']
record = {
    'stage': 'post_test_required_formatter',
    'head': head,
    'argv': argv,
    'source_hashes_before': source_before,
    'manifest_hashes_before': manifest_before,
    'started_unix': time.time(),
    'policy': 'Run formatter after all tests and full caller verification; no tests after formatting. Notes 61-line change is not a large change requiring just fix.',
}
(out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
    result = subprocess.run(argv, cwd=repo / 'codex-rs', env=env, stdout=stdout, stderr=stderr)
record.update({
    'exit_code': result.returncode,
    'finished_unix': time.time(),
    'source_hashes_after': {p: sha256(repo / p) for p in paths},
    'manifest_hashes_after': {p: sha256(repo / p) for p in manifest_paths},
    'git_status_tracked': subprocess.check_output(git + ['status', '--porcelain', '--untracked-files=no'], text=True),
    'source_git_blobs': {p: subprocess.check_output(git + ['hash-object', '--', p], text=True).strip() for p in paths},
})
record['source_unchanged'] = record['source_hashes_before'] == record['source_hashes_after']
record['manifest_unchanged'] = record['manifest_hashes_before'] == record['manifest_hashes_after']
for p in paths:
    snapshot = out / 'source' / p
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes((repo / p).read_bytes())
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')

members = []
for directory in ['red-tests', 'green-tests', 'green-tests-v2', 'fmt']:
    for path in sorted((root / directory).rglob('*')):
        if path.is_file() and not path.is_symlink():
            members.append(path)
members.append(root / 'notes-red-green.bundle')
index = {
    'merge_head': head,
    'red_exit_code': red['exit_code'],
    'green_results': green['results'],
    'formatter_exit_code': result.returncode,
    'source_unchanged_after_fmt': record['source_unchanged'],
    'manifest_unchanged_after_fmt': record['manifest_unchanged'],
    'members': [
        {'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': sha256(p)}
        for p in sorted(members)
    ],
}
index_path = root / 'notes-evidence-index.json'
index_path.write_text(json.dumps(index, indent=2) + '\n')
members.append(index_path)
archive = root / 'notes-validation-originals.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for path in sorted(members):
                data = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to(root)))
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
summary = {
    'archive': str(archive),
    'bytes': archive.stat().st_size,
    'sha256': sha256(archive),
    'members': len(members),
    'fmt_exit_code': result.returncode,
    'source_unchanged': record['source_unchanged'],
    'manifest_unchanged': record['manifest_unchanged'],
    'head': head,
    'source_git_blobs': record['source_git_blobs'],
}
(root / 'notes-validation-archive.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
raise SystemExit(0 if result.returncode == 0 and record['source_unchanged'] and record['manifest_unchanged'] and not record['git_status_tracked'] else 1)
