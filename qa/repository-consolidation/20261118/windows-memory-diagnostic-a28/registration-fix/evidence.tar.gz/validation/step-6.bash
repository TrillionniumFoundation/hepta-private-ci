set -euo pipefail
command=(
  ./.github/scripts/run-bazel-ci.sh
  --print-failed-action-summary
  --print-failed-test-logs
  --windows-msvc-host-platform
  --remote-download-toplevel
  --
  test
  --platforms=//:windows_x86_64_msvc
  --flaky_test_attempts=1
  --runs_per_test=1
  --cache_test_results=no
  --test_sharding_strategy=disabled
  --test_output=all
  "--test_arg=${MEMORY_CASE}"
  --test_arg=--exact
  --test_arg=--nocapture
  --test_arg=--color=never
  "--build_metadata=COMMIT_SHA=${SOURCE_SHA}"
  --
  "${MEMORY_TARGET}"
)
python - "${command[@]}" <<'PY'
import datetime
import json
import os
from pathlib import Path
import sys

record = {"argv": sys.argv[1:], "cwd": os.getcwd(),
          "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat()}
(Path(os.environ["EVIDENCE_DIR"]) / "invocation.json").write_text(
    json.dumps(record, indent=2) + "\n")
PY
set +e
"${command[@]}" 2>&1 | tee "${EVIDENCE_DIR}/bazel.stdout-stderr.log"
statuses=("${PIPESTATUS[@]}")
set -e
python - "${statuses[@]}" <<'PY'
import datetime
import json
import os
from pathlib import Path
import sys

record = {"bazel_exit_code": int(sys.argv[1]), "tee_exit_code": int(sys.argv[2]),
          "completed_at": datetime.datetime.now(datetime.timezone.utc).isoformat()}
(Path(os.environ["EVIDENCE_DIR"]) / "execution-result.json").write_text(
    json.dumps(record, indent=2) + "\n")
PY
if [[ "${statuses[0]}" -ne 0 ]]; then
  exit "${statuses[0]}"
fi
exit "${statuses[1]}"
