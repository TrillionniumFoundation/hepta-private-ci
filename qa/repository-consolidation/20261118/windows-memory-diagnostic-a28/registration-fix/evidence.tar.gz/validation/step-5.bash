set -euo pipefail
python - <<'PY'
import json
import os
from pathlib import Path
import subprocess

commands = [["bazel", "--version"], ["git", "--version"],
            ["rustc", "--version", "--verbose"], ["cl"]]
versions = []
for command in commands:
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        versions.append({"argv": command, "exit_code": result.returncode,
                         "stdout": result.stdout, "stderr": result.stderr})
    except OSError as error:
        versions.append({"argv": command, "error": str(error)})
(Path(os.environ["EVIDENCE_DIR"]) / "runner-tools.json").write_text(
    json.dumps(versions, indent=2) + "\n")
# Runner rustc is recorded separately from Bazel's pinned Rust toolchain.
if versions[0].get("exit_code") != 0:
    raise SystemExit("The original Bazel launcher is unavailable.")
PY
