set -euo pipefail
python - <<'PY'
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess

out = Path(os.environ["EVIDENCE_DIR"])
out.mkdir(parents=True, exist_ok=False)
def git(*args):
    return subprocess.check_output(["git", *args], text=True).strip()
paths = [
    "codex-rs/ext/hepta-memory/src/local_lifecycle.rs",
    "codex-rs/hepta-memory/src/local_lease_outbox.rs",
    "codex-rs/ext/hepta-memory/BUILD.bazel",
    "codex-rs/Cargo.lock", "MODULE.bazel", ".bazelversion", ".bazelrc",
    "defs.bzl", "workspace_root_test_launcher.bat.tpl",
    ".github/scripts/run-bazel-ci.sh",
    ".github/workflows/hepta-memory-lifecycle-windows-diagnostic.yml",
]
files = []
for name in paths:
    data = Path(name).read_bytes()
    saved = out / "source" / name
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes(data)
    files.append({"path": name, "bytes": len(data),
                  "sha256": hashlib.sha256(data).hexdigest(),
                  "git_blob": git("hash-object", "--", name)})
identity = {
    "expected_source_sha": os.environ["SOURCE_SHA"],
    "checked_out_sha": git("rev-parse", "HEAD"),
    "tree": git("rev-parse", "HEAD^{tree}"),
    "platform": platform.platform(), "system": platform.system(),
    "machine": platform.machine(), "python": platform.python_version(),
    "run_id": os.environ["GITHUB_RUN_ID"],
    "run_attempt": os.environ["GITHUB_RUN_ATTEMPT"],
    "job": os.environ["GITHUB_JOB"],
    "case": os.environ["MEMORY_CASE"],
    "target": os.environ["MEMORY_TARGET"], "source_files": files,
}
(out / "identity.json").write_text(json.dumps(identity, indent=2) + "\n")
if identity["system"] != "Windows":
    raise SystemExit("The diagnostic requires native Windows.")
if identity["checked_out_sha"] != identity["expected_source_sha"]:
    raise SystemExit("The checked-out source does not match the PR head.")
subprocess.run(["git", "diff", "--exit-code", "HEAD"], check=True)
PY
