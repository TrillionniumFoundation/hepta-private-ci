"""Review this exact workflow's expression locations and failure-path evidence."""

import hashlib
import json
import ntpath
import os
from pathlib import Path
import re
import subprocess
import sys

import yaml


ROOT = Path(__file__).resolve().parent
PATH = ".github/workflows/hepta-memory-lifecycle-windows-diagnostic.yml"
BEFORE = Path("/tmp/hepta-ci-audit-a28/memory-windows-diagnostic/candidate") / PATH
AFTER = ROOT / "candidate" / PATH
OUT = ROOT / "validation"
OUT.mkdir(exist_ok=True)
old = yaml.load(BEFORE.read_text(), Loader=yaml.BaseLoader)
new = yaml.load(AFTER.read_text(), Loader=yaml.BaseLoader)
JOB = {"github", "needs", "strategy", "matrix", "vars", "secrets", "inputs"}
STEP = JOB | {"job", "runner", "env", "steps"}


def contexts(document):
    found = []
    errors = []

    def walk(node, keys):
        if isinstance(node, dict):
            for key, value in node.items():
                walk(value, [*keys, key])
        elif isinstance(node, list):
            for index, value in enumerate(node):
                walk(value, [*keys, index])
        elif isinstance(node, str):
            for expression in re.findall(r"\$\{\{(.*?)\}\}", node, re.S):
                if len(keys) >= 4 and keys[0] == "jobs" and keys[2] == "env":
                    scope, allowed = "jobs.<job_id>.env", JOB
                elif len(keys) >= 6 and keys[0] == "jobs" and keys[2] == "steps":
                    field = keys[4]
                    assert field in {"env", "with", "working-directory", "run", "if"}, keys
                    scope, allowed = "jobs.<job_id>.steps.<step>." + field, STEP
                elif len(keys) == 5 and keys[0] == "jobs" and keys[2] == "steps":
                    assert keys[4] in {"working-directory", "run", "if"}, keys
                    scope, allowed = "jobs.<job_id>.steps.<step>." + keys[4], STEP
                else:
                    raise AssertionError(("Unreviewed expression location", keys, expression))
                names = set(re.findall(r"(?<![\w.])([A-Za-z_]\w*)(?=\.)", expression))
                bad = sorted(names - allowed)
                entry = {"path": keys, "expression": expression.strip(), "scope": scope,
                         "contexts": sorted(names), "unavailable": bad}
                found.append(entry)
                if bad:
                    errors.append(entry)
    walk(document, [])
    return {"expressions": found, "errors": errors}


negative = contexts(old)
positive = contexts(new)
assert len(negative["errors"]) == 1, negative
assert negative["errors"][0]["unavailable"] == ["runner"]
assert not positive["errors"], positive
old_job = old["jobs"]["original-crash-window"]
new_job = new["jobs"]["original-crash-window"]
assert "runner" not in " ".join(new_job["env"].values())
assert old["on"] == new["on"] and old["permissions"] == new["permissions"]
assert len(old_job["steps"]) == len(new_job["steps"])
unchanged = []
for index, (before, after) in enumerate(zip(old_job["steps"], new_job["steps"])):
    if index == 0:
        continue
    if "run" in before:
        assert before["run"] == after["run"], (index, before["name"])
        unchanged.append({"step": before["name"], "sha256": hashlib.sha256(before["run"].encode()).hexdigest()})
    if "uses" in before:
        assert before["uses"] == after["uses"]

initial = new_job["steps"][0]
collector = new_job["steps"][6]
upload = new_job["steps"][7]
assert initial["env"]["EVIDENCE_DIR"] == collector["env"]["EVIDENCE_DIR"]
assert upload["with"]["path"] == initial["env"]["EVIDENCE_DIR"] + "/"
assert "Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append" in initial["run"]
assert "mkdir" not in initial["run"] and "New-Item" not in initial["run"]
assert collector["if"] == upload["if"] == "always()"
for temporary in [r"D:\a\_temp", r"D:\runner temp\with spaces"]:
    value = initial["env"]["EVIDENCE_DIR"].replace("${{ runner.temp }}", temporary)
    target = upload["with"]["path"].replace("${{ runner.temp }}", temporary)
    assert ntpath.isabs(value) and ntpath.normpath(value) == ntpath.normpath(target)

for index, step in enumerate(new_job["steps"]):
    if step.get("shell") == "bash":
        script = OUT / f"step-{index+1}.bash"
        script.write_text(step["run"])
        subprocess.run(["bash", "-n", str(script)], check=True)

# One new synthetic control: the first runner step fails before checkout/setup
# and before GITHUB_ENV can carry any value. The always-step's own valid env
# still creates a deterministic FAIL receipt, and uploads use that same path.
script = re.findall(r"<<'PY'\n(.*?)\nPY(?:\n|$)", collector["run"], re.S)
assert len(script) == 1
failure_root = OUT / "bootstrap-failure-control"
failure_root.mkdir(exist_ok=False)
evidence = failure_root / "memory-lifecycle-diagnostic"
env = {key: value for key, value in os.environ.items() if key not in {"BAZEL_OUTPUT_BASE", "EVIDENCE_DIR"}}
env.update(EVIDENCE_DIR=str(evidence), MEMORY_CASE=new_job["env"]["MEMORY_CASE"])
result = subprocess.run([sys.executable, "-c", script[0]], env=env, cwd=failure_root, capture_output=True)
(failure_root / "collector.stdout").write_bytes(result.stdout)
(failure_root / "collector.stderr").write_bytes(result.stderr)
failure = json.loads((evidence / "diagnostic-result.json").read_text())
assert result.returncode == 1 and failure["result"] == "FAIL", failure
assert (evidence / "members.json").is_file()
assert any("BAZEL_OUTPUT_BASE" in error for error in failure["errors"]), failure

report = {
    "scope": "Exact GitHub expression-location review and one synthetic bootstrap-failure control; no native Windows or Rust run",
    "official_reference": "https://docs.github.com/en/actions/reference/workflows-and-actions/contexts#context-availability",
    "official_environment_file_reference": "https://docs.github.com/en/actions/reference/workflow-commands-for-github-actions#setting-an-environment-variable",
    "before_sha256": hashlib.sha256(BEFORE.read_bytes()).hexdigest(),
    "after_sha256": hashlib.sha256(AFTER.read_bytes()).hexdigest(),
    "original_registration_error_detected": negative["errors"],
    "fixed_workflow_all_expressions": positive["expressions"],
    "remaining_expression_errors": positive["errors"],
    "unchanged_executable_bash_blocks": unchanged,
    "original_17_receipt_and_4_pipeline_controls": "Exact validated blocks unchanged; not rerun",
    "first_step_creates_evidence_directory": False,
    "deterministic_evidence_path_in_success_and_bootstrap_failure": True,
    "bootstrap_failure_control": {"exit_code": result.returncode, "receipt": failure},
    "status": "PASS",
}
(OUT / "context-and-bootstrap-review.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": "PASS", "expressions_reviewed": len(positive["expressions"]),
                  "old_negative_errors": len(negative["errors"]), "new_errors": len(positive["errors"]),
                  "new_bootstrap_failure_control": "PASS", "new_native_runs": 0}))
