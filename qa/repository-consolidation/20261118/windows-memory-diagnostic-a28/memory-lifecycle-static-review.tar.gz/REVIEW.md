# Memory lifecycle crash-window failure: static contract and performance review

## Scope and conclusion

This is a read-only source audit at published integration commit `9a96facdfb878162bb0427b5313fd53a6996a5d4`. It addresses the original Windows Bazel failure of `local_lifecycle::tests::indeterminate_crash_window_replays_as_terminal_and_releases` at integration `770179d123b879355b53db1d75f8f9f301280d3e`. The lifecycle source is the same Git blob, `bf8721d9c2b719dce24f4f571ab3a7bf57d160de`. Every targeted source file copied for this review is pinned in `source-manifest.json`.

**No root cause is established by the original failure log.** Static analysis narrows the failing stage and identifies the observations needed to distinguish a replay error, a timeout before commit, and a commit whose acknowledgement missed the timeout. There is no demonstrated new optimization annotation omission and no nested SQLite write transaction in the reviewed replay path. No source was modified, no native test was run, and no remote ref was written by this audit.

## What the original result establishes

The raw Windows `test.log` records an assertion failure at lifecycle line 693, `guard.active.is_none()`. Its first libtest invocation reports 79 passes and one failure; a second invocation reports another 20 passes. The log contains no error value, timeout marker, phase duration, or journal snapshot for the failing operation. The full target took multiple seconds, but those aggregate times are not a measurement of this case or its finalization phase.

The fixture at lifecycle lines 636–710 creates one temporary store and successfully records `mark_indeterminate` before recreating the contributor and turn state with the same thread/turn identifiers. Both contributors share the same `Arc<CognitiveStore>`. It does not close and reopen SQLite. Initialization, migrations, and store-open integrity verification therefore precede this timed replay; the fixture models loss of host-turn state, not a database process restart. The old state and cloned handle also remain referenced for the later count assertion, but do not hold a live transaction.

In `on_turn_start` (lines 215–348), an acquisition error or acquisition timeout returns with no active handle. Therefore this observed assertion establishes that acquisition returned a handle. Under the intended intact fixture journal, it is an exact replay of the existing active lease. A successful `Released` result clears `active` and sets `terminal_started`; both finalization `Err` and timeout preserve the handle. The other possible successful replay states, `NotAdmitted` and `Queued`, would also ultimately retain an active handle, but would contradict the successfully committed admission and indeterminate transition expected in this isolated fixture. The original log does not identify which branch was actually taken.

## Exact expected replay work

The production constant remains `Duration::from_millis(250)` (lifecycle line 39). Acquisition and replay finalization each receive their own 250 ms timeout; there is no single 250 ms allowance spanning both calls.

`LocalLeaseOutbox::finalize_replayed_occurrence` (outbox lines 3245–3335) begins one guarded `BEGIN IMMEDIATE`, verifies the current lease and complete event/outbox chains, verifies pairing and the exact occurrence, checks all other unresolved work, audits compact journals related to this lease in the **same transaction**, appends a `Released` lease, and waits for `COMMIT`. Only then does it return `Released`.

For this fixture's expected one active lease row, two event rows, one outbox row, and no compact events, the explicit database work is:

| Step | Source | Explicit SQLite commands |
| --- | --- | --- |
| Guarded write transaction | `cognitive_store_barrier.rs:13–34` | `BEGIN IMMEDIATE` |
| Current lease-chain validation | `local_lease_outbox.rs:3377`, `3817–3960` | 1 `SELECT` |
| Event-chain validation | `local_lease_outbox.rs:4404–4515` | 2 `SELECT`s: active fences and event rows |
| Outbox-chain validation | `local_lease_outbox.rs:4678–4785` | 2 `SELECT`s: active fences and outbox rows |
| Original admission | `local_lease_outbox.rs:4960–4990` | 1 `SELECT` |
| Original outbox | `local_lease_outbox.rs:5049–5079` | 1 `SELECT` |
| Occurrence outcome replay | `local_lease_outbox.rs:5101–5134` | 1 `SELECT` |
| Related compact-journal discovery | `local_compact_executor.rs:1074–1100` | 1 `SELECT`, including its subquery |
| Terminal lease append | `local_lease_outbox.rs:3726–3798` | 1 `INSERT` |
| Durable finish | `local_lease_outbox.rs:3324–3328` | `COMMIT` |

Thus the expected finalization path has nine explicit `SELECT` statements, one `INSERT`, `BEGIN`, and `COMMIT`. This is a source-level command count, excluding pool acquisition, connection checks, worker messages, SQLite internals, triggers, and any new-connection setup. The empty compact-journal result avoids its per-journal loop. The fixture has no `retirement_acknowledged` events, so the two retirement-specific validation loops (`local_retirement_ack.rs:76–115`) inspect no matching records. The unresolved-outcome check is in memory and intentionally excludes the one non-queued occurrence being finalized, while retaining the guard for every other occurrence.

Acquisition has already independently verified this same lease/event/outbox evidence before finalization. Finalization also rechecks individual admission/outbox rows and occurrence events after the full chains. These repeated checks are statically present, but the fixture is small and no profile identifies them as the bottleneck. This review does not propose removing checks or weakening evidence completeness.

## SQLite durability and cancellation boundary

The fixture opens the legacy, unmanaged CognitiveStore. It has no bound publication owner, recovery checkpoint barrier, or separate observation pool. Its commit gate is initially open and unmanaged; `begin_write_transaction` does not enter the managed publication path. The compact verifier takes the existing transaction instead of opening a second writer, so the historical nested-transaction explanation does not match this source.

`codex-rs/state/src/sqlite.rs:344–414` opens the evidence pool with WAL, `synchronous=FULL`, a 5-second busy timeout, and up to five connections. Each connection gets the commit hook and checkout checks. The 5-second SQLite busy allowance can exceed the 250 ms lifecycle future timeout. This is a configuration fact, **not evidence that SQLite was busy in this run**. Other fixtures generally own separate temporary databases; shared disk/CPU/worker scheduling pressure is a different hypothesis from a lock held on this fixture's database.

The vendored SQLx SQLite worker is relevant to interpreting the result. `connection/worker.rs` uses a dedicated thread for each connection and asynchronously exchanges commands and acknowledgements. Its `Command::Commit` handling (lines 279–300) executes SQLite `COMMIT` before acknowledging it. If commit succeeds but acknowledgement is cancelled, it explicitly sets `ignore_next_start_rollback`, preventing the subsequent drop rollback from undoing an already completed transaction. This is deliberate library behavior.

Consequently, a retained `active` handle after a lifecycle timeout does **not** by itself prove that the `Released` lease row is absent. A commit may have completed while its acknowledgement was lost to cancellation. Conversely, a timeout before terminal append/commit can leave the original active journal. The current raw failure does not distinguish these outcomes. Preserving a recoverable handle on an error is the current conservative contract; this audit does not recommend eagerly clearing it or treating timeout as success.

## Crypto and build-profile comparison

The local path uses SHA-256: `Sha256Digest::for_bytes` and `from_sha256_output` in `hepta-contracts/src/receipt.rs`, and length-framed SHA-256 in `local_lease_outbox.rs:5449–5640`. `Digest32` also uses `sha2::Sha256`, but this fixture's local journal path uses `Sha256Digest`. Its path does not perform Ed25519/PQ signature verification, a Matrix KDF, external provider dispatch, or KG writes.

The workspace selects `sha2 = "0.10"`; its lock resolves the relevant backend to `0.10.9`. The lock also includes `sha2 0.11.1` for other consumers. Both Cargo and MODULE explicitly configure the following exact versions at optimization level 3:

| Package | Exact version | Cargo `[profile.dev.package]` | MODULE `crate.annotation` |
| --- | --- | --- | --- |
| `matrix-sdk-store-encryption` | `0.19.1` | 3 | `-Copt-level=3` |
| `sha2` | `0.10.9` | 3 | `-Copt-level=3` |
| `sha2` | `0.11.1` | 3 | `-Copt-level=3` |
| `ed25519-dalek` | `2.2.0` | 3 | `-Copt-level=3` |
| `curve25519-dalek` | `4.1.3` | 3 | `-Copt-level=3` |

The earlier missing SHA-256 annotation is present at this head. The lock additionally contains Ed25519 3.0.0 and curve25519 5.0.0; neither is configured by these five overrides, but neither is identified as an executed crypto backend in this fixture, so their presence is not a new defect. SQLx is `0.9.0` with the in-repository SQLite patch; SQLite bindings are `libsqlite3-sys 0.39.1`; Tokio is `1.53.3`. Exact parsed data is retained in `optimization-lock-comparison.json`.

These are verified configuration and source facts, not proof of the rustc command that produced the failed Windows executable. If build optimization remains a suspect, the decisive next evidence is the actual locked Windows Bazel action/params for `sha2 0.10.9`, including its final optimization flags and source identity. No current annotation change is justified solely by this failure.

The qualification-clock Bazel graph keeps a test-only CognitiveStore feature closure. This fixture uses the ordinary store's real lease clock and an unbound lease with no expiry field; the lifecycle timeout is still Tokio's independent 250 ms timeout. The qualification graph does not statically extend that timeout.

## Windows invocation context

`workspace_root_test_launcher.bat.tpl` routes the standard Windows config through selected-libtest invocation when `CODEX_BAZEL_TEST_SKIP_FILTERS` is defined. It sorts the selected tests and splits the command into batches at a 7000-character threshold, invoking each batch with `--exact`. This accounts for the two disjoint libtest groups in the raw target log; they are not evidence of retrying the failed case. The standard `ci-windows` configuration sets skip filters but does not set `RUST_TEST_THREADS=1`; that setting belongs to `ci-windows-cross`. The reviewed target supplies no explicit thread limit. The actual inherited runtime thread count is not recorded in the old log.

The peer's original single-case Windows baseline is therefore useful, but a single isolated PASS would only establish that the exact original case can pass in that execution context. It would not prove whether the original failure was scheduling pressure, durable I/O latency, an error, or another intermittent condition.

## Discriminating diagnostics, in priority order

1. Finish the already planned original single-case Windows run, preserving the original binary target, 250 ms budget, assertions, and attempt count. Capture exact source/tree, tool/configuration identity, original log/XML, and terminal exit. Do not label an isolated pass a root-cause finding.
2. If a diagnostic copy is then authorized, record only the branch and result at acquisition/finalization: `Acquired` versus `Replay`; finalization `NotAdmitted`, `Queued`, `Released`, exact error, or elapsed timeout; and monotonic phase durations. This separates semantic/SQLite errors from a missed deadline without changing the deadline.
3. For a timeout, collect an observation-only snapshot of the original lease/event/outbox state after the async worker settles. Distinguish an active journal from a durable released row whose acknowledgement was missed. Do not perform a repair, synthetic transition, re-admission, or retry while collecting this evidence.
4. Time pool checkout/begin, chain checks, original-row checks, compact lookup, terminal insert, and commit separately in that diagnostic copy. This discriminates durable I/O, worker handoff/scheduling, connection setup, and CPU/hash work. Never infer the slow phase from the full target's duration.
5. Only if the measurements point to CPU/hash work, inspect actual Bazel action flags before changing optimization. If they point to commit, preserve WAL/FULL durability and the lease/caller contract; a timeout increase or skipped verification would not establish a correct fix.

The most plausible unproven performance families are async worker scheduling/host load and durable SQLite completion latency. A typed verification or SQLite error remains possible until the result is observed. The audit supplies no evidence ranking those hypotheses quantitatively and intentionally proposes no production patch.
