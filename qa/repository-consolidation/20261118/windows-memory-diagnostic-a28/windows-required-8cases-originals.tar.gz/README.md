# Actual Windows required-check failures, PR #6293 / 770179d

This archive binds eight terminal failing test cases to GitHub Actions run 44331198533, attempt 1. The two jobs checked out prospective merge 2166fcf3e563bf93302fa1e6ee65f76093ab2a87. Its tree is exactly the PR head 770179d tree, 6911d7b83a7d2ae573efb4fbe08446f748a7a3a4.

Outer Bazel shard 3 (job 134916789892) fails the Agentd unit target in 3 of its 4 inner shards. Seven original tests print that peer user identity is unavailable on this platform, reject unauthenticated Agentd peers, then fail with ConnectionReset 10054. The separate fd5 session owns that Windows peer implementation work.

Outer Bazel shard 1 (job 134916789872) fails one ext/hepta-memory case: local_lifecycle::tests::indeterminate_crash_window_replays_as_terminal_and_releases. Its original assertion at local_lifecycle.rs:693 requires guard.active.is_none(). The current source deliberately retains this handle when replay finalization errors or times out within its unchanged 250ms budget. Original CI did not record the internal Result or phase timings, so timeout, SQLite error, and unexpected replay disposition remain distinct hypotheses.

The local_lifecycle file is byte-identical in 770179d, b7480ac, and the captured fd5 working file. The underlying acquire_local_lease and finalize_replayed_occurrence function bodies are also byte-identical between these commits. The unrelated Notes fence delta has been reviewed; no direct lifecycle fix was found. This is not a proof that every indirect dependency/platform effect is absent.

Four complete, original failed-target test.log files are present, retaining the passing batches as well as failures. The original GitHub artifacts contained no XML. windows-8-failing-cases.json maps every failing case to its unedited stdout and the source/job/artifact identities. Both complete original job logs, download receipts and original-byte manifest are nested in windows-bazel-joblogs-originals.tar.gz (6 verified members). The outer shard 1 Core target's recovered FLAKY result is explicitly separate from these terminal failures.

No source patch, skipped test, raised deadline, remote mutation, or new native execution is part of this evidence package. memory-crash-window-readonly-review.json records the bounded isolated Windows reproduction plan with all original inputs, assertions, fail-closed state and the 250ms production budget retained.
