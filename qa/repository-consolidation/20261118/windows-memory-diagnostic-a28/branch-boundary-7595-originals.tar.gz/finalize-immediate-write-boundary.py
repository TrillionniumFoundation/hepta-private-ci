from collections import deque
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile

A = Path('/workspace/scratch/a28fa6a6513a/audit')
PREFIX = 'refs-immediately-before-write'
previous = json.loads((A / 'hia-boundary-before-batch-write.json').read_text())
delta = json.loads((A / (PREFIX + '.json')).read_text())
snapshot = A / (PREFIX + '.tsv')
assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == delta['sha256']
refs = {}
for line in snapshot.read_text().splitlines():
    sha, ref = line.split('\t')
    assert ref.startswith('refs/heads/') and ref[11:] not in refs
    refs[ref[11:]] = sha
assert len(refs) == delta['count'] == 7595
assert len(delta['new']) == 2 and len(delta['moved']) == 4 and not delta['deleted']

graph = json.loads((A / 'frontier/parents_for_analysis.json').read_text())
sources = {sha: 'frontier/parents_for_analysis.json' for sha in graph}
def add(sha, parents, source):
    if sha in graph:
        assert graph[sha] == parents, sha
    else:
        graph[sha] = parents
        sources[sha] = source
for item in json.loads((A / 'new_graph_edges_all.json').read_text()):
    add(item['sha'], item['parents'], 'new_graph_edges_all.json')
for sha, parents in json.loads((A / 'refs-before-next-batch-hia-proof.json').read_text())['actual_parent_edges'].items():
    add(sha, parents, 'refs-before-next-batch-hia-proof.json')
for sha, parents in json.loads((A / 'refs-before-batch-write-incremental-hia-proof.json').read_text())['new_commit_parent_records'].items():
    add(sha, parents, 'refs-before-batch-write-incremental-hia-proof.json')
known_before = set(graph)
new = {}
for filename in sorted(A.glob(PREFIX + '-commit-objects-*.json')):
    for item in json.loads(filename.read_text()):
        parents = [p['sha'] for p in item['parents']]
        add(item['sha'], parents, filename.name)
        new[item['sha']] = parents
assert len(new) == 7
missing = sorted({p for parents in new.values() for p in parents} - known_before - set(new))
assert not missing
roots = [r['sha'] for r in previous['graph_roots']]
anchor = previous['retained_graph_anchor']['sha']
boundaries = set(roots + [anchor])
comparisons = json.loads((A / (PREFIX + '-root-comparisons.json')).read_text())
assert len(comparisons) == 18
by_tip = {}
for item in comparisons:
    c = item['comparison']
    ancestor = c['merge_base_commit']['sha'] == item['root']
    assert ancestor == (c['status'] in ('ahead', 'identical'))
    by_tip.setdefault(item['tip'], {})[item['root']] = {
        'ancestor': ancestor, 'status': c['status'],
        'ahead_by': c['ahead_by'], 'behind_by': c['behind_by'],
        'merge_base': c['merge_base_commit']['sha'], 'url': item['url'],
    }
assert len(by_tip) == 6 and all(set(v) == boundaries for v in by_tip.values())

def ancestry_path(start, targets):
    pending = deque([(start, [start])])
    visited = set()
    while pending:
        sha, path = pending.popleft()
        if sha in targets:
            return path
        if sha in visited:
            continue
        visited.add(sha)
        assert sha in graph, ('missing actual commit parent record', sha)
        for parent in graph[sha]:
            pending.append((parent, path + [parent]))
    return None

protected = {row['name']: dict(row) for row in previous['protected_branches']}
changes = []
for ref, sha in delta['new'].items():
    name = ref[11:]
    proof = by_tip[sha]
    assert name not in protected and proof[roots[1]]['ancestor']
    assert not proof[roots[0]]['ancestor'] and not proof[anchor]['ancestor']
    path = ancestry_path(sha, boundaries)
    assert path and path[-1] == roots[1]
    protected[name] = {
        'name': name, 'sha': sha,
        'reasons': ['real_parent_path_to_Cell_HIA_root_and_independent_root_comparisons'],
        'ancestry_path': path,
    }
    changes.append({'name': name, 'type': 'new_protected', 'sha': sha,
                    'ancestry_path': path, 'root_and_anchor_comparisons': proof})
for ref, move in delta['moved'].items():
    name = ref[11:]
    assert name in protected and protected[name]['sha'] == move['old']
    sha = move['new']
    proof = by_tip[sha]
    assert any(v['ancestor'] for v in proof.values())
    path = ancestry_path(sha, boundaries)
    forward = ancestry_path(sha, {move['old']})
    assert path and forward
    assert all(len(graph[node]) == 1 for node in forward[:-1])
    protected[name] = {**protected[name], 'sha': sha, 'previous_sha': move['old'],
                       'ancestry_path': path, 'observed_external_fast_forward': True}
    changes.append({'name': name, 'type': 'moved_protected', **move,
                    'ancestry_path': path, 'actual_parent_path_to_previous_tip': forward,
                    'root_and_anchor_comparisons': proof})
assert len(protected) == 370
for name, item in protected.items():
    assert refs[name] == item['sha']
ordinary = {name: sha for name, sha in refs.items() if name not in protected and name != 'main'}
assert len(ordinary) == 7224
protected_raw = ''.join(f"{protected[n]['sha']}\t{n}\n" for n in sorted(protected)).encode()
ordinary_raw = ''.join(f'{ordinary[n]}\t{n}\n' for n in sorted(ordinary)).encode()
(A / 'protected-hia-refs-immediately-before-write.tsv').write_bytes(protected_raw)
(A / 'ordinary-refs-immediately-before-write.tsv').write_bytes(ordinary_raw)

head = '9a96facdfb878162bb0427b5313fd53a6996a5d4'
env = os.environ.copy()
env['GIT_NO_LAZY_FETCH'] = '1'
git = ['git', '--git-dir', '/tmp/hepta-a28-repo/.git']
raw_graph = subprocess.check_output(git + ['rev-list', '--parents', head], env=env)
candidate_graph = {}
for line in raw_graph.decode().splitlines():
    sha, *parents = line.split()
    candidate_graph[sha] = parents
assert not ({p for parents in candidate_graph.values() for p in parents} - candidate_graph.keys())
candidate = set(candidate_graph)
assert not candidate.intersection({v['sha'] for v in protected.values()} | boundaries)
incoming = [
    '59d05538c9a2be1d1240e328648935832fac7cf4',
    '307dced98e8b40c1e8321a357e1af1cde3400fef',
    '60eb1a36e4e59291698a9652e9d5276d957f6678',
    'd5af612c3c04f9bd7f4555411edb94341fe4553a',
    '0e378dd351e0fca99d32f67613639b37c85605da',
    '7fd4b93c6fd917ad5e07115a6b2a929ea62b8964',
]
assert all(sha in candidate for sha in incoming)
covered = {name: sha for name, sha in ordinary.items() if sha in candidate}
assert len(covered) == 2070
checks = {
    'snapshot_sha256': delta['sha256'], 'protected_count': 370,
    'published_integration_head': head, 'complete_ancestor_commit_count': len(candidate),
    'complete_parent_graph_sha256': hashlib.sha256(raw_graph).hexdigest(),
    'missing_parent_records': [], 'protected_tip_intersection': [],
    'hia_root_and_anchor_intersection': [], 'ordinary_names_contained': len(covered),
    'incoming_branch_tips_in_history': incoming,
    'ordinary_total': len(ordinary), 'main': refs['main'],
    'scope': 'Actual published integration history, not a proposed union; historical source qualification is separately archived.',
}
(A / (PREFIX + '-candidate-hia-checks.json')).write_text(json.dumps(checks, indent=2) + '\n')
(A / (PREFIX + '-published-parent-graph.tsv.gz')).write_bytes(gzip.compress(raw_graph, mtime=0))
path_edges = {}
for change in changes:
    for sha in change['ancestry_path'][:-1]:
        path_edges[sha] = graph[sha]
proof = {
    'previous_complete_boundary': 'refs-before-batch-write-incremental-hia-proof.json',
    'new_commit_count': len(new), 'new_commit_parent_records': new,
    'known_parent_boundaries': sorted({p for parents in new.values() for p in parents if p not in new}),
    'known_parent_evidence_sources': {p: sources[p] for p in sorted({p for parents in new.values() for p in parents if p not in new})},
    'missing_new_commit_parents': [], 'real_parent_edges_for_changed_tip_paths': path_edges,
    'no_artificial_anchor_parent_edges': True,
}
(A / (PREFIX + '-incremental-hia-proof.json')).write_text(json.dumps(proof, indent=2) + '\n')
summary = {
    'repository': previous['repository'], 'snapshot': snapshot.name,
    'captured_at_utc': delta['recorded_at_utc'], 'snapshot_sha256': delta['sha256'],
    'branch_count': len(refs), 'protected_count': len(protected), 'ordinary_count': len(ordinary),
    'main': {'name': 'main', 'sha': refs['main']},
    'previous_boundary': 'hia-boundary-before-batch-write.json', 'previous_protected_count': 368,
    'new_protected_count': 2, 'new_ordinary_count': 0, 'moved_protected_count': 4,
    'moved_ordinary_count': 0, 'deleted_count': 0,
    'protected_branches': [protected[name] for name in sorted(protected)],
    'changes': changes, 'graph_roots': previous['graph_roots'],
    'retained_graph_anchor': previous['retained_graph_anchor'],
    'incremental_parent_proof': PREFIX + '-incremental-hia-proof.json',
    'candidate_checks': PREFIX + '-candidate-hia-checks.json',
    'tsv_sha256': {'protected': hashlib.sha256(protected_raw).hexdigest(), 'ordinary': hashlib.sha256(ordinary_raw).hexdigest()},
    'our_hia_ref_writes': 0, 'this_audit_remote_writes': 0,
}
(A / 'hia-boundary-immediately-before-write.json').write_text(json.dumps(summary, indent=2) + '\n')
compact = {k: v for k, v in summary.items() if k != 'protected_branches'}
(A / 'hia-boundary-immediately-before-write-compact.json').write_text(json.dumps(compact, indent=2) + '\n')
names = [PREFIX + '.json', 'protected-hia-refs-immediately-before-write.tsv',
         'hia-boundary-immediately-before-write-compact.json',
         PREFIX + '-incremental-hia-proof.json', PREFIX + '-candidate-hia-checks.json',
         PREFIX + '-root-comparisons.json', 'finalize-immediate-write-boundary.py']
names += [f.name for f in sorted(A.glob(PREFIX + '-commit-objects-*.json'))]
members = {name: (A / name).read_bytes() for name in names}
members[PREFIX + '.tsv.gz'] = gzip.compress(snapshot.read_bytes(), mtime=0)
index = {
    'snapshot_sha256': delta['sha256'],
    'members': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(members.items())],
    'ordinary_tsv_reconstruction': 'Normalize exact snapshot refs/heads/ and exclude main plus complete370protected names;7224lines/hash in compact summary.',
    'published_ancestry_reproduction': 'git rev-list --parents 9a96facdfb878162bb0427b5313fd53a6996a5d4; complete graph SHA256 is in candidate-hia-checks.',
}
members['index.json'] = (json.dumps(index, indent=2) + '\n').encode()
archive = A / (PREFIX + '-hia-evidence.tar.gz')
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, data in sorted(members.items()):
                assert len(data) < 512000
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = info.uid = info.gid = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
assert archive.stat().st_size < 512000
artifact = {'path': str(archive), 'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(members)}
(A / (PREFIX + '-hia-evidence-archive.json')).write_text(json.dumps(artifact, indent=2) + '\n')
print(json.dumps({'counts': [len(refs), len(protected), len(ordinary)], 'candidate': checks, 'artifact': artifact}, indent=2))
