# Windows Memory lifecycle baseline diagnostic

## Review disposition

Ready for root review and publication as one additive workflow, based on
`9a96facdfb878162bb0427b5313fd53a6996a5d4` (tree
`c7466f82606d312551a1266b131ad5e28e71e4ab`). This delivery has **not executed a
Windows Rust test**. The proposed hosted run obtains the first isolated baseline;
it is not a production fix and is not a replacement for either required aggregate.

The only index change is
`.github/workflows/hepta-memory-lifecycle-windows-diagnostic.yml`, 294 lines,
14,067 bytes, SHA-256
`0e71e2890c16b970fa7e38d9766cd71b42529ab32087345cc649ad9690f5aa71`.
The hypothetical candidate tree is `b57158ec41d2c663a131d441449bb51ab3ce0574`.
No integration commit or remote ref was created by this review; the receipt controls use local synthetic Git fixtures.

## Observed reason for the diagnostic

The original hosted Windows Bazel job `134916789872` at the 770179d integration
source failed `//codex-rs/ext/hepta-memory:hepta-memory-unit-tests`. Its native log
reported the original case
`local_lifecycle::tests::indeterminate_crash_window_replays_as_terminal_and_releases`
failing `guard.active.is_none()` at `local_lifecycle.rs:693`. The batch had 79
passing cases and one failure; the subsequent batch passed all 20 cases. These
are Windows libtest argument batches, not evidence of retries of this case.

The earlier complete evidence package is retained at
`audit/ci/gate-audit-770179d/windows-required-8cases-originals.tar.gz`, SHA-256
`64f1f37e68091bbac7a19fd0ed39f3119c28d2c065f1eb4fe21271d1928c5ce4`.
This new diagnostic does not supersede or remove that failure.

The lifecycle source is byte-identical at 770179d and the new 9a96fac head:
Git blob `bf8721d9c2b719dce24f4f571ab3a7bf57d160de`, SHA-256
`b77919130600f729f5d4d55a3735a2a9f4d717c55fa071e531aaf02311d4b245`.
The GitHub API contents and the immutable Git object agree. Neither the 250ms
production budget nor any test assertion is changed.

## Available execution and existing entry points

The configured Hepta host list contains five Linux aliases and two macOS aliases.
Read-only discovery on the configured ROG alias observed Linux
`7.0.0-43-generic`, no WSL environment or WSL interop binfmt entry, and no
`cmd.exe`, `powershell.exe`, `pwsh.exe`, `wsl.exe`, or `pwsh` in PATH. This is a
statement about the configured execution surfaces, not about unconfigured
machines. No guessed host or address was probed.

All 75 default-main workflow YAML files were inspected from immutable Git
objects. The five-owner Windows regression workflow and the 19-group current-CI
workflow exist in the integration candidate but are absent from main 732e934.
Existing main dispatch entry points include broad Bazel, VNext, Lane-D, Rust-full
and V8 workflows. None provides an existing arbitrary single Memory-case input.
The final root instruction selected a separate PR-path diagnostic so no existing
dispatch surface or default behavior needs modification.

## Runtime contract of the additive workflow

The new file has one Windows job, `contents: read`, and no shared cancellation
group. The PR path filter contains the workflow itself, the lifecycle source,
the lease/outbox implementation, and CognitiveStore source. Checkout explicitly
uses the PR head SHA. The original pinned checkout/upload actions and original
`prepare-bazel-ci` action are reused with the existing MSVC target and Bazel
environment.

The sole test command calls the unchanged repository Bazel wrapper and target.
It passes the full Rust case name plus `--exact` and `--nocapture`, with
`--flaky_test_attempts=1`, `--runs_per_test=1`,
`--cache_test_results=no`, and disabled sharding. It does not change a
test, a timeout, a security flag, a skip list, or a required workflow.

The native Windows launcher was reviewed at 9a96fac. Explicit libtest arguments
take its original direct-execution branch, so this command does not use the
unfiltered 7,000-character test batching path. The unchanged production test body
is the unit of observation. A passing isolated result would not prove that the
original concurrent full-target failure is resolved.

The workflow records exact checked-out source/tree, source-file hashes, platform,
runner tool versions, the full argv, start/end times, the original Bazel exit and
log-capture exit, and complete merged stdout/stderr. The collector first copies
all target `.log` and `.xml` files before reading receipts, preserving raw results
even if a receipt is missing. It then requires exactly one target/log/XML,
`running 1 test`, exactly the requested Rust case, one completed case, no ignored
or measured case, and a passing native summary. Any failure, duplicate, skip,
retry, missing evidence, changed source, or nonzero exit remains a failure.

Bazel's original `test.xml` may identify the target wrapper as a single JUnit
testcase. Exact Rust-case identity comes from the raw libtest name, running count,
and summary together. The collector deliberately does not equate an XML wrapper
name with the Rust case name. Original XML bytes are retained without synthesis.

## Validation and maintenance

- The final YAML parses; all Bash blocks passed `bash -n`; all five embedded
  Python blocks parsed before maintenance.
- Seventeen synthetic receipt controls exercised the exact collector. The one
  valid original-case receipt passes; failure, zero/duplicate/wrong case, ignored
  case, empty JUnit skip, inconsistent/missing/malformed JUnit, retry recovery,
  process/log exit failure, missing receipt, and changed source are rejected.
- Four synthetic Bash pipeline controls exercised the exact run step. They
  verified one wrapper invocation, unchanged selected argv, complete stdout and
  stderr capture, preservation of Bazel exit 3, log-capture failure, and Bazel's
  original exit when both fail. These controls execute no Rust test.
- Codespell 2.4.3 passed using the original 9a ignore file.
- Prettier 3.5.3 with the original 9a TOML configuration completed successfully
  without changing a byte.
- The real `/home/qian-qi/.cargo/bin/just fmt --base 9a96fac...` ran in a separate
  ROG sparse checkout of the exact 9a commit/tree. It exited zero in 0.077 seconds;
  the original formatter correctly selected no Rust/Python/Starlark group for a
  YAML-only change. Its complete durable job is `1a1ef8a4507-ffbe-535`.
- No test was rerun after maintenance. Read-only byte comparisons prove the final
  workflow and its embedded validated scripts are unchanged.

## Scope, ancestry, and remaining uncertainty

The existing `blocking-ci.yml`, `bazel.yml`, Architecture workflow, five-owner
Windows workflow, and 19-group Windows workflow are byte-identical. The full
index diff contains one added path and no other changes. No existing trigger,
schedule, push/PR behavior, input, matrix, job, or aggregate dependency changes.

The existing published-base ancestry report covers all 40,872 ancestors of 9a,
with no missing parent records, no intersection with the 370 protected tips, and
no HIA root/anchor intersection. This additive working-tree patch creates no
ancestry and writes no branch. The root must continue its normal fresh-boundary
check when publishing or deleting refs.

The original log does not distinguish a returned replay-finalization error, a
250ms timeout, or a late transaction commit. The separate static Memory review
documents why a retained active handle alone does not prove that release failed
to commit. This baseline intentionally leaves those production branches intact.
If it fails, the next diagnostic should record finalization result/elapsed time
and inspect original durable chain state without extending the deadline,
releasing an extra lease, skipping a case, or relaxing an assertion.
