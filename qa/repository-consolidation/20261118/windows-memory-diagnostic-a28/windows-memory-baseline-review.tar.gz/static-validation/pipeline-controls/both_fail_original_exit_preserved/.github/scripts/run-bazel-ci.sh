#!/usr/bin/env bash
printf 'synthetic wrapper stdout\n'
printf 'synthetic wrapper stderr\n' >&2
printf 'invoked\n' >> "${EVIDENCE_DIR}/wrapper-count.txt"
exit "${MOCK_BAZEL_EXIT}"
