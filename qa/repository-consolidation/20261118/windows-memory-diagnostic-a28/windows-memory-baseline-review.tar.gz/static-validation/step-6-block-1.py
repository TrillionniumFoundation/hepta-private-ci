import datetime
import json
import os
from pathlib import Path
import sys

record = {"argv": sys.argv[1:], "cwd": os.getcwd(),
          "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat()}
(Path(os.environ["EVIDENCE_DIR"]) / "invocation.json").write_text(
    json.dumps(record, indent=2) + "\n")
