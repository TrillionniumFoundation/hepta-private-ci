"""Check the exact workflow Bash step with a synthetic command, never Rust."""

import hashlib
import json
import os
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
SCRIPT = ROOT / "step-6.bash"
CASE = "local_lifecycle::tests::indeterminate_crash_window_replays_as_terminal_and_releases"
TARGET = "//codex-rs/ext/hepta-memory:hepta-memory-unit-tests"
records = []
for name, bazel_exit, tee_exit, expected in [
    ("success", 0, 0, 0),
    ("original_failure", 3, 0, 3),
    ("capture_failure", 0, 5, 5),
    ("both_fail_original_exit_preserved", 3, 5, 3),
]:
    root = ROOT / "pipeline-controls" / name
    wrapper = root / ".github/scripts/run-bazel-ci.sh"
    wrapper.parent.mkdir(parents=True, exist_ok=False)
    wrapper.write_text(
        "#!/usr/bin/env bash\n"
        "printf 'synthetic wrapper stdout\\n'\n"
        "printf 'synthetic wrapper stderr\\n' >&2\n"
        "printf 'invoked\\n' >> \"${EVIDENCE_DIR}/wrapper-count.txt\"\n"
        "exit \"${MOCK_BAZEL_EXIT}\"\n"
    )
    wrapper.chmod(0o755)
    out = root / "evidence"
    out.mkdir()
    tools = root / "tools"
    tools.mkdir()
    if tee_exit:
        tee = tools / "tee"
        tee.write_text(
            "#!/usr/bin/env python3\n"
            "import pathlib,sys\n"
            "data=sys.stdin.buffer.read()\n"
            "pathlib.Path(sys.argv[1]).write_bytes(data)\n"
            "sys.stdout.buffer.write(data)\n"
            "raise SystemExit(5)\n"
        )
        tee.chmod(0o755)
    env = {
        **os.environ, "PATH": str(tools) + os.pathsep + os.environ["PATH"],
        "EVIDENCE_DIR": str(out), "MEMORY_CASE": CASE, "MEMORY_TARGET": TARGET,
        "SOURCE_SHA": "9a96facdfb878162bb0427b5313fd53a6996a5d4",
        "MOCK_BAZEL_EXIT": str(bazel_exit),
    }
    result = subprocess.run(["bash", str(SCRIPT)], cwd=root, env=env, capture_output=True)
    (root / "step.stdout").write_bytes(result.stdout)
    (root / "step.stderr").write_bytes(result.stderr)
    execution = json.loads((out / "execution-result.json").read_text())
    invocation = json.loads((out / "invocation.json").read_text())
    assert result.returncode == expected, (name, result)
    assert execution["bazel_exit_code"] == bazel_exit
    assert execution["tee_exit_code"] == tee_exit
    assert (out / "wrapper-count.txt").read_text() == "invoked\n"
    assert (out / "bazel.stdout-stderr.log").read_text() == "synthetic wrapper stdout\nsynthetic wrapper stderr\n"
    args = invocation["argv"]
    for flag in ["--flaky_test_attempts=1", "--runs_per_test=1", "--cache_test_results=no",
                 "--test_sharding_strategy=disabled", "--test_arg=" + CASE, "--test_arg=--exact"]:
        assert args.count(flag) == 1, (name, flag, args)
    assert args[-2:] == ["--", TARGET], args
    records.append({"name": name, "expected_exit": expected, "actual_exit": result.returncode,
                    "execution": execution, "wrapper_executions": 1, "argv": args})
report = {"scope": "Synthetic pipeline control, not native Windows/Rust execution",
          "script_sha256": hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
          "total": len(records), "checks": records, "status": "PASS"}
(ROOT / "pipeline-controls-report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"total": len(records), "status": "PASS", "scope": report["scope"]}))
