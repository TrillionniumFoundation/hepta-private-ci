"""Exercise the workflow's exact collector against synthetic receipt controls.

These are validator checks on Linux, not a Windows Rust qualification.
"""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
COLLECTOR = ROOT / "step-7-block-1.py"
CASE = "local_lifecycle::tests::indeterminate_crash_window_replays_as_terminal_and_releases"
CONTROLS = ROOT / "receipt-controls"
CONTROLS.mkdir(exist_ok=True)


def log_text(count=1, passed=1, failed=0, ignored=0, names=None):
    names = [CASE] if names is None else names
    status = "FAILED" if failed else "ok"
    return (
        f"running {count} test{'s' if count != 1 else ''}\n"
        + "".join(f"test {name} ... {status}\n" for name in names)
        + f"\ntest result: {status}. {passed} passed; {failed} failed; "
        + f"{ignored} ignored; 0 measured; 99 filtered out; finished in 0.10s\n"
    )


def xml_text(*, failure=False, skipped=False, tests=1, failure_count=0):
    child = "<failure message='original assertion failed'/>" if failure else ""
    child += "<skipped/>" if skipped else ""
    return (
        f'<testsuites tests="{tests}" failures="{failure_count}">'
        f'<testsuite tests="{tests}" failures="{failure_count}">'
        f'<testcase name="hepta-memory-unit-tests">{child}</testcase>'
        "</testsuite></testsuites>"
    )


def check(name, expected_exit, mutate):
    case_root = CONTROLS / name
    if case_root.exists():
        raise RuntimeError(f"Refuse to overwrite control evidence: {case_root}")
    repo = case_root / "repo"
    repo.mkdir(parents=True)
    subprocess.run(["git", "init", "-q", str(repo)], check=True)
    source = repo / "source.rs"
    source.write_bytes(b"// Synthetic receipt fixture; no production code.\n")
    subprocess.run(["git", "-C", str(repo), "add", "source.rs"], check=True)
    subprocess.run(
        ["git", "-C", str(repo), "-c", "user.name=Receipt control", "-c",
         "user.email=receipt-control@invalid.example", "commit", "-qm", "Synthetic fixture"],
        check=True,
    )
    sha = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    out = case_root / "evidence"
    out.mkdir()
    target = case_root / "bazel" / "execroot" / "_main" / "bazel-out" / "x64_windows-fastbuild" / "testlogs" / "codex-rs" / "ext" / "hepta-memory" / "hepta-memory-unit-tests"
    target.mkdir(parents=True)
    (target / "test.log").write_text(log_text())
    (target / "test.xml").write_text(xml_text())
    identity = {
        "expected_source_sha": sha,
        "source_files": [{"path": "source.rs", "sha256": hashlib.sha256(source.read_bytes()).hexdigest()}],
    }
    execution = {"bazel_exit_code": 0, "tee_exit_code": 0}
    mutate(repo, out, target, identity, execution)
    (out / "identity.json").write_text(json.dumps(identity))
    if name != "missing_execution_receipt":
        (out / "execution-result.json").write_text(json.dumps(execution))
    env = {**os.environ, "EVIDENCE_DIR": str(out), "MEMORY_CASE": CASE,
           "BAZEL_OUTPUT_BASE": str(case_root / "bazel")}
    result = subprocess.run([sys.executable, str(COLLECTOR)], cwd=repo, env=env, capture_output=True)
    (case_root / "collector.stdout").write_bytes(result.stdout)
    (case_root / "collector.stderr").write_bytes(result.stderr)
    report = json.loads((out / "diagnostic-result.json").read_text())
    if result.returncode != expected_exit:
        raise AssertionError((name, result.returncode, expected_exit, report))
    if (report["result"] == "PASS") != (expected_exit == 0):
        raise AssertionError((name, report))
    if name == "missing_execution_receipt" and not list((out / "raw").rglob("test.log")):
        raise AssertionError("Raw logs were lost when the execution receipt was missing")
    members = json.loads((out / "members.json").read_text())
    for item in members:
        data = (out / item["path"]).read_bytes()
        if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
            raise AssertionError((name, item))
    return {"name": name, "expected_exit": expected_exit, "actual_exit": result.returncode,
            "result": report["result"], "errors": report["errors"], "member_hashes": "PASS"}


records = []
records.append(check("one_original_case_pass", 0, lambda *args: None))


def failed(repo, out, target, identity, execution):
    (target / "test.log").write_text(log_text(passed=0, failed=1))
    (target / "test.xml").write_text(xml_text(failure=True, failure_count=1))
    execution["bazel_exit_code"] = 3


records.append(check("one_original_case_failed", 1, failed))
records.append(check("zero_tests", 1, lambda r, o, t, i, e: (t / "test.log").write_text(log_text(count=0, passed=0, names=[]))))
records.append(check("duplicated_original_case", 1, lambda r, o, t, i, e: (t / "test.log").write_text(log_text(count=2, passed=2, names=[CASE, CASE]))))
records.append(check("different_case", 1, lambda r, o, t, i, e: (t / "test.log").write_text(log_text(names=["different::case"]))))
records.append(check("ignored_original_case", 1, lambda r, o, t, i, e: (t / "test.log").write_text(log_text(passed=0, ignored=1))))
records.append(check("empty_junit_skip_element", 1, lambda r, o, t, i, e: (t / "test.xml").write_text(xml_text(skipped=True))))
records.append(check("junit_failed_count_without_child", 1, lambda r, o, t, i, e: (t / "test.xml").write_text(xml_text(failure_count=1))))
records.append(check("junit_count_disagrees", 1, lambda r, o, t, i, e: (t / "test.xml").write_text(xml_text(tests=2))))
records.append(check("missing_junit", 1, lambda r, o, t, i, e: (t / "test.xml").unlink()))
records.append(check("malformed_junit", 1, lambda r, o, t, i, e: (t / "test.xml").write_text("<broken>")))


def retried(repo, out, target, identity, execution):
    attempts = target / "test_attempts"
    attempts.mkdir()
    (attempts / "attempt_1.log").write_text(log_text(passed=0, failed=1))


records.append(check("recovered_retry", 1, retried))
records.append(check("bazel_nonzero_with_pass_log", 1, lambda r, o, t, i, e: e.update(bazel_exit_code=3)))
records.append(check("log_capture_failed", 1, lambda r, o, t, i, e: e.update(tee_exit_code=1)))
records.append(check("missing_execution_receipt", 1, lambda *args: None))
records.append(check("source_identity_changed", 1, lambda r, o, t, i, e: i.update(expected_source_sha="0" * 40)))
records.append(check("source_bytes_changed", 1, lambda r, o, t, i, e: (r / "source.rs").write_text("// changed\n")))
report = {"scope": "Synthetic fail-closed receipt controls, not Windows native execution",
          "collector_sha256": hashlib.sha256(COLLECTOR.read_bytes()).hexdigest(),
          "checks": records, "total": len(records), "status": "PASS"}
(ROOT / "receipt-controls-report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"total": len(records), "status": report["status"], "scope": report["scope"]}))
