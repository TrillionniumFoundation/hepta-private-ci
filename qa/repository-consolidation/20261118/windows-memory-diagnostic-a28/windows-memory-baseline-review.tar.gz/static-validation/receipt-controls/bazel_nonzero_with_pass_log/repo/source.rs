// Synthetic receipt fixture; no production code.
