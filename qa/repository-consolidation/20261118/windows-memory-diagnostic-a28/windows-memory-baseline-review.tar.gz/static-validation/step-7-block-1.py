import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

out = Path(os.environ["EVIDENCE_DIR"])
out.mkdir(parents=True, exist_ok=True)
errors = []
report = {"expected_case": os.environ["MEMORY_CASE"], "errors": errors}
try:
    root = Path(os.environ["BAZEL_OUTPUT_BASE"]) / "execroot" / "_main" / "bazel-out"
    targets = list(root.glob("*/testlogs/codex-rs/ext/hepta-memory/hepta-memory-unit-tests"))
    report["target_directories"] = [str(path) for path in targets]
    logs = []
    xml_files = []
    for target in targets:
        for path in sorted(target.rglob("*")):
            if path.is_file() and path.suffix in (".log", ".xml"):
                saved = out / "raw" / path.relative_to(root)
                saved.parent.mkdir(parents=True, exist_ok=True)
                saved.write_bytes(path.read_bytes())
                (logs if path.suffix == ".log" else xml_files).append(saved)
    identity = json.loads((out / "identity.json").read_text())
    execution = json.loads((out / "execution-result.json").read_text())
    report["execution"] = execution
    actual_sha = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    if actual_sha != identity["expected_source_sha"]:
        errors.append("Checked-out source identity changed.")
    diff = subprocess.run(["git", "diff", "--exit-code", "HEAD"], capture_output=True)
    (out / "tracked-source.diff").write_bytes(diff.stdout + diff.stderr)
    if diff.returncode:
        errors.append("Tracked source changed during the diagnostic.")
    for item in identity["source_files"]:
        if hashlib.sha256(Path(item["path"]).read_bytes()).hexdigest() != item["sha256"]:
            errors.append("Source bytes changed: " + item["path"])
    if len(targets) != 1 or len(logs) != 1 or len(xml_files) != 1:
        errors.append("Expected one target, one test.log and one native test.xml; retries or missing evidence are invalid.")
    if len(logs) == 1:
        text = logs[0].read_text(errors="replace")
        text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
        runs = re.findall(r"(?m)^running (\d+) tests?\s*$", text)
        cases = re.findall(r"(?m)^test ([^\r\n]+?) \.\.\.", text)
        summaries = re.findall(
            r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;",
            text,
        )
        report.update(running_counts=runs, executed_cases=cases, summaries=summaries)
        if runs != ["1"] or cases != [os.environ["MEMORY_CASE"]] or len(summaries) != 1:
            errors.append("The raw log does not prove exactly one execution of the original case.")
        elif (sum(map(int, summaries[0][1:3])) != 1 or summaries[0][3:5] != ("0", "0")):
            errors.append("The original case was absent, ignored, measured or duplicated.")
        elif summaries[0][0:3] != ("ok", "1", "0"):
            errors.append("The original case failed; its unchanged raw failure is preserved.")
    if len(xml_files) == 1:
        document = ET.parse(xml_files[0])
        cases = list(document.iter("testcase"))
        report["junit_case_count"] = len(cases)
        if len(cases) != 1 or list(document.iter("skipped")):
            errors.append("JUnit does not contain one non-skipped test.")
        if list(document.iter("failure")) or list(document.iter("error")):
            errors.append("Native JUnit reports failure.")
        for suite in [*document.iter("testsuite"), *document.iter("testsuites")]:
            if any(int(suite.get(key, "0")) for key in ("errors", "failures", "skipped", "disabled")):
                errors.append("Native JUnit reports a failed or skipped count.")
            if "tests" in suite.attrib and int(suite.attrib["tests"]) != 1:
                errors.append("Native JUnit does not report exactly one test.")
    if execution["bazel_exit_code"] or execution["tee_exit_code"]:
        errors.append("The original Bazel invocation or complete log capture failed.")
except (OSError, ValueError, KeyError, subprocess.SubprocessError, ET.ParseError) as error:
    errors.append(type(error).__name__ + ": " + str(error))
report["result"] = "FAIL" if errors else "PASS"
(out / "diagnostic-result.json").write_text(json.dumps(report, indent=2) + "\n")
members = [{"path": path.relative_to(out).as_posix(), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
           for path in sorted(out.rglob("*")) if path.is_file() and path.name != "members.json"]
(out / "members.json").write_text(json.dumps(members, indent=2) + "\n")
print(json.dumps(report, indent=2))
raise SystemExit(1 if errors else 0)
