import datetime
import json
import os
from pathlib import Path
import sys

record = {"bazel_exit_code": int(sys.argv[1]), "tee_exit_code": int(sys.argv[2]),
          "completed_at": datetime.datetime.now(datetime.timezone.utc).isoformat()}
(Path(os.environ["EVIDENCE_DIR"]) / "execution-result.json").write_text(
    json.dumps(record, indent=2) + "\n")
