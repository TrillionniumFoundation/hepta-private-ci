from pathlib import Path
import difflib
import hashlib
import json
import os
import re
import subprocess

out = Path('/workspace/scratch/a28fa6a6513a/audit/frontier/historical-containment/7fd4b93')
wt = Path('/tmp/hepta-a28-7fd-worktree')
bare = Path('/tmp/hepta-a28-7fd-merge.git')
peer = Path('/tmp/hepta-ci-audit-a28/fleet-frontier-0e378dd')
path = 'codex-rs/hepta-fleet/src/authority_port.rs'
meta = json.loads((out / 'metadata.json').read_text())
base = (out / 'base.rs').read_text()
ours = (out / 'ours.rs').read_text()
theirs = (out / 'theirs.rs').read_text()
auto = (out / 'auto-merge.rs').read_text()
shared_review = json.loads((peer / 'semantic-review.json').read_text())
mapping = [row for row in shared_review['incoming_semantic_mapping'] if row['path'] == path]
assert len(mapping) == 14
for row in mapping:
    for role, source in [('current', ours), ('incoming', theirs)]:
        item = row.get(role)
        if isinstance(item, dict):
            assert item['needle'] in source, (row['id'], role)
assert meta['new_history'] == [meta['theirs']]
assert base[:base.index('mod tests {')] == theirs[:theirs.index('mod tests {')]

def function_body(source, needle):
    start = source.index(needle)
    end = source.index('\n    }\n', start) + len('\n    }\n')
    return source[start:end]

def literal(source, needle):
    start = source.index(needle)
    begin = source.index('{', start)
    depth = 0
    for i in range(begin, len(source)):
        if source[i] == '{': depth += 1
        elif source[i] == '}':
            depth -= 1
            if depth == 0: return source[start:i+1]
    raise AssertionError('unclosed fixture literal')

invariants = {
    'incoming_production_prefix_byte_identical_to_base': True,
    'grant_fixture_byte_identical': function_body(ours, 'fn grant() -> AllocationGrant {') == function_body(theirs, 'fn grant() -> AllocationGrant {'),
    'host_observation_literal_byte_identical': literal(ours, 'HostObservation {') == literal(theirs, 'HostObservation {'),
    'authority_lease_literal_byte_identical': literal(ours, 'AuthorityLease {') == literal(theirs, 'AuthorityLease {'),
    'receipt_and_authority_witness_assertions_byte_identical': ours[ours.index('        assert_eq!(receipt.allocation_id'):ours.index('\n\n        registry', ours.index('        assert_eq!(receipt.allocation_id'))] == theirs[theirs.index('        assert_eq!(receipt.allocation_id'):theirs.index('\n\n        registry', theirs.index('        assert_eq!(receipt.allocation_id'))],
    'scope_inequality_preserved': 'assert_ne!(first_binding.scope_sha256, changed_binding.scope_sha256);' in ours and 'assert_ne!(first_binding.scope_sha256, changed_binding.scope_sha256);' in theirs,
    'payload_equality_preserved': 'assert_eq!(first_binding.payload_sha256, changed_binding.payload_sha256);' in ours and 'assert_eq!(first_binding.payload_sha256, changed_binding.payload_sha256);' in theirs,
    'same_cpu_increment': 'changed.resources.cpu_millis += 1;' in ours and 'changed.resources.cpu_millis += 1;' in theirs,
    'current_final_dispatch_uses_verified_time': 'ledger.issue(witness.verified_at_unix_ms, grant)' in ours,
    'current_legacy_caller_clock_remains_non_authoritative': '_caller_now_ms: u64' in ours,
    'current_clock_regression_module_preserved': '#[path = "authority_port_clock_tests.rs"]\nmod clock_tests;' in ours,
    'current_has_no_expect_or_unwrap_method_calls': re.search(r'\.(?:expect|unwrap)\s*\(', ours) is None,
    'same_two_inline_test_cases': ours.count('    #[test]') == theirs.count('    #[test]') == 2,
}
assert all(invariants.values()), invariants

peer_decisions = [row for row in json.loads((peer / 'conflict-decisions.json').read_text()) if row['path'] == path]
assert len(peer_decisions) == 5
pattern = re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> ' + re.escape(meta['theirs']) + r'\n', re.M | re.S)
matches = list(pattern.finditer(auto)); assert len(matches) == 5
decisions = []
chunks = []; cursor = 0
for index, (match, decision) in enumerate(zip(matches, peer_decisions), 1):
    assert match.group(1) == decision['selected_text']
    assert match.group(2) == decision['incoming_text']
    chunks += [auto[cursor:match.start()], decision['selected_text']]
    cursor = match.end()
    decisions.append({
        'id': index,
        'actual_conflict_start_line': auto[:match.start()].count('\n') + 1,
        'current_text': match.group(1), 'incoming_text': match.group(2),
        'resolved_text': decision['selected_text'],
        'semantic_mapping_ids': decision['semantic_mapping_ids'],
        'decision': 'The reviewed incoming failure condition and all asserted values already exist in the current representation. Keep that coherent representation and its newer verified-clock behavior.',
    })
chunks.append(auto[cursor:]); resolved = ''.join(chunks)
automatic = json.loads((peer / 'automatic-edit-decisions.json').read_text())
assert len(automatic) == 6
for decision in automatic:
    assert resolved.count(decision['before']) == 1, decision
    resolved = resolved.replace(decision['before'], decision['after'], 1)
assert resolved == ours
assert not any(marker in resolved for marker in ['<<<<<<<', '=======', '>>>>>>>'])
(out / 'resolved.rs').write_text(resolved)
(out / 'conflict-decisions.json').write_text(json.dumps(decisions, indent=2) + '\n')
(out / 'automatic-edit-decisions.json').write_text(json.dumps(automatic, indent=2) + '\n')
(out / 'explicit-resolution.patch').write_text(''.join(difflib.unified_diff(auto.splitlines(True), resolved.splitlines(True), fromfile='auto-merge/authority_port.rs', tofile='resolved/authority_port.rs')))
review = {
    'incoming': meta['theirs'], 'current': meta['ours'], 'merge_base': meta['base'],
    'full_incoming_history': meta['new_history'], 'incoming_net_paths': [path],
    'incoming_semantic_mapping': mapping, 'source_invariants': invariants,
    'revoked_assertion_truth_table': shared_review['revoked_assertion_truth_table'],
    'historical_postimage_witness': {'sha': meta['witness'], 'source_blob': meta['blobs']['witness'], 'same_as_incoming': meta['blobs']['witness'] == meta['blobs']['theirs']},
    'later_evolution_review': 'The previously incorporated Result propagation was replaced with explicit assertion/panic-based test failure handling that still rejects every same failure. The newer production path obtains allocation time from the verified final dispatch witness and retains its clock regression module. All13 fallible/negative operations, complete fixture values, receipt/authority assertions and binding assertions are mapped above. No incoming production change exists.',
    'actual_conflicts_reviewed': 5, 'automatic_result_fragments_reviewed': 6,
    'construction': 'Ordinary git merge in an isolated sparse worktree. Each actual conflict block independently matched the reviewed current/incoming text, then six enumerated automatic Result-plumbing fragments were reconciled. No ours strategy, checkout-ours, or unreviewed whole-file reset was used.',
    'qualification': 'Exact full source tree equality is required. No native tests or formatting rerun for this zero-source-delta merge.',
}
(out / 'semantic-review.json').write_text(json.dumps(review, indent=2) + '\n')

env = os.environ.copy(); env['GIT_NO_LAZY_FETCH'] = '1'; env['GIT_TERMINAL_PROMPT'] = '0'
git = ['git', '-C', str(wt)]
def command(*args, **kwargs):
    return subprocess.run(git + list(args), env=env, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs)
assert command('rev-parse', 'HEAD').stdout.decode().strip() == meta['ours']
assert command('rev-parse', 'MERGE_HEAD').stdout.decode().strip() == meta['theirs']
(wt / path).write_text(resolved)
command('add', '--', path)
assert not command('ls-files', '-u').stdout
staged_tree = command('write-tree').stdout.decode().strip()
original_tree = command('rev-parse', meta['ours'] + '^{tree}').stdout.decode().strip()
assert staged_tree == original_tree == '6911d7b83a7d2ae573efb4fbe08446f748a7a3a4'
assert not command('diff', '--cached', '--name-only', meta['ours']).stdout
message = 'Merge previously incorporated Fleet fixture failure semantics\n\nThe complete one-commit incoming delta was previously present in current history and is covered by the evolved explicit fixture assertions and error failures. Resolve all five real conflicts and six automatic Result-plumbing fragments coherently while preserving the verified dispatch clock and all negative checks. The full source tree is byte-identical to the first parent.\n'
(out / 'merge-message.txt').write_text(message)
committed = command('commit', '-F', str(out / 'merge-message.txt'))
(out / 'commit.stdout').write_bytes(committed.stdout); (out / 'commit.stderr').write_bytes(committed.stderr)
commit = command('rev-parse', 'HEAD').stdout.decode().strip()
raw = command('cat-file', 'commit', commit).stdout
parents = [line[7:].decode() for line in raw.split(b'\n\n', 1)[0].splitlines() if line.startswith(b'parent ')]
assert parents == [meta['ours'], meta['theirs']]
assert command('rev-parse', 'HEAD^{tree}').stdout.decode().strip() == original_tree
assert not command('status', '--porcelain', '--untracked-files=no').stdout
assert not command('diff-tree', '--no-commit-id', '-r', meta['ours'], commit).stdout
command('update-ref', 'refs/a28-fleet/qualified-7fd4b93', commit, '0' * 40)
(out / 'merge-commit.raw').write_bytes(raw)
proof = {
    'candidate': commit, 'parents': parents, 'tree': original_tree,
    'bare_repository': str(bare), 'worktree': str(wt),
    'ref': 'refs/a28-fleet/qualified-7fd4b93',
    'full_tree_identical_to_first_parent': True,
    'source_blob': meta['blobs']['ours'], 'source_sha256': hashlib.sha256(resolved.encode()).hexdigest(),
    'source_changes': [], 'callers_or_manifest_changes': [],
    'conflict_count': 5, 'automatic_fragment_count': 6,
    'incoming_branch_is_real_second_parent': True,
    'native_or_formatter_commands_run': [],
    'fresh_hia_boundary_check': 'pending7593incrementalcheck',
}
(out / 'candidate-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
