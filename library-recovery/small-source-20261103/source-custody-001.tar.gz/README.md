# Historical source preservation

This independent draft preserves 229 original source/configuration/patch objects (2,444,026 bytes) from 108 original packages or standalone files associated with `TrillionniumFoundation/hepta-private-ci`.

The files are stored by their exact Git blob identifiers. Original names, package hashes, source fingerprints, candidate types, and repository attribution evidence remain in `SOURCE_MANIFEST.json`. Required accompanying notices are retained separately and do not enlarge the frozen source-candidate set.

This archive includes historical experiments and proposed changes. Their original failed observations and restrictions remain in their bytes. It does not establish research acceptance, production correctness, a deployable configuration, or complete source synchronization. DRAFT, SHADOW_ONLY, DENY_ALL, and HOLD_NO_GO boundaries remain in force.

Run `python3 verify_projection.py` from this directory to hash the stored bytes. The verifier never imports or executes the preserved sources. Source workflows are nested under this archive and are not installed as active workflows.
