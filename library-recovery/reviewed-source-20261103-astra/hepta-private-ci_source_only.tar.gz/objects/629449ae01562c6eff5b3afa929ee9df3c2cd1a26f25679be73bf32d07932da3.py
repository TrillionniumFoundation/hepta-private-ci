"""Assemble a dated project observation from committed inventory and exact test receipts."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent


def read(path):
    return json.loads(path.read_text())


def identity(path):
    return {"file": path.name, "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def build():
    inventory = read(ROOT / "candidate-source-inventory.json")
    bindings = read(ROOT / "p0-source-tree-bindings.json")
    entries = {row["path"]: row for row in bindings["entries"]}
    product = read(WORKSPACE / "product-runtime-impl/implementation-evidence-manifest.json")
    neuron = read(ROOT / "neuron-memory-execution.json")
    hia = read(WORKSPACE / "hia-pq-execution-manifest-20261103.json")
    related = {
        "ui.control": [4692, 4686], "ui.native": [4692, 4686],
        "runtime.agentd": [4685, 4687, 4688], "objective.compiler": [4688],
        "automation.taskflow": [4689], "learning.ledger": [4685],
        "learning.plasticity": [4685], "runtime.codex": [4690],
        "kernel.authority": [4690],
    }
    research = {"neuron.runtime": [4693, 4684], "utility.ndu": [4691],
                "learning.operator": [4693, 4684]}
    modules = []
    for module in inventory["modules"]:
        roots = []
        for root in module["roots"]:
            entry = entries.get(root["path"])
            assert entry is not None, root["path"]
            roots.append({**root, "gitTree": entry["sha"],
                          "schemaJsonPins": [v for p, v in entries.items()
                                             if p.startswith(root["path"] + "/")
                                             and p.endswith(".schema.json")]})
        modules.append({**module, "roots": roots,
                        "activeIntegrationCandidate": "ui-main-f33702d",
                        "sourceCommit": inventory["sourceCommit"],
                        "sourceTree": inventory["sourceTree"],
                        "relatedFixPullRequests": related.get(module["id"], []),
                        "relatedResearchPullRequests": research.get(module["id"], []),
                        "relatedFixReferencesDoNotEstablishIntegrationOrQualification": True,
                        "deployedBinaryBinding": None,
                        "liveModelAndSchemaNegotiation": None,
                        "qualification": "source fixed; product qualification remains open"})
    assert len(modules) == 40 and len({x["id"] for x in modules}) == 40
    result = {
        "schema": "hepta.project-execution-observation.v1",
        "observedAtUtc": datetime.now(timezone.utc).isoformat(),
        "repository": "https://github.com/TrillionniumFoundation/hepta-private-ci",
        "scope": "Execution observation and active work map; not a canonical promotion or deployment receipt",
        "fixedIntegrationCandidate": {
            "id": "ui-main-f33702d", "pullRequest": 4692,
            "sourceCommit": inventory["sourceCommit"], "sourceTree": inventory["sourceTree"],
            "orderedParents": product["ui_main_integration"]["ordered_parents"],
            "workspacePins": read(ROOT / "workspace-source-pins.json")["files"],
            "toolchain": product["ui"]["toolchain"],
            "qualifiedForProduction": False, "deployed": False,
        },
        "sourceInventory": identity(ROOT / "candidate-source-inventory.json"),
        "counts": inventory["counts"], "modules": modules,
        "organs": inventory["organs"], "dataDomains": inventory["dataDomains"],
        "productAndExternalDeployment": product,
        "memoryAndResearch": neuron, "hiaAndPairedChain": hia,
        "fixtureFinalValidation": read(ROOT / "hia-current-validation.json"),
        "finalNativeAndCurrentPlatformEvidence": read(WORKSPACE / "product-runtime-impl/root-final-native-manifest.json"),
        "parameterField": read(ROOT / "field-execution-manifest.json"),
        "moduleNextActions": read(ROOT / "module-work-map.json"),
        "objectiveUiIntegrationPlan": read(WORKSPACE / "product-runtime-impl/objective-ui-integration-plan.json"),
        "pullRequestSnapshot": read(ROOT / "pull-request-snapshot.json"),
        "wholeProjectComplete": False,
        "wholeP0Closed": False,
        "acceptanceCountPolicy": "Skipped, filtered, queued, old-head and scoped tests do not establish an untested integrated product pass",
    }
    destination = ROOT / "hepta-active-candidates-20261103.json"
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"modules": len(modules), "candidate": inventory["sourceCommit"],
                      "output": str(destination), **identity(destination)}))


if __name__ == "__main__":
    build()
