import hashlib, json, os, re, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
from scripts.hepta_ci_exec import git, observed_test_counts
out = Path(os.environ["RUNNER_TEMP"]) / "windows-ledger"
def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
if sys.argv[1] == "tests":
    name, minimum = sys.argv[2], int(sys.argv[3])
    code, log_code = map(int, sys.argv[4].split())
    raw = (out / (name + ".log")).read_bytes()
    text = raw.decode("utf-8", errors="replace")
    text = re.sub(r"\x1b\[[0-9;]*m", "", text)
    passed, failed = observed_test_counts(text)
    ok = code == log_code == 0 and passed >= minimum and failed == 0 and re.search(r"Summary[^\n]*?\d+ tests? run:", text) is not None
    save(name + ".json", {"returncode": code, "logging_returncode": log_code, "minimum_tests": minimum, "observed_passed_tests": passed, "observed_failed_tests": failed, "log_sha256": hashlib.sha256(raw).hexdigest(), "status": "passed" if ok else "failed"})
    sys.exit(0 if ok else 1)
phase = sys.argv[2]
result = {"scope": "native Windows ledger regressions only", "run_id": os.environ["GITHUB_RUN_ID"], "run_attempt": os.environ["GITHUB_RUN_ATTEMPT"], "status": "running"}
save("result.json", result)
assert sys.argv[1] == "source" and phase in {"before", "after"}
if phase == "before":
    for name in ("witness", "evaluated-shadow"):
        (out / (name + ".json")).unlink(missing_ok=True)
assert os.name == "nt", "this evidence requires native Windows execution"
assert "host: x86_64-pc-windows-msvc" in (out / "rustc.txt").read_text()
source, tested, base, lane = (os.environ[key] for key in ("SOURCE_SHA", "TESTED_SHA", "BASE_SHA", "HEPTA_CI_LANE"))
assert all(re.fullmatch(r"[0-9a-f]{40}", value) for value in (source, tested, base))
head, tree, parents = git("rev-parse", "HEAD"), git("rev-parse", "HEAD^{tree}"), git("show", "-s", "--format=%P", "HEAD").split()
assert head == tested
if lane == "source-head":
    assert tested == source
else:
    assert lane == "base-merge" and parents == [base, source]
    assert tree == git("merge-tree", "--write-tree", base, source)
assert not git("diff", "--cached", "--raw", "--no-ext-diff", "--no-textconv", "HEAD", "--")
assert not git("ls-files", "--others", "--exclude-standard", "-z")
assert not any(row and (row[0] == "S" or row[0].islower()) for row in git("ls-files", "-v", "-z").split("\0"))
manifest, placeholders = [], 0
for row in git("ls-tree", "--full-tree", "-r", "-z", "HEAD").split("\0"):
    if not row:
        continue
    metadata, relative = row.split("\t", 1)
    mode, kind, expected = metadata.split()
    assert kind == "blob" and mode in {"100644", "100755", "120000"}
    path = Path(relative)
    if path.is_symlink():
        assert mode == "120000"
        data = os.fsencode(os.readlink(path))
    else:
        assert path.is_file()
        data = path.read_bytes()
        placeholders += int(mode == "120000")
    # NTFS does not represent Git executable bits; bind tree modes and
    # exact blob bytes, including Git's Windows symlink placeholders.
    assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data, usedforsecurity=False).hexdigest() == expected, relative
    manifest.append([relative, mode, hashlib.sha256(data).hexdigest()])
snapshot = {"source_sha": source, "base_sha": base, "tested_sha": head, "tree": tree, "parents": parents, "lane": lane, "tracked_files": len(manifest), "tracked_bytes_sha256": hashlib.sha256(json.dumps(manifest, separators=(",", ":")).encode()).hexdigest(), "symlink_placeholders": placeholders}
save("source-" + phase + ".json", snapshot)
result["source"] = snapshot
if phase == "after":
    assert snapshot == json.loads((out / "source-before.json").read_text())
    result["tests"] = {name: json.loads((out / (name + ".json")).read_text()) for name in ("witness", "evaluated-shadow")}
    result["status"] = "passed" if all(value["status"] == "passed" for value in result["tests"].values()) else "failed"
save("result.json", result)
assert result["status"] != "failed"
