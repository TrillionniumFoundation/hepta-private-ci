"""Lane A closed-world current-contract verification helpers."""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "qualification/module-execution-dossiers"))
from native_source_bindings import BindingError, observe_native_bindings

LANE = ROOT / "docs/lane-a-foundation"
MATRIX_PATH = LANE / "MODULE_TRUTH_MATRIX.json"
CAPABILITY_MAP_PATH = LANE / "CAPABILITY_EVIDENCE_MAP.json"
BOUNDARY_POLICY_PATH = LANE / "BOUNDARY_POLICY.md"
NATIVE_BINDINGS_PATH = (
    ROOT / "qualification/module-execution-dossiers/NATIVE_BINDINGS_LANE_A.json"
)
EXPECTED_MODULES = [
    "platform.types",
    "platform.wire",
    "kernel.authority",
    "kernel.operations",
    "kernel.evidence",
    "auth.authbus",
    "secrets.heptabao",
]
AXES = [
    "source",
    "implementation",
    "durability",
    "qualification",
    "activation",
    "acceptance",
]
SECTIONS = [
    "## Current executable contract",
    "## Public symbols and source bindings",
    "## Durability and activation",
    "## Target-only design",
    "## Known limits and non-claims",
    "## Verification",
    "## Integration prerequisites",
]
MIGRATIONS = [
    "0001_governance.sql",
    "0002_provider_evidence.sql",
    "0003_provider_host_binding.sql",
    "0004_memory_mutation_shadow.sql",
    "0005_channel_ingress_evidence.sql",
    "0006_provider_ephemeral_input.sql",
    "0007_provider_effect_evidence.sql",
    "0008_provider_effect_ack_source.sql",
    "0009_authbus_replay.sql",
    "0010_authbus_outbox.sql",
    "0011_qualification_evidence.sql",
    "0012_authbus_recovery.sql",
]
PACKAGES = [
    "codex-hepta-types",
    "codex-hepta-wire",
    "codex-hepta-contracts",
    "codex-hepta-operations",
    "codex-hepta-evidence",
    "codex-hepta-authbus",
    "codex-hepta-bao-adapter",
]


class VerificationError(RuntimeError):
    """Repository truth and a Lane A claim diverged."""


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise VerificationError(f"cannot read JSON {path}: {error}") from error
    if not isinstance(value, dict):
        raise VerificationError(f"JSON object required: {path}")
    return value


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as error:
        raise VerificationError(f"cannot read UTF-8 {path}: {error}") from error


def validate_anchor(owner: str, item: Any, root: Path = ROOT) -> None:
    if not isinstance(item, dict) or not isinstance(item.get("path"), str):
        raise VerificationError(f"{owner}: invalid source/test anchor")
    source = read_text(root / item["path"])
    for field, required in (("mustContain", True), ("mustNotContain", False)):
        needles = item.get(field, [])
        if not isinstance(needles, list) or not all(
            isinstance(x, str) and x for x in needles
        ):
            raise VerificationError(f"{owner}: invalid {field}")
        for needle in needles:
            if (needle in source) != required:
                state = "missing" if required else "forbidden"
                raise VerificationError(
                    f"{owner}: {state} {needle!r} in {item['path']}"
                )


def validate_protocol_registry(value: dict[str, Any], root: Path = ROOT) -> None:
    """Validate one module entry plus optional same-owner executable surfaces."""
    rows = value.get("protocols")
    if (
        set(value) != {"schemaVersion", "lane", "role", "authority", "protocols"}
        or value.get("schemaVersion") != 1
        or value.get("lane") != "LANE-A-FOUNDATION"
        or value.get("role") != "current_executable_protocol_index"
        or value.get("authority") != "none"
        or not isinstance(rows, list)
        or any(not isinstance(row, dict) for row in rows)
        or [row.get("module") for row in rows] != EXPECTED_MODULES
    ):
        raise VerificationError("protocol registry header/module set mismatch")
    identities: set[str] = set()
    for row in rows:
        additional = row.get("additionalProtocols", [])
        if not isinstance(additional, list):
            raise VerificationError("additional protocols must be a list")
        for surface in [row, *additional]:
            if (
                not isinstance(surface, dict)
                or set(surface).difference({
                    "protocolId", "module", "kind", "source", "invariants",
                    "legacyProtocolId", "additionalProtocols",
                })
                or surface.get("module") != row["module"]
                or (surface is not row and "additionalProtocols" in surface)
                or not isinstance(surface.get("kind"), str)
                or not surface["kind"]
            ):
                raise VerificationError("invalid additional protocol owner/shape")
            for field in ("protocolId", "legacyProtocolId"):
                if field == "legacyProtocolId" and field not in surface:
                    continue
                identity = surface.get(field)
                if (
                    not isinstance(identity, str)
                    or not identity.startswith("hepta.")
                    or identity in identities
                ):
                    raise VerificationError("invalid/duplicate protocol identity")
                identities.add(identity)
            for field in ("source", "invariants"):
                items = surface.get(field)
                if not isinstance(items, list) or not items or any(
                    not isinstance(item, str) or not item.strip() for item in items
                ):
                    raise VerificationError(f"protocol {field} must be nonempty")
                if field == "source":
                    for item in items:
                        source = Path(item)
                        if (
                            chr(0) in item or chr(92) in item
                            or not source.parts
                            or source.is_absolute() or ".." in source.parts
                            or source.as_posix() != item
                            or not (root / source).resolve().is_relative_to(root.resolve())
                            or not (root / source).exists()
                        ):
                            raise VerificationError("invalid/unavailable protocol source path")


def validate_capability_map(
    matrix: dict[str, Any], value: dict[str, Any], root: Path = ROOT
) -> None:
    entries = value.get("entries")
    if (
        value.get("schemaVersion") != 1
        or value.get("lane") != "LANE-A-FOUNDATION"
        or value.get("closureScope") != "current executable capabilities only"
        or not isinstance(entries, list)
        or value.get("entryCount") != len(entries)
    ):
        raise VerificationError("capability evidence-map header mismatch")
    expected = [
        (module["module"], capability)
        for module in matrix["modules"]
        for capability in module["currentCapabilities"]
    ]
    by_module = {row["module"]: row for row in matrix["modules"]}
    observed: list[tuple[str, str]] = []
    ids: set[str] = set()
    for row in entries:
        if not isinstance(row, dict):
            raise VerificationError("capability evidence row must be an object")
        capability_id = row.get("capabilityId")
        module = row.get("module")
        summary = row.get("summary")
        if (
            not isinstance(capability_id, str)
            or not capability_id
            or capability_id in ids
        ):
            raise VerificationError(
                f"invalid/duplicate capability ID {capability_id!r}"
            )
        ids.add(capability_id)
        if module not in by_module or not isinstance(summary, str) or not summary:
            raise VerificationError(f"{capability_id}: invalid module or summary")
        observed.append((module, summary))
        state = by_module[module]["states"]
        if (
            row.get("durability") != state["durability"]
            or row.get("activation") != state["activation"]
        ):
            raise VerificationError(f"{capability_id}: matrix state mismatch")
        production_caller = row.get("productionCaller")
        allowed_callers = by_module[module].get("namedProductCallers", [])
        if production_caller is not None and production_caller not in allowed_callers:
            raise VerificationError(
                f"{capability_id}: unregistered production caller {production_caller!r}"
            )
        caller = row.get("productionCaller")
        if caller is not None:
            if not isinstance(caller, str) or not caller:
                raise VerificationError(f"{capability_id}: invalid production caller")
            caller_evidence = row.get("callerEvidence")
            if not isinstance(caller_evidence, list) or not caller_evidence:
                raise VerificationError(
                    f"{capability_id}: production caller requires callerEvidence"
                )
            for anchor in caller_evidence:
                validate_anchor(f"{capability_id}/callerEvidence", anchor, root)
        if row.get("receiptStatus") != "native_workflow_required":
            raise VerificationError(f"{capability_id}: invalid receipt status")
        symbols = row.get("publicSymbols")
        if (
            not isinstance(symbols, list)
            or not symbols
            or not all(isinstance(x, str) and x for x in symbols)
        ):
            raise VerificationError(f"{capability_id}: public symbols required")
        for field in ("sourceEvidence", "positiveTests", "negativeTests"):
            anchors = row.get(field)
            if not isinstance(anchors, list) or not anchors:
                raise VerificationError(f"{capability_id}: {field} required")
            for anchor in anchors:
                validate_anchor(f"{capability_id}/{field}", anchor, root)
    if observed != expected:
        raise VerificationError(
            "capability map does not exactly cover ordered current capabilities"
        )


def git_blob_sha(data: bytes) -> str:
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


def validate_native_bindings(root: Path = ROOT) -> dict[str, Any]:
    value = read_json(
        root / "qualification/module-execution-dossiers/NATIVE_BINDINGS_LANE_A.json"
    )
    rows = value.get("observations")
    if (
        value.get("schema") != "hepta.native-source-observations.lane-a.v1"
        or value.get("schemaVersion") != 1
        or value.get("lane") != "LANE-A-FOUNDATION"
        or value.get("moduleCoverage") != 7
        or value.get("closedWorldModules") != EXPECTED_MODULES
        or value.get("consumerCallsitesProved") is not False
        or value.get("productExecutionProved") is not False
        or value.get("sourceCodeCommitRole") != "provenance_only_non_authoritative"
        or value.get("candidateBinding") != "runtime_head_tree_and_source_blob_receipt"
        or not isinstance(rows, list)
        or [row.get("module") for row in rows if isinstance(row, dict)]
        != EXPECTED_MODULES
    ):
        raise VerificationError("Lane A native-binding header/module set mismatch")
    source_commit = str(value.get("sourceCodeCommit"))
    if re.fullmatch(r"[0-9a-f]{40}", source_commit) is None:
        raise VerificationError("native-binding provenance commit is not exact")
    observation_digest = hashlib.sha256(
        json.dumps(
            rows, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ).encode()
    ).hexdigest()
    if value.get("sourceObservationDigest") != observation_digest:
        raise VerificationError("native-binding observation digest mismatch")
    try:
        current = observe_native_bindings(root, rows, EXPECTED_MODULES)
    except BindingError as error:
        raise VerificationError(str(error)) from error
    value["currentSourceBinding"] = current
    return value


def validate_wire_vector(root: Path = ROOT) -> None:
    v1 = read_json(
        root / "docs/lane-a-foundation/platform.wire/HPTA_V1_CONFORMANCE.json"
    )
    try:
        v1_frame = bytes.fromhex(v1["frameHex"])
        v1_payload = bytes.fromhex(v1["fields"]["payloadHex"])
        v1_payload_digest = v1["fields"]["payloadSha256"]
    except (KeyError, TypeError, ValueError) as error:
        raise VerificationError(f"invalid HPTA V1 vector: {error}") from error
    if (
        v1.get("schemaVersion") != 1
        or v1.get("protocol") != "HPTA"
        or v1.get("version") != 1
        or v1.get("frameLength") != 59
        or len(v1_frame) != 59
        or v1_frame[:6] != b"HPTA\x00\x01"
        or hashlib.sha256(v1_frame).hexdigest() != v1.get("frameSha256")
        or hashlib.sha256(v1_payload).hexdigest() != v1_payload_digest
    ):
        raise VerificationError("HPTA V1 conformance vector mismatch")

    v2 = read_json(
        root / "docs/lane-a-foundation/platform.wire/HPTA_V2_CONFORMANCE.json"
    )
    try:
        v2_frame = bytes.fromhex(v2["frameHex"])
        v2_digest = v2["fields"]["frameDigestSha256"]
        v2_domain = bytes.fromhex(v2["digestDomainHex"])
    except (KeyError, TypeError, ValueError) as error:
        raise VerificationError(f"invalid HPTA V2 vector: {error}") from error
    if (
        v2.get("schemaVersion") != 1
        or v2.get("protocol") != "HPTA"
        or v2.get("version") != 2
        or v2.get("frameLength") != 59
        or len(v2_frame) != 59
        or v2_frame[:6] != b"HPTA\x00\x02"
        or hashlib.sha256(v2_frame).hexdigest() != v2.get("frameSha256")
    ):
        raise VerificationError("HPTA V2 conformance vector mismatch")
    v2_preimage = v2_domain + v2_frame[:18] + v2_frame[50:54] + v2_frame[54:]
    if hashlib.sha256(v2_preimage).hexdigest() != v2_digest:
        raise VerificationError("HPTA V2 frame-digest vector mismatch")

    hptn = read_json(
        root / "docs/lane-a-foundation/platform.wire/HPTN_V1_CONFORMANCE.json"
    )
    try:
        hello = bytes.fromhex(hptn["recordHex"])
    except (KeyError, TypeError, ValueError) as error:
        raise VerificationError(f"invalid HPTN V1 vector: {error}") from error
    if (
        hptn.get("schemaVersion") != 1
        or hptn.get("protocol") != "HPTN"
        or hptn.get("formatVersion") != 1
        or hptn.get("recordLength") != 20
        or len(hello) != 20
        or hello[:6] != b"HPTN\x00\x01"
        or hashlib.sha256(hello).hexdigest() != hptn.get("recordSha256")
        or hptn.get("wireVersions") != [1, 2]
        or hptn.get("capabilities", {}).get("currentMask") != 7
    ):
        raise VerificationError("HPTN V1 conformance vector mismatch")


def validate_source_specific(root: Path = ROOT) -> None:
    required = {
        "codex-rs/hepta-types/src/lib.rs": ["pub use identity::IdentityError;"],
        "codex-rs/hepta-wire/src/envelope.rs": ["const WIRE_VERSION: u16 = 1;"],
        "codex-rs/hepta-operations/src/lib.rs": [
            "in-memory reference models",
            "do not provide durable storage",
            "standalone durable qualification owner",
            "Agentd product owner and must never dual-write",
            "must never dual-write one logical operation",
            "The Agentd product owner is CognitiveStore",
        ],
        "codex-rs/hepta-operations/src/model.rs": [
            "pub struct ReferenceAuthorityWitness",
            "not a cryptographic credential",
        ],
        "codex-rs/hepta-operations/src/ledger.rs": [
            "MAX_MODEL_OPERATION_RECORDS",
            'InvalidDigest("dispatch")',
            "terminal_matches",
        ],
        "codex-rs/hepta-operations/src/outbox.rs": [
            "MAX_MODEL_OUTBOX_RECORDS",
            'InvalidDigest("outbox payload")',
            'InvalidDigest("outbox acknowledgement")',
        ],
        "codex-rs/hepta-authbus/src/lib.rs": [
            "pub use signed::SignedMessage;",
            "pub struct PreverifiedAuthEnvelope",
            "pub struct TrustedReplayContext",
            "BTreeMap<ReplayKey, u64>",
            "AuthorityPosture::DENY_ALL",
        ],
        "codex-rs/hepta-authbus/src/signed.rs": [
            "pub fn authenticate(",
            ".verify_strict(",
            "pub struct AuthenticatedMessage",
        ],
        "codex-rs/hepta-evidence/src/authbus_store.rs": [
            "pub async fn admit_authbus_message(",
            'begin_with("BEGIN IMMEDIATE")',
            "transaction.commit().await",
        ],
    }
    for path, needles in required.items():
        source = read_text(root / path)
        for needle in needles:
            if needle not in source:
                raise VerificationError(
                    f"source-specific check missing {needle!r} in {path}"
                )
    operations = read_text(root / "codex-rs/hepta-operations/src/model.rs")
    auth = read_text(root / "codex-rs/hepta-authbus/src/lib.rs")
    if "pub struct AuthorityWitness" in operations or "pub struct AuthEnvelope" in auth:
        raise VerificationError(
            "production-looking reference boundary was reintroduced"
        )
    envelope = auth[
        auth.index("pub struct PreverifiedAuthEnvelope") : auth.index(
            "pub struct TrustedReplayContext"
        )
    ]
    if "revoked" in envelope or any(
        value in auth for value in ("pub fn reserve(", "pub fn settle(")
    ):
        raise VerificationError(
            "AuthBus promoted an untrusted or target-only capability"
        )
    migrations = sorted(
        path.name
        for path in (root / "codex-rs/hepta-evidence/migrations").glob("*.sql")
    )
    if migrations != MIGRATIONS:
        raise VerificationError(f"evidence migration lineage drift: {migrations!r}")
    bao = read_text(root / "codex-rs/hepta-bao-adapter/src/https_consumer.rs")
    if any(
        value in bao
        for value in ("pub async fn put_", "pub async fn renew", "pub async fn revoke")
    ):
        raise VerificationError(
            "Bao mutation API promoted into current read-only slice"
        )
