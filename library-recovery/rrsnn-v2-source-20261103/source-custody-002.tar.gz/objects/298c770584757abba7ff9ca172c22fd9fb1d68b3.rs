//! Header: `arch/mips/include/uapi/asm/socket.h`

use crate::prelude::*;

pub const SOL_SOCKET: c_int = 0xffff;

pub const SO_DEBUG: c_int = 0x0001;
pub const SO_REUSEADDR: c_int = 0x0004;
pub const SO_KEEPALIVE: c_int = 0x0008;
pub const SO_DONTROUTE: c_int = 0x0010;
pub const SO_BROADCAST: c_int = 0x0020;
pub const SO_LINGER: c_int = 0x0080;
pub const SO_OOBINLINE: c_int = 0x0100;
pub const SO_REUSEPORT: c_int = 0x0200;

pub const SO_TYPE: c_int = 0x1008;
// pub const SO_STYLE: c_int = SO_TYPE;
pub const SO_ERROR: c_int = 0x1007;
pub const SO_SNDBUF: c_int = 0x1001;
pub const SO_RCVBUF: c_int = 0x1002;
pub const SO_SNDLOWAT: c_int = 0x1003;
pub const SO_RCVLOWAT: c_int = 0x1004;
const SO_SNDTIMEO_OLD: c_int = 0x1005;
const SO_RCVTIMEO_OLD: c_int = 0x1006;
pub const SO_ACCEPTCONN: c_int = 0x1009;
pub const SO_PROTOCOL: c_int = 0x1028;
pub const SO_DOMAIN: c_int = 0x1029;

pub const SO_NO_CHECK: c_int = 11;
pub const SO_PRIORITY: c_int = 12;
pub const SO_BSDCOMPAT: c_int = 14;

pub const SO_PASSCRED: c_int = 17;
pub const SO_PEERCRED: c_int = 18;

pub const SO_SECURITY_AUTHENTICATION: c_int = 22;
pub const SO_SECURITY_ENCRYPTION_TRANSPORT: c_int = 23;
pub const SO_SECURITY_ENCRYPTION_NETWORK: c_int = 24;

pub const SO_BINDTODEVICE: c_int = 25;

pub const SO_ATTACH_FILTER: c_int = 26;
pub const SO_DETACH_FILTER: c_int = 27;
pub const SO_GET_FILTER: c_int = SO_ATTACH_FILTER;

pub const SO_PEERNAME: c_int = 28;

pub const SO_PEERSEC: c_int = 30;
pub const SO_SNDBUFFORCE: c_int = 31;
pub const SO_RCVBUFFORCE: c_int = 33;
pub const SO_PASSSEC: c_int = 34;

pub const SO_MARK: c_int = 36;

pub const SO_RXQ_OVFL: c_int = 40;

pub const SO_WIFI_STATUS: c_int = 41;
pub const SCM_WIFI_STATUS: c_int = SO_WIFI_STATUS;
pub const SO_PEEK_OFF: c_int = 42;

pub const SO_NOFCS: c_int = 43;

pub const SO_LOCK_FILTER: c_int = 44;

pub const SO_SELECT_ERR_QUEUE: c_int = 45;

pub const SO_BUSY_POLL: c_int = 46;

pub const SO_MAX_PACING_RATE: c_int = 47;

pub const SO_BPF_EXTENSIONS: c_int = 48;

pub const SO_INCOMING_CPU: c_int = 49;

pub const SO_ATTACH_BPF: c_int = 50;
pub const SO_DETACH_BPF: c_int = SO_DETACH_FILTER;

pub const SO_ATTACH_REUSEPORT_CBPF: c_int = 51;
pub const SO_ATTACH_REUSEPORT_EBPF: c_int = 52;

pub const SO_CNX_ADVICE: c_int = 53;

pub const SCM_TIMESTAMPING_OPT_STATS: c_int = 54;

pub const SO_MEMINFO: c_int = 55;

pub const SO_INCOMING_NAPI_ID: c_int = 56;

pub const SO_COOKIE: c_int = 57;

pub const SCM_TIMESTAMPING_PKTINFO: c_int = 58;

pub const SO_PEERGROUPS: c_int = 59;

pub const SO_ZEROCOPY: c_int = 60;

pub const SO_TXTIME: c_int = 61;
pub const SCM_TXTIME: c_int = SO_TXTIME;

pub const SO_BINDTOIFINDEX: c_int = 62;

const SO_TIMESTAMP_OLD: c_int = 29;
const SO_TIMESTAMPNS_OLD: c_int = 35;
const SO_TIMESTAMPING_OLD: c_int = 37;

const SO_TIMESTAMP_NEW: c_int = 63;
const SO_TIMESTAMPNS_NEW: c_int = 64;
const SO_TIMESTAMPING_NEW: c_int = 65;

const SO_RCVTIMEO_NEW: c_int = 66;
const SO_SNDTIMEO_NEW: c_int = 67;

pub const SO_DETACH_REUSEPORT_BPF: c_int = 68;

pub const SO_PREFER_BUSY_POLL: c_int = 69;
pub const SO_BUSY_POLL_BUDGET: c_int = 70;

pub const SO_NETNS_COOKIE: c_int = 71;

pub const SO_BUF_LOCK: c_int = 72;

pub const SO_RESERVE_MEM: c_int = 73;

pub const SO_TXREHASH: c_int = 74;

pub const SO_RCVMARK: c_int = 75;

pub const SO_PASSPIDFD: c_int = 76;
pub const SO_PEERPIDFD: c_int = 77;

pub const SO_DEVMEM_LINEAR: c_int = 78;
pub const SCM_DEVMEM_LINEAR: c_int = SO_DEVMEM_LINEAR;
pub const SO_DEVMEM_DMABUF: c_int = 79;
pub const SCM_DEVMEM_DMABUF: c_int = SO_DEVMEM_DMABUF;
pub const SO_DEVMEM_DONTNEED: c_int = 80;

cfg_if! {
    if #[cfg(target_pointer_width = "64")] {
        pub const SO_TIMESTAMP: c_int = SO_TIMESTAMP_OLD;
        pub const SO_TIMESTAMPNS: c_int = SO_TIMESTAMPNS_OLD;
        pub const SO_TIMESTAMPING: c_int = SO_TIMESTAMPING_OLD;

        pub const SO_RCVTIMEO: c_int = SO_RCVTIMEO_OLD;
        pub const SO_SNDTIMEO: c_int = SO_SNDTIMEO_OLD;
    } else {
        #[allow(deprecated)]
        const TIME_T_LONG: bool = size_of::<crate::time_t>() == size_of::<c_long>();

        pub const SO_TIMESTAMP: c_int = if TIME_T_LONG {
            SO_TIMESTAMP_OLD
        } else {
            SO_TIMESTAMP_NEW
        };
        pub const SO_TIMESTAMPNS: c_int = if TIME_T_LONG {
            SO_TIMESTAMPNS_OLD
        } else {
            SO_TIMESTAMPNS_NEW
        };
        pub const SO_TIMESTAMPING: c_int = if TIME_T_LONG {
            SO_TIMESTAMPING_OLD
        } else {
            SO_TIMESTAMPING_NEW
        };

        pub const SO_RCVTIMEO: c_int = if TIME_T_LONG {
            SO_RCVTIMEO_OLD
        } else {
            SO_RCVTIMEO_NEW
        };
        pub const SO_SNDTIMEO: c_int = if TIME_T_LONG {
            SO_SNDTIMEO_OLD
        } else {
            SO_SNDTIMEO_NEW
        };
    }
}

pub const SCM_TIMESTAMP: c_int = SO_TIMESTAMP;
pub const SCM_TIMESTAMPNS: c_int = SO_TIMESTAMPNS;
pub const SCM_TIMESTAMPING: c_int = SO_TIMESTAMPING;
