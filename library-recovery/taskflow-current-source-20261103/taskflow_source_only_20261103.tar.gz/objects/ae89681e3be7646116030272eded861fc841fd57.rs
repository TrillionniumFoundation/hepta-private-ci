//! Prepared observational counterexamples for the existing count-only transport.
//!
//! These tests have NOT been compiled or run. Their small fixture sizes are not
//! proposed production defaults. They exercise the real protocol owner over
//! in-memory streams, without starting or altering any sandbox helper.

use super::*;
use pretty_assertions::assert_eq;
use serde_json::Value;
use serde_json::json;
use tokio::io::AsyncWriteExt;
use tokio::io::DuplexStream;
use tokio::io::duplex;
use tokio_tungstenite::tungstenite::protocol::Role;

type TestResult<T = ()> = Result<T, Box<dyn std::error::Error + Send + Sync>>;
type TestSocket = WebSocketStream<DuplexStream>;
const TEST_WATCHDOG: Duration = Duration::from_secs(5);

enum BootstrapTraffic {
    Empty,
    OneName(String),
}

async fn sockets() -> (TestSocket, TestSocket) {
    let (client, server) = duplex(16 * 1024);
    (
        WebSocketStream::from_raw_socket(client, Role::Client, Some(remote_websocket_config()))
            .await,
        WebSocketStream::from_raw_socket(server, Role::Server, None).await,
    )
}

fn notification(name: &str) -> Message {
    Message::Text(
        json!({
            "method": "thread/name/updated",
            "params": {"threadId": "receive-bytes", "threadName": name}
        })
        .to_string()
        .into(),
    )
}

async fn read_json(server: &mut TestSocket) -> TestResult<Value> {
    let message = server.next().await.ok_or("peer closed before request")??;
    Ok(serde_json::from_str(message.to_text()?)?)
}

async fn initialize(server: &mut TestSocket, traffic: BootstrapTraffic) -> TestResult {
    let request = read_json(server).await?;
    assert_eq!(request["method"], "initialize");
    if let BootstrapTraffic::OneName(name) = traffic {
        server.send(notification(&name)).await?;
    }
    server
        .send(Message::Text(
            json!({
                "id": request["id"],
                "result": {"userAgent": "fixture/1.0.0", "codexHome": "/fixture"}
            })
            .to_string()
            .into(),
        ))
        .await?;
    assert_eq!(read_json(server).await?["method"], "initialized");
    Ok(())
}

async fn wait_for_close(server: &mut TestSocket) -> TestResult {
    while let Some(message) = server.next().await {
        if matches!(message?, Message::Close(_)) {
            break;
        }
    }
    Ok(())
}

async fn connect(client: TestSocket) -> IoResult<RemoteAppServerClient> {
    RemoteAppServerClient::connect_with_stream(
        /*channel_capacity*/ 1,
        RemoteEventMode::Bounded { capacity: 1 },
        "in-memory-receive-boundary-fixture".into(),
        client,
        InitializeParams {
            client_info: ClientInfo {
                name: "receive-memory-boundary-test".into(),
                version: "1".into(),
                title: None,
            },
            capabilities: None,
        },
    )
    .await
}

fn request(id: i64) -> JSONRPCRequest {
    JSONRPCRequest {
        id: RequestId::Integer(id),
        method: "fixture/receiveBoundary".into(),
        params: None,
        trace: None,
    }
}

fn retained_event_counts(client: &RemoteAppServerClient) -> TestResult<(usize, usize)> {
    let RemoteEventReceiver::Bounded { receiver, .. } = &client.event_rx else {
        return Err("expected count-bounded receiver".into());
    };
    Ok((client.pending_events.len(), receiver.len()))
}

#[tokio::test]
async fn initialization_and_live_queue_each_retain_the_configured_count() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server) = sockets().await;
        let server_task = tokio::spawn(async move {
            initialize(&mut server, BootstrapTraffic::OneName("initial".into())).await?;
            let request = read_json(&mut server).await?;
            server.send(notification("steady")).await?;
            server
                .send(Message::Text(
                    json!({"id": request["id"], "result": null})
                        .to_string()
                        .into(),
                ))
                .await?;
            wait_for_close(&mut server).await
        });
        let client = connect(client).await?;
        // The response is an in-order barrier after the steady-state event.
        assert_eq!(
            client.request_handle().request_json_rpc(request(1)).await?,
            Ok(Value::Null)
        );
        assert_eq!(retained_event_counts(&client)?, (1, 1));
        client.shutdown().await?;
        server_task.await??;
        Ok(())
    })
    .await?
}

#[tokio::test]
async fn one_count_slot_can_retain_a_four_kib_utf8_payload() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server) = sockets().await;
        let name = "🦀".repeat(1024);
        let server_task = tokio::spawn(async move {
            initialize(&mut server, BootstrapTraffic::OneName(name)).await?;
            wait_for_close(&mut server).await
        });
        let mut client = connect(client).await?;
        assert_eq!(retained_event_counts(&client)?, (1, 0));
        let Some(AppServerEvent::ServerNotification(notification)) = client.next_event().await
        else {
            return Err("expected retained initialization event".into());
        };
        let ServerNotification::ThreadNameUpdated(notification) = notification.as_ref() else {
            return Err("expected thread-name event".into());
        };
        let name = notification.thread_name.as_deref().ok_or("name missing")?;
        assert_eq!((name.len(), name.chars().count()), (4096, 1024));
        client.shutdown().await?;
        server_task.await??;
        Ok(())
    })
    .await?
}

#[tokio::test]
async fn one_command_slot_does_not_limit_unanswered_requests_to_one() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server) = sockets().await;
        let (seen_tx, seen_rx) = oneshot::channel();
        let server_task = tokio::spawn(async move {
            initialize(&mut server, BootstrapTraffic::Empty).await?;
            for _ in 0..3 {
                assert_eq!(
                    read_json(&mut server).await?["method"],
                    "fixture/receiveBoundary"
                );
            }
            let _ = seen_tx.send(());
            // Deliberately do not reply: the connection owns all three waiters.
            wait_for_close(&mut server).await
        });
        let client = connect(client).await?;
        let mut requests = Vec::new();
        for id in 1..=3 {
            let handle = client.request_handle();
            requests.push(tokio::spawn(async move {
                handle.request_json_rpc(request(id)).await
            }));
        }
        seen_rx.await?;
        assert_eq!(
            requests
                .iter()
                .filter(|request| !request.is_finished())
                .count(),
            3
        );
        assert_eq!(retained_event_counts(&client)?, (0, 0));
        client.shutdown().await?;
        for request in requests {
            assert!(request.await?.is_err());
        }
        server_task.await??;
        Ok(())
    })
    .await?
}

#[tokio::test]
async fn response_array_capacity_can_exceed_its_encoded_bytes() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server) = sockets().await;
        let (encoded_len_tx, encoded_len_rx) = oneshot::channel();
        let server_task = tokio::spawn(async move {
            initialize(&mut server, BootstrapTraffic::Empty).await?;
            let request = read_json(&mut server).await?;
            let encoded =
                json!({"id": request["id"], "result": vec![Value::Null; 128]}).to_string();
            let encoded_len = encoded.len();
            server.send(Message::Text(encoded.into())).await?;
            let _ = encoded_len_tx.send(encoded_len);
            wait_for_close(&mut server).await
        });
        let client = connect(client).await?;
        let response = client.request_handle().request_json_rpc(request(1)).await?;
        let Ok(Value::Array(values)) = response else {
            return Err("expected response array".into());
        };
        let array_storage = values
            .capacity()
            .checked_mul(std::mem::size_of::<Value>())
            .ok_or("array storage overflow")?;
        assert!(array_storage > encoded_len_rx.await?);
        assert_eq!(retained_event_counts(&client)?, (0, 0));
        // This is capacity of one owned array, not an allocator or RSS bound.
        client.shutdown().await?;
        server_task.await??;
        drop(values);
        Ok(())
    })
    .await?
}

#[tokio::test]
async fn oversized_frame_header_is_rejected_without_waiting_for_payload() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server) = sockets().await;
        let server_task = tokio::spawn(async move {
            initialize(&mut server, BootstrapTraffic::Empty).await?;
            let declared_length = u64::try_from(REMOTE_APP_SERVER_MAX_WEBSOCKET_MESSAGE_SIZE)? + 1;
            let mut header = vec![0x81, 0x7f];
            header.extend_from_slice(&declared_length.to_be_bytes());
            // Send only ten bytes. No giant payload or allocation probe is used.
            server.get_mut().write_all(&header).await?;
            Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
        });
        let mut client = connect(client).await?;
        let Some(AppServerEvent::Disconnected { message }) = client.next_event().await else {
            return Err("expected the ordinary frame-limit transport rejection".into());
        };
        assert!(message.contains("Message too long"));
        client.shutdown().await?;
        server_task.await??;
        Ok(())
    })
    .await?
}
