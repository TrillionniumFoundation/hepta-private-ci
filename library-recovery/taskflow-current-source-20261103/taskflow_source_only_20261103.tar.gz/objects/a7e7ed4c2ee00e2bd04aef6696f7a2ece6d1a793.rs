use super::*;
use pretty_assertions::assert_eq;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering;
use tokio::io::AsyncWriteExt;

struct Permit(Arc<AtomicUsize>);
impl Drop for Permit {
    fn drop(&mut self) {
        self.0.fetch_sub(1, Ordering::SeqCst);
    }
}

fn write_permit(permits: Arc<AtomicUsize>) -> WritePermit {
    let permit = Permit(permits);
    Box::new(move |write| {
        let _permit = permit;
        write()
    })
}

struct Sink {
    writable: Arc<AtomicBool>,
    permits: Arc<AtomicUsize>,
    written: Arc<AtomicUsize>,
    observations: Arc<Mutex<Vec<usize>>>,
    max_write: usize,
}
impl AsyncWrite for Sink {
    fn poll_write(
        self: Pin<&mut Self>,
        _: &mut Context<'_>,
        buf: &[u8],
    ) -> Poll<io::Result<usize>> {
        self.observations
            .lock()
            .expect("gate fixture")
            .push(self.permits.load(Ordering::SeqCst));
        if !self.writable.load(Ordering::SeqCst) {
            return Poll::Pending;
        }
        let n = buf.len().min(self.max_write);
        self.written.fetch_add(n, Ordering::SeqCst);
        Poll::Ready(Ok(n))
    }
    fn poll_flush(self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<io::Result<()>> {
        Poll::Ready(Ok(()))
    }
    fn poll_shutdown(self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<io::Result<()>> {
        Poll::Ready(Ok(()))
    }
}

#[tokio::test]
async fn zero_byte_pending_releases_writer_and_rechecks_revocation() {
    let permits = Arc::new(AtomicUsize::new(0));
    let live = Arc::new(AtomicBool::new(true));
    let polls = Arc::new(AtomicUsize::new(0));
    let written = Arc::new(AtomicUsize::new(0));
    let observations = Arc::new(Mutex::new(Vec::new()));
    let (mut stream, gate) = GatedStream::new(Sink {
        writable: Arc::new(AtomicBool::new(false)),
        permits: permits.clone(),
        written: written.clone(),
        observations: observations.clone(),
        max_write: 1,
    });
    let guard = gate
        .arm(Box::new({
            let permits = permits.clone();
            let live = live.clone();
            let polls = polls.clone();
            move || {
                polls.fetch_add(1, Ordering::SeqCst);
                let permits = permits.clone();
                let live = live.clone();
                Box::pin(async move {
                    if !live.load(Ordering::SeqCst) {
                        return Err(io::Error::from(io::ErrorKind::PermissionDenied));
                    }
                    permits.fetch_add(1, Ordering::SeqCst);
                    Ok(write_permit(permits))
                })
            }
        }))
        .expect("gate fixture");
    for _ in 0..3 {
        std::future::poll_fn(|cx| {
            assert!(
                Pin::new(&mut stream)
                    .poll_write(cx, b"request")
                    .is_pending()
            );
            Poll::Ready(())
        })
        .await;
        assert_eq!(permits.load(Ordering::SeqCst), 0);
    }
    assert_eq!(permits.load(Ordering::SeqCst), 0);
    assert_eq!(polls.load(Ordering::SeqCst), 3);
    live.store(false, Ordering::SeqCst);
    assert_eq!(
        stream
            .write(b"request")
            .await
            .expect_err("gate rejects the write")
            .kind(),
        io::ErrorKind::PermissionDenied
    );
    assert_eq!(polls.load(Ordering::SeqCst), 4);
    assert_eq!(written.load(Ordering::SeqCst), 0);
    assert!(!guard.contacted().expect("gate fixture"));
    assert_eq!(*observations.lock().expect("gate fixture"), vec![1, 1, 1]);
    drop(guard);
    assert!(stream.write(b"rejected buffered frame").await.is_err());
    assert_eq!(written.load(Ordering::SeqCst), 0);
}

#[tokio::test]
async fn positive_partial_write_records_contact_and_releases_reservation() {
    let permits = Arc::new(AtomicUsize::new(0));
    let written = Arc::new(AtomicUsize::new(0));
    let observations = Arc::new(Mutex::new(Vec::new()));
    let (mut stream, gate) = GatedStream::new(Sink {
        writable: Arc::new(AtomicBool::new(true)),
        permits: permits.clone(),
        written: written.clone(),
        observations: observations.clone(),
        max_write: 1,
    });
    let guard = gate
        .arm(Box::new({
            let permits = permits.clone();
            move || {
                let permits = permits.clone();
                Box::pin(async move {
                    permits.fetch_add(1, Ordering::SeqCst);
                    Ok(write_permit(permits))
                })
            }
        }))
        .expect("gate fixture");
    assert_eq!(stream.write(b"request").await.expect("gate fixture"), 1);
    assert!(guard.contacted().expect("gate fixture"));
    assert_eq!(written.load(Ordering::SeqCst), 1);
    assert_eq!(permits.load(Ordering::SeqCst), 0);
    assert_eq!(
        stream.write(b"continuation").await.expect("gate fixture"),
        1
    );
    assert_eq!(*observations.lock().expect("gate fixture"), vec![1, 0]);
    stream.flush().await.expect("gate fixture");
    guard.finish().expect("gate fixture");
    let second = gate
        .arm(Box::new({
            let permits = permits.clone();
            move || {
                let permits = permits.clone();
                Box::pin(async move {
                    permits.fetch_add(1, Ordering::SeqCst);
                    Ok(write_permit(permits))
                })
            }
        }))
        .expect("gate fixture");
    assert_eq!(
        stream.write(b"second request").await.expect("gate fixture"),
        1
    );
    assert_eq!(*observations.lock().expect("gate fixture"), vec![1, 0, 1]);
    drop(second);
    assert!(
        stream
            .write(b"cancelled partial continuation")
            .await
            .is_err()
    );
    assert_eq!(written.load(Ordering::SeqCst), 3);
}

#[tokio::test]
async fn dropping_armed_request_drops_a_pending_owner_check() {
    let permits = Arc::new(AtomicUsize::new(0));
    let (mut stream, gate) = GatedStream::new(Sink {
        writable: Arc::new(AtomicBool::new(true)),
        permits: permits.clone(),
        written: Arc::new(AtomicUsize::new(0)),
        observations: Arc::new(Mutex::new(Vec::new())),
        max_write: 1,
    });
    let guard = gate
        .arm(Box::new({
            let permits = permits.clone();
            move || {
                let permits = permits.clone();
                Box::pin(async move {
                    permits.fetch_add(1, Ordering::SeqCst);
                    let _reservation = Permit(permits);
                    std::future::pending::<()>().await;
                    Ok(
                        Box::new(|write: &mut dyn FnMut() -> Poll<io::Result<usize>>| write())
                            as WritePermit,
                    )
                })
            }
        }))
        .expect("gate fixture");
    std::future::poll_fn(|cx| {
        assert!(
            Pin::new(&mut stream)
                .poll_write(cx, b"request")
                .is_pending()
        );
        Poll::Ready(())
    })
    .await;
    assert_eq!(permits.load(Ordering::SeqCst), 1);
    drop(guard);
    assert_eq!(permits.load(Ordering::SeqCst), 0);
    assert!(stream.write(b"abandoned frame").await.is_err());
}

#[tokio::test]
async fn zero_byte_ready_does_not_record_contact_or_keep_a_writer() {
    let permits = Arc::new(AtomicUsize::new(0));
    let written = Arc::new(AtomicUsize::new(0));
    let observations = Arc::new(Mutex::new(Vec::new()));
    let (mut stream, gate) = GatedStream::new(Sink {
        writable: Arc::new(AtomicBool::new(true)),
        permits: permits.clone(),
        written: written.clone(),
        observations: observations.clone(),
        max_write: 0,
    });
    let guard = gate
        .arm(Box::new({
            let permits = permits.clone();
            move || {
                let permits = permits.clone();
                Box::pin(async move {
                    permits.fetch_add(1, Ordering::SeqCst);
                    Ok(write_permit(permits))
                })
            }
        }))
        .expect("gate fixture");
    for _ in 0..2 {
        assert_eq!(stream.write(b"request").await.expect("gate fixture"), 0);
        assert_eq!(permits.load(Ordering::SeqCst), 0);
        assert!(!guard.contacted().expect("gate fixture"));
    }
    assert_eq!(*observations.lock().expect("gate fixture"), vec![1, 1]);
    assert!(guard.finish().is_err());
    assert!(stream.write(b"never contacted").await.is_err());
    assert_eq!(written.load(Ordering::SeqCst), 0);
}

#[test]
fn caller_drop_is_serialized_with_the_raw_poll_and_rejects_later_contact() {
    let cancellation = RequestCancellation::new();
    let lifetime = cancellation.cancel_on_drop();
    let result = cancellation.with_live_write(&mut || {
        assert!(
            cancellation.0.try_lock().is_err(),
            "the liveness fence covers the raw poll"
        );
        Poll::Ready(Ok(1))
    });
    assert!(matches!(result, Poll::Ready(Ok(1))));
    drop(lifetime);
    let mut called = false;
    let result = cancellation.with_live_write(&mut || {
        called = true;
        Poll::Ready(Ok(1))
    });
    assert!(
        matches!(result, Poll::Ready(Err(error)) if error.kind() == io::ErrorKind::Interrupted)
    );
    assert!(
        !called,
        "no first byte after the request future's drop returns"
    );
}
