"""Use the unchanged real recorder with actual temporary Git identities."""

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import yaml

ROOT = Path(__file__).resolve().parent
RUNNER = ROOT / "source/hepta_ci_exec.py"
WORKFLOW = Path(os.environ["TASKFLOW_WORKFLOW_UNDER_TEST"])
SOURCE_EXPRESSION = "${{ github.event.pull_request.head.sha || github.sha }}"
BASE_EXPRESSION = "${{ github.event.pull_request.base.sha || github.event.before || '' }}"
IDENTITY_KEYS = ("SOURCE_SHA", "TESTED_SHA", "BASE_SHA", "HEPTA_CI_LANE")

CHILD_TEST = '''import os
from pathlib import Path
import subprocess
import unittest

class ChildProbe(unittest.TestCase):
    def test_actual_committed_input(self):
        current = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
        self.assertEqual(current, os.environ["TESTED_SHA"])
        value = Path("input.txt").read_text()
        expected = "deliberate mismatch" if os.environ.get("PROBE_FAIL") else "reviewed input"
        self.assertEqual(value, expected)
        Path(os.environ["PROBE_MARKER"]).write_text(current)
'''


class WorkflowIdentityTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix="taskflow-identity-")
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        self.git("init", "-q")
        self.git("config", "user.name", "workflow-fixture")
        self.git("config", "user.email", "workflow-fixture@example.invalid")
        (self.repo / "input.txt").write_text("reviewed input")
        self.git("add", ".")
        self.git("commit", "-qm", "base fixture")
        self.base = self.git("rev-parse", "HEAD")
        (self.repo / "test_child.py").write_text(CHILD_TEST)
        self.git("add", ".")
        self.git("commit", "-qm", "source fixture with real unittest")
        self.source = self.git("rev-parse", "HEAD")
        self.result = self.root / "result.json"
        self.marker = self.root / "executed"

    def git(self, *args):
        return subprocess.check_output(
            ["git", "-C", str(self.repo), *args], text=True, stderr=subprocess.PIPE
        ).strip()

    def exact_environment(self):
        return {
            "SOURCE_SHA": self.source,
            "TESTED_SHA": self.source,
            "BASE_SHA": self.base,
            "HEPTA_CI_LANE": "source-head",
        }

    def workflow_environment(self):
        job = yaml.safe_load(WORKFLOW.read_text())["jobs"]["focused"]
        values = job.get("env", {})
        checkout = job["steps"][0]["with"]["ref"]
        self.assertEqual(checkout, SOURCE_EXPRESSION)
        resolved = {}
        for key in IDENTITY_KEYS:
            if key not in values:
                continue
            expected = {
                "SOURCE_SHA": SOURCE_EXPRESSION,
                "TESTED_SHA": checkout,
                "BASE_SHA": BASE_EXPRESSION,
                "HEPTA_CI_LANE": "source-head",
            }[key]
            self.assertEqual(values[key], expected)
            resolved[key] = self.exact_environment()[key]
        return resolved

    def execute(self, identities, *, fail_child=False):
        env = {key: value for key, value in os.environ.items() if key not in IDENTITY_KEYS}
        env.update(identities)
        env.update(PYTHONDONTWRITEBYTECODE="1", PROBE_MARKER=str(self.marker))
        if fail_child:
            env["PROBE_FAIL"] = "1"
        else:
            env.pop("PROBE_FAIL", None)
        process = subprocess.run(
            [sys.executable, str(RUNNER), "--output", str(self.result),
             "--minimum-tests", "1", "--timeout-seconds", "5", "--",
             sys.executable, "-m", "unittest", "-v", "test_child"],
            cwd=self.repo, env=env, text=True, capture_output=True, timeout=10,
        )
        record = json.loads(self.result.read_text())
        saved = ROOT / "evidence" / os.environ["TASKFLOW_PROBE_STAGE"] / self._testMethodName
        saved.mkdir(parents=True, exist_ok=True)
        (saved / "record.json").write_text(json.dumps(record, indent=2) + "\n")
        (saved / "wrapper.log").write_text(process.stdout + process.stderr)
        if record.get("log_file"):
            (saved / "child.log").write_bytes((self.root / record["log_file"]).read_bytes())
        return process, record

    def assert_rejected_without_dispatch(self, identities, reason):
        process, record = self.execute(identities)
        self.assertEqual(process.returncode, 2)
        self.assertEqual(record["status"], "rejected")
        self.assertIsNone(record["command_exit_code"])
        self.assertIn(reason, record["error"])
        self.assertFalse(self.marker.exists())

    def test_workflow_dispatches_real_test_after_exact_source_checkout(self):
        process, record = self.execute(self.workflow_environment())
        self.assertEqual(process.returncode, 0, record)
        self.assertEqual(record["status"], "passed")
        self.assertEqual(record["command_exit_code"], 0)
        self.assertEqual(record["observed_passed_tests"], 1)
        self.assertEqual(record["observed_failed_tests"], 0)
        self.assertEqual(record["before"], record["after"])
        self.assertEqual(record["tested_sha"], self.source)
        self.assertEqual(self.marker.read_text(), self.source)

    def test_missing_identity_still_rejects_before_dispatch(self):
        self.assert_rejected_without_dispatch({}, "invalid source_sha")

    def test_other_actual_tested_commit_still_rejects(self):
        env = self.exact_environment()
        env["TESTED_SHA"] = self.base
        self.assert_rejected_without_dispatch(env, "checkout")

    def test_other_actual_source_commit_still_rejects(self):
        env = self.exact_environment()
        env["SOURCE_SHA"] = self.base
        self.assert_rejected_without_dispatch(env, "source SHA")

    def test_missing_lane_still_rejects(self):
        env = self.exact_environment()
        env.pop("HEPTA_CI_LANE")
        self.assert_rejected_without_dispatch(env, "explicit source-head")

    def test_dirty_worktree_still_rejects(self):
        (self.repo / "input.txt").write_text("unreviewed")
        self.assert_rejected_without_dispatch(self.exact_environment(), "checkout")

    def test_real_failing_child_is_not_a_pass(self):
        process, record = self.execute(self.exact_environment(), fail_child=True)
        self.assertNotEqual(process.returncode, 0)
        self.assertEqual(record["status"], "failed")
        self.assertEqual(record["observed_failed_tests"], 1)
        self.assertEqual(record["observed_passed_tests"], 0)
        self.assertFalse(self.marker.exists())

    def test_only_identity_environment_changes(self):
        baseline = yaml.safe_load((ROOT / "source/automation-taskflow-focused.yml").read_text())
        candidate = yaml.safe_load(WORKFLOW.read_text())
        for key in IDENTITY_KEYS:
            candidate["jobs"]["focused"]["env"].pop(key, None)
        self.assertEqual(candidate, baseline)
        wrapped = [step["run"] for step in candidate["jobs"]["focused"]["steps"]
                   if "hepta_ci_exec.py" in step.get("run", "")]
        self.assertEqual(len(wrapped), 4)
        self.assertTrue(all("--minimum-tests 1 -- just test --locked" in run for run in wrapped))


if __name__ == "__main__":
    unittest.main()
