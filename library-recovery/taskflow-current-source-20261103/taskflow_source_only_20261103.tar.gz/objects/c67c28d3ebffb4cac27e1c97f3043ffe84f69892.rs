#![allow(
    clippy::expect_used,
    reason = "integration assertions and fixture setup must fail the test immediately"
)]

use std::sync::Arc;
use std::time::Duration;

use codex_hepta_automation::AutomationAdmission;
use codex_hepta_automation::AutomationError;
use codex_hepta_automation::AutomationFuture;
use codex_hepta_automation::AutomationMissedRunPolicy;
use codex_hepta_automation::AutomationOccurrenceState;
use codex_hepta_automation::AutomationOccurrenceTerminalState;
use codex_hepta_automation::AutomationOverlapPolicy;
use codex_hepta_automation::AutomationQueueReceipt;
use codex_hepta_automation::AutomationSchedule;
use codex_hepta_automation::AutomationScheduler;
use codex_hepta_automation::AutomationStore;
use codex_hepta_automation::AutomationTaskDraft;
use codex_hepta_automation::AutomationTaskId;
use codex_hepta_automation::AutomationTaskState;
use codex_hepta_automation::AutomationTick;
use codex_hepta_automation::AutomationTurnQueue;
use codex_hepta_automation::TaskFlowFence;
use codex_hepta_automation::TaskFlowReconcileOutcome;
use codex_hepta_automation::TaskFlowRunState;
use codex_hepta_automation::TaskFlowStepState;
use codex_hepta_contracts::AgentId;
use codex_hepta_contracts::Sha256Digest;
use codex_hepta_fleet::AgentManifest;
use codex_hepta_fleet::FleetRegistry;
use codex_hepta_fleet::ResourceBudget;
use codex_hepta_fleet::WorkspaceBinding;
use codex_hepta_paths::HeptaAgentLayout;
use codex_hepta_paths::HeptaFleetRoot;
use codex_state::SqliteConfig;
use codex_utils_absolute_path::AbsolutePathBuf;
use pretty_assertions::assert_eq;

#[path = "durable_causal_chain/claim_lifecycle_tests.rs"]
mod claim_lifecycle_tests;

#[path = "durable_causal_chain/observer_recovery_tests.rs"]
mod observer_recovery_tests;

#[path = "durable_causal_chain/terminal_recovery_tests.rs"]
mod terminal_recovery_tests;

const AGENT_ID: &str = "018f4f72-5f8f-7cc1-8f55-df9fb3aa2c12";
const THREAD_ID: &str = "019153a4-3088-7e03-a56a-9b1964f75ddd";

struct Fixture {
    _temp: tempfile::TempDir,
    layout: HeptaAgentLayout,
}

impl Fixture {
    fn new() -> Self {
        let temp = tempfile::tempdir().expect("temp root");
        let root = temp.path().canonicalize().expect("canonical root");
        let fleet_root = HeptaFleetRoot::parse(root.join("fleet")).expect("fleet root");
        let registry = FleetRegistry::initialize(fleet_root.clone()).expect("fleet registry");
        let workspace = root.join("workspace");
        std::fs::create_dir(&workspace).expect("workspace");
        let workspace = workspace.canonicalize().expect("canonical workspace");
        let manifest = AgentManifest::new(
            AgentId::parse(AGENT_ID).expect("agent id"),
            WorkspaceBinding::new(workspace, &fleet_root).expect("workspace binding"),
            ResourceBudget::local_default(),
        )
        .expect("manifest");
        let layout = registry.register(manifest).expect("register agent").layout;
        Self {
            _temp: temp,
            layout,
        }
    }
}

#[derive(Default)]
struct SuccessQueue;

impl AutomationTurnQueue for SuccessQueue {
    fn enqueue(
        &self,
        admission: AutomationAdmission,
    ) -> AutomationFuture<'_, AutomationQueueReceipt> {
        Box::pin(async move {
            Ok(AutomationQueueReceipt {
                queued_submission_id: format!(
                    "queue:{}:{}",
                    admission.task_id, admission.occurrence
                ),
                client_user_message_id: admission.client_user_message_id,
            })
        })
    }
}

#[derive(Default)]
struct UnknownQueue;

impl AutomationTurnQueue for UnknownQueue {
    fn enqueue(
        &self,
        _admission: AutomationAdmission,
    ) -> AutomationFuture<'_, AutomationQueueReceipt> {
        Box::pin(async { Err(AutomationError::DispatchUnknown) })
    }
}

fn draft(id: &str, schedule: AutomationSchedule, due: u64) -> AutomationTaskDraft {
    let mut draft = AutomationTaskDraft::new(THREAD_ID, "durable causal work", schedule, due, 1);
    draft.task_id = AutomationTaskId::parse(id).expect("task id");
    draft
}

#[tokio::test]
async fn claim_freezes_schedule_revision_before_occurrence_materialization() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75100",
        AutomationSchedule::Once,
        100,
    );
    store.create_task(&task).await.expect("create task");

    let lease = store
        .claim_due(100, 1, 30_000)
        .await
        .expect("claim")
        .expect("lease");
    assert_eq!(lease.schedule_revision, 1);

    assert!(matches!(
        store
            .set_schedule_policy(
                task.task_id,
                1,
                AutomationMissedRunPolicy::Coalesce,
                AutomationOverlapPolicy::Forbid,
                101,
            )
            .await,
        Err(AutomationError::Conflict)
    ));

    let occurrence = store
        .materialize_occurrence(&lease, 102)
        .await
        .expect("materialize frozen revision");
    assert_eq!(occurrence.schedule_revision, lease.schedule_revision);
    assert_eq!(occurrence.scheduled_for_ms, lease.scheduled_for_ms);
}

#[tokio::test]
async fn occurrence_materialization_rejects_stale_and_forged_claims() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75110",
        AutomationSchedule::Once,
        /*due*/ 100,
    );
    store.create_task(&task).await.expect("create task");
    let old = store
        .claim_due(
            /*now_ms*/ 100, /*generation*/ 1, /*lease_duration_ms*/ 10,
        )
        .await
        .expect("claim")
        .unwrap();
    let current = store
        .claim_due(
            /*now_ms*/ 110, /*generation*/ 2, /*lease_duration_ms*/ 100,
        )
        .await
        .expect("reclaim")
        .unwrap();
    assert_eq!(
        store.materialize_occurrence(&old, /*now_ms*/ 111).await,
        Err(AutomationError::Conflict)
    );
    assert_eq!(
        store
            .automation_occurrence(task.task_id, /*occurrence*/ 1)
            .await
            .unwrap(),
        None
    );
    let occurrence = store
        .materialize_occurrence(&current, /*now_ms*/ 111)
        .await
        .unwrap();
    let mut forged = current.clone();
    forged.task.prompt = "replace the canonical dispatch payload".to_string();
    for rejected in [&old, &forged] {
        assert_eq!(
            store.materialize_occurrence(rejected, /*now_ms*/ 112).await,
            Err(AutomationError::Conflict)
        );
        assert_eq!(
            store
                .automation_occurrence(task.task_id, /*occurrence*/ 1)
                .await
                .unwrap(),
            Some(occurrence.clone())
        );
    }
    store
        .prepare_occurrence_taskflow(
            &occurrence,
            &current,
            /*now_ms*/ 112,
            /*lease_duration_ms*/ 100,
        )
        .await
        .unwrap();
    assert_eq!(
        store
            .record_dispatch_uncertain(&forged, /*observed_at_ms*/ 113)
            .await,
        Err(AutomationError::Conflict)
    );
    assert_eq!(
        store.uncertain_dispatches(/*limit*/ 1).await.unwrap(),
        Vec::new()
    );
    store
        .record_dispatch_uncertain(&current, /*observed_at_ms*/ 113)
        .await
        .unwrap();
    store.close().await;
}

#[tokio::test]
async fn retirement_waits_for_lifecycle_settlement_while_handoff_preserves_it() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75111",
        AutomationSchedule::Once,
        /*due*/ 100,
    );
    store.create_task(&task).await.unwrap();
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        /*generation*/ 1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .unwrap();
    scheduler.tick(/*now_ms*/ 100).await.unwrap();
    assert!(store.quiesce_timer().await.unwrap().can_handoff());
    assert_eq!(store.retire_timer().await, Err(AutomationError::Conflict));
    let occurrence = store
        .automation_occurrence(task.task_id, /*occurrence*/ 1)
        .await
        .unwrap()
        .unwrap();
    store
        .record_occurrence_turn(
            task.task_id,
            /*occurrence*/ 1,
            &occurrence.client_user_message_id,
            "turn:drain",
            Sha256Digest::for_bytes(b"payload").as_str(),
            /*observed_at_ms*/ 101,
        )
        .await
        .unwrap();
    assert_eq!(store.retire_timer().await, Err(AutomationError::Conflict));
    store
        .mark_occurrence_indeterminate(
            task.task_id,
            /*occurrence*/ 1,
            &Sha256Digest::for_bytes(b"indeterminate"),
            /*observed_at_ms*/ 102,
        )
        .await
        .unwrap();
    assert_eq!(store.retire_timer().await, Err(AutomationError::Conflict));
    let successor = store.handoff_timer().await.unwrap();
    assert_eq!(
        successor.retire_timer().await,
        Err(AutomationError::Conflict)
    );
    let work = successor
        .pending_occurrence_work(/*limit*/ 1)
        .await
        .unwrap()
        .pop()
        .unwrap();
    let terminal = Sha256Digest::for_bytes(b"settled before retirement");
    successor
        .reconcile_occurrence_taskflow_terminal(
            &work,
            AutomationOccurrenceTerminalState::Succeeded,
            &terminal,
            /*now_ms*/ 103,
        )
        .await
        .unwrap();
    successor
        .complete_occurrence(
            task.task_id,
            /*occurrence*/ 1,
            AutomationOccurrenceTerminalState::Succeeded,
            &terminal,
            /*completed_at_ms*/ 103,
        )
        .await
        .unwrap();
    assert_eq!(
        successor.retire_timer().await.unwrap().phase,
        codex_hepta_automation::TimerPhase::Retired
    );
    store.close().await;
    successor.close().await;
}

#[tokio::test]
async fn retirement_preserves_provider_absent_pending_backlog() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.unwrap();
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75115",
        AutomationSchedule::Once,
        /*due*/ 100,
    );
    store.create_task(&task).await.unwrap();
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(UnknownQueue),
        /*generation*/ 1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .unwrap();
    scheduler.tick(/*now_ms*/ 100).await.unwrap();
    let occurrence = store
        .automation_occurrence(task.task_id, /*occurrence*/ 1)
        .await
        .unwrap()
        .unwrap();
    store
        .reconcile_uncertain_occurrence_absent(
            task.task_id,
            /*occurrence*/ 1,
            &occurrence.client_user_message_id,
            &Sha256Digest::for_bytes(b"provider absent"),
            /*observed_at_ms*/ 101,
        )
        .await
        .unwrap();
    assert_eq!(store.quiesce_timer().await.unwrap().pending_occurrences, 1);
    store.retire_timer().await.unwrap();
    store.close().await;
    let reopened = AutomationStore::open(&fixture.layout).await.unwrap();
    assert_eq!(
        reopened.timer_status().await.unwrap().phase,
        codex_hepta_automation::TimerPhase::Retired
    );
    assert_eq!(
        reopened
            .automation_occurrence(task.task_id, /*occurrence*/ 1)
            .await
            .unwrap()
            .unwrap()
            .state,
        AutomationOccurrenceState::Claimed
    );
    assert_eq!(
        reopened
            .claim_due(
                /*now_ms*/ 200, /*generation*/ 2, /*lease_duration_ms*/ 1_000
            )
            .await,
        Err(AutomationError::TimerFenced)
    );
    reopened.close().await;
}

#[tokio::test]
async fn completed_observations_rotate_work_without_overwriting_newer_state() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.unwrap();
    for (id, due) in [
        ("019153a4-3088-7000-a56a-9b1964f75112", 100),
        ("019153a4-3088-7000-a56a-9b1964f75113", 101),
    ] {
        store
            .create_task(&draft(id, AutomationSchedule::Once, due))
            .await
            .unwrap();
    }
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        /*generation*/ 1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .unwrap();
    scheduler.tick(/*now_ms*/ 100).await.unwrap();
    scheduler.tick(/*now_ms*/ 101).await.unwrap();
    let first = store
        .pending_occurrence_work(/*limit*/ 1)
        .await
        .unwrap()
        .pop()
        .unwrap()
        .occurrence;
    assert!(
        store
            .defer_occurrence_observation(&first, /*observed_at_ms*/ 102)
            .await
            .unwrap()
    );
    let second = store
        .pending_occurrence_work(/*limit*/ 1)
        .await
        .unwrap()
        .pop()
        .unwrap()
        .occurrence;
    assert_ne!(second.task_id, first.task_id);
    store
        .record_occurrence_turn(
            second.task_id,
            second.occurrence,
            &second.client_user_message_id,
            "turn:progress",
            Sha256Digest::for_bytes(b"payload").as_str(),
            /*observed_at_ms*/ 103,
        )
        .await
        .unwrap();
    let running = store
        .automation_occurrence(second.task_id, second.occurrence)
        .await
        .unwrap();
    assert!(
        !store
            .defer_occurrence_observation(&second, /*observed_at_ms*/ 200)
            .await
            .unwrap()
    );
    assert_eq!(
        store
            .automation_occurrence(second.task_id, second.occurrence)
            .await
            .unwrap(),
        running
    );
    assert!(
        !store
            .defer_occurrence_observation(&first, /*observed_at_ms*/ 200)
            .await
            .unwrap()
    );
    store.close().await;
}

#[tokio::test]
async fn disabling_and_resuming_cannot_bypass_forbidden_overlap() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.unwrap();
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75114",
        AutomationSchedule::FixedInterval { interval_ms: 1_000 },
        /*due*/ 100,
    );
    store.create_task(&task).await.unwrap();
    store
        .set_schedule_policy(
            task.task_id,
            /*expected_revision*/ 1,
            AutomationMissedRunPolicy::Skip,
            AutomationOverlapPolicy::Forbid,
            /*now_ms*/ 1,
        )
        .await
        .unwrap();
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        /*generation*/ 1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .unwrap();
    scheduler.tick(/*now_ms*/ 100).await.unwrap();
    let disabled = store
        .set_enabled(
            task.task_id,
            /*enabled*/ false,
            /*resume_at_ms*/ None,
            /*now_ms*/ 101,
        )
        .await
        .unwrap();
    assert_eq!(
        store
            .set_enabled(
                task.task_id,
                /*enabled*/ true,
                Some(102),
                /*now_ms*/ 102
            )
            .await,
        Err(AutomationError::Conflict)
    );
    assert_eq!(store.task(task.task_id).await.unwrap(), Some(disabled));
    assert_eq!(
        scheduler.tick(/*now_ms*/ 102).await.unwrap(),
        AutomationTick::Idle
    );

    // Disabling a provider-proven-absent queued intent must settle its old
    // local lifecycle so it cannot freeze future schedule policy revisions.
    let absent = draft(
        "019153a4-3088-7000-a56a-9b1964f75116",
        AutomationSchedule::FixedInterval { interval_ms: 1_000 },
        /*due*/ 103,
    );
    store.create_task(&absent).await.unwrap();
    store
        .set_schedule_policy(
            absent.task_id,
            /*expected_revision*/ 1,
            AutomationMissedRunPolicy::Skip,
            AutomationOverlapPolicy::Forbid,
            /*now_ms*/ 102,
        )
        .await
        .unwrap();
    let unknown = AutomationScheduler::new(
        store.clone(),
        Arc::new(UnknownQueue),
        /*generation*/ 1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .unwrap();
    unknown.tick(/*now_ms*/ 103).await.unwrap();
    let claimed = store
        .automation_occurrence(absent.task_id, /*occurrence*/ 1)
        .await
        .unwrap()
        .unwrap();
    store
        .reconcile_uncertain_occurrence_absent(
            absent.task_id,
            /*occurrence*/ 1,
            &claimed.client_user_message_id,
            &Sha256Digest::for_bytes(b"resume after provider absence"),
            /*observed_at_ms*/ 104,
        )
        .await
        .unwrap();
    store
        .set_enabled(
            absent.task_id,
            /*enabled*/ false,
            /*resume_at_ms*/ None,
            /*now_ms*/ 105,
        )
        .await
        .unwrap();
    assert_eq!(
        store
            .automation_occurrence(absent.task_id, /*occurrence*/ 1)
            .await
            .unwrap()
            .unwrap()
            .state,
        AutomationOccurrenceState::Cancelled
    );
    assert_eq!(
        store
            .taskflow_run(&claimed.taskflow_run_id)
            .await
            .unwrap()
            .unwrap()
            .state,
        TaskFlowRunState::Cancelled
    );
    let resumed = store
        .set_enabled(
            absent.task_id,
            /*enabled*/ true,
            Some(107),
            /*now_ms*/ 106,
        )
        .await
        .unwrap();
    assert_eq!(resumed.next_run_at_ms, Some(107));
    assert!(
        matches!(scheduler.tick(/*now_ms*/ 107).await.unwrap(), AutomationTick::Submitted { task_id, occurrence: 2, .. } if task_id == absent.task_id)
    );
    let work = store
        .pending_occurrence_work(/*limit*/ 1_024)
        .await
        .unwrap()
        .into_iter()
        .find(|work| work.occurrence.task_id == absent.task_id && work.occurrence.occurrence == 2)
        .unwrap();
    let terminal = Sha256Digest::for_bytes(b"resumed occurrence terminal success");
    store
        .reconcile_occurrence_taskflow_terminal(
            &work,
            AutomationOccurrenceTerminalState::Succeeded,
            &terminal,
            /*now_ms*/ 108,
        )
        .await
        .unwrap();
    store
        .complete_occurrence(
            absent.task_id,
            /*occurrence*/ 2,
            AutomationOccurrenceTerminalState::Succeeded,
            &terminal,
            /*completed_at_ms*/ 108,
        )
        .await
        .unwrap();
    assert_eq!(
        store
            .set_schedule_policy(
                absent.task_id,
                /*expected_revision*/ 2,
                AutomationMissedRunPolicy::Coalesce,
                AutomationOverlapPolicy::Allow,
                /*now_ms*/ 109,
            )
            .await
            .unwrap()
            .revision,
        3
    );

    let unresolved = draft(
        "019153a4-3088-7000-a56a-9b1964f75127",
        AutomationSchedule::Once,
        /*due*/ 200,
    );
    store.create_task(&unresolved).await.unwrap();
    unknown.tick(/*now_ms*/ 200).await.unwrap();
    store
        .set_enabled(
            unresolved.task_id,
            /*enabled*/ false,
            /*resume_at_ms*/ None,
            /*now_ms*/ 201,
        )
        .await
        .unwrap();
    assert_eq!(
        store
            .set_schedule_policy(
                unresolved.task_id,
                /*expected_revision*/ 1,
                AutomationMissedRunPolicy::Coalesce,
                AutomationOverlapPolicy::Allow,
                /*now_ms*/ 202,
            )
            .await,
        Err(AutomationError::Conflict)
    );
    assert_eq!(
        store
            .automation_occurrence(unresolved.task_id, /*occurrence*/ 1)
            .await
            .unwrap()
            .unwrap()
            .state,
        AutomationOccurrenceState::Claimed
    );
    store.close().await;
}

#[tokio::test]
async fn queue_submission_is_not_occurrence_or_taskflow_success() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75101",
        AutomationSchedule::Once,
        100,
    );
    store.create_task(&task).await.expect("create task");
    let policy = store.schedule_policy(task.task_id).await.expect("policy");
    assert_eq!(policy.overlap, AutomationOverlapPolicy::Allow);
    assert_eq!(policy.missed_run, AutomationMissedRunPolicy::Skip);

    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("scheduler");
    assert!(matches!(
        scheduler.tick(100).await.expect("tick"),
        AutomationTick::Submitted { occurrence: 1, .. }
    ));

    // Legacy task state means no further schedule instant; it is not the
    // execution outcome. The occurrence and TaskFlow run remain non-terminal.
    assert_eq!(
        store.task(task.task_id).await.expect("task").unwrap().state,
        AutomationTaskState::Completed
    );
    let occurrence = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("occurrence")
        .expect("materialized");
    assert_eq!(occurrence.state, AutomationOccurrenceState::Admitted);
    assert!(occurrence.terminal_at_ms.is_none());
    let run = store
        .taskflow_run(&occurrence.taskflow_run_id)
        .await
        .expect("run")
        .expect("taskflow run");
    assert_eq!(run.state, TaskFlowRunState::Indeterminate);

    let terminal = Sha256Digest::for_bytes(b"observed terminal success");
    assert!(matches!(
        store
            .complete_occurrence(
                task.task_id,
                1,
                AutomationOccurrenceTerminalState::Succeeded,
                &terminal,
                190,
            )
            .await,
        Err(AutomationError::Conflict)
    ));

    let work = store
        .pending_occurrence_work(1)
        .await
        .expect("work")
        .pop()
        .expect("pending occurrence");
    store
        .reconcile_occurrence_taskflow_terminal(
            &work,
            AutomationOccurrenceTerminalState::Succeeded,
            &terminal,
            200,
        )
        .await
        .expect("taskflow terminal");
    let occurrence = store
        .complete_occurrence(
            task.task_id,
            1,
            AutomationOccurrenceTerminalState::Succeeded,
            &terminal,
            200,
        )
        .await
        .expect("occurrence terminal");
    assert_eq!(occurrence.state, AutomationOccurrenceState::Succeeded);
    assert_eq!(occurrence.terminal_at_ms, Some(200));
}

#[tokio::test]
async fn allow_overlap_advances_recurrence_without_terminalizing_prior_occurrence() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75104",
        AutomationSchedule::FixedInterval { interval_ms: 1_000 },
        100,
    );
    store.create_task(&task).await.expect("create task");
    let policy = store.schedule_policy(task.task_id).await.expect("policy");
    assert_eq!(policy.overlap, AutomationOverlapPolicy::Allow);

    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("scheduler");
    assert!(matches!(
        scheduler.tick(100).await.expect("first tick"),
        AutomationTick::Submitted { occurrence: 1, .. }
    ));
    assert_eq!(
        store
            .task(task.task_id)
            .await
            .expect("task")
            .unwrap()
            .next_run_at_ms,
        Some(1_100),
        "allow overlap advances only the schedule frontier after durable admission"
    );

    let first = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("first occurrence")
        .expect("first materialized");
    assert_eq!(first.state, AutomationOccurrenceState::Admitted);
    assert!(first.terminal_at_ms.is_none());

    assert!(matches!(
        scheduler.tick(1_100).await.expect("second tick"),
        AutomationTick::Submitted { occurrence: 2, .. }
    ));
    let first_after = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("first occurrence after overlap")
        .expect("first remains materialized");
    let second = store
        .automation_occurrence(task.task_id, 2)
        .await
        .expect("second occurrence")
        .expect("second materialized");
    assert_eq!(first_after.state, AutomationOccurrenceState::Admitted);
    assert!(first_after.terminal_at_ms.is_none());
    assert_eq!(second.state, AutomationOccurrenceState::Admitted);
    assert_ne!(first_after.occurrence_id, second.occurrence_id);
}

#[tokio::test]
async fn forbid_overlap_parks_recurrence_until_terminal_observation() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75102",
        AutomationSchedule::FixedInterval { interval_ms: 1_000 },
        100,
    );
    store.create_task(&task).await.expect("create task");
    let policy = store
        .set_schedule_policy(
            task.task_id,
            1,
            AutomationMissedRunPolicy::Skip,
            AutomationOverlapPolicy::Forbid,
            2,
        )
        .await
        .expect("set policy");
    assert_eq!(policy.revision, 2);

    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("scheduler");
    scheduler.tick(100).await.expect("tick");
    assert_eq!(
        store
            .task(task.task_id)
            .await
            .expect("task")
            .unwrap()
            .next_run_at_ms,
        None,
        "forbidden overlap must park the timer after queue admission"
    );

    let work = store
        .pending_occurrence_work(1)
        .await
        .expect("work")
        .pop()
        .expect("pending occurrence");
    assert_eq!(work.occurrence.schedule_revision, 2);
    let receipt = Sha256Digest::for_bytes(b"terminal before next interval");
    store
        .reconcile_occurrence_taskflow_terminal(
            &work,
            AutomationOccurrenceTerminalState::Succeeded,
            &receipt,
            500,
        )
        .await
        .expect("taskflow terminal");
    store
        .complete_occurrence(
            task.task_id,
            1,
            AutomationOccurrenceTerminalState::Succeeded,
            &receipt,
            500,
        )
        .await
        .expect("occurrence terminal");
    assert_eq!(
        store
            .task(task.task_id)
            .await
            .expect("task")
            .unwrap()
            .next_run_at_ms,
        Some(1_100)
    );
}

#[tokio::test]
async fn terminal_observer_cursor_is_durable_bounded_progress() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75108",
        AutomationSchedule::Once,
        100,
    );
    store.create_task(&task).await.expect("create task");
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("scheduler");
    scheduler.tick(100).await.expect("queue admission");

    let occurrence = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("occurrence")
        .expect("materialized");
    let payload = Sha256Digest::for_bytes(b"terminal observer payload");
    let running = store
        .record_occurrence_turn(
            task.task_id,
            1,
            &occurrence.client_user_message_id,
            "turn-known-but-old",
            payload.as_str(),
            101,
        )
        .await
        .expect("record turn");
    assert!(running.terminal_scan_cursor.is_none());

    let cursor_one = r#"{"turn_id":"page-anchor-1600","include_anchor":false}"#;
    let advanced = store
        .record_terminal_scan_cursor(task.task_id, 1, "turn-known-but-old", None, cursor_one, 102)
        .await
        .expect("persist first bounded continuation");
    assert_eq!(advanced.terminal_scan_cursor.as_deref(), Some(cursor_one));

    assert!(matches!(
        store
            .record_terminal_scan_cursor(
                task.task_id,
                1,
                "turn-known-but-old",
                Some(cursor_one),
                cursor_one,
                103,
            )
            .await,
        Err(AutomationError::Invalid)
    ));

    store.close().await;
    let reopened = AutomationStore::open(&fixture.layout)
        .await
        .expect("reopen cursor state");
    let durable = reopened
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("read reopened occurrence")
        .expect("reopened materialized occurrence");
    assert_eq!(durable.terminal_scan_cursor.as_deref(), Some(cursor_one));

    let cursor_two = r#"{"turn_id":"page-anchor-3200","include_anchor":false}"#;
    assert!(matches!(
        reopened
            .record_terminal_scan_cursor(
                task.task_id,
                1,
                "turn-known-but-old",
                None,
                cursor_two,
                104,
            )
            .await,
        Err(AutomationError::Conflict)
    ));
    let advanced = reopened
        .record_terminal_scan_cursor(
            task.task_id,
            1,
            "turn-known-but-old",
            Some(cursor_one),
            cursor_two,
            105,
        )
        .await
        .expect("advance exact cursor");
    assert_eq!(advanced.terminal_scan_cursor.as_deref(), Some(cursor_two));

    let missing = Sha256Digest::for_bytes(b"full history exhausted");
    let indeterminate = reopened
        .mark_occurrence_indeterminate(task.task_id, 1, &missing, 106)
        .await
        .expect("terminal scan exhaustion");
    assert_eq!(
        indeterminate.state,
        AutomationOccurrenceState::Indeterminate
    );
    assert!(indeterminate.terminal_scan_cursor.is_none());
}

#[tokio::test]
async fn proven_absent_unknown_dispatch_reuses_same_occurrence_identity() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75103",
        AutomationSchedule::Once,
        100,
    );
    store.create_task(&task).await.expect("create task");
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(UnknownQueue),
        1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("scheduler");
    assert_eq!(
        scheduler.tick(100).await.expect("unknown tick"),
        AutomationTick::DispatchUncertain {
            task_id: task.task_id,
            occurrence: 1,
        }
    );
    let first = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("occurrence")
        .expect("materialized");
    assert_eq!(first.state, AutomationOccurrenceState::Claimed);
    let uncertain = store
        .uncertain_dispatches(1)
        .await
        .expect("uncertain")
        .pop()
        .expect("uncertain row");

    // Only an external ReconcileOnly `Missing` proof may open this retry path.
    let run_before_absence = store
        .taskflow_run(&first.taskflow_run_id)
        .await
        .expect("run before absence")
        .expect("running TaskFlow");
    let old_fence = TaskFlowFence::new(
        run_before_absence.owner_agent_id.clone(),
        run_before_absence.owner_id.clone().expect("owner id"),
        run_before_absence.owner_epoch.expect("owner epoch"),
        run_before_absence.generation.expect("generation"),
        run_before_absence
            .fencing_token
            .clone()
            .expect("fencing token"),
    )
    .expect("historical fence");
    let proof_digest = Sha256Digest::for_bytes(b"provider proved stable id absent");
    store
        .reconcile_uncertain_occurrence_absent(
            task.task_id,
            1,
            &uncertain.client_user_message_id,
            &proof_digest,
            101,
        )
        .await
        .expect("release after absence proof");
    let old_step = store
        .read_taskflow_step(
            &first.taskflow_run_id,
            "codex_turn",
            first.step_attempt,
            &old_fence,
        )
        .await
        .expect("read old step")
        .expect("old step evidence");
    assert_eq!(old_step.state, TaskFlowStepState::Reconciled);
    assert_eq!(
        old_step.final_outcome,
        Some(TaskFlowReconcileOutcome::Cancelled)
    );
    assert_eq!(old_step.receipt_digest.as_ref(), Some(&proof_digest));

    // Exercise the real second scheduler pass, not merely rematerialization.
    // Reusing the same Agent generation proves TaskFlow's attempt-generation
    // fence advances independently from the Agent spawn generation.
    let retry_scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("retry scheduler");
    assert!(matches!(
        retry_scheduler.tick(102).await.expect("retry tick"),
        AutomationTick::Submitted {
            task_id,
            occurrence: 1,
            ..
        } if task_id == task.task_id
    ));
    let second = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("occurrence")
        .expect("same occurrence after retry");
    assert_eq!(second.occurrence_id, first.occurrence_id);
    assert_eq!(second.schedule_revision, first.schedule_revision);
    assert_eq!(
        second.client_user_message_id,
        uncertain.client_user_message_id
    );
    assert_eq!(second.claim_generation, 1);
    assert_eq!(second.step_attempt, 2);
    assert_eq!(second.state, AutomationOccurrenceState::Admitted);
}

#[tokio::test]
async fn retired_schedule_with_proven_absence_terminalizes_taskflow_and_occurrence() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75105",
        AutomationSchedule::Once,
        100,
    );
    store.create_task(&task).await.expect("create task");
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(UnknownQueue),
        1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("scheduler");
    assert!(matches!(
        scheduler.tick(100).await.expect("unknown tick"),
        AutomationTick::DispatchUncertain { occurrence: 1, .. }
    ));
    store
        .set_enabled(task.task_id, false, None, 101)
        .await
        .expect("disable while outcome is unknown");
    let uncertain = store
        .uncertain_dispatches(1)
        .await
        .expect("uncertain")
        .pop()
        .expect("uncertain row");
    let proof = Sha256Digest::for_bytes(b"retired schedule provider absence");
    store
        .reconcile_uncertain_occurrence_absent(
            task.task_id,
            1,
            &uncertain.client_user_message_id,
            &proof,
            102,
        )
        .await
        .expect("terminalize retired absence");

    let occurrence = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("occurrence")
        .expect("materialized");
    assert_eq!(occurrence.state, AutomationOccurrenceState::Cancelled);
    assert_eq!(occurrence.terminal_receipt_digest.as_ref(), Some(&proof));
    let run = store
        .taskflow_run(&occurrence.taskflow_run_id)
        .await
        .expect("run")
        .expect("taskflow run");
    assert_eq!(run.state, TaskFlowRunState::Cancelled);
    assert!(
        store
            .uncertain_dispatches(1)
            .await
            .expect("uncertain scan")
            .is_empty()
    );
    assert_eq!(
        store.task(task.task_id).await.expect("task").unwrap().state,
        AutomationTaskState::Disabled
    );

    drop(scheduler);
    store.close().await;
    let reopened = AutomationStore::open(&fixture.layout)
        .await
        .expect("reopen after provider-absence cancellation");
    let reopened_occurrence = reopened
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("reopened occurrence")
        .expect("reopened materialized occurrence");
    assert_eq!(
        reopened_occurrence.state,
        AutomationOccurrenceState::Cancelled
    );
    assert_eq!(
        reopened_occurrence.terminal_receipt_digest.as_ref(),
        Some(&proof)
    );
    let reopened_run = reopened
        .taskflow_run(&reopened_occurrence.taskflow_run_id)
        .await
        .expect("reopened run")
        .expect("reopened TaskFlow run");
    assert_eq!(reopened_run.state, TaskFlowRunState::Cancelled);
    reopened.close().await;
}

#[tokio::test]
async fn stale_generation_between_taskflow_intent_and_uncertainty_recovers_same_occurrence() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75106",
        AutomationSchedule::Once,
        100,
    );
    store.create_task(&task).await.expect("create task");
    let lease = store
        .claim_due(100, 1, 30_000)
        .await
        .expect("claim")
        .expect("lease");
    let occurrence = store
        .materialize_occurrence(&lease, 100)
        .await
        .expect("materialize");
    store
        .prepare_occurrence_taskflow(&occurrence, &lease, 100, 30_000)
        .await
        .expect("persist TaskFlow intent");
    // Simulate process loss before record_dispatch_uncertain().
    assert_eq!(
        store
            .recover_stale_generation(2, 101)
            .await
            .expect("causal stale recovery"),
        1
    );

    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        2,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("replacement scheduler");
    assert!(matches!(
        scheduler.tick(102).await.expect("replacement tick"),
        AutomationTick::Submitted { occurrence: 1, .. }
    ));
    let recovered = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("occurrence")
        .expect("same occurrence");
    assert_eq!(recovered.occurrence_id, occurrence.occurrence_id);
    assert_eq!(
        recovered.client_user_message_id,
        occurrence.client_user_message_id
    );
    assert_eq!(recovered.step_attempt, 2);
    assert_eq!(recovered.claim_generation, 2);
    assert_eq!(recovered.state, AutomationOccurrenceState::Admitted);
}

#[tokio::test]
async fn retired_stale_generation_before_uncertainty_closes_without_provider_contact() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75107",
        AutomationSchedule::Once,
        100,
    );
    store.create_task(&task).await.expect("create task");
    let lease = store
        .claim_due(100, 1, 30_000)
        .await
        .expect("claim")
        .expect("lease");
    let occurrence = store
        .materialize_occurrence(&lease, 100)
        .await
        .expect("materialize");
    store
        .prepare_occurrence_taskflow(&occurrence, &lease, 100, 30_000)
        .await
        .expect("persist TaskFlow intent");
    store
        .set_enabled(task.task_id, false, None, 101)
        .await
        .expect("retire schedule");
    assert_eq!(
        store
            .recover_stale_generation(2, 102)
            .await
            .expect("retired stale recovery"),
        1
    );
    let terminal = store
        .automation_occurrence(task.task_id, 1)
        .await
        .expect("occurrence")
        .expect("terminal occurrence");
    assert_eq!(terminal.state, AutomationOccurrenceState::Cancelled);
    assert!(terminal.terminal_receipt_digest.is_some());
    assert_eq!(
        store
            .taskflow_run(&terminal.taskflow_run_id)
            .await
            .expect("run")
            .expect("taskflow")
            .state,
        TaskFlowRunState::Cancelled
    );
}

#[tokio::test]
async fn reopen_rejects_tampered_canonical_occurrence_identity() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75107",
        AutomationSchedule::Once,
        100,
    );
    store.create_task(&task).await.expect("create task");
    let lease = store
        .claim_due(100, 1, 30_000)
        .await
        .expect("claim")
        .expect("lease");
    let occurrence = store
        .materialize_occurrence(&lease, 100)
        .await
        .expect("materialize");
    let database_path = store.path().to_path_buf();
    store.close().await;

    let sqlite_home =
        AbsolutePathBuf::from_absolute_path(fixture.layout.automation_root()).expect("sqlite home");
    let pool = SqliteConfig::from_sqlite_home(sqlite_home)
        .open_durable_evidence_pool(&database_path)
        .await
        .expect("inspection pool");
    sqlx::query("DROP TRIGGER automation_occurrence_identity_no_update")
        .execute(&pool)
        .await
        .expect("drop identity trigger");
    let forged = format!("automation-occurrence:{}", "a".repeat(64));
    assert_ne!(forged, occurrence.occurrence_id);
    sqlx::query(
        "UPDATE automation_occurrence_lifecycle
         SET occurrence_id = ?
         WHERE task_id = ? AND occurrence = ?",
    )
    .bind(forged)
    .bind(task.task_id.to_string())
    .bind(1_i64)
    .execute(&pool)
    .await
    .expect("tamper occurrence identity");
    pool.close().await;

    assert!(matches!(
        AutomationStore::open(&fixture.layout).await,
        Err(AutomationError::Corrupt)
    ));
}

#[tokio::test]
async fn preparation_rejects_payload_mutated_after_materialization() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75120",
        AutomationSchedule::Once,
        /*due*/ 100,
    );
    store.create_task(&task).await.expect("task");
    let lease = store
        .claim_due(
            /*now_ms*/ 100, /*generation*/ 1, /*lease_duration_ms*/ 30_000,
        )
        .await
        .expect("claim")
        .unwrap();
    let occurrence = store
        .materialize_occurrence(&lease, /*now_ms*/ 100)
        .await
        .expect("occurrence");
    let mut forged = lease.clone();
    forged.task.prompt = "altered after materialization".to_string();
    assert!(matches!(
        store
            .prepare_occurrence_taskflow(
                &occurrence,
                &forged,
                /*now_ms*/ 101,
                /*lease_duration_ms*/ 30_000
            )
            .await,
        Err(codex_hepta_automation::TaskFlowError::Conflict(_))
    ));
    assert_eq!(
        store
            .taskflow_run(&occurrence.taskflow_run_id)
            .await
            .expect("run"),
        None
    );
    store
        .prepare_occurrence_taskflow(
            &occurrence,
            &lease,
            /*now_ms*/ 101,
            /*lease_duration_ms*/ 30_000,
        )
        .await
        .expect("canonical preparation");
    store
        .record_dispatch_uncertain(&lease, /*observed_at_ms*/ 102)
        .await
        .expect("canonical boundary");
    store.close().await;
}

#[tokio::test]
async fn terminal_recovery_cannot_rewrite_a_settled_historical_step() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75121",
        AutomationSchedule::Once,
        /*due*/ 100,
    );
    store.create_task(&task).await.expect("task");
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        /*generation*/ 1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("scheduler");
    scheduler.tick(/*now_ms*/ 100).await.expect("tick");
    let work = store
        .pending_occurrence_work(/*limit*/ 1)
        .await
        .expect("work")
        .pop()
        .unwrap();
    let run = store
        .taskflow_run(&work.occurrence.taskflow_run_id)
        .await
        .expect("run")
        .unwrap();
    let fence = TaskFlowFence::new(
        run.owner_agent_id.clone(),
        run.owner_id.unwrap(),
        run.owner_epoch.unwrap(),
        run.generation.unwrap(),
        run.fencing_token.unwrap(),
    )
    .expect("fence");
    let step = store
        .read_taskflow_step(&run.run_id, "codex_turn", /*attempt*/ 1, &fence)
        .await
        .expect("step")
        .unwrap();
    let terminal = Sha256Digest::for_bytes(b"immutable terminal receipt");
    store
        .reconcile_taskflow_step(
            &run.run_id,
            "codex_turn",
            /*attempt*/ 1,
            &fence,
            &step.intent_digest,
            &step.payload_digest,
            "step-only-terminal",
            &terminal,
            TaskFlowReconcileOutcome::Succeeded,
            /*now_ms*/ 101,
        )
        .await
        .expect("step settles before crash");
    store.close().await;
    let reopened = AutomationStore::open(&fixture.layout)
        .await
        .expect("reopen after crash");
    for (state, receipt) in [
        (AutomationOccurrenceTerminalState::Failed, terminal.clone()),
        (
            AutomationOccurrenceTerminalState::Succeeded,
            Sha256Digest::for_bytes(b"changed receipt"),
        ),
    ] {
        assert!(matches!(
            reopened
                .reconcile_occurrence_taskflow_terminal_with_recovery(
                    &work, state, &receipt, /*now_ms*/ 102,
                    /*recovery_generation*/ 100_000, /*recovery_lease_ms*/ 30_000
                )
                .await,
            Err(codex_hepta_automation::TaskFlowError::InvalidTransition(_))
        ));
    }
    assert_eq!(
        reopened
            .taskflow_run(&run.run_id)
            .await
            .expect("run")
            .unwrap()
            .state,
        TaskFlowRunState::Indeterminate
    );
    reopened
        .reconcile_occurrence_taskflow_terminal_with_recovery(
            &work,
            AutomationOccurrenceTerminalState::Succeeded,
            &terminal,
            /*now_ms*/ 102,
            /*recovery_generation*/ 100_000,
            /*recovery_lease_ms*/ 30_000,
        )
        .await
        .expect("exact terminal history recovers");
    assert_eq!(
        reopened
            .taskflow_run(&run.run_id)
            .await
            .expect("run")
            .unwrap()
            .state,
        TaskFlowRunState::Succeeded
    );
    reopened.close().await;
}

#[tokio::test]
async fn pre_step_crash_reclaims_using_taskflow_generation_units() {
    let fixture = Fixture::new();
    let store = AutomationStore::open(&fixture.layout).await.expect("store");
    let template = draft(
        "019153a4-3088-7000-a56a-9b1964f75122",
        AutomationSchedule::Once,
        /*due*/ 100,
    );
    store.create_task(&template).await.expect("template task");
    let scheduler = AutomationScheduler::new(
        store.clone(),
        Arc::new(SuccessQueue),
        /*generation*/ 1,
        Duration::from_secs(30),
        Duration::from_secs(2),
    )
    .expect("scheduler");
    scheduler
        .tick(/*now_ms*/ 100)
        .await
        .expect("register canonical automation definition");
    let definition = store
        .taskflow_definition("hepta.automation.codex-turn", /*version*/ 1)
        .await
        .expect("definition")
        .unwrap();
    let task = draft(
        "019153a4-3088-7000-a56a-9b1964f75123",
        AutomationSchedule::Once,
        /*due*/ 200,
    );
    store.create_task(&task).await.expect("task");
    let old = store
        .claim_due(
            /*now_ms*/ 200, /*generation*/ 2, /*lease_duration_ms*/ 10,
        )
        .await
        .expect("claim")
        .unwrap();
    let occurrence = store
        .materialize_occurrence(&old, /*now_ms*/ 200)
        .await
        .expect("occurrence");
    let fence = TaskFlowFence::new(
        old.task.owner_agent_id.clone(),
        format!("automation.scheduler:{}", task.task_id),
        old.lease_generation,
        /*generation*/ 1_000_001,
        old.lease_token.clone(),
    )
    .expect("historical taskflow fence");
    store
        .create_taskflow_run(
            &occurrence.taskflow_run_id,
            &definition.workflow_id,
            definition.version,
            definition.definition_digest(),
            THREAD_ID,
            /*created_at_ms*/ 200,
        )
        .await
        .expect("run");
    let claimed = store
        .claim_taskflow_run(
            &occurrence.taskflow_run_id,
            &fence,
            /*now_ms*/ 200,
            /*lease_duration_ms*/ 10,
        )
        .await
        .expect("run claim");
    store
        .apply_taskflow_command(
            &codex_hepta_automation::TaskFlowCommand::new(
                &occurrence.taskflow_run_id,
                "pre-step-start",
                fence,
                claimed.revision,
                codex_hepta_automation::TaskFlowTransition::Start,
                /*now_ms*/ 200,
            )
            .expect("start"),
        )
        .await
        .expect("durable prefix before step crash");
    store.close().await;
    let reopened = AutomationStore::open(&fixture.layout)
        .await
        .expect("reopen crash");
    let successor = reopened
        .claim_due(
            /*now_ms*/ 210, /*generation*/ 3, /*lease_duration_ms*/ 100,
        )
        .await
        .expect("reclaim")
        .unwrap();
    let reclaimed = reopened
        .materialize_occurrence(&successor, /*now_ms*/ 210)
        .await
        .expect("same occurrence");
    assert_eq!(reclaimed.occurrence_id, occurrence.occurrence_id);
    let dispatch = reopened
        .prepare_occurrence_taskflow(
            &reclaimed, &successor, /*now_ms*/ 210, /*lease_duration_ms*/ 100,
        )
        .await
        .expect("reclaim uses TaskFlow units instead of raw scheduler epoch");
    assert_eq!(dispatch.step_attempt, 1);
    assert_eq!(dispatch.fence.generation, 2_000_001);
    reopened
        .record_dispatch_uncertain(&successor, /*observed_at_ms*/ 211)
        .await
        .expect("dispatch boundary");
    reopened.close().await;
}
