# automation.taskflow adversarial audit

This stable audit guide records failure mechanisms, repaired invariants, regression locations and remaining implementation boundaries.
Git history preserves prior revisions. Current candidate identity, test results and pull-request status are supplied only by exact-candidate Git/CI evidence; this document is not an execution or activation receipt.
Primary owner: `automation-platform`; Agentd composition co-owner: `agent-runtime`.
Contracts, write domains and authority ceilings remain those of the canonical registries.

## Scope and method

The audit compared [the technical guide](TECHNICAL.md), [the execution dossier](../../../qualification/module-execution-dossiers/detail/automation.taskflow.md), `docs/DEVELOPMENT.md`, module/source/readiness registries and `CALLERS.toml` against native source and tests.
Source scope included `hepta-automation`, Agentd scheduler/recovery/effect-host control and the HTTP provider-effect transport.
Reviews separately covered authority/payload/provider identity, durable crash/restart state, program progression and runtime/product composition.
Adversarial cases included forged decoded fields, expired/stale fences, uncertain provider contact, lost replies, terminal crash cuts, retirement and calendar/profile boundaries.
Real SQLite reopen cases and bounded mock-provider tests are source checks; they do not establish deployment or an independently qualified provider.

## Completion by layer

| Layer | Implemented source | Remaining completion boundary |
| --- | --- | --- |
| Development documentation | Detailed guide, native implementation map and execution dossier | Keep source/host/schema truth synchronized and verify the committed candidate |
| Timer/calendar owner | Once/interval compatibility, Calendar V2, frozen revisions, deterministic occurrences and timer writer epochs | Authentic/current IANA profile and selected-host DST, races and capacity evidence |
| Agentd/Codex composition | Existing scheduler, stable queue reconciliation, durable turn observation and TaskFlow terminal propagation | Selected-host execution/restore qualification |
| TaskFlow ledger/outbox | Bounded definitions/runs/events, fenced step intent/receipt history and unresolved-work barriers | General DAG execution and trusted predecessor facts are not supplied by the ledger alone |
| External-effect seam/host | Signed final-use binding, immutable attempts, versioned provider keys, new-attempt contract pinning, optional configured HTTP host and explicit status control | Legacy unbound configuration continuity, safe automatic rotation and arbitrary scheduled-effect workflow composition |
| Neural Circuit candidate | Typed bounded compiler and exact-predecessor successor validation | Actual DecisionCells/organ ports, direct ingress, joins, feedback, subcircuits, cancellation and runtime fairness |
| Production status | Source root exists; ordinary source composition is present | `production_implementation`, product execution, independent acceptance, activation and release remain false |

TaskFlow remains the durable execution foundation within the existing CNS.
Timers decide when to wake a scheduled run; Agentd/Codex and registered effect owners retain their execution responsibilities.
No second scheduler, daemon, authority issuer, domain writer or universal state store is introduced.
The timer's built-in workflow is `codex_turn`; configured HTTP execution requires an already claimed/prepared effect step.

## Fixed findings and regression locations

### Follow-up source review, 2026-10-02

Review of source commit `805fc395161b3c29e334e4dc64f05068e26aa98f`
(tree `1efa0f71d5bc5007503b8f7dbec0e08353fcce90`) found the additional
boundaries below. AF-37/38 have local source corrections and native Rust
regression evidence, including failure with each correction removed. Historical
CI on that source commit does not validate these edits. The local execution scope
and remaining environment failure are recorded below.
The repaired source boundaries and selected-host evidence are tracked separately.
AF-39 target-host qualification remains open. The follow-up source review also
covers bounded initialization and idle connection release below; it does not
promote deployment, acceptance or general TaskFlow completion.

| ID | Priority | Finding | Status and regression |
| --- | --- | --- | --- |
| AF-37 | P1 | The HTTP effect host accepted an entry timestamp, awaited two owner reads, then let the store establish a new elapsed-time anchor. Waiting before that anchor could extend an expired lease. | Host execution now retains its original monotonic anchor and rebases before live-fence/store admission. `host_dispatches_exact_wire_payload_once` includes a controlled elapsed-anchor rejection, overflow rejection and no-attempt check before the ordinary real-provider path. The native test passes; removing elapsed-time rebasing makes it fail after the expired request reaches the mock provider. |
| AF-38 | P1 | Expired terminal recovery compared raw Agent spawn generation with encoded TaskFlow run generation. Agent generation 2/attempt 1 records 1,000,001, so a real generation-3 restart was rejected as stale. | Initial admission, occurrence validation and terminal recovery share one checked encoding helper. `expired_terminal_recovery_encodes_the_next_agent_generation` covers generations 2 and 9, same-generation rejection, real crash/reopen and idempotent terminal replay. The native test passes; restoring the old recovery comparison fails with `StaleFence`. |
| AF-39 | P1 | Queue contact released the SQLite writer before host-readiness checks, and WebSocket `start_send` could buffer before an awaited physical flush. Durable cancellation, local host closure or caller Drop could invalidate the earlier check. | Raw-IPC source candidate now retains the timer writer through one raw poll, serializes local host admission and caller Drop, and permanently rejects abandoned buffers. `physical_write_gate_tests.rs`, `remote_first_write_tests.rs`, `remote_first_write_client_tests.rs`, `queue_contact_tests.rs` and `raw_contact_serializes_local_drain_fence_and_detachment` cover these cuts. Qualification remains open: in-memory bytes do not prove an OS socket profile, and WebSocket/TLS strict contact is unsupported. |
| AF-40 | P2 | The high-priority Lane-B navigation page still described schema-v16 and omitted the configured Agentd HTTP execute/reconcile path. | Lane-B now matches schema-v23 and separates the existing control path from independent provider/authority and selected-host qualification. |
| AF-41 | P2 | After the final client sender disappeared, an idle SDK worker awaited a permanently backpressured WebSocket close without a deadline. | The existing five-second shutdown budget now bounds this close branch before stream destruction. The raw-memory regression observes an actual blocked write and stream Drop; removing only the timeout fails twice, restoring it passes. This is not a deadline for every in-flight request. Test helpers propagate errors without lint suppression. |
| AF-42 | P1 | Bounded SDK connections accumulated recognized initialization events in an unbounded Vec until the initialize reply; both TaskFlow execution and recovery use that connection mode. | Notifications and typed server requests now share a capacity check before each retained push. Exact capacity and legacy unbounded behavior remain unchanged. Four original worker regressions and an additional gated-constructor test run on the TaskFlow source. Removing the guard fails all three overflow probes, including the constructor that must reject before a reply and release its owned raw stream. This limits retained event count, not total bytes. |

Actual migration SQL was exercised with SQLite 3.53.1 from each empty-history
v1–v23 cut through reopen and schema-v23 upgrade, with integrity, foreign-key
and immutable-metadata checks. This is not SQLx legacy-checksum repair, populated
history validation or native Rust execution. Generation/elapsed-time arithmetic
models and source-level review are likewise not native test results.

The AF-37/38 correction set (`a44199f4c2e227c7816ccfef813e4dfe0df8b006`)
used Rust 1.95.0 and the original Cargo workspace, dependency
lock, feature declarations, nextest profile and configuration files. Automation
passed 157 default-package and 162 structural cases, with no skips. The Agentd
library ran all 173 cases: 172 passed, including the repaired host regression;
`cognitive_ranker::tests::running_socket_uses_launch_bound_model_and_isolates_ranker_revocation`
failed twice because the environment refused binding its control Unix socket
with `EPERM`. This is not an all-green Agentd or selected-host result. The test
was not removed or weakened. Scoped formatting passed; configured automation
Clippy completed with pre-existing warnings, so no warning-free claim is made.
Resource-only local settings used one compiler job, disabled incremental builds
and omitted dev/test debug symbols. No full-workspace, Windows, macOS or release
qualification was executed for these edits.

AF-39 has a separate validation lineage. A cross-checkout shared Cargo target
reused obsolete local dependency artifacts, so post-handoff integration results
were withheld and each candidate now requires an independent empty target.
The saved diagnostic is not a newly discovered source API defect. Earlier
first-write experiments and in-memory raw-stream checks do not replace the
real Unix IPC regressions that this environment refused to bind (`EPERM`).
Neither tests nor host safety checks were removed to hide that restriction.

The AF-39 source candidate `6f585e2df40e4f5f918feb90187c2c8041bdbc7e`
was rebuilt in an independent empty target: Automation passed 160 cases and
structural qualification passed 165. App Server client and Agentd libraries
ran 220 cases, with 213 passing and seven failing. Four failures were refused
Unix binds; three existing in-process SDK fixtures lacked sandbox runtime
helper paths. A reviewed retry of the four Unix cases still failed with EPERM.
Those failures remain unqualified and were not converted into skips or
unsandboxed execution. The caller-Drop negative control wrote 262450 raw bytes;
restoring its first-write liveness fence returned the observed delta to zero.

A later cloud workspace replacement interrupted the initial AF-41 Clippy run.
The saved AF-39 bundle and original upstream tree were restored; reconstructing
the two AF-41 source files reproduced the exact original tree
`c4c4ba2143065beff1d0f5d423de3261bd54b313`. The restored commit is
`dcb4a7956f563a15771129f21ada7ab1f98fe3c8`; the missing original commit object
and interrupted lint are not fabricated. A new empty target again passed the
18 selected SDK cases and the close-timeout negative/restored controls.

AF-42 was ported narrowly from the independently reviewed worker candidate
`6c63afeb9ad422b31e0288cbcc83cd4d907ac4f5`, without its other owner or fixture
changes. On TaskFlow source `642772e0c0006e05e1c975aa6f62f2e49530e042`
(tree `71647e6188388d41ff9e751af504dfc46415b19f`), the combined SDK selection
passed 23 cases; 29 cases were filtered and were not executed. The three
initialization overflow controls each failed twice with the pre-push check
removed; restoring the exact source bytes passed all 23 cases again. Scoped
all-target SDK Clippy with `--no-deps -D warnings` passed, and `just fix` did
not change source. Its dependency log retains two pre-existing memory-extension
dead-code warnings; this is not a warning-free whole-workspace claim.

Independent re-review found no additional concrete defect in the inspected
idle-close, initialization-retention and retained raw-write composition. This
is bounded source-review convergence, not proof of all possible correctness or
performance properties. Raw-memory constructor tests do not qualify Unix/TLS,
all initialization write deadlines, total byte retention, other owner candidates,
selected-host operation or independent acceptance. The small private retention
check stays beside the existing initializer because this port changes its two
existing push sites; a full initializer extraction would be a separate refactor.

Exact-blob source navigation binds reviewed source and test paths. Rebinding a
map does not transfer historical executable acceptance to new code. Selected-host
execution, cross-process Fleet authority protocol, deployment and independent
acceptance remain separate evidence boundaries.

### Earlier repaired findings

Priority P1 denotes a correctness, authority or availability boundary; P2 denotes narrower liveness or documentation accuracy.
The locations below identify source fixes and executable regressions, not independent acceptance evidence.

| ID | Priority | Failure mechanism and resulting behavior | Owning source / regression |
| --- | --- | --- | --- |
| AF-01 | P1 | Forged/stale claim tuples or mutated payloads could reach materialization/preparation; durable claim, canonical instant/revision and prompt/thread now revalidate before outbox creation | `lifecycle.rs`, `automation_taskflow.rs`; `occurrence_materialization_rejects_stale_and_forged_claims`, `preparation_rejects_payload_mutated_after_materialization` |
| AF-02 | P1 | Unknown/claimed step work could be abandoned through progression, takeover or another attempt; latest unresolved steps now block those mutations transactionally | `taskflow_guard.rs`, `taskflow.rs`, `taskflow_step.rs`; `tests/taskflow_step.rs` and authorized-effect crash cases |
| AF-03 | P1 | Decoded constructor-placeholder definition digests bypassed canonical validation; serialized registration now requires the computed digest | `taskflow.rs`; `registration_rejects_constructor_placeholder_before_writing` |
| AF-04 | P2 | Saturating successor arithmetic admitted a repeated maximum version; checked version+1 now rejects overflow | `neural_circuit.rs`; `saturated_version_cannot_admit_same_version_successor` |
| AF-05 | P1 | Retirement could strand admitted execution; API, SQL trigger and reopen checks now reject admitted/running/indeterminate work | `timer_lifecycle.rs`, migration `0020`; `retirement_waits_for_lifecycle_settlement_while_handoff_preserves_it` |
| AF-06 | P1 | Provider identities lacked owner isolation; new v2 keys bind owner/run/step while persisted v1 attempts retain original recovery keys | `authorized_effect.rs`, `effect_dispatch_ledger.rs`, migration `0021`, Agentd host; `provider_identity_is_owner_scoped_and_preserves_historical_recovery` |
| AF-07 | P1 | Effect entry lacked exact live-lease admission, stale recovery could append evidence, and writer/final-use waits could admit with a pre-wait timestamp; logical entry time plus monotonic elapsed time now revalidates at writer admission and inside the authorized consumer immediately before driver contact, while historical recovery checks its exact fence | `authorized_effect.rs`, `effect_dispatch_ledger.rs`, `tests/authorized_effect/effect_admission_tests.rs`; expired-lease, stale-recovery and four sync/async writer/consumer-wait regressions |
| AF-08 | P1 | Host synchronous thread joining blocked runtime progress; native async dispatch now retains the final-use active fence without the join | Agentd `automation_effect_host.rs`; `host_dispatches_exact_wire_payload_once` |
| AF-09 | P1 | Same-frontier revocation contents, raced file reads and unbounded HTTP body buffering weakened trust/capacity checks; full-head equality, capped stable-file reads and <=65536-byte streamed responses now reject drift/oversize | Agentd host and `model-provider/src/provider_effect.rs`; host/provider source tests |
| AF-10 | P2 | One unresolved occurrence could monopolize observation; successful still-pending snapshots now rotate with exact CAS, and queue/turn observations have a 5-second deadline | `occurrence_observer.rs`, Agentd `automation_recovery.rs`; `completed_observations_rotate_work_without_overwriting_newer_state` and timeout regression |
| AF-11 | P2 | Calendar resume bypassed canonical timing/forbidden overlap; finite delayed coalescing incorrectly depended on an expired profile reference | `schedule_v2.rs`, `lifecycle.rs`; resume/finite-profile regressions and `disabling_and_resuming_cannot_bypass_forbidden_overlap` |
| AF-12 | P1 | Terminal crash recovery could reinterpret a settled step, and pre-step reclaim compared differently scaled generations; exact terminal receipt/outcome and same-unit generations now govern recovery | `automation_taskflow.rs`; `terminal_recovery_cannot_rewrite_a_settled_historical_step`, `pre_step_crash_reclaims_using_taskflow_generation_units` |
| AF-13 | P1 | Scheduler detachment could remove explicit external-effect recovery along with admission; Agentd retains a recovery-only store while new execution remains disabled | Agentd `state.rs` / `state_control.rs`; `host_dispatches_exact_wire_payload_once` exercises detached control reaching exact-attempt validation and denied new execution |
| AF-14 | P2 | Guide/dossier stopped at schema16 and denied an existing configured host; documentation now reflects the current schema, actual control composition and layered completion | `TECHNICAL.md`, execution dossier and native mapping |
| AF-15 | P2 | The inherited map anchor was not an ancestor of the inspected candidate; a scoped fresh navigation review now binds current source objects and explicitly retains the superseded identity/reason | `IMPLEMENTATION_MAP.json`; development navigation verification, without transferring executable acceptance evidence |
| AF-16 | P1 | Recovery recomputed host identity from current configuration; new HTTP attempts now persist immutable scope/attested-contract binding before contact and reject changed remote recovery, while already durable terminal evidence remains locally recoverable | migration `0022`, authorized-effect ledger and Agentd host; durable binding/reopen and scope/reattested-endpoint drift regressions |
| AF-17 | P2 | String parsing rejected the IPv6 loopback HTTP fixture; typed URL hosts now accept loopback addresses while retaining HTTPS for non-loopback destinations | `model-provider/src/provider_effect.rs`; `attested_http_adapter_accepts_ipv6_loopback_fixture_only` |
| AF-18 | P1 | The directly consumed durable operation kernel sampled time before writer admission, allowing queued writes to falsely report clock rollback or renew an expired lease | `hepta-operations/src/durable_store.rs`; held-writer, true rollback and delayed-renewal regressions |
| AF-19 | P2 | Calendar search assumed local-label order matched UTC order, missed midnight rollbacks and inclusive profile boundaries, and scanned past finite ends; UTC envelopes now bound both directions and unsupported triple overlaps reject at validation | `schedule_v2.rs`; midnight, adjacent-transition, finite-end and three-way-overlap regressions |
| AF-20 | P1 | A cancelled, disabled, expired or non-running occurrence could cross the first queue-contact boundary; exact current task/run/claim and both lease horizons now guard first intent, with monotonic elapsed time at the scheduler contact cut | `store.rs`, `scheduler.rs`; first-intent and delayed-preparation regressions; existing uncertainty remains historically recoverable |
| AF-21 | P2 | Expired local claims could roll lifecycle identity before settling the old step; safely cancelled backlog could retain an orphan Claimed lifecycle and permanently freeze schedule policy | `automation_taskflow.rs`, `taskflow_step.rs`, `taskflow.rs`, `lifecycle.rs`; exact attempt/fence and independent-contact barriers, expired-claim and disable/resume regressions |
| AF-22 | P1 | A recording command collision could leave an already-sent effect without a writable projection; contradictory recovery could poison immutable evidence before terminal-step validation | `authorized_effect.rs`, `effect_dispatch_ledger.rs`, `taskflow_step.rs`; pre-contact command uniqueness and atomic terminal outcome/receipt guards in both write directions |
| AF-23 | P1 | Status NotFound was treated as proven absence, and Accepted admission was lost when flattened into an opaque indeterminate receipt; typed initial status and dispatch/lookup acceptance witnesses now preserve admission across restart. Known Accepted excludes both later rejection and proven absence while allowing terminal execution observations | migration `0023`, authorized bridge and HTTP host; NotFound quarantine, `lookup_acceptance_survives_reopen_and_cannot_become_rejection_or_absence`, `rejected_lookup_distinguishes_unknown_accepted_and_legacy_dispatch` |
| AF-24 | P2 | Agent draining blocked current-generation historical recovery; the narrow recovery gate now permits settlement while preserving critical/revocation readiness, exact generation and denied new execution | Agentd `state_control.rs`; draining recovery, stale generation and execution-denial assertions |
| AF-25 | P1 | A regular configuration file replaced by a FIFO before open could block the host; Unix open now uses NOFOLLOW/NONBLOCK and rejects nonregular descriptors | Actual shared `automation_protected_file.rs` and sibling tests; isolated runtime target reads the same production source |
| AF-26 | P2 | The focused CI only watched an obsolete branch, and documentation used a dated status file with an incomplete owner write envelope | `.github/workflows/automation-taskflow-focused.yml`, stable `AUDIT.md`, work packages and guide; relevant-path PR/main triggers, locked repository test runner and precise host source registration |
| AF-27 | P1 | Settled terminal/absence recovery depended on cleared live-run ownership, and repeated absence settlement could touch a successor; exact owned attempts now recover their verified historical step fence. Absence requires the cancelled step's exact proof receipt and its committed requeue event; repeated settlement only observes the old attempt. Retry admission now uses effective reconciliation evidence instead of the original unknown observation | `authorized_effect.rs`, `taskflow_step.rs`, `taskflow.rs`, Agentd host; `tests/authorized_effect/effect_recovery_tests.rs` covers terminal reopen, unresolved fences, absence across successor owner/attempt and pre-contact absence after owner clearing |
| AF-28 | P2 | The real-FIFO regression called a rustix API excluded on Apple targets, preventing macOS test compilation; the Apple fixture now invokes the absolute system FIFO utility and verifies the created file type, while other supported Unix targets retain the rustix path | Agentd `automation_protected_file_tests.rs`; `protected_open_rejects_links_and_never_waits_for_fifo_writer` retains link rejection and the bounded no-writer open check; target-platform execution remains required |
| AF-29 | P1 | A queue request could wait through connection/initialization or the remote worker backlog, then send after its leases or host readiness expired; scheduler-created single-use contact checks now run after socket readiness in the real worker. Exact timer/run/step/payload and host readiness are checked before the final elapsed-time lease sample; cancelled queued requests cannot send later | `queue_contact.rs` and its real-SQLite tests, scheduler, Agentd `automation.rs`, App Server client `remote_send_guard.rs` and real-socket regressions |
| AF-30 | P1 | Public operation claims could substitute payload/predecessor while retaining the leased tuple; shared current-lease and historical replay guards now compare the complete durable intent. Rejected claims do not consume a grant nonce | Kernel Operations `durable_store.rs`; `durable_claim_intent_rejects_payload_and_predecessor_substitution` |
| AF-31 | P1 | Exact operation claims bypassed the destination-wide durable clock frontier and could overwrite a future persisted timestamp | Operations `exact_claim.rs` now shares the existing clock guard; `exact_claim_cannot_erase_a_future_durable_frontier` verifies unchanged complete state |
| AF-32 | P2 | Windows temporary directories could fail strict canonical-root admission before new scheduler and historical migration regressions executed; fixtures now canonicalize actual created owner roots without weakening production checks | Scheduler writer-wait test and `migration_convergence_tests.rs` shared reopen fixture; native target-platform execution remains required |
| AF-33 | P1 | A retained kernel `AuthorizedDispatch` could enter its effect after lease expiry or owner adoption, with rejection only during outcome recording; the actual bounded synchronous consumer now rechecks exact current dispatching state under the source writer fence, including time after authority waits | Operations `execute_authorized`; `delayed_effect_entry_rejects_expired_and_adopted_dispatches` and `effect_entry_checks_lease_after_authority_wait`; callbacks immediately enqueue and must not reenter the source store or await remote execution |
| AF-34 | P1 | A typed destination receipt could terminalize a same-ID source operation with a different destination/payload or the wrong semantic digest domain; receipt identity, destination-dedupe digest and source intent now bind in the same transaction as generation checks and terminal projection/replay | Operations `reconcile_destination_receipt`; `destination_receipt_binding_is_checked_before_terminal_projection_and_replay` uses real persisted destination receipts |
| AF-35 | P1 | Quarantined occurrences lost observation progress: a later exact admitted turn could not bind, a known turn could not advance its scan cursor, and an exhausted scan retained its tail cursor indefinitely. Observation now retains Indeterminate and original missing evidence while admitting exact Submitted-witness turn binding, cursor CAS and a full-snapshot exhaustion reset; no new execution is authorized | `lifecycle.rs`, Agentd `automation_recovery.rs` and `tests/durable_causal_chain/observer_recovery_tests.rs`; real SQLite reopen, stale/ABA snapshot rejection, head rescan, terminal recovery, identity substitution and missing-witness rejection |
| AF-36 | P1 | A queued destination owner could persist Applied before the producer recorded dispatch or acknowledgement, causing a false API failure or attempted late uncertainty. Only an already-entered authorized consumer now recognizes an immutable Applied receipt matching its complete intent, writer fence and owner/observer generation after a bookkeeping conflict; public stale APIs stay strict | Operations `execute_authorized`; `authoritative_applied_receipt_wins_over_late_transport_projection` deterministically orders real SQLite owner/producer cuts and retains rejection for new owners, NotApplied and Quarantined |

Permanent retirement is stricter than compatible handoff, but does not erase a safely stopped backlog.
Provider-proven-absent pending/claimed work can remain behind its tombstone after leased/uncertain drain; it cannot admit a new provider effect.
Schema19's pre-existing migration convergence preserves recognized SQL/checksums and rejects unknown, dirty or conflicting historical identities.

## Repeat-review method

Compare documentation and registries to actual callers, then review identity/authority, durable lifecycle, progression and host execution independently.
After each coherent source repair, re-read the combined changes at pre-contact, lost-reply, terminal-persistence, cancellation, retirement, reopen and compatibility cuts.
Exercise concurrent writer admission, exact command/attempt identity, historical provider lookup, scope/contract drift and timezone boundaries through their owning native APIs.
Run affected-package regressions before repeating the adversarial review. Stop a review round only when no new concrete defect remains in that inspected scope; record unresolved implementation and evidence boundaries separately.
Review convergence is bounded by scope and evidence. It is not a claim that no bugs or future optimizations exist.

## Remaining implementation work

- A general TaskFlow/Neural Circuit runtime still needs actual DecisionCells, organ calls, event ingress, joins, feedback, subcircuits, cancellation and fair conserved budgets.
- Signed dependency/compensation descriptors bind bytes; the effect seam does not independently prove predecessor completion. Product owners must obtain trusted predecessor receipts.
- External-effect recovery is explicit Agentd control. The scheduled observer reconciles ordinary Codex queue/turn occurrences; it is not a generic external-effect backlog worker.
- New configured HTTP attempts pin the original provider scope and attested contract digest. Changed remote lookup rejects; original configuration bytes are not retained or automatically restored. Legacy/generic `NULL` bindings require original key/status-lookup continuity or must remain unresolved; a safe automatic rotation protocol is unfinished.
- Historical v1 keys retain their original delimiter/tenant ambiguity. Recovery must investigate provider-specific identity collisions rather than invent a unique identity after contact.
- A terminal provider observation persisted before ledger settlement requires exact-attempt reconciliation; an unknown outcome never becomes safe redispatch through restart, cancellation or configuration change.

Already settled terminal evidence and committed absence remain observable after live run ownership clears. Historical absence requires the exact cancelled step receipt and the same proof in that attempt's verified immutable requeue event; a cancelled step alone does not bypass an unfinished projection repair. Re-reading the old attempt after a successor owner/attempt advances returns its historical result without mutating the successor or authorizing another provider contact.

## Remaining target-host and independent evidence

- Independently provision final-use trust/revocation and provider contract/terminal-observer configuration for each activated effect.
- Bind authentic/current timezone provenance, DST behavior, multi-scheduler races, restore and sustained backlog/capacity measurements to the selected host.
- Measure queue age, latency distributions, memory/storage growth and recovery work; source ceilings are not measured SLOs.
- Obtain independent acceptance and activation decisions; promotion/release remain separately governed.

## Candidate verification requirements

Resolve the source head/tree, current base and any prospective merge from fresh Git/CI receipts. Attach command outputs and their exact candidate identity to the review; do not cache live results or pull-request state here.

| Check | Required evidence and interpretation |
| --- | --- |
| `just test -p codex-hepta-automation --offline --locked` | Execute the affected owner package, including migrations, lifecycle and effect regressions. |
| `just test -p codex-hepta-automation --features taskflow-structural-qualification --offline --locked` | Execute the feature-gated kernel/step qualification cases; compilation alone does not pass them. |
| `just test -p codex-model-provider --lib --offline --locked` | Execute provider transport/status validation when that owner changes. |
| `just test -p codex-hepta-operations --lib --offline --locked` | Execute durable operation regressions when the consumed kernel owner changes. |
| `just test -p codex-hepta-agentd --lib --offline --locked` | Execute actual runtime composition/recovery cases; a dependency build failure leaves them unexecuted. |
| `just test -p codex-app-server-client --lib --offline --locked -E 'test(remote_send_guard) | test(physical_write_gate) | test(first_write_client_tests) | test(initialize_bounds)'` | Execute the actual generic guarded worker over real loopback WebSocket frames; existing Unix transport tests and target-platform execution are separate evidence. |
| Scoped `just fix`, `just fmt` and whitespace | Apply repository-required lint/format checks; static test-target type-checking does not execute tests. |
| Privileged caller verifier | Run its self-test and source verification after final-use/caller changes. |
| Readiness, module docs and implementation maps | Run development-profile navigation checks on the committed candidate; they do not requalify historical execution or acceptance evidence. |
| TaskFlow exact source observation | Bind the current source paths/blobs and owner callers through the scoped native map. Retain superseded non-ancestral provenance with its reason; never transfer old execution evidence to a fresh navigation observation. |
| Selected-host/provider qualification | Supply independent provisioning, restore, authority, authentic timezone and performance evidence before activation. |

Separate a failed regression from a build failure, a skipped step and a passed check. Earlier failures in an aggregate job can prevent the TaskFlow commands from executing at all. Inspect the exact failing owner and baseline source before attributing an aggregate failure to this module; required checks remain unsatisfied until their current candidate receipts pass.
Verify inherited map ancestry against the current candidate. A scoped TaskFlow navigation repair must not refresh or promote independent module observations. Whole-repository qualification remains governed by each owner's exact evidence.

## Operational continuity

Keep existing Agentd ownership, private per-Agent storage and kernel authority; do not add another execution spine to close an integration gap.
Preserve schema23, immutable observation/reconciliation and provider admission history, provider-key version/contract binding, stable queue identity and unresolved effects during rollback.
Use a newer fenced compatible owner for handoff; do not revive predecessor handles or restore an old database over current receipts.
Retain provider status access for pending effects before changing configuration or removing admission; control recovery does not authorize new execution.
