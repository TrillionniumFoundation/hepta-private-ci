//! Tiny in-memory transports exercise the real initialization routine.
//! These tests do not change the runtime sandbox or claim a physical host SLO.

use super::*;
use pretty_assertions::assert_eq;
use serde_json::Value;
use serde_json::json;
use std::future::Future;
use std::pin::Pin;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::AtomicUsize;
use std::task::Context;
use std::task::Poll;
use tokio::io::DuplexStream;
use tokio::io::ReadBuf;
use tokio::io::duplex;
use tokio::time::Sleep;
use tokio_tungstenite::tungstenite::protocol::Role;

type TestResult<T = ()> = Result<T, Box<dyn std::error::Error + Send + Sync>>;
type Initialization = IoResult<(Vec<AppServerEvent>, Option<String>, Option<String>)>;
const INITIALIZATION_BUDGET: Duration = Duration::from_millis(100);
const TEST_WATCHDOG: Duration = Duration::from_secs(1);

#[derive(Clone, Copy, PartialEq, Eq)]
enum Stall {
    None,
    InitialWrite,
    InitialFlush,
    InitializedWrite,
    InitializedFlush,
}

#[derive(Clone, Copy)]
enum Reply {
    Accept,
    Reject,
    Withhold,
    Delayed,
}

#[derive(Default)]
struct IoObservation {
    response_read: AtomicBool,
    blocked_polls: AtomicUsize,
    dropped: AtomicBool,
    first_delay_completed: AtomicBool,
    request_received: AtomicBool,
    response_delay_started: AtomicBool,
}

enum FirstWriteDelay {
    None,
    StartOnPoll,
    Sleeping(Pin<Box<Sleep>>),
    Complete,
}

struct ObservedIo {
    inner: DuplexStream,
    observation: Arc<IoObservation>,
    stall: Stall,
    first_write_delay: FirstWriteDelay,
}

impl Drop for ObservedIo {
    fn drop(&mut self) {
        self.observation.dropped.store(true, Ordering::Release);
    }
}

impl AsyncRead for ObservedIo {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buffer: &mut ReadBuf<'_>,
    ) -> Poll<IoResult<()>> {
        let before = buffer.filled().len();
        let result = Pin::new(&mut self.inner).poll_read(cx, buffer);
        if buffer.filled().len() > before {
            self.observation
                .response_read
                .store(true, Ordering::Release);
        }
        result
    }
}

impl AsyncWrite for ObservedIo {
    fn poll_write(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buffer: &[u8],
    ) -> Poll<IoResult<usize>> {
        if matches!(self.first_write_delay, FirstWriteDelay::StartOnPoll) {
            self.first_write_delay =
                FirstWriteDelay::Sleeping(Box::pin(tokio::time::sleep(Duration::from_millis(70))));
        }
        if let FirstWriteDelay::Sleeping(delay) = &mut self.first_write_delay {
            if delay.as_mut().poll(cx).is_pending() {
                return Poll::Pending;
            }
            self.first_write_delay = FirstWriteDelay::Complete;
            self.observation
                .first_delay_completed
                .store(true, Ordering::Release);
        }
        let response_read = self.observation.response_read.load(Ordering::Acquire);
        if matches!(
            (self.stall, response_read),
            (Stall::InitialWrite, false) | (Stall::InitializedWrite, true)
        ) {
            self.observation
                .blocked_polls
                .fetch_add(1, Ordering::AcqRel);
            return Poll::Pending;
        }
        Pin::new(&mut self.inner).poll_write(cx, buffer)
    }

    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<IoResult<()>> {
        let response_read = self.observation.response_read.load(Ordering::Acquire);
        if matches!(
            (self.stall, response_read),
            (Stall::InitialFlush, false) | (Stall::InitializedFlush, true)
        ) {
            self.observation
                .blocked_polls
                .fetch_add(1, Ordering::AcqRel);
            return Poll::Pending;
        }
        Pin::new(&mut self.inner).poll_flush(cx)
    }

    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<IoResult<()>> {
        Pin::new(&mut self.inner).poll_shutdown(cx)
    }
}

struct ProbeResult {
    result: Result<Initialization, tokio::time::error::Elapsed>,
    observation: Arc<IoObservation>,
    initialized: Option<Value>,
}

async fn probe(stall: Stall, reply: Reply) -> TestResult<ProbeResult> {
    let (client_io, server_io) = duplex(/*max_buf_size*/ 4096);
    let observation = Arc::new(IoObservation::default());
    let io = ObservedIo {
        inner: client_io,
        observation: Arc::clone(&observation),
        stall,
        first_write_delay: match reply {
            Reply::Delayed => FirstWriteDelay::StartOnPoll,
            Reply::Accept | Reply::Reject | Reply::Withhold => FirstWriteDelay::None,
        },
    };
    let mut client =
        WebSocketStream::from_raw_socket(io, Role::Client, Some(remote_websocket_config())).await;
    let mut server =
        WebSocketStream::from_raw_socket(server_io, Role::Server, /*config*/ None).await;
    let (initialized_tx, initialized_rx) = oneshot::channel();
    let server_observation = Arc::clone(&observation);
    let server_task = tokio::spawn(async move {
        let request = server.next().await.ok_or("missing initialize request")??;
        let request: Value = serde_json::from_str(request.to_text()?)?;
        assert_eq!(request["method"], "initialize");
        server_observation
            .request_received
            .store(true, Ordering::Release);
        match reply {
            Reply::Withhold => std::future::pending::<()>().await,
            Reply::Delayed => {
                server_observation
                    .response_delay_started
                    .store(true, Ordering::Release);
                tokio::time::sleep(Duration::from_millis(70)).await;
            }
            Reply::Accept | Reply::Reject => {}
        }
        let response = match reply {
            Reply::Reject => json!({
                "id": request["id"],
                "error": {"code": -32000, "message": "fixture rejects initialize"}
            }),
            Reply::Accept | Reply::Delayed | Reply::Withhold => json!({
                "id": request["id"],
                "result": {"userAgent": "initialize-fixture/1.2.3", "codexHome": "/fixture"}
            }),
        };
        server
            .send(Message::Text(response.to_string().into()))
            .await?;
        let initialized = server
            .next()
            .await
            .ok_or("missing initialized notification")??;
        let initialized: Value = serde_json::from_str(initialized.to_text()?)?;
        let _ = initialized_tx.send(initialized);
        // Keep the peer alive until the probe explicitly joins its cleanup.
        std::future::pending::<TestResult>().await
    });
    let result = timeout(
        TEST_WATCHDOG,
        initialize_remote_connection(
            &mut client,
            "initialize-deadline-memory-fixture",
            InitializeParams {
                client_info: ClientInfo {
                    name: "initialize-deadline-test".into(),
                    version: "1".into(),
                    title: None,
                },
                capabilities: None,
            },
            INITIALIZATION_BUDGET,
            RemoteEventMode::BacklogBounded { capacity: 1 },
        ),
    )
    .await;
    let initialized = if matches!(result, Ok(Ok(_))) {
        timeout(TEST_WATCHDOG, initialized_rx)
            .await
            .ok()
            .and_then(Result::ok)
    } else {
        None
    };
    drop(client);
    server_task.abort();
    let _ = server_task.await;
    assert!(observation.dropped.load(Ordering::Acquire));
    Ok(ProbeResult {
        result,
        observation,
        initialized,
    })
}

#[tokio::test]
async fn initialize_deadline_bounds_initial_request_write() -> TestResult {
    let probe = probe(Stall::InitialWrite, Reply::Accept).await?;
    assert!(probe.observation.blocked_polls.load(Ordering::Acquire) > 0);
    assert!(!probe.observation.response_read.load(Ordering::Acquire));
    assert!(matches!(probe.result, Ok(Err(error)) if error.kind() == ErrorKind::TimedOut));
    Ok(())
}

#[tokio::test]
async fn initialize_deadline_bounds_initial_request_flush() -> TestResult {
    let probe = probe(Stall::InitialFlush, Reply::Accept).await?;
    assert!(probe.observation.blocked_polls.load(Ordering::Acquire) > 0);
    assert!(!probe.observation.response_read.load(Ordering::Acquire));
    assert!(matches!(probe.result, Ok(Err(error)) if error.kind() == ErrorKind::TimedOut));
    Ok(())
}

#[tokio::test]
async fn initialize_deadline_bounds_initialized_notification_write() -> TestResult {
    let probe = probe(Stall::InitializedWrite, Reply::Accept).await?;
    assert!(probe.observation.blocked_polls.load(Ordering::Acquire) > 0);
    assert!(probe.observation.response_read.load(Ordering::Acquire));
    assert!(matches!(probe.result, Ok(Err(error)) if error.kind() == ErrorKind::TimedOut));
    Ok(())
}

#[tokio::test]
async fn initialize_deadline_bounds_initialized_notification_flush() -> TestResult {
    let probe = probe(Stall::InitializedFlush, Reply::Accept).await?;
    assert!(probe.observation.blocked_polls.load(Ordering::Acquire) > 0);
    assert!(probe.observation.response_read.load(Ordering::Acquire));
    assert!(matches!(probe.result, Ok(Err(error)) if error.kind() == ErrorKind::TimedOut));
    Ok(())
}

#[tokio::test]
async fn initialize_deadline_is_shared_by_request_and_response() -> TestResult {
    let probe = probe(Stall::None, Reply::Delayed).await?;
    assert!(
        probe
            .observation
            .first_delay_completed
            .load(Ordering::Acquire)
    );
    assert!(probe.observation.request_received.load(Ordering::Acquire));
    assert!(
        probe
            .observation
            .response_delay_started
            .load(Ordering::Acquire)
    );
    assert!(!probe.observation.response_read.load(Ordering::Acquire));
    assert!(matches!(probe.result, Ok(Err(error)) if error.kind() == ErrorKind::TimedOut));
    Ok(())
}

#[tokio::test]
async fn initialize_deadline_preserves_response_timeout() -> TestResult {
    let probe = probe(Stall::None, Reply::Withhold).await?;
    assert!(matches!(probe.result, Ok(Err(error)) if error.kind() == ErrorKind::TimedOut));
    Ok(())
}

#[tokio::test]
async fn initialize_deadline_preserves_server_rejection() -> TestResult {
    let probe = probe(Stall::None, Reply::Reject).await?;
    assert!(
        matches!(probe.result, Ok(Err(error)) if error.kind() == ErrorKind::Other
        && error.to_string().contains("fixture rejects initialize"))
    );
    Ok(())
}

#[tokio::test]
async fn initialize_deadline_preserves_success_and_initialized_message() -> TestResult {
    let probe = probe(Stall::None, Reply::Accept).await?;
    let (events, version, home) = probe.result??;
    assert!(events.is_empty());
    assert_eq!(
        (version, home),
        (Some("1.2.3".into()), Some("/fixture".into()))
    );
    assert_eq!(probe.initialized, Some(json!({"method": "initialized"})));
    Ok(())
}
