//! Caller-owner composition over real SQLite and one real duplex write poll.
//! No SDK framing/rearming, request-Drop, socket or deployed-host claim is made.

use std::future::Future;
use std::io;
use std::pin::Pin;
use std::sync::Arc;
use std::sync::Mutex;
use std::task::Context;
use std::task::Poll;
use std::task::Waker;
use std::time::Duration;

use codex_hepta_automation::AutomationAdmission;
use codex_hepta_automation::AutomationDispatchUncertainty;
use codex_hepta_automation::AutomationError;
use codex_hepta_automation::AutomationFuture;
use codex_hepta_automation::AutomationQueueContact;
use codex_hepta_automation::AutomationQueueReceipt;
use codex_hepta_automation::AutomationScheduler;
use codex_hepta_automation::AutomationTick;
use codex_hepta_automation::AutomationTurnQueue;
use codex_hepta_fleet::AgentLifecycle;
use codex_state::SqliteConfig;
use codex_utils_absolute_path::AbsolutePathBuf;
use tokio::io::AsyncRead;
use tokio::io::AsyncReadExt;
use tokio::io::AsyncWrite;
use tokio::io::AsyncWriteExt;
use tokio::io::DuplexStream;
use tokio::io::ReadBuf;
use tokio::sync::oneshot;
use tokio::time::timeout;

use super::Fixture;
use super::draft;
use super::fixture;
use crate::AgentdError;

const WATCHDOG: Duration = Duration::from_secs(10);
const LONG_LEASE: Duration = Duration::from_secs(30);
const EXPIRING_LEASE: Duration = Duration::from_secs(2);
type TestResult<T = ()> = Result<T, Box<dyn std::error::Error + Send + Sync>>;
type Captured = (AutomationAdmission, AutomationQueueContact);
type RawWritePoll = Poll<io::Result<usize>>;

/// Only captures the existing scheduler handoff, never implements a transport.
/// It never returns an invented provider acknowledgement, even after bytes write.
struct ContactCapture {
    captured: Mutex<Option<oneshot::Sender<Captured>>>,
    release: Mutex<Option<oneshot::Receiver<()>>>,
}

impl AutomationTurnQueue for ContactCapture {
    fn enqueue(
        &self,
        _admission: AutomationAdmission,
    ) -> AutomationFuture<'_, AutomationQueueReceipt> {
        Box::pin(async { Err(AutomationError::AccessDenied) })
    }

    fn enqueue_with_contact(
        &self,
        admission: AutomationAdmission,
        contact: AutomationQueueContact,
    ) -> AutomationFuture<'_, AutomationQueueReceipt> {
        Box::pin(async move {
            let captured = self
                .captured
                .lock()
                .expect("capture lock")
                .take()
                .expect("one handoff");
            let release = self
                .release
                .lock()
                .expect("release lock")
                .take()
                .expect("one release");
            captured
                .send((admission, contact))
                .map_err(|_| AutomationError::DispatchUnknown)?;
            let _ = release.await;
            Err(AutomationError::DispatchUnknown)
        })
    }
}

struct Prepared {
    fixture: Fixture,
    admission: Arc<AutomationAdmission>,
    contact: Arc<AutomationQueueContact>,
    before: Vec<AutomationDispatchUncertainty>,
    release: Option<oneshot::Sender<()>>,
    tick: tokio::task::JoinHandle<Result<AutomationTick, AutomationError>>,
}

impl Prepared {
    async fn new(lease: Duration) -> TestResult<Self> {
        let fixture = fixture().await;
        fixture.registry.compare_and_transition(
            &fixture.identity.agent_id,
            1,
            AgentLifecycle::Running,
        )?;
        fixture.state.refresh_generation()?;
        let cognitive =
            codex_hepta_cognitive_store::DurableCognitiveStore::open(&fixture.identity.layout)
                .await?;
        fixture.state.attach_cognitive_store(Arc::new(cognitive))?;
        fixture.state.mark_runtime_prerequisites_ready()?;
        fixture.state.mark_app_server_ready()?;
        fixture.store.create_task(&draft()).await?;
        let (captured_tx, captured_rx) = oneshot::channel();
        let (release_tx, release_rx) = oneshot::channel();
        let queue = Arc::new(ContactCapture {
            captured: Mutex::new(Some(captured_tx)),
            release: Mutex::new(Some(release_rx)),
        });
        let scheduler =
            AutomationScheduler::new(fixture.store.clone(), queue, 1, lease, lease / 2)?;
        let tick = tokio::spawn(async move { scheduler.tick(100).await });
        let (admission, contact) = timeout(WATCHDOG, captured_rx).await??;
        let before = fixture.store.uncertain_dispatches(2).await?;
        assert_eq!(before.len(), 1);
        Ok(Self {
            fixture,
            admission: Arc::new(admission),
            contact: Arc::new(contact),
            before,
            release: Some(release_tx),
            tick,
        })
    }

    fn prepare(
        &self,
    ) -> impl Future<
        Output = io::Result<
            impl FnOnce(&mut dyn FnMut() -> RawWritePoll) -> RawWritePoll + Send + 'static + use<>,
        >,
    >
    + Send
    + 'static
    + use<> {
        Arc::clone(&self.fixture.state)
            .prepare_automation_contact(Arc::clone(&self.contact), Arc::clone(&self.admission))
    }

    async fn assert_same_uncertainty(&self) -> TestResult {
        let after = self.fixture.store.uncertain_dispatches(2).await?;
        // The scheduler can refresh observed_at_ms while retaining the exact
        // unresolved identity; this test does not turn its clock into evidence.
        let identities = |rows: &[AutomationDispatchUncertainty]| {
            rows.iter()
                .map(|row| {
                    (
                        row.task_id,
                        row.occurrence,
                        row.scheduled_for_ms,
                        row.client_user_message_id.clone(),
                    )
                })
                .collect::<Vec<_>>()
        };
        assert_eq!(identities(&after), identities(&self.before));
        Ok(())
    }

    async fn finish(mut self) -> TestResult {
        // The short-lease controls can reach the real scheduler dispatch timeout
        // before lease expiry. This checks unresolved identity, not which path
        // produced DispatchUncertain or whether the capture callback completed.
        drop(self.release.take());
        let result = timeout(WATCHDOG, &mut self.tick).await???;
        assert_eq!(
            result,
            AutomationTick::DispatchUncertain {
                task_id: self.admission.task_id,
                occurrence: self.admission.occurrence
            }
        );
        self.assert_same_uncertainty().await?;
        self.fixture.store.close().await;
        Ok(())
    }
}

fn raw_poll(stream: &mut DuplexStream, bytes: &[u8]) -> Poll<io::Result<usize>> {
    Pin::new(stream).poll_write(&mut Context::from_waker(Waker::noop()), bytes)
}

fn assert_no_byte(stream: &mut DuplexStream) {
    let mut bytes = [0_u8; 1];
    let mut buffer = ReadBuf::new(&mut bytes);
    assert!(
        Pin::new(stream)
            .poll_read(&mut Context::from_waker(Waker::noop()), &mut buffer)
            .is_pending()
    );
    assert_eq!(buffer.filled(), b"");
}

fn expect_owner_error<T>(result: io::Result<T>, expected: AutomationError) {
    match result {
        Err(error) => {
            assert_eq!(error.kind(), io::ErrorKind::PermissionDenied);
            assert_eq!(
                error
                    .get_ref()
                    .and_then(|source| source.downcast_ref::<AutomationError>()),
                Some(&expected),
            );
        }
        Ok(_) => panic!("the exact owner reason must reject this preparation"),
    }
}

async fn second_writer(prepared: &Prepared) -> TestResult<sqlx::SqlitePool> {
    let path = prepared.fixture.store.path();
    let home = path
        .parent()
        .ok_or_else(|| io::Error::other("fixture database needs its private parent"))?;
    // Reuse the canonical durability/connection policy, including its five-second
    // busy timeout. Only an actual SQLite BUSY error is a positive exclusion check.
    let config = SqliteConfig::from_sqlite_home(AbsolutePathBuf::try_from(home.to_path_buf())?);
    Ok(config.open_durable_evidence_pool(path).await?)
}

#[tokio::test]
async fn caller_contact_live_write_preserves_capture_and_permit_lifetimes() -> TestResult {
    let prepared = Prepared::new(LONG_LEASE).await?;
    let counts = (
        Arc::strong_count(&prepared.contact),
        Arc::strong_count(&prepared.admission),
        Arc::strong_count(&prepared.fixture.state),
    );
    let future = prepared.prepare();
    assert_eq!(
        (
            Arc::strong_count(&prepared.contact),
            Arc::strong_count(&prepared.admission),
            Arc::strong_count(&prepared.fixture.state)
        ),
        (counts.0 + 1, counts.1 + 1, counts.2 + 1)
    );
    drop(future);
    assert_eq!(
        (
            Arc::strong_count(&prepared.contact),
            Arc::strong_count(&prepared.admission),
            Arc::strong_count(&prepared.fixture.state)
        ),
        counts
    );
    let unused = timeout(WATCHDOG, prepared.prepare()).await??;
    drop(unused);
    assert_eq!(
        (
            Arc::strong_count(&prepared.contact),
            Arc::strong_count(&prepared.admission),
            Arc::strong_count(&prepared.fixture.state)
        ),
        counts,
    );
    // Successfully reacquiring the real writer also checks that an unconsumed
    // permit's Drop eventually releases its SQL reservation, without a raw poll.
    let permit = timeout(WATCHDOG, prepared.prepare()).await??;
    assert_eq!(
        (
            Arc::strong_count(&prepared.contact),
            Arc::strong_count(&prepared.admission),
            Arc::strong_count(&prepared.fixture.state)
        ),
        (counts.0, counts.1, counts.2 + 1)
    );
    let (mut writer, mut peer) = tokio::io::duplex(16);
    let mut calls = 0;
    assert!(matches!(
        permit(&mut || {
            calls += 1;
            raw_poll(&mut writer, b"live")
        }),
        Poll::Ready(Ok(4))
    ));
    assert_eq!(calls, 1);
    assert_eq!(
        (
            Arc::strong_count(&prepared.contact),
            Arc::strong_count(&prepared.admission),
            Arc::strong_count(&prepared.fixture.state)
        ),
        counts
    );
    let mut received = [0_u8; 4];
    timeout(WATCHDOG, peer.read_exact(&mut received)).await??;
    assert_eq!(received, *b"live");
    prepared.assert_same_uncertainty().await?;
    prepared.finish().await
}

#[tokio::test]
async fn caller_contact_pending_releases_sql_before_durable_task_cancellation() -> TestResult {
    let prepared = Prepared::new(LONG_LEASE).await?;
    let competitor = second_writer(&prepared).await?;
    let permit = timeout(WATCHDOG, prepared.prepare()).await??;
    let attempt = timeout(WATCHDOG, competitor.begin_with("BEGIN IMMEDIATE")).await?;
    match attempt {
        Err(sqlx::Error::Database(error)) => assert_eq!(error.code().as_deref(), Some("5")),
        _ => panic!("the retained real writer must return SQLite BUSY, not a watchdog timeout"),
    }
    let (mut writer, mut peer) = tokio::io::duplex(1);
    timeout(WATCHDOG, writer.write_all(b"x")).await??;
    let mut pending_calls = 0;
    assert!(
        permit(&mut || {
            pending_calls += 1;
            raw_poll(&mut writer, b"payload")
        })
        .is_pending()
    );
    assert_eq!(pending_calls, 1);
    timeout(
        WATCHDOG,
        prepared
            .fixture
            .store
            .cancel_task(prepared.admission.task_id, 101),
    )
    .await??;
    expect_owner_error(
        timeout(WATCHDOG, prepared.prepare()).await?,
        AutomationError::Conflict,
    );
    let mut filler = [0_u8; 1];
    timeout(WATCHDOG, peer.read_exact(&mut filler)).await??;
    assert_eq!(filler, *b"x");
    assert_no_byte(&mut peer);
    competitor.close().await;
    prepared.finish().await
}

#[tokio::test]
async fn caller_contact_pending_then_local_host_closure_prevents_next_poll() -> TestResult {
    for close in ["drain", "fence", "detach"] {
        let prepared = Prepared::new(LONG_LEASE).await?;
        let (mut writer, mut peer) = tokio::io::duplex(1);
        timeout(WATCHDOG, writer.write_all(b"x")).await??;
        let permit = timeout(WATCHDOG, prepared.prepare()).await??;
        let mut pending_calls = 0;
        assert!(
            permit(&mut || {
                pending_calls += 1;
                raw_poll(&mut writer, b"payload")
            })
            .is_pending()
        );
        assert_eq!(pending_calls, 1);
        match close {
            "drain" => prepared.fixture.state.mark_draining()?,
            "fence" => prepared.fixture.state.mark_fenced(),
            "detach" => prepared.fixture.state.mark_automation_unavailable()?,
            _ => unreachable!(),
        }
        let permit = timeout(WATCHDOG, prepared.prepare()).await??;
        let mut calls = 0;
        let result = permit(&mut || {
            calls += 1;
            raw_poll(&mut writer, b"payload")
        });
        match result {
            Poll::Ready(Err(error)) => {
                assert_eq!(error.kind(), io::ErrorKind::PermissionDenied);
                assert!(matches!(
                    error
                        .get_ref()
                        .and_then(|source| source.downcast_ref::<AgentdError>()),
                    Some(AgentdError::GenerationFenced(_)),
                ));
            }
            _ => panic!("a closed host must reject before the raw callback"),
        }
        assert_eq!(calls, 0);
        let mut filler = [0_u8; 1];
        timeout(WATCHDOG, peer.read_exact(&mut filler)).await??;
        assert_eq!(filler, *b"x");
        assert_no_byte(&mut peer);
        prepared.finish().await?;
    }
    Ok(())
}

#[tokio::test]
async fn caller_contact_pending_drop_releases_captures_and_delayed_preparation_expires()
-> TestResult {
    let prepared = Prepared::new(EXPIRING_LEASE).await?;
    let competitor = second_writer(&prepared).await?;
    let writer = competitor.begin_with("BEGIN IMMEDIATE").await?;
    let counts = (
        Arc::strong_count(&prepared.contact),
        Arc::strong_count(&prepared.admission),
        Arc::strong_count(&prepared.fixture.state),
    );
    // Pending can be pool ping/acquisition or writer work. It is evidence only
    // that this owned future has suspended, not that a SQLite write wait began.
    let mut abandoned = Box::pin(prepared.prepare());
    assert!(
        abandoned
            .as_mut()
            .poll(&mut Context::from_waker(Waker::noop()))
            .is_pending()
    );
    assert_eq!(
        (
            Arc::strong_count(&prepared.contact),
            Arc::strong_count(&prepared.admission),
            Arc::strong_count(&prepared.fixture.state)
        ),
        (counts.0 + 1, counts.1 + 1, counts.2 + 1)
    );
    drop(abandoned);
    assert_eq!(
        (
            Arc::strong_count(&prepared.contact),
            Arc::strong_count(&prepared.admission),
            Arc::strong_count(&prepared.fixture.state)
        ),
        counts
    );
    let waiting = prepared.prepare();
    // This second future is deliberately delayed before polling. Real elapsed
    // expiry is checked; no writer-wait location or resampling order is claimed.
    tokio::time::sleep(EXPIRING_LEASE + Duration::from_millis(100)).await;
    writer.commit().await?;
    expect_owner_error(timeout(WATCHDOG, waiting).await?, AutomationError::Conflict);
    assert_eq!(
        (
            Arc::strong_count(&prepared.contact),
            Arc::strong_count(&prepared.admission),
            Arc::strong_count(&prepared.fixture.state)
        ),
        counts
    );
    competitor.close().await;
    prepared.finish().await
}

#[tokio::test]
async fn caller_contact_issued_permit_rechecks_expiry_when_consumed() -> TestResult {
    let prepared = Prepared::new(EXPIRING_LEASE).await?;
    let permit = timeout(WATCHDOG, prepared.prepare()).await??;
    // This probes delayed permit consumption, not an observed host-mutex wait.
    tokio::time::sleep(EXPIRING_LEASE + Duration::from_millis(100)).await;
    let (mut writer, mut peer) = tokio::io::duplex(16);
    let mut calls = 0;
    let result = permit(&mut || {
        calls += 1;
        raw_poll(&mut writer, b"late")
    });
    match result {
        Poll::Ready(result) => expect_owner_error(result, AutomationError::Conflict),
        Poll::Pending => panic!("expired issued permit must reject before raw contact"),
    }
    assert_eq!(calls, 0);
    assert_no_byte(&mut peer);
    prepared.finish().await
}

#[tokio::test]
async fn caller_contact_rejects_exact_admission_drift_before_raw_poll() -> TestResult {
    let prepared = Prepared::new(LONG_LEASE).await?;
    let mut changed = (*prepared.admission).clone();
    changed.prompt.push_str(" substituted");
    let result = timeout(
        WATCHDOG,
        Arc::clone(&prepared.fixture.state)
            .prepare_automation_contact(Arc::clone(&prepared.contact), Arc::new(changed)),
    )
    .await?;
    expect_owner_error(result, AutomationError::AccessDenied);
    let (_writer, mut peer) = tokio::io::duplex(16);
    assert_no_byte(&mut peer);
    prepared.assert_same_uncertainty().await?;
    prepared.finish().await
}

#[tokio::test]
async fn caller_contact_preserves_real_raw_error_without_retry_receipt() -> TestResult {
    let prepared = Prepared::new(LONG_LEASE).await?;
    let permit = timeout(WATCHDOG, prepared.prepare()).await??;
    let (mut writer, peer) = tokio::io::duplex(16);
    drop(peer);
    let mut calls = 0;
    match permit(&mut || {
        calls += 1;
        raw_poll(&mut writer, b"closed")
    }) {
        Poll::Ready(Err(error)) => assert_eq!(error.kind(), io::ErrorKind::BrokenPipe),
        other => panic!("closed duplex must report its real error: {other:?}"),
    }
    assert_eq!(calls, 1);
    prepared.assert_same_uncertainty().await?;
    prepared.finish().await
}

#[tokio::test]
async fn caller_contact_returns_positive_prefix_without_replaying_or_settling() -> TestResult {
    let prepared = Prepared::new(LONG_LEASE).await?;
    let permit = timeout(WATCHDOG, prepared.prepare()).await??;
    let (mut writer, mut peer) = tokio::io::duplex(1);
    let mut calls = 0;
    assert!(matches!(
        permit(&mut || {
            calls += 1;
            raw_poll(&mut writer, b"partial")
        }),
        Poll::Ready(Ok(1))
    ));
    assert_eq!(calls, 1);
    let mut byte = [0_u8; 1];
    timeout(WATCHDOG, peer.read_exact(&mut byte)).await??;
    assert_eq!(byte, *b"p");
    assert_no_byte(&mut peer);
    prepared.assert_same_uncertainty().await?;
    prepared.finish().await
}
