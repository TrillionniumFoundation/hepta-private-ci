"""Run only the scheduled TaskFlow SDK in-memory shared-count cases.

This does not run Agentd/Worker callers or any real socket/sandbox fixture.
A parent-assigned isolated graph is mandatory; resource guards are not authority.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time

ROOT = Path('/workspace/shared/runtime-recovery-20261002')
REPO = Path('/workspace/shared/taskflow-recovery-20261002/repo')
OUT = ROOT / 'taskflow-caller-20261003'
HEAD = '199dd7eb70063a76a943e9f4cd5eba854315901b'
TREE = 'f579de8f0dc80f0879c9d65088eb31c64c03aebb'
TARGET = ROOT / 'target-taskflow-shared-backlog-20261003'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def measured_bytes(path):
    size = 0
    for directory, _, files in os.walk(path):
        for name in files:
            try:
                size += (Path(directory) / name).stat().st_size
            except FileNotFoundError:
                # rustc renames/removes temporary files during sampling.
                pass
    return size


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--parent-slot-assigned', action='store_true', required=True)
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--target-cap-bytes', type=int, default=5_200_000_000)
    parser.add_argument('--free-floor-bytes', type=int, default=3 * 1024**3)
    args = parser.parse_args()
    assert git('rev-parse', 'HEAD') == HEAD
    assert git('rev-parse', 'HEAD^{tree}') == TREE
    assert not git('status', '--porcelain')
    if args.attempt == 1:
        assert not TARGET.exists(), 'Initial run must use a new isolated target'
    assert shutil.disk_usage(ROOT).free > args.free_floor_bytes
    label = f'sdk-attempt{args.attempt:02}'
    log = OUT / (label + '.log')
    result_path = OUT / (label + '-result.json')
    assert not log.exists() and not result_path.exists()
    command = ['just', 'test', '--locked', '--offline', '-p', 'codex-app-server-client',
               '--lib', '-E', 'test(remote_shared_backlog_tests)']
    env = dict(os.environ)
    env.update(PATH='/workspace/shared/toolchains/bin:/workspace/shared/toolchains/cargo/bin:' + os.environ['PATH'],
               CARGO_HOME='/workspace/shared/toolchains/cargo', RUSTUP_HOME='/workspace/shared/toolchains/rustup',
               CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
    paths = ['codex-rs/Cargo.lock', 'codex-rs/app-server-client/Cargo.toml',
             'codex-rs/app-server-client/src/remote.rs',
             'codex-rs/app-server-client/src/remote_shared_backlog_tests.rs',
             'codex-rs/hepta-agentd/src/automation.rs', 'codex-rs/hepta-agentd/src/automation_recovery.rs']
    result = {'head':HEAD, 'tree':TREE, 'command':command, 'target':str(TARGET),
              'expected_tests':7, 'stage':'SDK mechanics only; no real caller connection proof',
              'source_sha256':{p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in paths},
              'target_cap_bytes':args.target_cap_bytes,'free_floor_bytes':args.free_floor_bytes,
              'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    (OUT/(label+'-command.json')).write_text(json.dumps(result,indent=2)+'\n')
    stats = {'peak_sampled_target_bytes':0,'minimum_sampled_free_bytes':shutil.disk_usage(ROOT).free,
             'guard_triggered':False,'sampling_seconds':2}
    finished=threading.Event()
    def sample():
        while not finished.is_set():
            current=measured_bytes(TARGET); free=shutil.disk_usage(ROOT).free
            stats['peak_sampled_target_bytes']=max(stats['peak_sampled_target_bytes'],current)
            stats['minimum_sampled_free_bytes']=min(stats['minimum_sampled_free_bytes'],free)
            stats['guard_triggered']=stats['guard_triggered'] or current>args.target_cap_bytes or free<args.free_floor_bytes
            (OUT/(label+'-resources.json')).write_text(json.dumps(stats,indent=2)+'\n')
            if stats['guard_triggered']:
                print('RESOURCE_GUARD_TRIGGERED: stop through this terminal and preserve logs',flush=True)
                return
            finished.wait(2)
    sampler=threading.Thread(target=sample,daemon=True);sampler.start()
    started=time.monotonic()
    with log.open('w') as stream:
        process=subprocess.Popen(command,cwd=REPO/'codex-rs',env=env,stdout=stream,stderr=subprocess.STDOUT)
        try:
            code=process.wait()
        except KeyboardInterrupt:
            result['terminal_interrupt']=True
            code=process.wait()
    finished.set();sampler.join()
    final_bytes=measured_bytes(TARGET); final_free=shutil.disk_usage(ROOT).free
    stats['peak_sampled_target_bytes']=max(stats['peak_sampled_target_bytes'],final_bytes)
    stats['minimum_sampled_free_bytes']=min(stats['minimum_sampled_free_bytes'],final_free)
    stats['guard_triggered']=stats['guard_triggered'] or final_bytes>args.target_cap_bytes or final_free<args.free_floor_bytes
    (OUT/(label+'-resources.json')).write_text(json.dumps(stats,indent=2)+'\n')
    summaries=re.findall(r'Summary \[[^\]]+\] (\d+) tests run: (\d+) passed',log.read_text())
    selected={'run':int(summaries[-1][0]),'passed':int(summaries[-1][1])} if summaries else None
    result.update(exit=code,observed_tests=selected,elapsed_seconds=time.monotonic()-started,
                  source_clean_after=not bool(git('status','--porcelain')),resources=stats,
                  finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    result['sdk_seven_passed']=code==0 and selected=={'run':7,'passed':7} and result['source_clean_after'] and not stats['guard_triggered']
    result_path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));print(log.read_text()[-6000:])
    raise SystemExit(0 if result['sdk_seven_passed'] else (code or 1))


if __name__=='__main__':
    main()
