use std::future::Future;

use super::GuardedWriteError;
use super::write_first_request;
use crate::physical_write_gate::FirstWriteCheck;
use crate::physical_write_gate::GatedStream;
use crate::physical_write_gate::WritePermit;
use codex_app_server_protocol::JSONRPCMessage;
use codex_app_server_protocol::JSONRPCRequest;
use codex_app_server_protocol::RequestId;
use futures::SinkExt;
use pretty_assertions::assert_eq;
use std::io;
use std::sync::Arc;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering;
use std::task::Poll;
use tokio::io::AsyncReadExt;
use tokio::io::AsyncWriteExt;
use tokio::sync::oneshot;
use tokio_tungstenite::WebSocketStream;
use tokio_tungstenite::tungstenite::Message;
use tokio_tungstenite::tungstenite::protocol::Role;

#[tokio::test]
async fn dropping_the_sending_future_cannot_flush_its_buffered_frame() {
    let (mut raw, mut peer) = tokio::io::duplex(1);
    raw.write_all(b"x").await.expect("fill raw transport");
    let (raw, gate) = GatedStream::new(raw);
    let mut websocket = WebSocketStream::from_raw_socket(raw, Role::Client, None).await;
    let (mut tx, _rx) = oneshot::channel::<()>();
    let mut sending = Box::pin(write_first_request(
        &mut websocket,
        request(6),
        check(
            Arc::new(AtomicBool::new(true)),
            Arc::new(AtomicUsize::new(0)),
        ),
        Some(&gate),
        &mut tx,
    ));
    std::future::poll_fn(|cx| {
        assert!(sending.as_mut().poll(cx).is_pending());
        Poll::Ready(())
    })
    .await;
    // This is also the drop operation performed when a timeout expires.
    drop(sending);
    assert!(websocket.flush().await.is_err());
    drop(websocket);
    let mut bytes = Vec::new();
    peer.read_to_end(&mut bytes).await.expect("drain peer");
    assert_eq!(bytes, b"x");
}

#[tokio::test]
async fn disconnected_raw_peer_rejects_contact_and_cannot_rearm() {
    let (raw, peer) = tokio::io::duplex(1);
    drop(peer);
    let (raw, gate) = GatedStream::new(raw);
    let mut websocket = WebSocketStream::from_raw_socket(raw, Role::Client, None).await;
    let (mut tx, _rx) = oneshot::channel::<()>();
    let result = write_first_request(
        &mut websocket,
        request(7),
        check(
            Arc::new(AtomicBool::new(true)),
            Arc::new(AtomicUsize::new(0)),
        ),
        Some(&gate),
        &mut tx,
    )
    .await;
    assert!(matches!(result, Err(GuardedWriteError::Transport(_))));
    assert!(
        gate.arm(check(
            Arc::new(AtomicBool::new(true)),
            Arc::new(AtomicUsize::new(0))
        ))
        .is_err()
    );
}

fn request(id: i64) -> JSONRPCMessage {
    JSONRPCMessage::Request(JSONRPCRequest {
        id: RequestId::Integer(id),
        method: "thread/queue/reconcile".into(),
        params: Some(serde_json::json!({"identity": id})),
        trace: None,
    })
}

fn check(live: Arc<AtomicBool>, checks: Arc<AtomicUsize>) -> FirstWriteCheck {
    Box::new(move || {
        let live = live.clone();
        let checks = checks.clone();
        Box::pin(async move {
            checks.fetch_add(1, Ordering::SeqCst);
            if !live.load(Ordering::SeqCst) {
                return Err(io::Error::from(io::ErrorKind::PermissionDenied));
            }
            Ok(
                Box::new(|write: &mut dyn FnMut() -> Poll<io::Result<usize>>| write())
                    as WritePermit,
            )
        })
    })
}

#[tokio::test]
async fn backpressure_revocation_writes_no_bytes_and_cannot_flush_later() {
    let live = Arc::new(AtomicBool::new(true));
    let checks = Arc::new(AtomicUsize::new(0));
    // Fill the raw transport before framing. The first actual request write
    // must return zero-byte Pending even though WebSocket accepts its buffer.
    let (mut raw, mut peer) = tokio::io::duplex(1);
    raw.write_all(b"x").await.expect("transport fixture");
    let (raw, gate) = GatedStream::new(raw);
    let mut websocket = WebSocketStream::from_raw_socket(raw, Role::Client, None).await;
    let (mut tx, _rx) = oneshot::channel::<()>();
    let mut sending = Box::pin(write_first_request(
        &mut websocket,
        request(1),
        check(live.clone(), checks.clone()),
        Some(&gate),
        &mut tx,
    ));
    std::future::poll_fn(|cx| {
        assert!(sending.as_mut().poll(cx).is_pending());
        Poll::Ready(())
    })
    .await;
    assert_eq!(checks.load(Ordering::SeqCst), 1);
    live.store(false, Ordering::SeqCst);
    let mut old_byte = [0];
    peer.read_exact(&mut old_byte)
        .await
        .expect("transport fixture");
    assert_eq!(old_byte, [b'x']);
    assert!(matches!(
        sending.await,
        Err(GuardedWriteError::Transport(_))
    ));
    assert_eq!(checks.load(Ordering::SeqCst), 2);
    assert!(
        websocket.flush().await.is_err(),
        "rejected buffer cannot flush later"
    );
    drop(websocket);
    let mut bytes = Vec::new();
    peer.read_to_end(&mut bytes)
        .await
        .expect("transport fixture");
    assert!(
        bytes.is_empty(),
        "revocation before positive bytes must produce zero request bytes"
    );
}

#[tokio::test]
async fn positive_partial_contact_then_cancel_cannot_replay() {
    // Once a positive partial write occurred, cancellation aborts the rest and
    // remains uncertain. It must neither replay nor complete the buffered frame.
    let (raw, mut peer) = tokio::io::duplex(1);
    let (raw, gate) = GatedStream::new(raw);
    let mut websocket = WebSocketStream::from_raw_socket(raw, Role::Client, None).await;
    let (mut tx, rx) = oneshot::channel::<()>();
    let checks = Arc::new(AtomicUsize::new(0));
    let mut sending = Box::pin(write_first_request(
        &mut websocket,
        request(2),
        check(Arc::new(AtomicBool::new(true)), checks.clone()),
        Some(&gate),
        &mut tx,
    ));
    std::future::poll_fn(|cx| {
        assert!(sending.as_mut().poll(cx).is_pending());
        Poll::Ready(())
    })
    .await;
    drop(rx);
    assert!(matches!(
        sending.await,
        Err(GuardedWriteError::Transport(_))
    ));
    assert!(websocket.flush().await.is_err());
    drop(websocket);
    let mut bytes = Vec::new();
    peer.read_to_end(&mut bytes)
        .await
        .expect("transport fixture");
    assert_eq!(bytes.len(), 1);
    assert_eq!(checks.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn cancelled_or_unsupported_contact_never_consumes_the_owner_check() {
    // Cancellation before arming and unsupported profiles do not consume any
    // owner check and do not leave a request in a protocol buffer.
    for unsupported in [false, true] {
        let (raw, mut peer) = tokio::io::duplex(4096);
        let (raw, gate) = GatedStream::new(raw);
        let mut websocket = WebSocketStream::from_raw_socket(raw, Role::Client, None).await;
        let (mut tx, rx) = oneshot::channel::<()>();
        let checks = Arc::new(AtomicUsize::new(0));
        let held_rx = if unsupported {
            Some(rx)
        } else {
            drop(rx);
            None
        };
        let result = write_first_request(
            &mut websocket,
            request(3),
            check(Arc::new(AtomicBool::new(true)), checks.clone()),
            if unsupported { None } else { Some(&gate) },
            &mut tx,
        )
        .await;
        assert!(matches!(result, Err(GuardedWriteError::BeforeSend(_))));
        assert_eq!(checks.load(Ordering::SeqCst), 0);
        websocket.flush().await.expect("transport fixture");
        drop(websocket);
        drop(held_rx);
        let mut bytes = Vec::new();
        peer.read_to_end(&mut bytes)
            .await
            .expect("transport fixture");
        assert!(bytes.is_empty());
    }
}

#[tokio::test]
async fn completed_contact_rearms_and_rejects_the_next_frame_independently() {
    // The complete successful frame can be followed by a separately checked
    // request. Rejecting the second must not leak it on close/flush.
    let (raw, mut peer) = tokio::io::duplex(4096);
    let (raw, gate) = GatedStream::new(raw);
    let mut websocket = WebSocketStream::from_raw_socket(raw, Role::Client, None).await;
    let (mut tx, _rx) = oneshot::channel::<()>();
    let checks = Arc::new(AtomicUsize::new(0));
    let first = request(4);
    write_first_request(
        &mut websocket,
        first.clone(),
        check(Arc::new(AtomicBool::new(true)), checks.clone()),
        Some(&gate),
        &mut tx,
    )
    .await
    .unwrap_or_else(|_| panic!("first frame must complete"));
    let result = write_first_request(
        &mut websocket,
        request(5),
        check(Arc::new(AtomicBool::new(false)), checks.clone()),
        Some(&gate),
        &mut tx,
    )
    .await;
    assert!(matches!(result, Err(GuardedWriteError::Transport(_))));
    assert!(websocket.flush().await.is_err());
    drop(websocket);
    let mut bytes = Vec::new();
    peer.read_to_end(&mut bytes)
        .await
        .expect("transport fixture");
    let mut decoder = tokio_tungstenite::tungstenite::WebSocket::from_raw_socket(
        io::Cursor::new(bytes),
        Role::Server,
        None,
    );
    let Message::Text(text) = decoder.read().expect("transport fixture") else {
        panic!("request frame")
    };
    assert_eq!(
        serde_json::from_str::<JSONRPCMessage>(&text).expect("transport fixture"),
        first
    );
    assert!(decoder.read().is_err());
    assert_eq!(checks.load(Ordering::SeqCst), 2);
}
