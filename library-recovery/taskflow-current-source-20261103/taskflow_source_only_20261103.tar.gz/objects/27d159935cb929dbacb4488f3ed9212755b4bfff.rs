//! Real reader tests for the explicit shared-count backlog API.

use super::*;
use pretty_assertions::assert_eq;
use serde_json::Value;
use serde_json::json;
use std::pin::Pin;
use std::sync::atomic::AtomicBool;
use std::task::Context;
use std::task::Poll;
use tokio::io::DuplexStream;
use tokio::io::ReadBuf;
use tokio::io::duplex;
use tokio_tungstenite::tungstenite::protocol::Role;

type TestResult<T = ()> = Result<T, Box<dyn std::error::Error + Send + Sync>>;
type ServerSocket = WebSocketStream<DuplexStream>;
const TEST_WATCHDOG: Duration = Duration::from_secs(3);

struct DropObservedIo {
    inner: DuplexStream,
    dropped: Arc<AtomicBool>,
}

impl Drop for DropObservedIo {
    fn drop(&mut self) {
        self.dropped.store(true, Ordering::Release);
    }
}

impl AsyncRead for DropObservedIo {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buffer: &mut ReadBuf<'_>,
    ) -> Poll<IoResult<()>> {
        Pin::new(&mut self.inner).poll_read(cx, buffer)
    }
}

impl AsyncWrite for DropObservedIo {
    fn poll_write(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buffer: &[u8],
    ) -> Poll<IoResult<usize>> {
        Pin::new(&mut self.inner).poll_write(cx, buffer)
    }

    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<IoResult<()>> {
        Pin::new(&mut self.inner).poll_flush(cx)
    }

    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<IoResult<()>> {
        Pin::new(&mut self.inner).poll_shutdown(cx)
    }
}

async fn sockets() -> (
    WebSocketStream<DropObservedIo>,
    ServerSocket,
    Arc<AtomicBool>,
) {
    let (client, server) = duplex(/*max_buf_size*/ 16 * 1024);
    let dropped = Arc::new(AtomicBool::new(false));
    let client = WebSocketStream::from_raw_socket(
        DropObservedIo {
            inner: client,
            dropped: Arc::clone(&dropped),
        },
        Role::Client,
        Some(remote_websocket_config()),
    )
    .await;
    let server = WebSocketStream::from_raw_socket(server, Role::Server, /*config*/ None).await;
    (client, server, dropped)
}

fn name_event(name: &str) -> Message {
    Message::Text(
        json!({
            "method": "thread/name/updated",
            "params": {"threadId": "shared-backlog", "threadName": name}
        })
        .to_string()
        .into(),
    )
}

async fn read_json(server: &mut ServerSocket) -> TestResult<Value> {
    let message = server.next().await.ok_or("peer closed")??;
    Ok(serde_json::from_str(message.to_text()?)?)
}

async fn initialize(server: &mut ServerSocket, events: Vec<Message>) -> TestResult {
    let request = read_json(server).await?;
    assert_eq!(request["method"], "initialize");
    for event in events {
        server.send(event).await?;
    }
    server
        .send(Message::Text(
            json!({
                "id": request["id"],
                "result": {"userAgent": "fixture/1", "codexHome": "/fixture"}
            })
            .to_string()
            .into(),
        ))
        .await?;
    assert_eq!(read_json(server).await?["method"], "initialized");
    Ok(())
}

async fn connect(
    client: WebSocketStream<DropObservedIo>,
    event_backlog_capacity: usize,
) -> IoResult<RemoteAppServerClient> {
    RemoteAppServerClient::connect_with_stream(
        /*channel_capacity*/ 1,
        RemoteEventMode::BacklogBounded {
            capacity: event_backlog_capacity,
        },
        "shared-backlog-memory-fixture".into(),
        client,
        /*physical_write_gate*/ None,
        InitializeParams {
            client_info: ClientInfo {
                name: "shared-backlog-test".into(),
                version: "1".into(),
                title: None,
            },
            capabilities: None,
        },
    )
    .await
}

fn request() -> JSONRPCRequest {
    JSONRPCRequest {
        id: RequestId::Integer(1),
        method: "fixture/barrier".into(),
        params: None,
        trace: None,
    }
}

fn name(event: Option<AppServerEvent>) -> TestResult<String> {
    let Some(AppServerEvent::ServerNotification(notification)) = event else {
        return Err("expected a name notification".into());
    };
    let ServerNotification::ThreadNameUpdated(notification) = notification.as_ref() else {
        return Err("unexpected notification kind".into());
    };
    notification
        .thread_name
        .clone()
        .ok_or_else(|| "name missing".into())
}

async fn overflow(initial_event: Message) -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server, dropped) = sockets().await;
        let (release, released) = oneshot::channel();
        let server_task = tokio::spawn(async move {
            initialize(&mut server, vec![initial_event]).await?;
            let barrier = read_json(&mut server).await?;
            server.send(name_event("over-capacity")).await?;
            // The reply follows the overflowing event. It must not make the
            // already-failed reader's pending request look successful.
            let _ = server
                .send(Message::Text(
                    json!({"id": barrier["id"], "result": null})
                        .to_string()
                        .into(),
                ))
                .await;
            let _ = released.await;
            Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
        });
        let mut client = connect(client, /*event_backlog_capacity*/ 1).await?;
        let reply = client.request_handle().request_json_rpc(request()).await;
        assert!(
            reply.is_err(),
            "overflow must fail the pending request: {reply:?}"
        );
        assert!(matches!(
            client.next_event().await,
            Some(AppServerEvent::ServerNotification(_) | AppServerEvent::ServerRequest(_))
        ));
        let Some(AppServerEvent::Disconnected { message }) = client.next_event().await else {
            return Err("expected overflow terminal after the retained initial event".into());
        };
        assert!(message.contains("bounded remote app-server event queue is full"));
        assert!(
            client.next_event().await.is_none(),
            "terminal must be delivered once"
        );
        client.shutdown().await?;
        assert!(dropped.load(Ordering::Acquire));
        let _ = release.send(());
        server_task.await??;
        Ok(())
    })
    .await?
}

#[tokio::test]
async fn initial_notification_and_live_event_share_one_backlog_slot() -> TestResult {
    overflow(name_event("initial")).await
}

#[tokio::test]
async fn initial_server_request_and_live_event_share_one_backlog_slot() -> TestResult {
    overflow(Message::Text(json!({
        "id": 7,
        "method": "item/tool/requestUserInput",
        "params": {"threadId": "shared-backlog", "turnId": "turn-1", "itemId": "item-1", "questions": [], "isBlocking": true}
    }).to_string().into())).await
}

#[tokio::test]
async fn exact_total_capacity_preserves_initialization_then_live_order() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server, dropped) = sockets().await;
        let (release, released) = oneshot::channel();
        let server_task = tokio::spawn(async move {
            initialize(
                &mut server,
                vec![name_event("initial-0"), name_event("initial-1")],
            )
            .await?;
            let barrier = read_json(&mut server).await?;
            server.send(name_event("live-2")).await?;
            server
                .send(Message::Text(
                    json!({"id": barrier["id"], "result": null})
                        .to_string()
                        .into(),
                ))
                .await?;
            let _ = released.await;
            Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
        });
        let mut client = connect(client, /*event_backlog_capacity*/ 3).await?;
        assert_eq!(
            client.request_handle().request_json_rpc(request()).await?,
            Ok(Value::Null)
        );
        let mut observed = Vec::new();
        for _ in 0..3 {
            observed.push(name(client.next_event().await)?);
        }
        assert_eq!(observed, vec!["initial-0", "initial-1", "live-2"]);
        client.shutdown().await?;
        assert!(dropped.load(Ordering::Acquire));
        let _ = release.send(());
        server_task.await??;
        Ok(())
    })
    .await?
}

#[tokio::test]
async fn draining_an_initial_event_releases_space_for_live_events() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server, dropped) = sockets().await;
        let (release, released) = oneshot::channel();
        let server_task = tokio::spawn(async move {
            initialize(&mut server, vec![name_event("initial")]).await?;
            let barrier = read_json(&mut server).await?;
            server.send(name_event("live")).await?;
            server
                .send(Message::Text(
                    json!({"id": barrier["id"], "result": null})
                        .to_string()
                        .into(),
                ))
                .await?;
            let _ = released.await;
            Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
        });
        let mut client = connect(client, /*event_backlog_capacity*/ 1).await?;
        assert_eq!(name(client.next_event().await)?, "initial");
        assert_eq!(
            client.request_handle().request_json_rpc(request()).await?,
            Ok(Value::Null)
        );
        assert_eq!(name(client.next_event().await)?, "live");
        client.shutdown().await?;
        assert!(dropped.load(Ordering::Acquire));
        let _ = release.send(());
        server_task.await??;
        Ok(())
    })
    .await?
}

#[tokio::test]
async fn disconnect_with_full_initial_backlog_preserves_order_and_one_terminal() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server, dropped) = sockets().await;
        let server_task = tokio::spawn(async move {
            initialize(&mut server, vec![name_event("initial")]).await?;
            server.close(/*msg*/ None).await?;
            Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
        });
        let mut client = connect(client, /*event_backlog_capacity*/ 1).await?;
        while !client.worker_handle.is_finished() {
            tokio::task::yield_now().await;
        }
        assert_eq!(name(client.next_event().await)?, "initial");
        assert!(matches!(
            client.next_event().await,
            Some(AppServerEvent::Disconnected { .. })
        ));
        assert!(client.next_event().await.is_none());
        client.shutdown().await?;
        assert!(dropped.load(Ordering::Acquire));
        server_task.await??;
        Ok(())
    })
    .await?
}

#[tokio::test]
async fn reader_abort_releases_transport_and_retains_already_queued_events() -> TestResult {
    timeout(TEST_WATCHDOG, async {
        let (client, mut server, dropped) = sockets().await;
        let (release, released) = oneshot::channel();
        let server_task = tokio::spawn(async move {
            initialize(&mut server, vec![name_event("initial")]).await?;
            let _ = released.await;
            Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
        });
        let mut client = connect(client, /*event_backlog_capacity*/ 1).await?;
        client.worker_handle.abort();
        assert_eq!(name(client.next_event().await)?, "initial");
        assert!(client.next_event().await.is_none());
        client.shutdown().await?;
        assert!(dropped.load(Ordering::Acquire));
        let _ = release.send(());
        server_task.await??;
        Ok(())
    })
    .await?
}

#[derive(Clone, Copy, Debug)]
enum InitializationFailure {
    Reject,
    Malformed,
    Overflow,
}

#[tokio::test]
async fn failed_initialization_drops_transport_before_returning() -> TestResult {
    for failure in [
        InitializationFailure::Reject,
        InitializationFailure::Malformed,
        InitializationFailure::Overflow,
    ] {
        timeout(TEST_WATCHDOG, async {
            let (client, mut server, dropped) = sockets().await;
            let (release, released) = oneshot::channel();
            let server_task = tokio::spawn(async move {
                let request = read_json(&mut server).await?;
                server.send(name_event("initial")).await?;
                let message = match failure {
                    InitializationFailure::Reject => Message::Text(json!({"id": request["id"], "error": {"code": -32603, "message": "fixture rejection"}}).to_string().into()),
                    InitializationFailure::Malformed => Message::Text("not-json".into()),
                    InitializationFailure::Overflow => name_event("over-capacity"),
                };
                server.send(message).await?;
                let _ = released.await;
                Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
            });
            let result = connect(client, /*event_backlog_capacity*/ 1).await;
            assert!(result.is_err(), "initialization must fail for {failure:?}");
            assert!(dropped.load(Ordering::Acquire), "failed initialization retained its transport");
            let _ = release.send(());
            server_task.await??;
            Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
        }).await??;
    }
    Ok(())
}
