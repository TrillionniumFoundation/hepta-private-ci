"""Prepare exact candidates without checking them out or starting a build."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspace/shared/runtime-recovery-20261002')
REPO = ROOT / 'worker1329-repo'
OUT = ROOT / 'initialize-preparation-20261003'
BASE = 'a9e551c1a6488cfe082d3bc608f254c3043a3445'
REMOTE = 'codex-rs/app-server-client/src/remote.rs'
TEST = 'codex-rs/app-server-client/src/remote_initialize_deadline_tests.rs'
RUSTFMT = '/workspace/shared/toolchains/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustfmt'

def git(*args, data=None, env=None):
    return subprocess.check_output(['git', '-C', str(REPO), *args], input=data, env=env).decode().strip()

source = git('show', f'{BASE}:{REMOTE}') + '\n'
red = source + '\n#[cfg(test)]\n#[path = "remote_initialize_deadline_tests.rs"]\nmod remote_initialize_deadline_tests;\n'
start = red.index('async fn initialize_remote_connection<S>(')
end = red.index('\nfn app_server_event_from_notification(', start)
function = red[start:end]
body_start = function.index('    let initialize_request_id =')
loop_start = function.index('    timeout(initialize_timeout, async {\n')
await_start = function.index('    })\n    .await\n    .map_err', loop_start)
write_start = function.index('\n    write_jsonrpc_message(', await_start)
prefix = function[body_start:loop_start]
loop = function[loop_start + len('    timeout(initialize_timeout, async {\n'):await_start]
assert loop.endswith('        }\n')
loop = loop[:-1] + '?;\n'
loop = ''.join(line[4:] if line.startswith('    ') else line for line in loop.splitlines(keepends=True))
suffix = function[write_start:].rstrip()
assert suffix.endswith('\n}')
suffix = suffix[:-2]
body = prefix + loop + suffix + '\n'
fixed_function = function[:body_start] + '''    // The existing initialization budget covers both handshake writes and
    // the response loop. A peer that stops reading must not bypass it.
    timeout(initialize_timeout, async {
''' + ''.join('    ' + line if line.strip() else line for line in body.splitlines(keepends=True)) + '''    })
    .await
    .map_err(|_| {
        IoError::new(
            ErrorKind::TimedOut,
            format!("timed out initializing remote app server at `{endpoint}`"),
        )
    })?
}
'''
fixed = red[:start] + fixed_function + red[end:]

for filename, content in [('remote-red.rs', red), ('remote-fixed.rs', fixed)]:
    file = OUT / filename
    file.write_text(content)
    subprocess.run([RUSTFMT, '--edition', '2024', '--config', 'skip_children=true', str(file)], check=True)
subprocess.run([RUSTFMT, '--edition', '2024', str(OUT / Path(TEST).name)], check=True)

env = os.environ.copy()
env['GIT_INDEX_FILE'] = str(OUT / 'scratch.index')
parent = BASE
records = []
for label in ['red', 'fixed']:
    git('read-tree', parent, env=env)
    for path, file in [(REMOTE, OUT / f'remote-{label}.rs'), (TEST, OUT / Path(TEST).name)]:
        blob = git('hash-object', '-w', '--stdin', data=file.read_bytes())
        git('update-index', '--add', '--cacheinfo', f'100644,{blob},{path}', env=env)
    tree = git('write-tree', env=env)
    commit = git('-c', 'user.name=Codex', '-c', 'user.email=codex@openai.com',
                 'commit-tree', tree, '-p', parent,
                 data=f'Prepare unexecuted initialization deadline {label}\n'.encode())
    git('update-ref', f'refs/heads/audit/prepared-worker-initialize-{label}-20261003', commit)
    patch = subprocess.check_output(['git', '-C', str(REPO), 'diff', '--binary', parent, commit])
    (OUT / f'{label}.patch').write_bytes(patch)
    git('read-tree', parent, env=env)
    git('apply', '--cached', str(OUT / f'{label}.patch'), env=env)
    assert git('write-tree', env=env) == tree
    records.append({'stage': label, 'parent': parent, 'commit': commit, 'tree': tree,
                    'patch_sha256': hashlib.sha256(patch).hexdigest(),
                    'patch_roundtrip_exact': True, 'compiled': False, 'executed': False})
    parent = commit
(OUT / 'scratch.index').unlink()
summary = {
    'base': BASE, 'base_tree': git('rev-parse', BASE + '^{tree}'), 'stages': records,
    'tests': 8, 'expected_red_cases_not_observed': 5, 'positive_controls_not_executed': 3,
    'test_sha256': hashlib.sha256((OUT / Path(TEST).name).read_bytes()).hexdigest(),
    'working_checkout_unchanged': git('rev-parse', 'HEAD') == BASE and not git('status', '--porcelain'),
    'cargo_executed': False, 'sandbox_helpers_requested': False,
    'formatter': 'Standalone rustfmt parse/format only. Repository just fmt/strict/native deferred to an assigned build slot.',
    'scope': 'Original initialization duration covers initial write/flush, response loop, initialized write/flush; not endpoint connect or total caller latency.'
}
(OUT / 'PREPARED_CANDIDATES.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
