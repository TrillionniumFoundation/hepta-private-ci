//! Public shutdown regressions using the production worker and tiny raw streams.
//! Connection setup injects an in-memory transport; shutdown is the public API.

use super::*;
use pretty_assertions::assert_eq;
use serde_json::Value;
use serde_json::json;
use std::pin::Pin;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::AtomicUsize;
use std::task::Context;
use std::task::Poll;
use tokio::io::DuplexStream;
use tokio::io::ReadBuf;
use tokio::io::duplex;
use tokio::task::AbortHandle;
use tokio::task::JoinHandle;
use tokio_tungstenite::tungstenite::protocol::Role;

type TestResult<T = ()> = Result<T, Box<dyn std::error::Error + Send + Sync>>;
type ServerSocket = WebSocketStream<DuplexStream>;
const TEST_WATCHDOG: Duration = Duration::from_secs(2);

struct AbortOnDrop(AbortHandle);

impl Drop for AbortOnDrop {
    fn drop(&mut self) {
        self.0.abort();
    }
}

#[derive(Default)]
struct WriteState {
    pending: AtomicBool,
    fail: AtomicBool,
    blocked_polls: AtomicUsize,
    dropped: AtomicBool,
}

struct ObservedIo {
    inner: DuplexStream,
    state: Arc<WriteState>,
}

impl Drop for ObservedIo {
    fn drop(&mut self) {
        self.state.dropped.store(true, Ordering::Release);
    }
}

impl AsyncRead for ObservedIo {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buffer: &mut ReadBuf<'_>,
    ) -> Poll<IoResult<()>> {
        Pin::new(&mut self.inner).poll_read(cx, buffer)
    }
}

impl AsyncWrite for ObservedIo {
    fn poll_write(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buffer: &[u8],
    ) -> Poll<IoResult<usize>> {
        if self.state.fail.load(Ordering::Acquire) {
            return Poll::Ready(Err(IoError::new(
                ErrorKind::PermissionDenied,
                "injected close write failure",
            )));
        }
        if self.state.pending.load(Ordering::Acquire) {
            self.state.blocked_polls.fetch_add(1, Ordering::AcqRel);
            return Poll::Pending;
        }
        Pin::new(&mut self.inner).poll_write(cx, buffer)
    }

    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<IoResult<()>> {
        Pin::new(&mut self.inner).poll_flush(cx)
    }

    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<IoResult<()>> {
        Pin::new(&mut self.inner).poll_shutdown(cx)
    }
}

async fn initialize(mut server: ServerSocket) -> TestResult<ServerSocket> {
    let request = server.next().await.ok_or("missing initialize")??;
    let request: Value = serde_json::from_str(request.to_text()?)?;
    assert_eq!(request["method"], "initialize");
    server
        .send(Message::Text(
            json!({
                "id": request["id"],
                "result": {"userAgent": "shutdown-fixture/1", "codexHome": "/fixture"}
            })
            .to_string()
            .into(),
        ))
        .await?;
    let initialized = server.next().await.ok_or("missing initialized")??;
    let initialized: Value = serde_json::from_str(initialized.to_text()?)?;
    assert_eq!(initialized["method"], "initialized");
    Ok(server)
}

async fn connected() -> TestResult<(
    RemoteAppServerClient,
    ServerSocket,
    Arc<WriteState>,
    AbortOnDrop,
)> {
    let (client_io, server_io) = duplex(/*max_buf_size*/ 4096);
    let state = Arc::new(WriteState::default());
    let client_stream = WebSocketStream::from_raw_socket(
        ObservedIo {
            inner: client_io,
            state: Arc::clone(&state),
        },
        Role::Client,
        Some(remote_websocket_config()),
    )
    .await;
    let server_stream =
        WebSocketStream::from_raw_socket(server_io, Role::Server, /*config*/ None).await;
    let server_task = tokio::spawn(initialize(server_stream));
    let _server_cleanup = AbortOnDrop(server_task.abort_handle());
    let client = timeout(
        TEST_WATCHDOG,
        RemoteAppServerClient::connect_with_stream(
            /*channel_capacity*/ 1,
            RemoteEventMode::BacklogBounded { capacity: 1 },
            "public-shutdown-memory-fixture".into(),
            client_stream,
            InitializeParams {
                client_info: ClientInfo {
                    name: "shutdown-test".into(),
                    version: "1".into(),
                    title: None,
                },
                capabilities: None,
            },
        ),
    )
    .await??;
    let worker_cleanup = AbortOnDrop(client.worker_handle.abort_handle());
    let server = timeout(TEST_WATCHDOG, server_task).await???;
    Ok((client, server, state, worker_cleanup))
}

fn request(id: i64) -> JSONRPCRequest {
    JSONRPCRequest {
        id: RequestId::Integer(id),
        method: "shutdown/probe".into(),
        params: None,
        trace: None,
    }
}

// On a negative control the caller's watchdog expires first. Explicitly abort
// and join the production worker before returning the failing assertion so a
// detached test task cannot manufacture the observed transport release.
async fn finish_with_watchdog(
    mut shutdown: JoinHandle<IoResult<()>>,
    worker_abort: AbortHandle,
) -> TestResult<bool> {
    match timeout(SHUTDOWN_TIMEOUT + Duration::from_secs(1), &mut shutdown).await {
        Ok(result) => {
            result??;
            Ok(true)
        }
        Err(_) => {
            worker_abort.abort();
            timeout(TEST_WATCHDOG, shutdown).await???;
            Ok(false)
        }
    }
}

#[tokio::test]
async fn public_shutdown_bounds_full_command_queue_after_actual_write_pending() -> TestResult {
    let (client, _server, state, _worker_cleanup) = connected().await?;
    state.pending.store(true, Ordering::Release);
    let first_handle = client.request_handle();
    let first = tokio::spawn(async move { first_handle.request_json_rpc(request(1)).await });
    let _first_cleanup = AbortOnDrop(first.abort_handle());
    timeout(TEST_WATCHDOG, async {
        while state.blocked_polls.load(Ordering::Acquire) == 0 {
            tokio::task::yield_now().await;
        }
    })
    .await?;
    let second_handle = client.request_handle();
    let second = tokio::spawn(async move { second_handle.request_json_rpc(request(2)).await });
    let _second_cleanup = AbortOnDrop(second.abort_handle());
    timeout(TEST_WATCHDOG, async {
        while client.command_tx.capacity() != 0 {
            tokio::task::yield_now().await;
        }
    })
    .await?;
    let worker_abort = client.worker_handle.abort_handle();
    let completed = finish_with_watchdog(tokio::spawn(client.shutdown()), worker_abort).await?;
    let first_result = timeout(TEST_WATCHDOG, first).await??;
    let second_result = timeout(TEST_WATCHDOG, second).await??;
    assert!(
        first_result.is_err(),
        "in-flight request must not report success"
    );
    assert!(
        second_result.is_err(),
        "queued request must not report success"
    );
    assert!(state.dropped.load(Ordering::Acquire));
    assert!(completed, "public shutdown did not bound command enqueue");
    Ok(())
}

#[tokio::test]
async fn public_shutdown_uses_one_budget_for_close_ack_and_worker_join() -> TestResult {
    let (client, _server, state, _worker_cleanup) = connected().await?;
    state.pending.store(true, Ordering::Release);
    let worker_abort = client.worker_handle.abort_handle();
    let completed = finish_with_watchdog(tokio::spawn(client.shutdown()), worker_abort).await?;
    assert!(state.blocked_polls.load(Ordering::Acquire) > 0);
    assert!(state.dropped.load(Ordering::Acquire));
    assert!(
        completed,
        "shutdown restarted the close budget before joining"
    );
    Ok(())
}

#[tokio::test]
async fn public_shutdown_graceful_close_releases_real_transport() -> TestResult {
    let (client, mut server, state, _worker_cleanup) = connected().await?;
    timeout(TEST_WATCHDOG, client.shutdown()).await??;
    let close = timeout(TEST_WATCHDOG, server.next())
        .await?
        .ok_or("missing close frame")??;
    assert!(matches!(close, Message::Close(_)));
    assert!(state.dropped.load(Ordering::Acquire));
    Ok(())
}

#[tokio::test]
async fn public_shutdown_preserves_close_error_and_releases_real_transport() -> TestResult {
    let (client, _server, state, _worker_cleanup) = connected().await?;
    state.fail.store(true, Ordering::Release);
    let Err(error) = timeout(TEST_WATCHDOG, client.shutdown()).await? else {
        return Err("injected non-tolerated close failure was not returned".into());
    };
    assert!(error.to_string().contains("injected close write failure"));
    assert!(state.dropped.load(Ordering::Acquire));
    Ok(())
}

#[tokio::test]
async fn last_sender_drop_bounds_idle_websocket_close() -> TestResult {
    let (client, _server, state, _worker_cleanup) = connected().await?;
    state.pending.store(true, Ordering::Release);
    let worker_abort = client.worker_handle.abort_handle();
    drop(client);
    let released = timeout(SHUTDOWN_TIMEOUT + Duration::from_secs(1), async {
        while !state.dropped.load(Ordering::Acquire) {
            tokio::task::yield_now().await;
        }
    })
    .await
    .is_ok();
    if !released {
        worker_abort.abort();
        timeout(TEST_WATCHDOG, async {
            while !state.dropped.load(Ordering::Acquire) {
                tokio::task::yield_now().await;
            }
        })
        .await?;
    }
    assert!(state.blocked_polls.load(Ordering::Acquire) > 0);
    assert!(
        released,
        "last sender drop left idle close pending indefinitely"
    );
    Ok(())
}

#[tokio::test]
async fn externally_timed_out_public_shutdown_releases_stalled_transport() -> TestResult {
    let (client, _server, state, _worker_cleanup) = connected().await?;
    state.pending.store(true, Ordering::Release);
    let request_handle = client.request_handle();
    let pending = tokio::spawn(async move { request_handle.request_json_rpc(request(1)).await });
    let _request_cleanup = AbortOnDrop(pending.abort_handle());
    timeout(TEST_WATCHDOG, async {
        while state.blocked_polls.load(Ordering::Acquire) == 0 {
            tokio::task::yield_now().await;
        }
    })
    .await?;
    let worker_abort = client.worker_handle.abort_handle();
    // Deliberately make the caller's budget shorter than the SDK's. This tests
    // future cancellation deterministically, not a same-instant timer race or
    // a new production timeout value.
    let outer = timeout(Duration::from_millis(50), client.shutdown()).await;
    assert!(
        outer.is_err(),
        "caller deadline must cancel the polled shutdown"
    );
    let released = timeout(TEST_WATCHDOG, async {
        while !state.dropped.load(Ordering::Acquire) {
            tokio::task::yield_now().await;
        }
    })
    .await
    .is_ok();
    if !released {
        worker_abort.abort();
    }
    let request_result = timeout(TEST_WATCHDOG, pending).await??;
    assert!(request_result.is_err());
    assert!(released, "cancelled shutdown detached its stalled worker");
    Ok(())
}
