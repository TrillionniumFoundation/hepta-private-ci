use super::*;
use serde_json::json;
use tokio::io::duplex;
use tokio_tungstenite::tungstenite::protocol::Role;

type TestResult<T = ()> = Result<T, Box<dyn std::error::Error + Send + Sync>>;
type Initialization = IoResult<(Vec<AppServerEvent>, Option<String>, Option<String>)>;

#[derive(Clone, Copy)]
enum InitializeReply {
    Withhold,
    Accept,
}

#[derive(Clone, Copy)]
enum InitializeTraffic {
    Notifications(usize),
    Mixed,
}

async fn probe(
    mode: RemoteEventMode,
    traffic: InitializeTraffic,
    reply: InitializeReply,
) -> TestResult<Result<Initialization, tokio::time::error::Elapsed>> {
    let (client_io, server_io) = duplex(16 * 1024);
    let mut client = WebSocketStream::from_raw_socket(client_io, Role::Client, None).await;
    let mut server = WebSocketStream::from_raw_socket(server_io, Role::Server, None).await;
    let (release, released) = oneshot::channel();
    let server_task = tokio::spawn(async move {
        let request = server.next().await.ok_or("initialize request missing")??;
        let request: serde_json::Value = serde_json::from_str(request.to_text()?)?;
        assert_eq!(request["method"], "initialize");
        let notification_count = match traffic {
            InitializeTraffic::Notifications(count) => count,
            InitializeTraffic::Mixed => 1,
        };
        for index in 0..notification_count {
            server.send(Message::Text(json!({
                "method": "thread/name/updated",
                "params": {"threadId": "bounded-init", "threadName": format!("event-{index}")}
            }).to_string().into())).await?;
        }
        if matches!(traffic, InitializeTraffic::Mixed) {
            server.send(Message::Text(json!({
                "id": 7,
                "method": "item/tool/requestUserInput",
                "params": {"threadId": "bounded-init", "turnId": "turn-1", "itemId": "item-1", "questions": [], "isBlocking": true}
            }).to_string().into())).await?;
        }
        if matches!(reply, InitializeReply::Accept) {
            server
                .send(Message::Text(
                    json!({
                        "id": request["id"],
                        "result": {"userAgent": "fixture/1.0.0", "codexHome": "/fixture"}
                    })
                    .to_string()
                    .into(),
                ))
                .await?;
        }
        let _ = released.await;
        Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
    });
    let result = timeout(
        Duration::from_secs(1),
        initialize_remote_connection(
            &mut client,
            "in-memory-websocket-fixture",
            InitializeParams {
                client_info: ClientInfo {
                    name: "initialization-bound-test".into(),
                    version: "1".into(),
                    title: None,
                },
                capabilities: None,
            },
            INITIALIZE_TIMEOUT,
            mode,
        ),
    )
    .await;
    let _ = release.send(());
    server_task.await??;
    Ok(result)
}

#[tokio::test]
async fn bounded_initialization_rejects_before_the_server_sends_initialize_response() -> TestResult
{
    let result = probe(
        RemoteEventMode::Bounded { capacity: 1 },
        InitializeTraffic::Notifications(2),
        InitializeReply::Withhold,
    )
    .await?;
    assert!(matches!(result, Ok(Err(error)) if error.kind() == ErrorKind::OutOfMemory));
    Ok(())
}

#[tokio::test]
async fn exact_capacity_initialization_retains_each_event_in_order() -> TestResult {
    let (events, version, home) = probe(
        RemoteEventMode::Bounded { capacity: 2 },
        InitializeTraffic::Notifications(2),
        InitializeReply::Accept,
    )
    .await???;
    assert_eq!(events.len(), 2);
    assert_eq!(version.as_deref(), Some("1.0.0"));
    assert_eq!(home.as_deref(), Some("/fixture"));
    for (index, event) in events.iter().enumerate() {
        let AppServerEvent::ServerNotification(notification) = event else {
            return Err("expected server notification".into());
        };
        let ServerNotification::ThreadNameUpdated(notification) = notification.as_ref() else {
            return Err("expected thread name notification".into());
        };
        assert_eq!(
            notification.thread_name.as_deref(),
            Some(format!("event-{index}").as_str())
        );
    }
    Ok(())
}

#[tokio::test]
async fn legacy_unbounded_initialization_keeps_its_existing_behavior() -> TestResult {
    let (events, _, _) = probe(
        RemoteEventMode::Unbounded,
        InitializeTraffic::Notifications(3),
        InitializeReply::Accept,
    )
    .await???;
    assert_eq!(events.len(), 3);
    Ok(())
}

#[tokio::test]
async fn known_server_requests_share_the_same_initialization_capacity() -> TestResult {
    let result = probe(
        RemoteEventMode::Bounded { capacity: 1 },
        InitializeTraffic::Mixed,
        InitializeReply::Withhold,
    )
    .await?;
    assert!(matches!(result, Ok(Err(error)) if error.kind() == ErrorKind::OutOfMemory));
    let (events, _, _) = probe(
        RemoteEventMode::Bounded { capacity: 2 },
        InitializeTraffic::Mixed,
        InitializeReply::Accept,
    )
    .await???;
    assert!(matches!(
        events.as_slice(),
        [
            AppServerEvent::ServerNotification(_),
            AppServerEvent::ServerRequest(_)
        ]
    ));
    Ok(())
}

#[tokio::test]
async fn gated_constructor_forwards_capacity_and_drops_overflow_before_worker_start() -> TestResult
{
    let (client_io, server_io) = duplex(16 * 1024);
    let (client_io, gate) = GatedStream::new(client_io);
    let client = WebSocketStream::from_raw_socket(client_io, Role::Client, None).await;
    let mut server = WebSocketStream::from_raw_socket(server_io, Role::Server, None).await;
    let server_task = tokio::spawn(async move {
        let request = server.next().await.ok_or("initialize request missing")??;
        let request: serde_json::Value = serde_json::from_str(request.to_text()?)?;
        assert_eq!(request["method"], "initialize");
        for index in 0..2 {
            server.send(Message::Text(json!({
                "method": "thread/name/updated",
                "params": {"threadId": "bounded-init", "threadName": format!("event-{index}")}
            }).to_string().into())).await?;
        }
        // The server deliberately withholds the initialize response. Overflow
        // must close the owned stream before any worker or queue request exists.
        assert!(matches!(
            timeout(Duration::from_secs(1), server.next()).await?,
            None | Some(Err(_))
        ));
        Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
    });
    let result = timeout(
        Duration::from_secs(1),
        RemoteAppServerClient::connect_with_stream(
            /*channel_capacity*/ 8,
            RemoteEventMode::Bounded { capacity: 1 },
            "gated-memory-initialize-fixture".to_string(),
            client,
            Some(gate),
            InitializeParams {
                client_info: ClientInfo {
                    name: "gated-initialization-bound-test".into(),
                    version: "1".into(),
                    title: None,
                },
                capabilities: None,
            },
        ),
    )
    .await?;
    assert!(matches!(result, Err(error) if error.kind() == ErrorKind::OutOfMemory));
    server_task.await??;
    Ok(())
}
