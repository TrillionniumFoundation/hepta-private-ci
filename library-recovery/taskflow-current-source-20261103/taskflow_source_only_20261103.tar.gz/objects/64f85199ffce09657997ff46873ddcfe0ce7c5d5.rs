//! Request-local admission at a raw IPC stream's first positive byte write.
//! This wrapper must be below protocol buffering. It is not a TLS/plaintext gate.

use std::future::Future;
use std::io;
use std::pin::Pin;
use std::sync::Arc;
use std::sync::Mutex;
use std::task::Context;
use std::task::Poll;

use tokio::io::AsyncRead;
use tokio::io::AsyncWrite;
use tokio::io::ReadBuf;

/// The owner may retain synchronous host locks around exactly one raw write.
/// The closure and its reservations are consumed in this poll, never awaited.
pub(crate) type WritePermit =
    Box<dyn FnOnce(&mut dyn FnMut() -> Poll<io::Result<usize>>) -> Poll<io::Result<usize>> + Send>;
pub(crate) type WriteCheckFuture = Pin<Box<dyn Future<Output = io::Result<WritePermit>> + Send>>;
pub(crate) type FirstWriteCheck = Box<dyn FnMut() -> WriteCheckFuture + Send>;

/// Serializes caller cancellation with the first synchronous raw write. Merely
/// checking a response channel before polling a future leaves a cross-thread gap.
#[derive(Clone)]
pub(crate) struct RequestCancellation(Arc<Mutex<bool>>);

pub(crate) struct CancelRequestOnDrop(RequestCancellation);

impl RequestCancellation {
    pub(crate) fn new() -> Self {
        Self(Arc::new(Mutex::new(true)))
    }

    pub(crate) fn cancel_on_drop(&self) -> CancelRequestOnDrop {
        CancelRequestOnDrop(self.clone())
    }

    pub(crate) fn with_live_write(
        &self,
        write: &mut dyn FnMut() -> Poll<io::Result<usize>>,
    ) -> Poll<io::Result<usize>> {
        let live = match self.0.lock() {
            Ok(live) => live,
            Err(_) => return Poll::Ready(Err(poisoned())),
        };
        if !*live {
            return Poll::Ready(Err(io::Error::new(
                io::ErrorKind::Interrupted,
                "caller cancelled before the raw write",
            )));
        }
        let result = write();
        drop(live);
        result
    }
}

impl Drop for CancelRequestOnDrop {
    fn drop(&mut self) {
        if let Ok(mut live) = self.0.0.lock() {
            *live = false;
        }
    }
}

enum GateState {
    Idle,
    Armed {
        check: FirstWriteCheck,
        pending: Option<WriteCheckFuture>,
    },
    Contacted,
    Rejected,
}

#[derive(Clone)]
pub(crate) struct PhysicalWriteGate(Arc<Mutex<GateState>>);

pub(crate) struct GatedStream<S> {
    inner: S,
    gate: PhysicalWriteGate,
}

/// Clearing an armed request drops its pending owner check/reservation. The
/// caller must discard the protocol connection if any request bytes were queued.
pub(crate) struct ArmedWrite {
    gate: PhysicalWriteGate,
    finished: bool,
}

impl PhysicalWriteGate {
    pub(crate) fn arm(&self, check: FirstWriteCheck) -> io::Result<ArmedWrite> {
        let mut state = self.0.lock().map_err(|_| poisoned())?;
        if !matches!(*state, GateState::Idle) {
            return Err(io::Error::other("a physical write gate is already active"));
        }
        *state = GateState::Armed {
            check,
            pending: None,
        };
        Ok(ArmedWrite {
            gate: self.clone(),
            finished: false,
        })
    }
}

impl ArmedWrite {
    pub(crate) fn contacted(&self) -> io::Result<bool> {
        Ok(matches!(
            *self.gate.0.lock().map_err(|_| poisoned())?,
            GateState::Contacted
        ))
    }

    pub(crate) fn finish(mut self) -> io::Result<()> {
        let mut state = self.gate.0.lock().map_err(|_| poisoned())?;
        if !matches!(*state, GateState::Contacted) {
            return Err(io::Error::other(
                "request completed without a positive byte write",
            ));
        }
        *state = GateState::Idle;
        self.finished = true;
        Ok(())
    }
}

impl Drop for ArmedWrite {
    fn drop(&mut self) {
        if !self.finished
            && let Ok(mut state) = self.gate.0.lock()
        {
            // Even an accidental later close/flush cannot release a rejected
            // frame left in a protocol buffer. Only successful finish rearms.
            *state = GateState::Rejected;
        }
    }
}

impl<S> GatedStream<S> {
    pub(crate) fn new(inner: S) -> (Self, PhysicalWriteGate) {
        let gate = PhysicalWriteGate(Arc::new(Mutex::new(GateState::Idle)));
        (
            Self {
                inner,
                gate: gate.clone(),
            },
            gate,
        )
    }
}

impl<S: AsyncRead + Unpin> AsyncRead for GatedStream<S> {
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        Pin::new(&mut self.get_mut().inner).poll_read(cx, buf)
    }
}

impl<S: AsyncWrite + Unpin> AsyncWrite for GatedStream<S> {
    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &[u8],
    ) -> Poll<io::Result<usize>> {
        let this = self.get_mut();
        let mut state = match this.gate.0.lock() {
            Ok(state) => state,
            Err(_) => return Poll::Ready(Err(poisoned())),
        };
        if buf.is_empty() {
            return Poll::Ready(Ok(0));
        }
        let permit = match &mut *state {
            GateState::Idle | GateState::Contacted => None,
            GateState::Rejected => {
                return Poll::Ready(Err(io::Error::other(
                    "physical write admission was rejected",
                )));
            }
            GateState::Armed { check, pending } => {
                let future = pending.get_or_insert_with(check);
                match future.as_mut().poll(cx) {
                    Poll::Pending => return Poll::Pending,
                    Poll::Ready(Err(error)) => {
                        *state = GateState::Rejected;
                        return Poll::Ready(Err(error));
                    }
                    Poll::Ready(Ok(permit)) => {
                        *pending = None;
                        Some(permit)
                    }
                }
            }
        };
        // No await separates the completed owner check from this raw write.
        // On a zero-byte Pending, drop the permit and recheck next time. Holding
        // a SQLite writer across backpressure would starve unrelated owner work.
        let guarded = permit.is_some();
        let result = match permit {
            Some(permit) => {
                let mut attempted = false;
                let mut observed = None;
                let result = permit(&mut || {
                    if std::mem::replace(&mut attempted, true) {
                        return Poll::Ready(Err(io::Error::other(
                            "raw write may only be invoked once",
                        )));
                    }
                    let result = Pin::new(&mut this.inner).poll_write(cx, buf);
                    observed = Some(match &result {
                        Poll::Pending => Ok(None),
                        Poll::Ready(Ok(n)) => Ok(Some(*n)),
                        Poll::Ready(Err(error)) => Err(error.kind()),
                    });
                    result
                });
                let returned = match &result {
                    Poll::Pending => Ok(None),
                    Poll::Ready(Ok(n)) => Ok(Some(*n)),
                    Poll::Ready(Err(error)) => Err(error.kind()),
                };
                if observed.is_some_and(|observed| observed != returned)
                    || (observed.is_none() && returned.is_ok())
                {
                    Poll::Ready(Err(io::Error::other("owner changed the raw write outcome")))
                } else {
                    result
                }
            }
            None => Pin::new(&mut this.inner).poll_write(cx, buf),
        };
        if guarded {
            match &result {
                Poll::Ready(Ok(written)) if *written > 0 => *state = GateState::Contacted,
                Poll::Ready(Err(_)) => *state = GateState::Rejected,
                Poll::Pending | Poll::Ready(Ok(_)) => {}
            }
        }
        result
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.get_mut().inner).poll_flush(cx)
    }

    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.get_mut().inner).poll_shutdown(cx)
    }
}

fn poisoned() -> io::Error {
    io::Error::other("physical write gate is poisoned")
}

#[cfg(test)]
#[path = "physical_write_gate_tests.rs"]
mod tests;
