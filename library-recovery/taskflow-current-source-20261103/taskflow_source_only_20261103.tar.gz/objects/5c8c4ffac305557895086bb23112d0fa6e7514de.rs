/*
This module implements the remote app-server client transport.

It owns the remote connection lifecycle, including the initialize/initialized
handshake, JSON-RPC request/response routing, server-request resolution, and
notification streaming. Remote connections always carry WebSocket frames, over
either TCP WebSocket URLs or local Unix sockets. The rest of the crate uses the
same `AppServerEvent` surface for both in-process and remote transports, so
callers such as the TUI can switch between them without changing their
higher-level session logic.
*/

use std::collections::HashMap;
use std::collections::VecDeque;
use std::error::Error as StdError;
use std::fmt;
use std::future::Future;
use std::io::Error as IoError;
use std::io::ErrorKind;
use std::io::Result as IoResult;
use std::sync::Arc;
use std::sync::OnceLock;
use std::sync::atomic::AtomicU64;
use std::sync::atomic::Ordering;
use std::time::Duration;

use crate::AppServerEvent;
use crate::RequestResult;
use crate::SHUTDOWN_TIMEOUT;
use crate::TypedRequestError;
use crate::physical_write_gate::GatedStream;
use crate::physical_write_gate::PhysicalWriteGate;
use crate::physical_write_gate::RequestCancellation;
use crate::physical_write_gate::WritePermit;
use crate::remote_send_guard::BeforeSend;
use crate::remote_send_guard::GuardedWriteError;
use crate::remote_send_guard::write_first_request;
use crate::remote_send_guard::write_guarded_request;
use codex_app_server_protocol::ClientInfo;
use codex_app_server_protocol::ClientNotification;
use codex_app_server_protocol::ClientRequest;
use codex_app_server_protocol::InitializeCapabilities;
use codex_app_server_protocol::InitializeParams;
use codex_app_server_protocol::JSONRPCError;
use codex_app_server_protocol::JSONRPCErrorError;
use codex_app_server_protocol::JSONRPCMessage;
use codex_app_server_protocol::JSONRPCNotification;
use codex_app_server_protocol::JSONRPCRequest;
use codex_app_server_protocol::JSONRPCResponse;
use codex_app_server_protocol::RequestId;
use codex_app_server_protocol::Result as JsonRpcResult;
use codex_app_server_protocol::ServerNotification;
use codex_app_server_protocol::ServerRequest;
use codex_uds::UnixStream;
use codex_utils_absolute_path::AbsolutePathBuf;
use codex_utils_rustls_provider::ensure_rustls_crypto_provider;
use futures::SinkExt;
use futures::StreamExt;
use serde::de::DeserializeOwned;
use tokio::io::AsyncRead;
use tokio::io::AsyncWrite;
use tokio::net::TcpStream;
use tokio::sync::mpsc;
use tokio::sync::oneshot;
use tokio::time::timeout;
use tokio_tungstenite::MaybeTlsStream;
use tokio_tungstenite::WebSocketStream;
use tokio_tungstenite::client_async_with_config;
use tokio_tungstenite::connect_async_with_config;
use tokio_tungstenite::tungstenite::Error as TungsteniteError;
use tokio_tungstenite::tungstenite::Message;
use tokio_tungstenite::tungstenite::client::IntoClientRequest;
use tokio_tungstenite::tungstenite::http::HeaderValue;
use tokio_tungstenite::tungstenite::http::header::AUTHORIZATION;
use tokio_tungstenite::tungstenite::protocol::WebSocketConfig;
use tracing::warn;
use url::Url;

const CONNECT_TIMEOUT: Duration = Duration::from_secs(10);
const INITIALIZE_TIMEOUT: Duration = Duration::from_secs(10);
const REMOTE_APP_SERVER_MAX_WEBSOCKET_MESSAGE_SIZE: usize = 128 << 20;
const MAX_REMOTE_EVENT_CHANNEL_CAPACITY: usize = 65_536;
static NEXT_REMOTE_CONNECTION_ID: AtomicU64 = AtomicU64::new(1);
// Tungstenite still needs an HTTP request URI for the WebSocket handshake;
// the bytes travel over the Unix socket, not TCP.
const UDS_WEBSOCKET_HANDSHAKE_URL: &str = "ws://localhost/rpc";

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RemoteAppServerEndpoint {
    WebSocket {
        websocket_url: String,
        auth_token: Option<String>,
    },
    UnixSocket {
        socket_path: AbsolutePathBuf,
    },
}

#[derive(Debug, Clone)]
pub struct RemoteAppServerConnectArgs {
    pub endpoint: RemoteAppServerEndpoint,
    pub client_name: String,
    pub client_version: String,
    pub experimental_api: bool,
    pub mcp_server_openai_form_elicitation: bool,
    pub opt_out_notification_methods: Vec<String>,
    pub channel_capacity: usize,
}
impl RemoteAppServerConnectArgs {
    pub(crate) fn initialize_params(&self) -> InitializeParams {
        let capabilities = InitializeCapabilities {
            experimental_api: self.experimental_api,
            request_attestation: false,
            extensions: None,
            opt_out_notification_methods: if self.opt_out_notification_methods.is_empty() {
                None
            } else {
                Some(self.opt_out_notification_methods.clone())
            },
            mcp_server_openai_form_elicitation: self.mcp_server_openai_form_elicitation,
        };

        InitializeParams {
            client_info: ClientInfo {
                name: self.client_name.clone(),
                title: None,
                version: self.client_version.clone(),
            },
            capabilities: Some(capabilities),
        }
    }
}

pub(crate) fn websocket_url_supports_auth_token(url: &Url) -> bool {
    match (url.scheme(), url.host()) {
        ("wss", Some(_)) => true,
        ("ws", Some(url::Host::Domain(domain))) => domain.eq_ignore_ascii_case("localhost"),
        ("ws", Some(url::Host::Ipv4(addr))) => addr.is_loopback(),
        ("ws", Some(url::Host::Ipv6(addr))) => addr.is_loopback(),
        _ => false,
    }
}

enum RemoteClientCommand {
    Request {
        request: Box<JSONRPCRequest>,
        response_tx: oneshot::Sender<IoResult<RequestResult>>,
        before_send: Option<BeforeSend>,
    },
    Notify {
        notification: ClientNotification,
        response_tx: oneshot::Sender<IoResult<()>>,
    },
    ResolveServerRequest {
        request_id: RequestId,
        result: JsonRpcResult,
        response_tx: oneshot::Sender<IoResult<()>>,
    },
    RejectServerRequest {
        request_id: RequestId,
        error: JSONRPCErrorError,
        response_tx: oneshot::Sender<IoResult<()>>,
    },
    Shutdown {
        response_tx: oneshot::Sender<IoResult<()>>,
    },
}

/// Process-local proof that an event was read from an initialized remote
/// App Server connection. The private fields prevent arbitrary protocol DTOs
/// from being promoted into runtime.codex terminal evidence.
#[derive(Debug)]
pub struct RemoteAppServerObservedEvent {
    event: AppServerEvent,
    connection_id: u64,
    server_version: Option<String>,
    codex_home: Option<String>,
}

impl RemoteAppServerObservedEvent {
    pub fn event(&self) -> &AppServerEvent {
        &self.event
    }
    pub const fn connection_id(&self) -> u64 {
        self.connection_id
    }
    pub fn server_version(&self) -> Option<&str> {
        self.server_version.as_deref()
    }
    pub fn codex_home(&self) -> Option<&str> {
        self.codex_home.as_deref()
    }

    #[cfg(feature = "test-support")]
    #[doc(hidden)]
    pub fn from_test_event(
        event: AppServerEvent,
        connection_id: u64,
        server_version: Option<String>,
        codex_home: Option<String>,
    ) -> Self {
        Self {
            event,
            connection_id,
            server_version,
            codex_home,
        }
    }
}

/// Process-local proof that a successful typed response was read from one
/// initialized remote App Server connection. Private provenance fields prevent
/// an arbitrary protocol DTO from being promoted into reconciliation evidence.
#[derive(Debug)]
pub struct RemoteAppServerObservedResponse<T> {
    response: T,
    method: String,
    request_id: RequestId,
    connection_id: u64,
    server_version: Option<String>,
    codex_home: Option<String>,
}

impl<T> RemoteAppServerObservedResponse<T> {
    pub fn response(&self) -> &T {
        &self.response
    }

    pub fn into_response(self) -> T {
        self.response
    }

    pub fn method(&self) -> &str {
        &self.method
    }

    pub fn request_id(&self) -> &RequestId {
        &self.request_id
    }

    pub const fn connection_id(&self) -> u64 {
        self.connection_id
    }

    pub fn server_version(&self) -> Option<&str> {
        self.server_version.as_deref()
    }

    pub fn codex_home(&self) -> Option<&str> {
        self.codex_home.as_deref()
    }

    #[cfg(feature = "test-support")]
    #[doc(hidden)]
    pub fn from_test_response(
        response: T,
        method: String,
        request_id: RequestId,
        connection_id: u64,
        server_version: Option<String>,
        codex_home: Option<String>,
    ) -> Self {
        Self {
            response,
            method,
            request_id,
            connection_id,
            server_version,
            codex_home,
        }
    }
}

/// Process-local proof that an explicit JSON-RPC error was returned by the
/// initialized remote request path.
#[derive(Debug)]
pub struct RemoteAppServerObservedServerError {
    method: String,
    request_id: RequestId,
    error: JSONRPCErrorError,
    connection_id: u64,
    server_version: Option<String>,
    codex_home: Option<String>,
}

impl RemoteAppServerObservedServerError {
    pub fn method(&self) -> &str {
        &self.method
    }
    pub fn request_id(&self) -> &RequestId {
        &self.request_id
    }
    pub fn error(&self) -> &JSONRPCErrorError {
        &self.error
    }
    pub const fn connection_id(&self) -> u64 {
        self.connection_id
    }
    pub fn server_version(&self) -> Option<&str> {
        self.server_version.as_deref()
    }
    pub fn codex_home(&self) -> Option<&str> {
        self.codex_home.as_deref()
    }

    #[cfg(feature = "test-support")]
    #[doc(hidden)]
    pub fn from_test_error(
        method: String,
        request_id: RequestId,
        error: JSONRPCErrorError,
        connection_id: u64,
        server_version: Option<String>,
        codex_home: Option<String>,
    ) -> Self {
        Self {
            method,
            request_id,
            error,
            connection_id,
            server_version,
            codex_home,
        }
    }
}

#[derive(Debug)]
pub enum RemoteObservedTypedRequestError {
    Transport {
        method: String,
        source: IoError,
    },
    Server {
        observed: RemoteAppServerObservedServerError,
    },
    Deserialize {
        method: String,
        source: serde_json::Error,
    },
}

impl fmt::Display for RemoteObservedTypedRequestError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Transport { method, source } => write!(f, "{method} transport error: {source}"),
            Self::Server { observed } => write!(
                f,
                "{} failed: {} (code {})",
                observed.method, observed.error.message, observed.error.code
            ),
            Self::Deserialize { method, source } => {
                write!(f, "{method} response decode error: {source}")
            }
        }
    }
}

impl StdError for RemoteObservedTypedRequestError {
    fn source(&self) -> Option<&(dyn StdError + 'static)> {
        match self {
            Self::Transport { source, .. } => Some(source),
            Self::Server { .. } => None,
            Self::Deserialize { source, .. } => Some(source),
        }
    }
}

pub struct RemoteAppServerClient {
    command_tx: mpsc::Sender<RemoteClientCommand>,
    event_rx: RemoteEventReceiver,
    pending_events: VecDeque<AppServerEvent>,
    server_version: Option<String>,
    codex_home: Option<String>,
    connection_id: u64,
    worker_handle: tokio::task::JoinHandle<()>,
}

#[derive(Clone, Copy)]
enum RemoteEventMode {
    Unbounded,
    Bounded { capacity: usize },
}

enum RemoteEventSender {
    Unbounded(mpsc::UnboundedSender<AppServerEvent>),
    Bounded {
        sender: mpsc::Sender<AppServerEvent>,
        terminal_reason: Arc<OnceLock<String>>,
    },
}

enum RemoteEventReceiver {
    Unbounded(mpsc::UnboundedReceiver<AppServerEvent>),
    Bounded {
        receiver: mpsc::Receiver<AppServerEvent>,
        terminal_reason: Arc<OnceLock<String>>,
        terminal_delivered: bool,
    },
}

impl RemoteEventReceiver {
    async fn recv(&mut self) -> Option<AppServerEvent> {
        match self {
            Self::Unbounded(receiver) => receiver.recv().await,
            Self::Bounded {
                receiver,
                terminal_reason,
                terminal_delivered,
            } => match receiver.recv().await {
                Some(event) => Some(event),
                None if !*terminal_delivered => {
                    *terminal_delivered = true;
                    terminal_reason
                        .get()
                        .cloned()
                        .map(|message| AppServerEvent::Disconnected { message })
                }
                None => None,
            },
        }
    }
}

#[derive(Clone)]
pub struct RemoteAppServerRequestHandle {
    command_tx: mpsc::Sender<RemoteClientCommand>,
}

impl RemoteAppServerRequestHandle {
    /// Resolves one server-initiated request received on this connection.
    ///
    /// Keeping this on the cloneable request handle lets a bounded event
    /// projector and an owner-local control plane share one App Server
    /// connection without sharing ownership of the event receiver.
    pub async fn resolve_server_request(
        &self,
        request_id: RequestId,
        result: JsonRpcResult,
    ) -> IoResult<()> {
        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(RemoteClientCommand::ResolveServerRequest {
                request_id,
                result,
                response_tx,
            })
            .await
            .map_err(|_| {
                IoError::new(
                    ErrorKind::BrokenPipe,
                    "remote app-server worker channel is closed",
                )
            })?;
        response_rx.await.map_err(|_| {
            IoError::new(
                ErrorKind::BrokenPipe,
                "remote app-server resolve channel is closed",
            )
        })?
    }

    /// Rejects one unsupported server-initiated request on this connection.
    pub async fn reject_server_request(
        &self,
        request_id: RequestId,
        error: JSONRPCErrorError,
    ) -> IoResult<()> {
        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(RemoteClientCommand::RejectServerRequest {
                request_id,
                error,
                response_tx,
            })
            .await
            .map_err(|_| {
                IoError::new(
                    ErrorKind::BrokenPipe,
                    "remote app-server worker channel is closed",
                )
            })?;
        response_rx.await.map_err(|_| {
            IoError::new(
                ErrorKind::BrokenPipe,
                "remote app-server reject channel is closed",
            )
        })?
    }
}

impl RemoteAppServerClient {
    pub async fn connect(args: RemoteAppServerConnectArgs) -> IoResult<Self> {
        Self::connect_with_event_mode(args, RemoteEventMode::Unbounded).await
    }

    /// Connects with a fail-fast bounded consumer event queue.
    ///
    /// The existing [`Self::connect`] behavior remains lossless and unbounded for
    /// compatibility. Long-running bridges should use this entrypoint: if the
    /// caller stops draining notifications, the remote connection closes instead
    /// of retaining unbounded transcript data. After already queued events are
    /// drained, [`Self::next_event`] yields one `Disconnected` event that tells the
    /// caller to reconcile from the durable app-server state.
    pub async fn connect_with_bounded_events(
        args: RemoteAppServerConnectArgs,
        event_channel_capacity: usize,
    ) -> IoResult<Self> {
        if !(1..=MAX_REMOTE_EVENT_CHANNEL_CAPACITY).contains(&event_channel_capacity) {
            return Err(IoError::new(
                ErrorKind::InvalidInput,
                format!(
                    "remote app-server event channel capacity must be between 1 and {MAX_REMOTE_EVENT_CHANNEL_CAPACITY}"
                ),
            ));
        }
        Self::connect_with_event_mode(
            args,
            RemoteEventMode::Bounded {
                capacity: event_channel_capacity,
            },
        )
        .await
    }

    async fn connect_with_event_mode(
        args: RemoteAppServerConnectArgs,
        event_mode: RemoteEventMode,
    ) -> IoResult<Self> {
        let channel_capacity = args.channel_capacity.max(1);
        let initialize_params = args.initialize_params();
        match args.endpoint {
            RemoteAppServerEndpoint::WebSocket {
                websocket_url,
                auth_token,
            } => {
                let (endpoint, stream) =
                    connect_websocket_endpoint(websocket_url, auth_token).await?;
                Self::connect_with_stream(
                    channel_capacity,
                    event_mode,
                    endpoint,
                    stream,
                    /*physical_write_gate*/ None,
                    initialize_params,
                )
                .await
            }
            RemoteAppServerEndpoint::UnixSocket { socket_path } => {
                let (endpoint, stream, gate) = connect_unix_socket_endpoint(socket_path).await?;
                Self::connect_with_stream(
                    channel_capacity,
                    event_mode,
                    endpoint,
                    stream,
                    Some(gate),
                    initialize_params,
                )
                .await
            }
        }
    }

    pub fn server_version(&self) -> Option<&str> {
        self.server_version.as_deref()
    }

    pub fn codex_home(&self) -> Option<&str> {
        self.codex_home.as_deref()
    }

    pub const fn connection_id(&self) -> u64 {
        self.connection_id
    }

    async fn connect_with_stream<S>(
        channel_capacity: usize,
        event_mode: RemoteEventMode,
        endpoint: String,
        stream: WebSocketStream<S>,
        physical_write_gate: Option<PhysicalWriteGate>,
        initialize_params: InitializeParams,
    ) -> IoResult<Self>
    where
        S: AsyncRead + AsyncWrite + Unpin + Send + 'static,
    {
        let mut stream = stream;
        let (pending_events, server_version, codex_home) = initialize_remote_connection(
            &mut stream,
            &endpoint,
            initialize_params,
            INITIALIZE_TIMEOUT,
        )
        .await?;

        if let RemoteEventMode::Bounded { capacity } = event_mode
            && pending_events.len() > capacity
        {
            return Err(IoError::new(
                ErrorKind::OutOfMemory,
                format!(
                    "remote app server at `{endpoint}` emitted more initialization events than the bounded event channel can retain; reconnect and resync"
                ),
            ));
        }

        let (command_tx, mut command_rx) = mpsc::channel::<RemoteClientCommand>(channel_capacity);
        let (event_tx, event_rx) = match event_mode {
            RemoteEventMode::Unbounded => {
                let (sender, receiver) = mpsc::unbounded_channel::<AppServerEvent>();
                (
                    RemoteEventSender::Unbounded(sender),
                    RemoteEventReceiver::Unbounded(receiver),
                )
            }
            RemoteEventMode::Bounded { capacity } => {
                let (sender, receiver) = mpsc::channel::<AppServerEvent>(capacity);
                let terminal_reason = Arc::new(OnceLock::new());
                (
                    RemoteEventSender::Bounded {
                        sender,
                        terminal_reason: Arc::clone(&terminal_reason),
                    },
                    RemoteEventReceiver::Bounded {
                        receiver,
                        terminal_reason,
                        terminal_delivered: false,
                    },
                )
            }
        };
        let worker_handle = tokio::spawn(async move {
            let mut pending_requests =
                HashMap::<RequestId, oneshot::Sender<IoResult<RequestResult>>>::new();
            let mut worker_exit_error: Option<(ErrorKind, String)> = None;
            loop {
                tokio::select! {
                    command = command_rx.recv() => {
                        let Some(command) = command else {
                            let _ = stream.close(None).await;
                            break;
                        };
                        match command {
                            RemoteClientCommand::Request { request, mut response_tx, before_send } => {
                                let request_id = request.id.clone();
                                if pending_requests.contains_key(&request_id) {
                                    let _ = response_tx.send(Err(IoError::new(
                                        ErrorKind::InvalidInput,
                                        format!("duplicate remote app-server request id `{request_id}`"),
                                    )));
                                    continue;
                                }
                                let result = match before_send {
                                    Some(before_send) => match match before_send {
                                        BeforeSend::Snapshot(check) => write_guarded_request(
                                            &mut stream, JSONRPCMessage::Request(*request), check,
                                            &mut response_tx,
                                        ).await,
                                        BeforeSend::Physical(check) => write_first_request(
                                            &mut stream, JSONRPCMessage::Request(*request), check,
                                            physical_write_gate.as_ref(), &mut response_tx,
                                        ).await,
                                    } {
                                        Ok(()) => Ok(()),
                                        Err(GuardedWriteError::BeforeSend(error)) => {
                                            let _ = response_tx.send(Err(error));
                                            continue;
                                        }
                                        Err(GuardedWriteError::Transport(error)) => Err(error),
                                    },
                                    None => write_jsonrpc_message(
                                        &mut stream, JSONRPCMessage::Request(*request), &endpoint,
                                    ).await,
                                };
                                pending_requests.insert(request_id.clone(), response_tx);
                                if let Err(err) = result {
                                    let err_message = err.to_string();
                                    let message = format!(
                                        "remote app server at `{endpoint}` write failed: {err_message}"
                                    );
                                    if let Some(response_tx) = pending_requests.remove(&request_id) {
                                        let _ = response_tx.send(Err(err));
                                    }
                                    let _ = deliver_event(
                                        &event_tx,
                                        AppServerEvent::Disconnected {
                                            message: message.clone(),
                                        },
                                    );
                                    worker_exit_error = Some((ErrorKind::BrokenPipe, message));
                                    break;
                                }
                            }
                            RemoteClientCommand::Notify { notification, response_tx } => {
                                let result = write_jsonrpc_message(
                                    &mut stream,
                                    JSONRPCMessage::Notification(
                                        jsonrpc_notification_from_client_notification(notification),
                                    ),
                                    &endpoint,
                                )
                                .await;
                                let _ = response_tx.send(result);
                            }
                            RemoteClientCommand::ResolveServerRequest {
                                request_id,
                                result,
                                response_tx,
                            } => {
                                let result = write_jsonrpc_message(
                                    &mut stream,
                                    JSONRPCMessage::Response(JSONRPCResponse {
                                        id: request_id,
                                        result,
                                    }),
                                    &endpoint,
                                )
                                .await;
                                let _ = response_tx.send(result);
                            }
                            RemoteClientCommand::RejectServerRequest {
                                request_id,
                                error,
                                response_tx,
                            } => {
                                let result = write_jsonrpc_message(
                                    &mut stream,
                                    JSONRPCMessage::Error(JSONRPCError {
                                        error,
                                        id: request_id,
                                    }),
                                    &endpoint,
                                )
                                .await;
                                let _ = response_tx.send(result);
                            }
                            RemoteClientCommand::Shutdown { response_tx } => {
                                let close_result = stream.close(None).await.or_else(|err| {
                                    if websocket_close_error_is_already_closed(&err) {
                                        Ok(())
                                    } else {
                                        Err(IoError::other(format!(
                                            "failed to close websocket app server `{endpoint}`: {err}"
                                        )))
                                    }
                                });
                                let _ = response_tx.send(close_result);
                                break;
                            }
                        }
                    }
                    message = stream.next() => {
                        match message {
                            Some(Ok(Message::Text(text))) => {
                                match serde_json::from_str::<JSONRPCMessage>(&text) {
                                    Ok(JSONRPCMessage::Response(response)) => {
                                        if let Some(response_tx) = pending_requests.remove(&response.id) {
                                            let _ = response_tx.send(Ok(Ok(response.result)));
                                        }
                                    }
                                    Ok(JSONRPCMessage::Error(error)) => {
                                        if let Some(response_tx) = pending_requests.remove(&error.id) {
                                            let _ = response_tx.send(Ok(Err(error.error)));
                                        }
                                    }
                                    Ok(JSONRPCMessage::Notification(notification)) => {
                                        if let Some(event) =
                                            app_server_event_from_notification(notification)
                                            && let Err(err) = deliver_event(
                                                &event_tx,
                                                event,
                                            )
                                            {
                                                warn!(%err, "failed to deliver remote app-server event");
                                                break;
                                            }
                                    }
                                    Ok(JSONRPCMessage::Request(request)) => {
                                        let request_id = request.id.clone();
                                        let method = request.method.clone();
                                        match ServerRequest::try_from(request) {
                                            Ok(request) => {
                                                if let Err(err) = deliver_event(
                                                    &event_tx,
                                                    AppServerEvent::ServerRequest(Box::new(request)),
                                                )
                                                {
                                                    warn!(%err, "failed to deliver remote app-server server request");
                                                    break;
                                                }
                                            }
                                            Err(err) => {
                                                warn!(%err, method, "rejecting unknown remote app-server request");
                                                if let Err(reject_err) = write_jsonrpc_message(
                                                    &mut stream,
                                                    JSONRPCMessage::Error(JSONRPCError {
                                                        error: JSONRPCErrorError {
                                                            code: -32601,
                                                            message: format!(
                                                                "unsupported remote app-server request `{method}`"
                                                            ),
                                                            data: None,
                                                        },
                                                        id: request_id,
                                                    }),
                                                    &endpoint,
                                                )
                                                .await
                                                {
                                                    let err_message = reject_err.to_string();
                                                    let message = format!(
                                                        "remote app server at `{endpoint}` write failed: {err_message}"
                                                    );
                                                    let _ = deliver_event(
                                                        &event_tx,
                                                        AppServerEvent::Disconnected {
                                                            message: message.clone(),
                                                        },
                                                    );
                                                    worker_exit_error =
                                                        Some((ErrorKind::BrokenPipe, message));
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    Err(err) => {
                                        let message = format!(
                                            "remote app server at `{endpoint}` sent invalid JSON-RPC: {err}"
                                        );
                                        let _ = deliver_event(
                                            &event_tx,
                                            AppServerEvent::Disconnected {
                                                message: message.clone(),
                                            },
                                        );
                                        worker_exit_error =
                                            Some((ErrorKind::InvalidData, message));
                                        break;
                                    }
                                }
                            }
                            Some(Ok(Message::Close(frame))) => {
                                let reason = frame
                                    .as_ref()
                                    .map(|frame| frame.reason.to_string())
                                    .filter(|reason| !reason.is_empty())
                                    .unwrap_or_else(|| "connection closed".to_string());
                                let message = format!(
                                    "remote app server at `{endpoint}` disconnected: {reason}"
                                );
                                let _ = deliver_event(
                                    &event_tx,
                                    AppServerEvent::Disconnected {
                                        message: message.clone(),
                                    },
                                );
                                worker_exit_error = Some((
                                    ErrorKind::ConnectionAborted,
                                    message,
                                ));
                                break;
                            }
                            Some(Ok(Message::Binary(_)))
                            | Some(Ok(Message::Ping(_)))
                            | Some(Ok(Message::Pong(_)))
                            | Some(Ok(Message::Frame(_))) => {}
                            Some(Err(err)) => {
                                let message = format!(
                                    "remote app server at `{endpoint}` transport failed: {err}"
                                );
                                let _ = deliver_event(
                                    &event_tx,
                                    AppServerEvent::Disconnected {
                                        message: message.clone(),
                                    },
                                );
                                worker_exit_error = Some((ErrorKind::InvalidData, message));
                                break;
                            }
                            None => {
                                let message = format!(
                                    "remote app server at `{endpoint}` closed the connection"
                                );
                                let _ = deliver_event(
                                    &event_tx,
                                    AppServerEvent::Disconnected {
                                        message: message.clone(),
                                    },
                                );
                                worker_exit_error = Some((ErrorKind::UnexpectedEof, message));
                                break;
                            }
                        }
                    }
                }
            }

            let (err_kind, err_message) = worker_exit_error.unwrap_or_else(|| {
                (
                    ErrorKind::BrokenPipe,
                    "remote app-server worker channel is closed".to_string(),
                )
            });
            for (_, response_tx) in pending_requests {
                let _ = response_tx.send(Err(IoError::new(err_kind, err_message.clone())));
            }
        });

        let connection_id = NEXT_REMOTE_CONNECTION_ID.fetch_add(1, Ordering::Relaxed);
        let connection_id = if connection_id == 0 {
            NEXT_REMOTE_CONNECTION_ID.store(2, Ordering::Relaxed);
            1
        } else {
            connection_id
        };
        Ok(Self {
            command_tx,
            event_rx,
            pending_events: pending_events.into(),
            server_version,
            codex_home,
            connection_id,
            worker_handle,
        })
    }

    pub fn request_handle(&self) -> RemoteAppServerRequestHandle {
        RemoteAppServerRequestHandle {
            command_tx: self.command_tx.clone(),
        }
    }

    pub async fn request(&self, request: ClientRequest) -> IoResult<RequestResult> {
        self.request_handle().request(request).await
    }

    pub async fn request_typed<T>(&self, request: ClientRequest) -> Result<T, TypedRequestError>
    where
        T: DeserializeOwned,
    {
        let method = request.method_name();
        let response =
            self.request(request)
                .await
                .map_err(|source| TypedRequestError::Transport {
                    method: method.to_string(),
                    source,
                })?;
        let result = response.map_err(|source| TypedRequestError::Server {
            method: method.to_string(),
            source,
        })?;
        serde_json::from_value(result).map_err(|source| TypedRequestError::Deserialize {
            method: method.to_string(),
            source,
        })
    }

    pub async fn request_typed_observed<T>(
        &self,
        request: ClientRequest,
    ) -> Result<T, RemoteObservedTypedRequestError>
    where
        T: DeserializeOwned,
    {
        self.request_typed_observed_response(request)
            .await
            .map(RemoteAppServerObservedResponse::into_response)
    }

    pub async fn request_typed_observed_response<T>(
        &self,
        request: ClientRequest,
    ) -> Result<RemoteAppServerObservedResponse<T>, RemoteObservedTypedRequestError>
    where
        T: DeserializeOwned,
    {
        let method = request.method_name().to_string();
        let request_id = request.id().clone();
        let response = self.request(request).await.map_err(|source| {
            RemoteObservedTypedRequestError::Transport {
                method: method.clone(),
                source,
            }
        })?;
        let result = response.map_err(|error| RemoteObservedTypedRequestError::Server {
            observed: RemoteAppServerObservedServerError {
                method: method.clone(),
                request_id: request_id.clone(),
                error,
                connection_id: self.connection_id,
                server_version: self.server_version.clone(),
                codex_home: self.codex_home.clone(),
            },
        })?;
        let response = serde_json::from_value(result).map_err(|source| {
            RemoteObservedTypedRequestError::Deserialize {
                method: method.clone(),
                source,
            }
        })?;
        Ok(RemoteAppServerObservedResponse {
            response,
            method,
            request_id,
            connection_id: self.connection_id,
            server_version: self.server_version.clone(),
            codex_home: self.codex_home.clone(),
        })
    }

    pub async fn notify(&self, notification: ClientNotification) -> IoResult<()> {
        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(RemoteClientCommand::Notify {
                notification,
                response_tx,
            })
            .await
            .map_err(|_| {
                IoError::new(
                    ErrorKind::BrokenPipe,
                    "remote app-server worker channel is closed",
                )
            })?;
        response_rx.await.map_err(|_| {
            IoError::new(
                ErrorKind::BrokenPipe,
                "remote app-server notify channel is closed",
            )
        })?
    }

    pub async fn resolve_server_request(
        &self,
        request_id: RequestId,
        result: JsonRpcResult,
    ) -> IoResult<()> {
        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(RemoteClientCommand::ResolveServerRequest {
                request_id,
                result,
                response_tx,
            })
            .await
            .map_err(|_| {
                IoError::new(
                    ErrorKind::BrokenPipe,
                    "remote app-server worker channel is closed",
                )
            })?;
        response_rx.await.map_err(|_| {
            IoError::new(
                ErrorKind::BrokenPipe,
                "remote app-server resolve channel is closed",
            )
        })?
    }

    pub async fn reject_server_request(
        &self,
        request_id: RequestId,
        error: JSONRPCErrorError,
    ) -> IoResult<()> {
        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(RemoteClientCommand::RejectServerRequest {
                request_id,
                error,
                response_tx,
            })
            .await
            .map_err(|_| {
                IoError::new(
                    ErrorKind::BrokenPipe,
                    "remote app-server worker channel is closed",
                )
            })?;
        response_rx.await.map_err(|_| {
            IoError::new(
                ErrorKind::BrokenPipe,
                "remote app-server reject channel is closed",
            )
        })?
    }

    pub async fn next_event(&mut self) -> Option<AppServerEvent> {
        if let Some(event) = self.pending_events.pop_front() {
            return Some(event);
        }
        self.event_rx.recv().await
    }

    pub async fn next_observed_event(&mut self) -> Option<RemoteAppServerObservedEvent> {
        let event = self.next_event().await?;
        Some(RemoteAppServerObservedEvent {
            event,
            connection_id: self.connection_id,
            server_version: self.server_version.clone(),
            codex_home: self.codex_home.clone(),
        })
    }

    pub async fn shutdown(self) -> IoResult<()> {
        let Self {
            command_tx,
            event_rx,
            pending_events: _pending_events,
            server_version: _server_version,
            codex_home: _codex_home,
            connection_id: _connection_id,
            worker_handle,
        } = self;
        let mut worker_handle = worker_handle;
        drop(event_rx);
        let (response_tx, response_rx) = oneshot::channel();
        if command_tx
            .send(RemoteClientCommand::Shutdown { response_tx })
            .await
            .is_ok()
            && let Ok(Ok(close_result)) = timeout(SHUTDOWN_TIMEOUT, response_rx).await
        {
            close_result?;
        }

        if let Err(_elapsed) = timeout(SHUTDOWN_TIMEOUT, &mut worker_handle).await {
            worker_handle.abort();
            let _ = worker_handle.await;
        }
        Ok(())
    }
}

impl RemoteAppServerRequestHandle {
    pub async fn request(&self, request: ClientRequest) -> IoResult<RequestResult> {
        self.request_json_rpc(jsonrpc_request_from_client_request(request))
            .await
    }

    pub async fn request_json_rpc(&self, request: JSONRPCRequest) -> IoResult<RequestResult> {
        self.request_json_rpc_with_before_send(request, /*before_send*/ None)
            .await
    }

    async fn request_json_rpc_with_before_send(
        &self,
        request: JSONRPCRequest,
        before_send: Option<BeforeSend>,
    ) -> IoResult<RequestResult> {
        let (response_tx, response_rx) = oneshot::channel();
        self.command_tx
            .send(RemoteClientCommand::Request {
                request: Box::new(request),
                response_tx,
                before_send,
            })
            .await
            .map_err(|_| {
                IoError::new(
                    ErrorKind::BrokenPipe,
                    "remote app-server worker channel is closed",
                )
            })?;
        response_rx.await.map_err(|_| {
            IoError::new(
                ErrorKind::BrokenPipe,
                "remote app-server request channel is closed",
            )
        })?
    }

    /// Execute a snapshot owner check after command-queue and WebSocket
    /// readiness waits. Rejection or cancellation observed before buffering
    /// writes no request frame. This does not retain admission through the
    /// later physical flush; use `request_typed_at_first_write` for that cut.
    /// The check grants no identity or authority by itself.
    pub async fn request_typed_before_send<T>(
        &self,
        request: ClientRequest,
        before_send: impl Future<Output = IoResult<()>> + Send + 'static,
    ) -> Result<T, TypedRequestError>
    where
        T: DeserializeOwned,
    {
        self.request_typed_with_before_send(request, BeforeSend::Snapshot(Box::pin(before_send)))
            .await
    }

    /// Recheck the same owner identity at each zero-byte raw IPC write attempt.
    /// The returned reservation is held only through the synchronous byte-write
    /// poll. Positive/partial contact is never retried under a new identity.
    /// The reservation callback may reject without calling the supplied writer;
    /// otherwise it must invoke it once and return its unchanged outcome. It
    /// must not await, block on network I/O, or reenter this transport. Its Drop
    /// releases all owner reservations after the poll. Connection setup and
    /// initialization occur before this request's admission boundary.
    /// Unsupported WebSocket/TLS connections reject before buffering this request.
    pub async fn request_typed_at_first_write<T, G, F>(
        &self,
        request: ClientRequest,
        mut check: impl FnMut() -> F + Send + 'static,
    ) -> Result<T, TypedRequestError>
    where
        T: DeserializeOwned,
        G: FnOnce(
                &mut dyn FnMut() -> std::task::Poll<IoResult<usize>>,
            ) -> std::task::Poll<IoResult<usize>>
            + Send
            + 'static,
        F: Future<Output = IoResult<G>> + Send + 'static,
    {
        let cancellation = RequestCancellation::new();
        let _cancel_on_drop = cancellation.cancel_on_drop();
        self.request_typed_with_before_send(
            request,
            BeforeSend::Physical(Box::new(move || {
                let future = check();
                let cancellation = cancellation.clone();
                Box::pin(async move {
                    future.await.map(move |guard| {
                        Box::new(
                            move |write: &mut dyn FnMut() -> std::task::Poll<IoResult<usize>>| {
                                // Hold the request's liveness fence only at the raw
                                // poll, after the owner has acquired its own locks.
                                guard(&mut || cancellation.with_live_write(write))
                            },
                        ) as WritePermit
                    })
                })
            })),
        )
        .await
    }

    async fn request_typed_with_before_send<T>(
        &self,
        request: ClientRequest,
        before_send: BeforeSend,
    ) -> Result<T, TypedRequestError>
    where
        T: DeserializeOwned,
    {
        let method = request.method_name();
        let response = self
            .request_json_rpc_with_before_send(
                jsonrpc_request_from_client_request(request),
                Some(before_send),
            )
            .await
            .map_err(|source| TypedRequestError::Transport {
                method: method.to_string(),
                source,
            })?;
        let result = response.map_err(|source| TypedRequestError::Server {
            method: method.to_string(),
            source,
        })?;
        serde_json::from_value(result).map_err(|source| TypedRequestError::Deserialize {
            method: method.to_string(),
            source,
        })
    }

    pub async fn request_typed<T>(&self, request: ClientRequest) -> Result<T, TypedRequestError>
    where
        T: DeserializeOwned,
    {
        let method = request.method_name();
        let response =
            self.request(request)
                .await
                .map_err(|source| TypedRequestError::Transport {
                    method: method.to_string(),
                    source,
                })?;
        let result = response.map_err(|source| TypedRequestError::Server {
            method: method.to_string(),
            source,
        })?;
        serde_json::from_value(result).map_err(|source| TypedRequestError::Deserialize {
            method: method.to_string(),
            source,
        })
    }
}

async fn connect_websocket_endpoint(
    websocket_url: String,
    auth_token: Option<String>,
) -> IoResult<(String, WebSocketStream<MaybeTlsStream<TcpStream>>)> {
    let url = Url::parse(&websocket_url).map_err(|err| {
        IoError::new(
            ErrorKind::InvalidInput,
            format!("invalid websocket URL `{websocket_url}`: {err}"),
        )
    })?;
    if auth_token.is_some() && !websocket_url_supports_auth_token(&url) {
        return Err(IoError::new(
            ErrorKind::InvalidInput,
            format!(
                "remote auth tokens require `wss://` or loopback `ws://` URLs; got `{websocket_url}`"
            ),
        ));
    }

    let mut request = url.as_str().into_client_request().map_err(|err| {
        IoError::new(
            ErrorKind::InvalidInput,
            format!("invalid websocket URL `{websocket_url}`: {err}"),
        )
    })?;
    if let Some(auth_token) = auth_token.as_deref() {
        let header_value =
            HeaderValue::from_str(&format!("Bearer {auth_token}")).map_err(|err| {
                IoError::new(
                    ErrorKind::InvalidInput,
                    format!("invalid remote authorization header value: {err}"),
                )
            })?;
        request.headers_mut().insert(AUTHORIZATION, header_value);
    }

    ensure_rustls_crypto_provider();
    let websocket_config = remote_websocket_config();
    let stream = timeout(
        CONNECT_TIMEOUT,
        connect_async_with_config(
            request,
            Some(websocket_config),
            /*disable_nagle*/ false,
        ),
    )
    .await
    .map_err(|_| {
        IoError::new(
            ErrorKind::TimedOut,
            format!("timed out connecting to remote app server at `{websocket_url}`"),
        )
    })?
    .map(|(stream, _response)| stream)
    .map_err(|err| {
        IoError::other(format!(
            "failed to connect to remote app server at `{websocket_url}`: {err}"
        ))
    })?;

    Ok((websocket_url, stream))
}

async fn connect_unix_socket_endpoint(
    socket_path: AbsolutePathBuf,
) -> IoResult<(
    String,
    WebSocketStream<GatedStream<UnixStream>>,
    PhysicalWriteGate,
)> {
    let endpoint = format!("unix://{}", socket_path.display());
    let request = UDS_WEBSOCKET_HANDSHAKE_URL
        .into_client_request()
        .map_err(|err| {
            IoError::new(
                ErrorKind::InvalidInput,
                format!("invalid UDS websocket handshake URL: {err}"),
            )
        })?;
    let stream = timeout(CONNECT_TIMEOUT, UnixStream::connect(socket_path.as_path()))
        .await
        .map_err(|_| {
            IoError::new(
                ErrorKind::TimedOut,
                format!("timed out connecting to remote app server at `{endpoint}`"),
            )
        })?
        .map_err(|err| {
            IoError::other(format!(
                "failed to connect to remote app server at `{endpoint}`: {err}"
            ))
        })?;
    let (stream, gate) = GatedStream::new(stream);
    let websocket_config = remote_websocket_config();
    let stream = timeout(
        CONNECT_TIMEOUT,
        client_async_with_config(request, stream, Some(websocket_config)),
    )
    .await
    .map_err(|_| {
        IoError::new(
            ErrorKind::TimedOut,
            format!("timed out upgrading remote app server at `{endpoint}`"),
        )
    })?
    .map(|(stream, _response)| stream)
    .map_err(|err| {
        IoError::other(format!(
            "failed to upgrade remote app server at `{endpoint}`: {err}"
        ))
    })?;

    Ok((endpoint, stream, gate))
}

fn remote_websocket_config() -> WebSocketConfig {
    WebSocketConfig::default()
        .max_frame_size(Some(REMOTE_APP_SERVER_MAX_WEBSOCKET_MESSAGE_SIZE))
        .max_message_size(Some(REMOTE_APP_SERVER_MAX_WEBSOCKET_MESSAGE_SIZE))
}

async fn initialize_remote_connection<S>(
    stream: &mut WebSocketStream<S>,
    endpoint: &str,
    params: InitializeParams,
    initialize_timeout: Duration,
) -> IoResult<(Vec<AppServerEvent>, Option<String>, Option<String>)>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    let initialize_request_id = RequestId::String("initialize".to_string());
    let mut pending_events = Vec::new();
    let mut server_version = None;
    let mut codex_home = None;
    write_jsonrpc_message(
        stream,
        JSONRPCMessage::Request(jsonrpc_request_from_client_request(
            ClientRequest::Initialize {
                request_id: initialize_request_id.clone(),
                params,
            },
        )),
        endpoint,
    )
    .await?;

    timeout(initialize_timeout, async {
        loop {
            match stream.next().await {
                Some(Ok(Message::Text(text))) => {
                    let message = serde_json::from_str::<JSONRPCMessage>(&text).map_err(|err| {
                        IoError::other(format!(
                            "remote app server at `{endpoint}` sent invalid initialize response: {err}"
                        ))
                    })?;
                    match message {
                        JSONRPCMessage::Response(response) if response.id == initialize_request_id => {
                            server_version = response
                                .result
                                .get("userAgent")
                                .and_then(serde_json::Value::as_str)
                                .and_then(|user_agent| {
                                    let (_, rest) = user_agent.split_once('/')?;
                                    rest.split_whitespace().next().map(str::to_string)
                                });
                            codex_home = response
                                .result
                                .get("codexHome")
                                .and_then(serde_json::Value::as_str)
                                .filter(|codex_home| !codex_home.is_empty())
                                .map(str::to_string);
                            break Ok(());
                        }
                        JSONRPCMessage::Error(error) if error.id == initialize_request_id => {
                            break Err(IoError::other(format!(
                                "remote app server at `{endpoint}` rejected initialize: {}",
                                error.error.message
                            )));
                        }
                        JSONRPCMessage::Notification(notification) => {
                            if let Some(event) = app_server_event_from_notification(notification) {
                                pending_events.push(event);
                            }
                        }
                        JSONRPCMessage::Request(request) => {
                            let request_id = request.id.clone();
                            let method = request.method.clone();
                            match ServerRequest::try_from(request) {
                                Ok(request) => {
                                    pending_events
                                        .push(AppServerEvent::ServerRequest(Box::new(request)));
                                }
                                Err(err) => {
                                    warn!(%err, method, "rejecting unknown remote app-server request during initialize");
                                    write_jsonrpc_message(
                                        stream,
                                        JSONRPCMessage::Error(JSONRPCError {
                                            error: JSONRPCErrorError {
                                                code: -32601,
                                                message: format!(
                                                    "unsupported remote app-server request `{method}`"
                                                ),
                                                data: None,
                                            },
                                            id: request_id,
                                        }),
                                        endpoint,
                                    )
                                    .await?;
                                }
                            }
                        }
                        JSONRPCMessage::Response(_) | JSONRPCMessage::Error(_) => {}
                    }
                }
                Some(Ok(Message::Binary(_)))
                | Some(Ok(Message::Ping(_)))
                | Some(Ok(Message::Pong(_)))
                | Some(Ok(Message::Frame(_))) => {}
                Some(Ok(Message::Close(frame))) => {
                    let reason = frame
                        .as_ref()
                        .map(|frame| frame.reason.to_string())
                        .filter(|reason| !reason.is_empty())
                        .unwrap_or_else(|| "connection closed during initialize".to_string());
                    break Err(IoError::new(
                        ErrorKind::ConnectionAborted,
                        format!(
                            "remote app server at `{endpoint}` closed during initialize: {reason}"
                        ),
                    ));
                }
                Some(Err(err)) => {
                    break Err(IoError::other(format!(
                        "remote app server at `{endpoint}` transport failed during initialize: {err}"
                    )));
                }
                None => {
                    break Err(IoError::new(
                        ErrorKind::UnexpectedEof,
                        format!("remote app server at `{endpoint}` closed during initialize"),
                    ));
                }
            }
        }
    })
    .await
    .map_err(|_| {
        IoError::new(
            ErrorKind::TimedOut,
            format!("timed out waiting for initialize response from `{endpoint}`"),
        )
    })??;

    write_jsonrpc_message(
        stream,
        JSONRPCMessage::Notification(jsonrpc_notification_from_client_notification(
            ClientNotification::Initialized,
        )),
        endpoint,
    )
    .await?;

    Ok((pending_events, server_version, codex_home))
}

fn app_server_event_from_notification(notification: JSONRPCNotification) -> Option<AppServerEvent> {
    match ServerNotification::try_from(notification) {
        Ok(notification) => Some(AppServerEvent::ServerNotification(Box::new(notification))),
        Err(_) => None,
    }
}

fn deliver_event(event_tx: &RemoteEventSender, event: AppServerEvent) -> IoResult<()> {
    match event_tx {
        RemoteEventSender::Unbounded(sender) => sender.send(event).map_err(|_| {
            IoError::new(
                ErrorKind::BrokenPipe,
                "remote app-server event consumer channel is closed",
            )
        }),
        RemoteEventSender::Bounded {
            sender,
            terminal_reason,
        } => sender.try_send(event).map_err(|error| match error {
            mpsc::error::TrySendError::Full(event) => {
                let reason = match event {
                    AppServerEvent::Disconnected { message } => message,
                    _ => "bounded remote app-server event queue is full; reconnect and resync from durable thread state".to_string(),
                };
                let _ = terminal_reason.set(reason.clone());
                IoError::new(ErrorKind::OutOfMemory, reason)
            }
            mpsc::error::TrySendError::Closed(_) => IoError::new(
                ErrorKind::BrokenPipe,
                "remote app-server event consumer channel is closed",
            ),
        }),
    }
}

fn jsonrpc_request_from_client_request(request: ClientRequest) -> JSONRPCRequest {
    let value = match serde_json::to_value(request) {
        Ok(value) => value,
        Err(err) => panic!("client request should serialize: {err}"),
    };
    match serde_json::from_value(value) {
        Ok(request) => request,
        Err(err) => panic!("client request should encode as JSON-RPC request: {err}"),
    }
}

fn jsonrpc_notification_from_client_notification(
    notification: ClientNotification,
) -> JSONRPCNotification {
    let value = match serde_json::to_value(notification) {
        Ok(value) => value,
        Err(err) => panic!("client notification should serialize: {err}"),
    };
    match serde_json::from_value(value) {
        Ok(notification) => notification,
        Err(err) => panic!("client notification should encode as JSON-RPC notification: {err}"),
    }
}

async fn write_jsonrpc_message<S>(
    stream: &mut WebSocketStream<S>,
    message: JSONRPCMessage,
    endpoint: &str,
) -> IoResult<()>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    let payload = serde_json::to_string(&message).map_err(IoError::other)?;
    stream
        .send(Message::Text(payload.into()))
        .await
        .map_err(|err| {
            IoError::other(format!(
                "failed to write websocket message to `{endpoint}`: {err}"
            ))
        })
}

fn websocket_close_error_is_already_closed(err: &TungsteniteError) -> bool {
    match err {
        TungsteniteError::ConnectionClosed | TungsteniteError::AlreadyClosed => true,
        TungsteniteError::Io(err) => matches!(
            err.kind(),
            ErrorKind::BrokenPipe | ErrorKind::ConnectionReset | ErrorKind::NotConnected
        ),
        _ => false,
    }
}
#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn shutdown_tolerates_worker_exit_after_command_is_queued() {
        let (command_tx, mut command_rx) = mpsc::channel(1);
        let (_event_tx, event_rx) = mpsc::unbounded_channel::<AppServerEvent>();
        let worker_handle = tokio::spawn(async move {
            let _ = command_rx.recv().await;
        });
        let client = RemoteAppServerClient {
            command_tx,
            event_rx: RemoteEventReceiver::Unbounded(event_rx),
            pending_events: VecDeque::new(),
            server_version: None,
            codex_home: None,
            connection_id: 1,
            worker_handle,
        };

        client
            .shutdown()
            .await
            .expect("shutdown should complete when worker exits first");
    }
}

#[cfg(all(test, unix))]
#[path = "remote_first_write_client_tests.rs"]
mod first_write_client_tests;
