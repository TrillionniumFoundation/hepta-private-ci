//! Bounded raw queue contact under the existing Agentd admission locks.

use super::AgentdState;
use super::poisoned_state;
use crate::AgentdError;
use codex_hepta_fleet::AgentLifecycle;

impl AgentdState {
    /// Refresh the existing Fleet observation, then serialize the synchronous
    /// raw write with local drain/fence and optional-module detachment. The
    /// callback must not await, block on network I/O, or reenter Agentd state.
    /// This does not mint authority or promise a cross-process Fleet transaction.
    pub(crate) fn with_automation_contact<T>(
        &self,
        write: impl FnOnce() -> T,
    ) -> Result<T, AgentdError> {
        self.refresh_generation()?;
        let runtime = self.runtime.lock().map_err(poisoned_state)?;
        let automation = self.automation.lock().map_err(poisoned_state)?;
        if runtime.lifecycle != AgentLifecycle::Running
            || !runtime.app_server_ready
            || !runtime.critical_stores_ready
            || !runtime.revocation_ready
            || !runtime.required_ports_ready
            || !runtime.admission_open
            || runtime.fenced
            || automation.is_none()
        {
            return Err(AgentdError::GenerationFenced(
                "automation raw contact requires its ready attached host".to_string(),
            ));
        }
        Ok(write())
    }
}
