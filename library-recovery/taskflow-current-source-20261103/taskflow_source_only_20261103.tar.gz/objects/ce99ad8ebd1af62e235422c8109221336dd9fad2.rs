//! Snapshot admission and retained raw-write admission in the remote worker.

use std::future::Future;
use std::future::poll_fn;
use std::io;
use std::pin::Pin;

use codex_app_server_protocol::JSONRPCMessage;
use futures::Sink;
use futures::SinkExt;
use tokio::io::AsyncRead;
use tokio::io::AsyncWrite;
use tokio::sync::oneshot;
use tokio_tungstenite::WebSocketStream;
use tokio_tungstenite::tungstenite::Error as WebSocketError;
use tokio_tungstenite::tungstenite::Message;

use crate::physical_write_gate::FirstWriteCheck;
use crate::physical_write_gate::PhysicalWriteGate;

type BeforeSendFuture = Pin<Box<dyn Future<Output = io::Result<()>> + Send + 'static>>;

pub(crate) enum BeforeSend {
    Snapshot(BeforeSendFuture),
    Physical(FirstWriteCheck),
}

pub(crate) enum GuardedWriteError {
    BeforeSend(io::Error),
    Transport(io::Error),
}

pub(crate) async fn write_guarded_request<S, T>(
    stream: &mut WebSocketStream<S>,
    message: JSONRPCMessage,
    before_send: BeforeSendFuture,
    response_tx: &mut oneshot::Sender<T>,
) -> Result<(), GuardedWriteError>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    let payload = serde_json::to_string(&message)
        .map_err(|error| GuardedWriteError::Transport(io::Error::other(error)))?;
    // Wait for transport readiness before polling the owner's live check.
    // Only this worker owns the stream, so no other command can consume readiness.
    tokio::select! {
        biased;
        _ = response_tx.closed() => return Err(cancelled()),
        result = poll_fn(|cx| Pin::new(&mut *stream).poll_ready(cx)) => {
            result.map_err(|error| GuardedWriteError::Transport(io::Error::other(error)))?;
        }
    }
    tokio::select! {
        biased;
        _ = response_tx.closed() => return Err(cancelled()),
        result = before_send => result.map_err(GuardedWriteError::BeforeSend)?,
    }
    if response_tx.is_closed() {
        return Err(cancelled());
    }
    // No await or channel handoff lies between the live check and first send.
    stream
        .start_send_unpin(Message::Text(payload.into()))
        .map_err(|error| GuardedWriteError::Transport(io::Error::other(error)))?;
    stream
        .flush()
        .await
        .map_err(|error| GuardedWriteError::Transport(io::Error::other(error)))
}

/// A strict gate is available only below a supported raw local IPC stream.
/// WebSocket/TLS connections without that wrapper reject before queueing bytes.
pub(crate) async fn write_first_request<S, T>(
    stream: &mut WebSocketStream<S>,
    message: JSONRPCMessage,
    check: FirstWriteCheck,
    gate: Option<&PhysicalWriteGate>,
    response_tx: &mut oneshot::Sender<T>,
) -> Result<(), GuardedWriteError>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    let gate = gate.ok_or_else(|| {
        GuardedWriteError::BeforeSend(io::Error::new(
            io::ErrorKind::Unsupported,
            "physical first-write admission requires a raw local IPC connection",
        ))
    })?;
    let payload = serde_json::to_string(&message)
        .map_err(|error| GuardedWriteError::Transport(io::Error::other(error)))?;
    // Complete older/control frames before arming this exact request. Handshake
    // and initialize have already completed and cannot carry this queue effect.
    tokio::select! {
        biased;
        _ = response_tx.closed() => return Err(cancelled()),
        result = stream.flush() => {
            result.map_err(websocket_transport_error)?;
        }
    }
    let armed = gate.arm(check).map_err(GuardedWriteError::BeforeSend)?;
    stream
        .start_send_unpin(Message::Text(payload.into()))
        .map_err(websocket_transport_error)?;
    // Once the frame is queued, any failure must discard the connection rather
    // than reusing or closing/flushing it. Even zero-byte rejection can leave
    // an unapproved frame inside the protocol buffer. Partial contact stays
    // uncertain and the owning scheduler performs exact-id reconciliation.
    tokio::select! {
        biased;
        _ = response_tx.closed() => return Err(GuardedWriteError::Transport(io::Error::new(
            io::ErrorKind::Interrupted,
            "physical-write request cancelled; discard the buffered connection",
        ))),
        result = stream.flush() => {
            result.map_err(websocket_transport_error)?;
        }
    }
    if !armed.contacted().map_err(GuardedWriteError::Transport)? {
        return Err(GuardedWriteError::Transport(io::Error::other(
            "request flush completed without a physical contact observation",
        )));
    }
    armed.finish().map_err(GuardedWriteError::Transport)?;
    Ok(())
}

fn websocket_transport_error(error: WebSocketError) -> GuardedWriteError {
    match error {
        WebSocketError::Io(error) => GuardedWriteError::Transport(error),
        error => GuardedWriteError::Transport(io::Error::other(error)),
    }
}

fn cancelled() -> GuardedWriteError {
    GuardedWriteError::BeforeSend(io::Error::new(
        io::ErrorKind::Interrupted,
        "guarded request was cancelled before first send",
    ))
}

#[cfg(test)]
#[path = "remote_send_guard_tests.rs"]
mod tests;

#[cfg(test)]
#[path = "remote_first_write_tests.rs"]
mod first_write_tests;
