//! Bounded raw queue contact under the existing Agentd admission locks.

use super::AgentdState;
use super::poisoned_state;
use crate::AgentdError;
use codex_hepta_fleet::AgentLifecycle;

type AutomationContactWritePoll = std::task::Poll<std::io::Result<usize>>;

impl AgentdState {
    /// Refresh the existing Fleet observation, then serialize the synchronous
    /// raw write with local drain/fence and optional-module detachment. The
    /// callback must not await, block on network I/O, or reenter Agentd state.
    /// This does not mint authority or promise a cross-process Fleet transaction.
    pub(crate) fn with_automation_contact<T>(
        &self,
        write: impl FnOnce() -> T,
    ) -> Result<T, AgentdError> {
        self.refresh_generation()?;
        let runtime = self.runtime.lock().map_err(poisoned_state)?;
        let automation = self.automation.lock().map_err(poisoned_state)?;
        if runtime.lifecycle != AgentLifecycle::Running
            || !runtime.app_server_ready
            || !runtime.critical_stores_ready
            || !runtime.revocation_ready
            || !runtime.required_ports_ready
            || !runtime.admission_open
            || runtime.fenced
            || automation.is_none()
        {
            return Err(AgentdError::GenerationFenced(
                "automation raw contact requires its ready attached host".to_string(),
            ));
        }
        Ok(write())
    }
}

impl AgentdState {
    /// Construct the same future used by the queue caller after SDK readiness.
    /// The original async block owns contact/admission until preparation ends;
    /// only the SQL reservation and host Arc move into the returned raw poll.
    pub(crate) fn prepare_automation_contact(
        self: std::sync::Arc<Self>,
        contact: std::sync::Arc<codex_hepta_automation::AutomationQueueContact>,
        contact_admission: std::sync::Arc<codex_hepta_automation::AutomationAdmission>,
    ) -> impl std::future::Future<
        Output = std::io::Result<
            impl FnOnce(&mut dyn FnMut() -> AutomationContactWritePoll) -> AutomationContactWritePoll
            + Send
            + 'static,
        >,
    > + Send
    + 'static {
        let contact_state = self;
        async move {
            // The transport polls this only after connection/initialization,
            // command-queue and WebSocket readiness waits. Rejecting keeps
            // the existing durable uncertainty for exact-id reconciliation.
            let guard = contact
                .retain_before_contact(&contact_admission, || Ok(()))
                .await
                .map_err(|error| {
                    std::io::Error::new(std::io::ErrorKind::PermissionDenied, error)
                })?;
            Ok(
                move |write: &mut dyn FnMut() -> std::task::Poll<std::io::Result<usize>>| {
                    match contact_state.with_automation_contact(|| {
                        if let Err(error) = guard.verify_clock() {
                            return std::task::Poll::Ready(Err(std::io::Error::new(
                                std::io::ErrorKind::PermissionDenied,
                                error,
                            )));
                        }
                        write()
                    }) {
                        Ok(result) => result,
                        Err(error) => std::task::Poll::Ready(Err(std::io::Error::new(
                            std::io::ErrorKind::PermissionDenied,
                            error,
                        ))),
                    }
                },
            )
        }
    }
}
