"""Prepare source-bound Agentd metadata/fix stages; running requires an assigned slot. Never executes tests."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import threading
import time

ROOT = Path('/workspace/shared/runtime-recovery-20261002')
OUT = ROOT / 'queue-contact-composition-plan-20261003'
CANDIDATES = {
    'queue-contact': (Path('/workspace/shared/taskflow-recovery-20261002/repo'), '8ca34fc8b31dcbde4901ea779ee86280e1fc5c8e', 'codex-hepta-agentd', [
        'codex-rs/hepta-agentd/src/lib.rs', 'codex-rs/hepta-agentd/src/automation.rs',
        'codex-rs/hepta-agentd/src/automation_contact.rs',
        'codex-rs/hepta-agentd/src/automation_contact_composition_tests.rs',
        'codex-rs/hepta-agentd/src/automation_service_tests.rs',
        'codex-rs/hepta-agentd/Cargo.toml',
        'codex-rs/hepta-automation/src/queue_contact.rs']),
}

def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def measured_bytes(path):
    # Rustc can atomically remove/rename a temporary rmeta during traversal.
    # Retry the whole observation at most three times; never hide other errors.
    def raise_walk_error(error):
        raise error
    for attempt in range(3):
        try:
            total = 0
            for directory, _, files in os.walk(path, onerror=raise_walk_error):
                for name in files:
                    total += (Path(directory) / name).stat().st_size
            return total, attempt
        except FileNotFoundError:
            if attempt == 2:
                raise
            time.sleep(0.01)
    raise AssertionError('unreachable observation state')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lineage', choices=CANDIDATES, required=True)
    parser.add_argument('--parent-slot-assigned', action='store_true', required=True)
    parser.add_argument('--target-cap-bytes', type=int, required=True)
    parser.add_argument('--free-floor-bytes', type=int, required=True)
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--stage', choices=['check', 'tests-check', 'fix'], default='check')
    args = parser.parse_args()
    repo, head, package, paths = CANDIDATES[args.lineage]
    def git(*argv):
        return subprocess.check_output(['git', *argv], cwd=repo, text=True).strip()
    assert git('rev-parse', 'HEAD') == head
    assert not git('status', '--porcelain')
    target = ROOT / ('target-taskflow-queue-contact-metadata-20261003')
    target.mkdir(exist_ok=True)
    assert not target.is_symlink()
    identity = target / 'CALLER_CHECK_IDENTITY.json'
    expected = {'head': head, 'repository': str(repo), 'package': package}
    if identity.exists():
        assert json.loads(identity.read_text()) == expected
    else:
        assert not any(target.iterdir())
        write_json(identity, expected)
    assert shutil.disk_usage(ROOT).free > args.free_floor_bytes
    label = f'{args.lineage}-{args.stage}-attempt{args.attempt:02}'
    log = OUT / (label + '.log')
    result_path = OUT / (label + '-result.json')
    assert not log.exists() and not result_path.exists()
    paths += ['codex-rs/Cargo.lock', 'codex-rs/Cargo.toml',
              'codex-rs/core/src/client.rs', 'codex-rs/core/src/client_tests.rs',
              'codex-rs/core/src/client_provider_policy_tests.rs',
              'codex-rs/app-server-client/src/remote.rs']
    command = ['cargo', 'check', '--locked', '--offline', '-p', package, '--lib']
    if args.stage == 'tests-check':
        command = ['cargo', 'check', '--locked', '--offline', '-p', package, '--tests', '--message-format=json']
    elif args.stage == 'fix':
        command = ['just', 'fix', '--locked', '--offline', '-p', package]

    env = dict(os.environ, PATH='/workspace/shared/toolchains/bin:/workspace/shared/toolchains/cargo/bin:' + os.environ['PATH'],
               CARGO_HOME='/workspace/shared/toolchains/cargo', RUSTUP_HOME='/workspace/shared/toolchains/rustup',
               CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
    result = {**expected, 'graph_owner_package': package, 'package': command[command.index('-p') + 1], 'tree': git('rev-parse', 'HEAD^{tree}'), 'command': command,
              'target': str(target), 'source_sha256': {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in paths},
              'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'target_cap_bytes': args.target_cap_bytes, 'free_floor_bytes': args.free_floor_bytes,
              'stage': args.stage, 'scope': 'Agentd default production library or test-target metadata check/fix for the private queue contact candidate; no executed native tests, no process launch, no socket fixture, no transport connectivity claim'}
    write_json(OUT / (label + '-command.json'), result)
    stats = {'peak_sampled_target_bytes': 0, 'minimum_sampled_free_bytes': shutil.disk_usage(ROOT).free,
             'guard_triggered': False, 'near_guard': False, 'sampling_seconds': 2,
             'transient_enoent_retries': 0, 'observation_error': None}
    finished = threading.Event()
    def sample_once():
        try:
            size, retries = measured_bytes(target)
            stats['transient_enoent_retries'] += retries
            free = shutil.disk_usage(ROOT).free
        except Exception as error:
            stats['observation_error'] = {'type': type(error).__name__, 'message': str(error)}
            stats['near_guard'] = True
            write_json(OUT / (label + '-resources.json'), stats)
            print('RESOURCE_OBSERVATION_FAILED: interrupt this owned terminal; no further blind sampling', flush=True)
            return False
        stats['peak_sampled_target_bytes'] = max(stats['peak_sampled_target_bytes'], size)
        stats['minimum_sampled_free_bytes'] = min(stats['minimum_sampled_free_bytes'], free)
        stats['guard_triggered'] |= size > args.target_cap_bytes or free < args.free_floor_bytes
        stats['near_guard'] |= size > args.target_cap_bytes - 100 * 1024**2 or free < args.free_floor_bytes + 100 * 1024**2
        write_json(OUT / (label + '-resources.json'), stats)
        if stats['near_guard']:
            print('RESOURCE_GUARD_WARNING: interrupt this terminal and preserve outputs; do not kill by PID', flush=True)
        return True
    def monitor():
        while not finished.is_set():
            if not sample_once():
                return
            finished.wait(2)
    sampler = threading.Thread(target=monitor, daemon=True)
    sampler.start()
    started = time.monotonic()
    with log.open('w') as stream:
        process = subprocess.Popen(command, cwd=repo / 'codex-rs', env=env, stdout=stream, stderr=subprocess.STDOUT)
        try:
            code = process.wait()
        except KeyboardInterrupt:
            result['terminal_interrupt'] = True
            code = process.wait()
    finished.set()
    sampler.join()
    if stats['observation_error'] is None:
        sample_once()
    test_artifacts = []
    if args.stage == 'tests-check':
        for line in log.read_text().splitlines():
            try:
                artifact = json.loads(line)
            except json.JSONDecodeError:
                continue
            if artifact.get('reason') == 'compiler-artifact' and artifact.get('target', {}).get('name') == 'codex_hepta_agentd':
                test_artifacts.append({key: artifact[key] for key in ['target', 'profile', 'features', 'filenames', 'fresh']})
        write_json(OUT / (label + '-owner-artifacts.json'), test_artifacts)
        result['owner_library_test_profile_observed'] = any(
            'lib' in item['target']['kind'] and item['profile'].get('test') is True for item in test_artifacts
        )
    result.update(exit=code, source_clean_after=not bool(git('status', '--porcelain')),
                  elapsed_seconds=time.monotonic() - started, resources=stats,
                  finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    result['passed'] = code == 0 and result['source_clean_after'] and not stats['guard_triggered'] and stats['observation_error'] is None and result.get('owner_library_test_profile_observed', True)
    write_json(result_path, result)
    print(json.dumps(result, indent=2))
    print(log.read_text()[-6000:])
    raise SystemExit(0 if result['passed'] else (code or 1))

if __name__ == '__main__':
    main()
