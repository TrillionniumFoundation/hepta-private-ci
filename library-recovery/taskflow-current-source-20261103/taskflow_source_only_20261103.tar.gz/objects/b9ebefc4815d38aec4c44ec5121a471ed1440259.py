from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/workspace/shared/runtime-recovery-20261003-2000');repo=root/'taskflow-objects.git';out=root/'taskflow-source-recovery';e=root/'extracted-evidence/taskflow-worker-v10'
env=dict(os.environ,GIT_INDEX_FILE=str(out/'reconstruction.index'),GIT_TERMINAL_PROMPT='0')
def run(args):
 p=subprocess.run(['git','--git-dir',str(repo),*args],env=env,capture_output=True,text=True)
 with (out/'tree-reconstruction-commands.log').open('a') as f:f.write('$ git '+' '.join(args)+'\n'+p.stdout+p.stderr+'\nEXIT '+str(p.returncode)+'\n')
 if p.returncode:raise RuntimeError(p.stderr)
 return p.stdout.strip()
base='41e3d9c22bbc6a4ffe553112c60dc0676d3c12cc';run(['read-tree',base])
steps=[('sdk-d018',e/'taskflow-native-sdk-20261003/tested-source.patch','426c32e0860cc914fc20a4272c40b76c96157ccd'),('core-4af',e/'core-response-source-20261003/taskflow-candidate.patch','12d4353f42fa36f85bf9ccc6db50f2a2420b79c9'),('queue-8ca',e/'queue-contact-qualified-20261003/qualified-source.patch','5d00638fc694ab3503869504723cfae172c4f234')]
records=[]
for label,patch,expected in steps:
 run(['apply','--cached','--check',str(patch)]);run(['apply','--cached',str(patch)]);tree=run(['write-tree'])
 r={'label':label,'patch':str(patch),'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'tree':tree,'expected_tree':expected,'tree_matches':tree==expected}
 records.append(r);(out/'TREE_RECOVERY.json').write_text(json.dumps({'base_original_commit':base,'steps':records,'new_compile_or_tests':False},indent=2)+'\n');print(json.dumps(r),flush=True);assert tree==expected
