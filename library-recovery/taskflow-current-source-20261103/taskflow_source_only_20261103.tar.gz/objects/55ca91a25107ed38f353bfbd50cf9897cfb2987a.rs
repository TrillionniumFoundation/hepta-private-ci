//! Public SDK/worker regressions over raw memory streams and real Unix IPC.
//! Memory-stream results do not claim an operating-system socket qualification.

use std::io;
use std::pin::Pin;
use std::sync::Arc;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering;
use std::task::Context;
use std::task::Poll;
use std::time::Duration;
use tokio::io::ReadBuf;

use super::RemoteEventMode;
use crate::physical_write_gate::GatedStream;
use codex_app_server_protocol::ClientRequest;
use codex_app_server_protocol::JSONRPCMessage;
use codex_app_server_protocol::JSONRPCResponse;
use codex_app_server_protocol::RequestId;
use codex_app_server_protocol::ThreadQueueReconcileMode;
use codex_app_server_protocol::ThreadQueueReconcileParams;
use codex_app_server_protocol::UserInput;
#[cfg(unix)]
use codex_utils_absolute_path::AbsolutePathBuf;
use futures::SinkExt;
use futures::StreamExt;
use pretty_assertions::assert_eq;
use tokio::io::AsyncRead;
use tokio::io::AsyncWrite;
use tokio::sync::Notify;
use tokio::time::timeout;
use tokio_tungstenite::WebSocketStream;
use tokio_tungstenite::tungstenite::Message;
use tokio_tungstenite::tungstenite::protocol::Role;

use crate::RemoteAppServerClient;
use crate::RemoteAppServerConnectArgs;
use crate::RemoteAppServerEndpoint;
use crate::TypedRequestError;

fn request(id: i64) -> ClientRequest {
    ClientRequest::ThreadQueueReconcile {
        request_id: RequestId::Integer(id),
        params: ThreadQueueReconcileParams {
            thread_id: "physical-owner-thread".to_string(),
            input: Vec::new(),
            client_user_message_id: format!("physical-{id}"),
            expected_payload_sha256: "b".repeat(64),
            mode: ThreadQueueReconcileMode::AllowIfAbsent,
        },
    }
}

type TestResult<T = ()> = Result<T, Box<dyn std::error::Error + Send + Sync>>;

type Fixture = (
    Option<tempfile::TempDir>,
    RemoteAppServerClient,
    tokio::task::JoinHandle<TestResult<Vec<String>>>,
    Option<RawStreamProbe>,
);

#[derive(Clone)]
struct RawStreamProbe {
    bytes: Arc<AtomicUsize>,
    blocked_writes: Arc<AtomicUsize>,
    writable: Arc<AtomicBool>,
    dropped: Arc<Notify>,
}

struct CountedRawStream {
    inner: tokio::io::DuplexStream,
    probe: RawStreamProbe,
}

impl Drop for CountedRawStream {
    fn drop(&mut self) {
        self.probe.dropped.notify_one();
    }
}

impl AsyncRead for CountedRawStream {
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buffer: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        Pin::new(&mut self.get_mut().inner).poll_read(cx, buffer)
    }
}

impl AsyncWrite for CountedRawStream {
    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        bytes: &[u8],
    ) -> Poll<io::Result<usize>> {
        let this = self.get_mut();
        if !this.probe.writable.load(Ordering::SeqCst) {
            // Model a peer that will never make the close frame writable.
            this.probe.blocked_writes.fetch_add(1, Ordering::SeqCst);
            return Poll::Pending;
        }
        let result = Pin::new(&mut this.inner).poll_write(cx, bytes);
        if let Poll::Ready(Ok(written)) = result {
            this.probe.bytes.fetch_add(written, Ordering::SeqCst);
        }
        result
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.get_mut().inner).poll_flush(cx)
    }

    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.get_mut().inner).poll_shutdown(cx)
    }
}

fn args(endpoint: RemoteAppServerEndpoint) -> RemoteAppServerConnectArgs {
    RemoteAppServerConnectArgs {
        endpoint,
        client_name: "physical-write-test".to_string(),
        client_version: "1".to_string(),
        experimental_api: true,
        mcp_server_openai_form_elicitation: false,
        opt_out_notification_methods: Vec::new(),
        channel_capacity: 8,
    }
}

async fn serve<S: AsyncRead + AsyncWrite + Unpin>(
    mut websocket: WebSocketStream<S>,
) -> TestResult<Vec<String>> {
    let mut requests = Vec::new();
    while let Some(frame) = websocket.next().await {
        // Rejected/cancelled buffered requests must drop the connection,
        // without sending a graceful close that could flush the frame.
        let Ok(frame) = frame else { break };
        let Message::Text(text) = frame else { continue };
        let JSONRPCMessage::Request(request) = serde_json::from_str(&text)? else {
            continue;
        };
        let result = if request.method == "initialize" {
            serde_json::json!({"userAgent": "physical-test", "codexHome": "/owned/home"})
        } else {
            requests.push(request.method);
            serde_json::json!({"accepted": true})
        };
        if websocket
            .send(Message::Text(
                serde_json::to_string(&JSONRPCMessage::Response(JSONRPCResponse {
                    id: request.id,
                    result,
                }))?
                .into(),
            ))
            .await
            .is_err()
        {
            // Preserve the observed method even if a cancelled caller has
            // already dropped the socket before its response can be sent.
            break;
        }
    }
    Ok(requests)
}

#[cfg(unix)]
async fn unix_fixture() -> TestResult<Fixture> {
    let directory = tempfile::tempdir()?;
    let path = directory.path().join("app.sock");
    let mut listener = codex_uds::UnixListener::bind(&path).await?;
    let server = tokio::spawn(async move {
        let stream = listener.accept().await?;
        let websocket = tokio_tungstenite::accept_async(stream).await?;
        serve(websocket).await
    });
    let client = RemoteAppServerClient::connect(args(RemoteAppServerEndpoint::UnixSocket {
        socket_path: AbsolutePathBuf::try_from(path)?,
    }))
    .await?;
    Ok((Some(directory), client, server, None))
}

async fn memory_fixture() -> TestResult<Fixture> {
    memory_fixture_with_mode(RemoteEventMode::Unbounded).await
}

async fn memory_fixture_with_mode(event_mode: RemoteEventMode) -> TestResult<Fixture> {
    let (raw, peer) = tokio::io::duplex(1024 * 1024);
    let probe = RawStreamProbe {
        bytes: Arc::new(AtomicUsize::new(0)),
        blocked_writes: Arc::new(AtomicUsize::new(0)),
        writable: Arc::new(AtomicBool::new(true)),
        dropped: Arc::new(Notify::new()),
    };
    let (raw, gate) = GatedStream::new(CountedRawStream {
        inner: raw,
        probe: probe.clone(),
    });
    let websocket = WebSocketStream::from_raw_socket(raw, Role::Client, None).await;
    let peer = WebSocketStream::from_raw_socket(peer, Role::Server, None).await;
    let server = tokio::spawn(serve(peer));
    let args = args(RemoteAppServerEndpoint::WebSocket {
        websocket_url: "ws://unused.invalid".to_string(),
        auth_token: None,
    });
    // This private production constructor owns initialize and the actual SDK
    // worker. Only the raw byte stream is an in-memory test transport. No
    // connection or HTTP/TLS handshake is claimed by this fixture.
    let client = RemoteAppServerClient::connect_with_stream(
        args.channel_capacity,
        event_mode,
        "raw-memory-fixture".to_string(),
        websocket,
        Some(gate),
        args.initialize_params(),
    )
    .await?;
    Ok((None, client, server, Some(probe)))
}

type RawWritePermit = fn(&mut dyn FnMut() -> Poll<io::Result<usize>>) -> Poll<io::Result<usize>>;

fn raw_write(write: &mut dyn FnMut() -> Poll<io::Result<usize>>) -> Poll<io::Result<usize>> {
    write()
}

async fn assert_rearms(fixture: Fixture) -> TestResult {
    let (_directory, client, server, _bytes) = fixture;
    let checks = Arc::new(AtomicUsize::new(0));
    let first_checks = Arc::clone(&checks);
    let first: serde_json::Value = client
        .request_handle()
        .request_typed_at_first_write(request(1), move || {
            first_checks.fetch_add(1, Ordering::SeqCst);
            async { Ok(raw_write) }
        })
        .await?;
    assert_eq!(first, serde_json::json!({"accepted": true}));
    let next_checks = Arc::clone(&checks);
    let rejected: Result<serde_json::Value, _> = client
        .request_handle()
        .request_typed_at_first_write(request(2), move || {
            next_checks.fetch_add(1, Ordering::SeqCst);
            async { Err::<RawWritePermit, _>(io::Error::from(io::ErrorKind::PermissionDenied)) }
        })
        .await;
    assert!(
        matches!(rejected, Err(TypedRequestError::Transport { source, .. })
        if source.kind() == io::ErrorKind::PermissionDenied)
    );
    client.shutdown().await?;
    assert_eq!(
        timeout(Duration::from_secs(2), server).await???,
        vec!["thread/queue/reconcile".to_string()]
    );
    assert!(checks.load(Ordering::SeqCst) >= 2);
    Ok(())
}

async fn assert_caller_cancellation(fixture: Fixture) -> TestResult {
    let (_directory, client, server, _bytes) = fixture;
    let entered = Arc::new(Notify::new());
    let owner_entered = Arc::clone(&entered);
    let handle = client.request_handle();
    let request = tokio::spawn(async move {
        handle
            .request_typed_at_first_write::<serde_json::Value, _, _>(request(3), move || {
                owner_entered.notify_one();
                async {
                    std::future::pending::<()>().await;
                    Ok(raw_write)
                }
            })
            .await
    });
    timeout(Duration::from_secs(2), entered.notified()).await?;
    request.abort();
    assert!(matches!(request.await, Err(error) if error.is_cancelled()));
    assert_eq!(
        timeout(Duration::from_secs(2), server).await???,
        Vec::<String>::new()
    );
    client.shutdown().await?;
    Ok(())
}

#[cfg(unix)]
#[tokio::test]
async fn ipc_worker_rearms_after_success_and_discards_a_rejected_buffer() -> TestResult {
    assert_rearms(unix_fixture().await?).await
}

#[cfg(unix)]
#[tokio::test]
async fn ipc_worker_caller_cancellation_drops_pending_check_and_queued_frame() -> TestResult {
    assert_caller_cancellation(unix_fixture().await?).await
}

#[tokio::test]
async fn raw_memory_worker_rearms_and_discards_rejected_buffer() -> TestResult {
    assert_rearms(memory_fixture().await?).await
}

#[tokio::test]
async fn raw_memory_worker_cancellation_drops_pending_check() -> TestResult {
    assert_caller_cancellation(memory_fixture().await?).await
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn caller_drop_during_owner_wait_prevents_large_frame_first_byte() -> TestResult {
    let (_directory, client, server, bytes) = memory_fixture().await?;
    let bytes = bytes.expect("raw memory byte counter").bytes;
    // Initialize and initialized have finished before the production worker is
    // returned. Count below WebSocket buffering, not decoded peer messages.
    let initialized_bytes = bytes.load(Ordering::SeqCst);
    let entered = Arc::new(Notify::new());
    let owner_entered = Arc::clone(&entered);
    let (release, waiting) = std::sync::mpsc::channel();
    let waiting = Arc::new(std::sync::Mutex::new(Some(waiting)));
    let handle = client.request_handle();
    let mut large_request = request(4);
    let ClientRequest::ThreadQueueReconcile { params, .. } = &mut large_request else {
        unreachable!()
    };
    params.input = vec![UserInput::Text {
        text: "x".repeat(256 * 1024),
        text_elements: Vec::new(),
    }];
    let sending = tokio::spawn(async move {
        handle
            .request_typed_at_first_write::<serde_json::Value, _, _>(large_request, move || {
                let owner_entered = Arc::clone(&owner_entered);
                let waiting = Arc::clone(&waiting);
                async move {
                    Ok(move |write: &mut dyn FnMut() -> Poll<io::Result<usize>>| {
                        // Model a synchronous host-lock wait after the async owner
                        // check. A large frame can reach here from start_send,
                        // before the helper's flush/cancellation select is polled.
                        owner_entered.notify_one();
                        waiting
                            .lock()
                            .expect("controlled owner wait")
                            .take()
                            .expect("one first-byte attempt")
                            .recv_timeout(Duration::from_secs(2))
                            .expect("release owner wait");
                        write()
                    })
                }
            })
            .await
    });
    timeout(Duration::from_secs(2), entered.notified())
        .await
        .expect("raw attempt entered");
    sending.abort();
    assert!(sending.await.expect_err("caller cancelled").is_cancelled());
    release
        .send(())
        .expect("release host wait after cancellation completed");
    client.shutdown().await.expect("join worker");
    assert_eq!(
        bytes.load(Ordering::SeqCst) - initialized_bytes,
        0,
        "caller cancellation forbids even a partial first frame byte"
    );
    assert_eq!(
        timeout(Duration::from_secs(2), server).await???,
        Vec::<String>::new(),
    );
    Ok(())
}

#[tokio::test]
async fn dropping_last_client_bounds_a_permanently_backpressured_close() -> TestResult {
    let (_directory, client, server, probe) = memory_fixture().await?;
    let probe = probe.expect("raw stream probe");
    probe.writable.store(false, Ordering::SeqCst);
    drop(client);
    timeout(
        crate::SHUTDOWN_TIMEOUT + Duration::from_secs(1),
        probe.dropped.notified(),
    )
    .await
    .expect("last sender drop must release the worker and stream within the existing close budget");
    assert!(
        probe.blocked_writes.load(Ordering::SeqCst) > 0,
        "close must actually reach raw write backpressure before the worker is released"
    );
    assert_eq!(
        timeout(Duration::from_secs(2), server).await???,
        Vec::<String>::new(),
    );
    Ok(())
}

#[tokio::test]
async fn backlog_memory_worker_rearms_and_discards_rejected_buffer() -> TestResult {
    assert_rearms(memory_fixture_with_mode(RemoteEventMode::BacklogBounded { capacity: 1 }).await?)
        .await
}

#[tokio::test]
async fn backlog_memory_worker_cancellation_drops_pending_check() -> TestResult {
    assert_caller_cancellation(
        memory_fixture_with_mode(RemoteEventMode::BacklogBounded { capacity: 1 }).await?,
    )
    .await
}
