"""Run scoped source-identity checks using the unmodified repository verifier."""
import json
from pathlib import Path
import runpy
import subprocess
import sys

sys.path.insert(0, str(Path("scripts").resolve()))
ns = runpy.run_path("scripts/hepta-implementation-maps.py", run_name="taskflow_source_identity")
row = ns["load"]("docs/modules/automation.taskflow/IMPLEMENTATION_MAP.json")
module = next(x for x in ns["load"]("docs/modules/MODULES.json")["modules"] if x["id"] == "automation.taskflow")
candidate = ns["current_source_base"]()
assert len(sys.argv) == 3
assert candidate == {"commit": sys.argv[1], "tree": sys.argv[2]}
ns["require_clean_candidate"](candidate)
ns["validate_claim_types"](row)
ns["validate_closed_world_bindings"](row)
roots = ns["resolve_source_roots"](ns["ROOT"], module)
assert row["resolvedRoots"] == roots
ns["validate_operation_inventory"]("automation.taskflow", row["operations"])
paths = ns["verify_source_identity"](row, roots, candidate, profile="qualification")
failures = []
ns["validate_path_blob_manifest"](row, "automation.taskflow", failures, profile="qualification")
assert not failures, failures
for operation in row["operations"]:
    assert ns["git"]("rev-parse", candidate["commit"] + ":" + operation["sourcePath"]) == operation["sourceBlob"]
assert row["sourceObjects"] == ns["current_source_objects"](row)
changed = subprocess.check_output([
    "git", "diff", "--name-only", "805fc395161b3c29e334e4dc64f05068e26aa98f", candidate["commit"], "--", "codex-rs",
], text=True).splitlines()
for path in changed:
    assert path in paths or any(path.startswith(root + "/") for root in roots), ("unobserved changed source", path)
ns["require_clean_candidate"](candidate, paths)
print(json.dumps({
    "status": "PASS_TASKFLOW_CANDIDATE_SOURCE_IDENTITY_SUBCHECK",
    "candidate": candidate,
    "operations": len(row["operations"]),
    "exactManifestEntries": len(row["exactSourceEvidence"]["entries"]),
    "sourceObjects": len(row["sourceObjects"]),
    "observedEvidencePaths": len(paths),
    "changedRustPathsCovered": len(changed),
    "scope": "TaskFlow exact source identity with unmodified repository functions; not global map qualification, native execution, host qualification or independent acceptance",
}, indent=2))
