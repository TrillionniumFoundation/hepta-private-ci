use super::*;
use pretty_assertions::assert_eq;

#[tokio::test]
async fn expired_terminal_recovery_encodes_the_next_agent_generation() {
    for original_generation in [2, 9] {
        let fixture = Fixture::new();
        let store = AutomationStore::open(&fixture.layout).await.expect("store");
        let task = draft(
            "019153a4-3088-7000-a56a-9b1964f75124",
            AutomationSchedule::Once,
            /*due*/ 100,
        );
        store.create_task(&task).await.expect("task");
        let lease = store
            .claim_due(
                /*now_ms*/ 100,
                original_generation,
                /*lease_duration_ms*/ 10,
            )
            .await
            .expect("timer claim")
            .expect("due task");
        let occurrence = store
            .materialize_occurrence(&lease, /*now_ms*/ 100)
            .await
            .expect("occurrence");
        store
            .prepare_occurrence_taskflow(
                &occurrence,
                &lease,
                /*now_ms*/ 100,
                /*lease_duration_ms*/ 10,
            )
            .await
            .expect("prepare step");
        store
            .record_dispatch_uncertain(&lease, /*observed_at_ms*/ 100)
            .await
            .expect("dispatch boundary");
        store
            .record_occurrence_admitted(
                &lease,
                &AutomationQueueReceipt {
                    queued_submission_id: "queue:terminal-recovery".to_string(),
                    client_user_message_id: lease.client_user_message_id.clone(),
                },
                /*admitted_at_ms*/ 101,
            )
            .await
            .expect("admission persisted before crash");
        // Crash before mark_occurrence_taskflow_admitted can quarantine the run.
        store.close().await;
        let store = AutomationStore::open(&fixture.layout)
            .await
            .expect("reopen");
        let work = store
            .pending_occurrence_work(/*limit*/ 1)
            .await
            .expect("recovery work")
            .pop()
            .expect("admitted occurrence");
        store
            .ensure_admitted_taskflow_uncertainty(&work, /*now_ms*/ 111)
            .await
            .expect("restore historical step uncertainty after lease expiry");
        let terminal = Sha256Digest::for_bytes(b"observed terminal after restart");
        assert!(matches!(
            store
                .reconcile_occurrence_taskflow_terminal_with_recovery(
                    &work,
                    AutomationOccurrenceTerminalState::Succeeded,
                    &terminal,
                    /*now_ms*/ 111,
                    original_generation,
                    /*recovery_lease_ms*/ 30_000,
                )
                .await,
            Err(codex_hepta_automation::TaskFlowError::StaleFence)
        ));
        store
            .reconcile_occurrence_taskflow_terminal_with_recovery(
                &work,
                AutomationOccurrenceTerminalState::Succeeded,
                &terminal,
                /*now_ms*/ 111,
                original_generation + 1,
                /*recovery_lease_ms*/ 30_000,
            )
            .await
            .expect("the actual next Agent generation can repair the projection");
        let settled = store
            .taskflow_run(&work.occurrence.taskflow_run_id)
            .await
            .expect("run")
            .expect("settled run");
        assert_eq!(settled.state, TaskFlowRunState::Succeeded);
        store.close().await;
        let store = AutomationStore::open(&fixture.layout)
            .await
            .expect("reopen terminal");
        store
            .reconcile_occurrence_taskflow_terminal_with_recovery(
                &work,
                AutomationOccurrenceTerminalState::Succeeded,
                &terminal,
                /*now_ms*/ 112,
                original_generation + 1,
                /*recovery_lease_ms*/ 30_000,
            )
            .await
            .expect("historical replay does not issue a new claim or effect");
        assert_eq!(
            store
                .taskflow_run(&settled.run_id)
                .await
                .expect("replayed run"),
            Some(settled)
        );
        store.close().await;
    }
}
