fn review_only() {
    let _future = async move {
        // The transport polls this only after connection/initialization,
        // command-queue and WebSocket readiness waits. Rejecting keeps
        // the existing durable uncertainty for exact-id reconciliation.
        let guard = contact
            .retain_before_contact(&contact_admission, || Ok(()))
            .await
            .map_err(|error| std::io::Error::new(std::io::ErrorKind::PermissionDenied, error))?;
        Ok(
            move |write: &mut dyn FnMut() -> std::task::Poll<std::io::Result<usize>>| {
                match contact_state.with_automation_contact(|| {
                    if let Err(error) = guard.verify_clock() {
                        return std::task::Poll::Ready(Err(std::io::Error::new(
                            std::io::ErrorKind::PermissionDenied,
                            error,
                        )));
                    }
                    write()
                }) {
                    Ok(result) => result,
                    Err(error) => std::task::Poll::Ready(Err(std::io::Error::new(
                        std::io::ErrorKind::PermissionDenied,
                        error,
                    ))),
                }
            },
        )
    };
}
