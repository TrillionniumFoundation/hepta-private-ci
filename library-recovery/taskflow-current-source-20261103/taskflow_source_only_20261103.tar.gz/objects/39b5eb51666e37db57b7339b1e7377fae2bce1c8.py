"""Execute one explicitly allocated initialization probe stage."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import resource
import shutil
import subprocess
import time

ROOT = Path('/workspace/shared/runtime-recovery-20261002')
REPO = ROOT / 'worker1329-repo'
OUT = ROOT / 'initialize-preparation-20261003'
TARGET = ROOT / 'target-worker-initialize'
BASE = 'a9e551c1a6488cfe082d3bc608f254c3043a3445'

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()

p = argparse.ArgumentParser()
p.add_argument('label')
p.add_argument('--head', required=True)
p.add_argument('--first', action='store_true')
p.add_argument('--mode', choices=['test', 'fix', 'strict'], default='test')
p.add_argument('--filter', default='test(remote_initialize_deadline_tests)')
p.add_argument('--expected-tests', type=int, default=8)
a = p.parse_args()
assert re.fullmatch(r'[a-z0-9-]+', a.label)
assert (OUT / 'PARENT_SLOT_HANDOFF.json').is_file()
assert git('rev-parse', 'HEAD') == a.head and not git('status', '--porcelain')
subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', BASE, a.head], check=True)
if a.first:
    assert not TARGET.exists()
    assert shutil.disk_usage(ROOT).free >= 8 * 1024**3
else:
    assert TARGET.exists()
    assert shutil.disk_usage(ROOT).free >= 3 * 1024**3
commands = {
    'test': ['just', 'test', '-p', 'codex-app-server-client', '--lib', '--locked', '--offline', '-E', a.filter],
    'fix': ['just', 'fix', '-p', 'codex-app-server-client', '--no-deps', '--lib', '--locked', '--offline'],
    'strict': ['cargo', 'clippy', '-p', 'codex-app-server-client', '--all-targets', '--no-deps', '--locked', '--offline', '--', '-D', 'warnings'],
}
command = commands[a.mode]
env = dict(os.environ, PATH='/workspace/shared/toolchains/bin:/workspace/shared/toolchains/cargo/bin:' + os.environ['PATH'],
           CARGO_HOME='/workspace/shared/toolchains/cargo', RUSTUP_HOME='/workspace/shared/toolchains/rustup',
           CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           CARGO_TARGET_DIR=str(TARGET), NEXTEST_TEST_THREADS='1')
paths = ['codex-rs/Cargo.lock', 'codex-rs/app-server-client/Cargo.toml',
         'codex-rs/app-server-client/src/remote.rs', 'codex-rs/app-server-client/src/remote_initialize_deadline_tests.rs']
meta = {'head': a.head, 'tree': git('rev-parse', 'HEAD^{tree}'), 'command': command,
        'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'target': str(TARGET),
        'profile': {'jobs': 1, 'debug': 0, 'incremental': False, 'nextest_threads': 1},
        'target_cap_bytes': 6 * 1024**3, 'free_floor_bytes': 3 * 1024**3,
        'free_bytes_start': shutil.disk_usage(ROOT).free, 'expected_selected_tests': a.expected_tests,
        'helper_build_requested': False, 'sandbox_helper_execution_requested': False,
        'input_sha256': {path: hashlib.sha256((REPO / path).read_bytes()).hexdigest() for path in paths}}
log = OUT / f'{a.label}.log'
receipt = OUT / f'{a.label}-result.json'
assert not log.exists() and not receipt.exists()
started = time.monotonic()
with log.open('w') as stream:
    stream.write(json.dumps(meta) + '\n')
    stream.flush()
    child = subprocess.Popen(command, cwd=REPO / 'codex-rs', env=env, stdout=stream, stderr=subprocess.STDOUT)
    samples = []
    while child.poll() is None:
        free = shutil.disk_usage(ROOT).free
        measure = subprocess.run(['du', '-sb', str(TARGET)], text=True, capture_output=True, check=False) if TARGET.exists() else None
        target_bytes = int(measure.stdout.split()[0]) if measure is not None and measure.stdout else 0
        sample = {'elapsed_seconds': time.monotonic() - started, 'target_bytes': target_bytes, 'free_bytes': free}
        samples.append(sample)
        if measure is not None and measure.returncode:
            sample['measurement_warning'] = measure.stderr
        (OUT / f'{a.label}-resources.json').write_text(json.dumps(samples, indent=2) + '\n')
        if target_bytes >= 6 * 1024**3 or free < 3 * 1024**3:
            print('RESOURCE_GUARD_BREACH ' + json.dumps(sample), flush=True)
            (OUT / f'{a.label}-guard-breach.json').write_text(json.dumps(sample, indent=2) + '\n')
        time.sleep(5)
output = log.read_text()
match = re.search(r'Summary \[[^\]]*\] (\d+) tests run: (\d+) passed', output)
counts = {'run': int(match[1]), 'passed': int(match[2])} if match else None
meta.update(exit=child.returncode, elapsed_seconds=time.monotonic() - started,
            free_bytes_end=shutil.disk_usage(ROOT).free,
            max_child_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
            source_clean_after=not bool(git('status', '--porcelain')), counts=counts,
            log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
receipt.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta, indent=2))
print(output[-18000:])
raise SystemExit(child.returncode)
