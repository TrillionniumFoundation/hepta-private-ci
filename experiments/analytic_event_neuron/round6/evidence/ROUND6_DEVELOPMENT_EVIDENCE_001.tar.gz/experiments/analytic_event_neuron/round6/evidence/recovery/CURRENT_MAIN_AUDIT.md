# Round6: current Hepta native integration audit

Audit date: 2026-10-30. Read-only source review; no runtime, scientific experiment,
or native binary execution is claimed by this audit.

## Fixed identities

Current `main` is `732e934ba496d90fbe042b8d41d479ef901643e5`, a direct child of
`f8c9419df6ddeb36ff8b522a50219981fb8d9345`. Its commit clears the homepage README.
The analytic-event research branch remains exactly
`d6a828eac92cc8df03f3ccce0a6d2fc04c7ce9f6`; main has no `experiments/` tree.
Root `AGENTS.md` is Git blob `faa57cc0db48123e1011f1eb47692cd3bbbcfc3a`.
No nested AGENTS file occurs in the inspected neuron, types, infer-core, agentd,
intelligence or NDU crate subtrees. All downloaded main source bytes were checked
against their actual Git blob identities. See `SOURCE_AUDIT.json`.

## Current main and the historical AEN native pin are compatible at the mechanism boundary

The original `NATIVE_SOURCE_MANIFEST.json` pins 83 files at
`0acfd9b27db910c180b0d8911f39aea469b7f864`. Bounded current-main subtree retrieval
finds **80 identical Git blobs**. All neuron and types files are identical.
The three differences are confined to infer-core: main lacks
`generation_step.rs` and its tests, while `src/lib.rs` lacks only that module and
its exported generation-step names. Its neuron-feature API is unchanged.
The full comparison is in `native_comparison.json`.

Consequences:

- A verified original AEN binary can be used for a clearly new research run;
  its original build and source identity must remain explicit.
- A current-main build can use a new manifest of the 81 actual current crate
  files, with a new build receipt. Do not overwrite the old frozen manifest or
  represent newly built bytes as the missing original executable.
- `prepare_native.py` verifies exact Git objects, uses an isolated three-crate
  workspace, builds the original sparse/typed runtime examples, and requires a
  lock-matching vendor plus Rust, rustfmt and just. Supply its prerequisites or
  implement a separately named new builder; do not weaken its old checks.

## Real API and execution ownership

`codex-rs/hepta-neuron/src/sparse.rs` exports `SparseConfig`, `SparseTick`,
`SparseCheckpoint`, `SparseSignalReceipt` and `sparse_tick`. This pure signed-Q24
kernel has bounded recurrence, inhibition, top-k activation, homeostasis and
eligibility. It enforces width 5..256, 1%..20% top-k, bounded input [-8,8] and
canonical ties-to-even integer products. It always emits
`requires_calibration=true` and `AuthorityPosture::DENY_ALL`.

`NeuronRuntime::tick` validates the expected checkpoint, executes a
`NeuronModelPort`, verifies model output, commits the original `SparseJournal`,
calculates calibration/resource posture, and CAS-publishes the independent
anchor witness. A witness failure after journal commit enters explicit pending
reconciliation. Recovery has named root/segment operations; arbitrary rollback
or replay is not treated as a fresh tick.

The product composition path is
`AgentdNeuronOwner::tick -> InferenceControlModelPort ->
NeuronInferenceControlPort::execute_feature(NeuronFeatureRequestV1) -> verified
NeuronFeatureReceiptV1 -> NeuronRuntime::tick`. `hepta-intelligence` also has a
named `run_neuron_tick_v1` wrapper. The agentd source explicitly says that
constructing its owner **does not activate the daemon startup path**. A research
typed port is useful integration evidence but does not establish active daemon
integration, authenticated dispatch, selected-artifact activation or production
qualification.

## Smallest concrete new paid-feedback experiment

Reuse the actual Round4 `runtime_owner.Owner` and `native_adapter.Native` as
separate components under a new Round6 protocol/run identity. `Owner.step`
persists and fsyncs a packed law, independently reopens/decodes it, executes
`Native.typed` for every component, checks original native checkpoint sequences,
forms the mixture using post-native-Q24 parameters and probabilities, and
persists the result and local witness. The native Rust head implements the real
`NeuronModelPort`, calls original `NeuronRuntime`/`SparseJournal`, and separately
reports head probability and sparse activation receipts.

Round4 `runtime_evidence` and `runtime_study` already provide actual output
delivery/readback, acquired noisy feedback, paid wait/repair/stop, final output
delivery, separate target-bearing scoring, raw execution archives and native
replay. A fresh Round6 study can reuse these source identities and register new
training, calibration, selection and confirmation namespaces without recovering
the old final scientific archive first.

Important causal and engineering limits:

- Baseline event/direct/float policies use `action_values` on the received
  conditional-law moments. Their downstream utility does not alone isolate a
  CDF or mixture-shape contribution. Learned analytic/numeric/history arms use
  actual derived features; preserve matched-information/shape ablations.
- The policy worker is target-free by its data contract, but it has the whole
  public potential-observation array and is not hostile-process isolation.
  Actual acquisition order must still be audited.
- The original typed head deliberately abstains and denies authority; it
  reports `native_owner_integration=false`, experimental local owner.
- The mixture owner declares `cross_owner_atomicity=false`. Partial native
  component transactions are stopped for reconciliation. A test of one owner
  cannot prove multi-owner atomicity.
- Full propagation, probability calibration, released Q24 probability,
  sparse activation and actual task utility are distinct quantities.

## Related newer research found

`research/continuous-boundary-flow-20261028` at
`9b03618be452d264cd7a3778677144ebc9b45fc2` contains
`experiments/native_readout_objective`. Its published README reports real native
kernel/NDU decisions and different-PID cold recovery, but its registered
policy-regret-vs-iterative-MSE benefit gate failed. Those results belong to that
study, not to Round6. Its native build manifest pins original base `5898cd8...`
and binary `fa9dc78b129b0ec3b072e9fc8c8fdd49479515c79aeb2660f355e38f41e54dce`.

`research/hcsn-regenerative-free-boundary-20261029` at
`4bcdecd2ff334b8705c565a5c77a4a97f05ba5e4` publishes a portable research host under
`experiments/hcsn_free_boundary_v1/native_vendor/`: two gzip parts of 400,000 and
180,191 bytes, decoded binary 1,306,448 bytes, SHA256
`1dc702aea6a448ad84407aeb71dc8f23066205fab79fe7c6859fc02c55e6f7a5`.
The original base is `5898cd8b0f724c3152b6cc52856721f72e5e08be`, wrapper
`7bec42aa4f79432f4a724d5295c67f9d69ee5a8d`, Rust 1.95 Linux x86_64, not a full
daemon build. This continuous-host protocol is **not** a drop-in AEN Native
protocol. The native environment agent independently succeeded fetching these
binary parts with the connector's supported `encoding: base64` route; restoration
and execution outcomes must come from that agent's actual receipts.

Other inspected branch heads include first-passage-adaptive `9b71cf4...`,
first-passage-operator `6396bc0...`, and adaptive-neuron-closure `e298cf4...`.
They contain separate native/owner/credit evidence and explicit remaining CI or
scientific gaps. No inspected branch should be assumed to restore the original
Round4 final archive or to imply current agentd production activation.

## Recommendation

Proceed with a new registered paid-feedback execution using exact restored AEN
native bytes if recoverable, otherwise a separately receipted current-main build.
Keep the original sparse kernel as the actual strong control and the original
typed journal/witness path as the lifecycle substrate. Make learned/calibrated
law consumption affect paid decisions and final readback utility; test that
connection with matched interventions. Preserve current abstention and authority
boundaries until independently qualified production integration exists.
