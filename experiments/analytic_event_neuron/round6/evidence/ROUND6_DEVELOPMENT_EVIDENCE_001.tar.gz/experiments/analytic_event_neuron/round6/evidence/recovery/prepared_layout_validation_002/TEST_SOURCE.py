"""Independent development-only fixtures for the final prepared-layout rules."""

from datetime import datetime, timezone
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from experiments.analytic_event_neuron.round6 import lifecycle as m
from experiments.analytic_event_neuron.round4.runtime_evidence import write_json

EXPECTED = "5800ce39395b2d35e891d8b5fbcb8311fa6c18824ca189e50075e4133bfe9720"
SCENARIOS = []
SOURCES = m.sources()
ENVIRONMENT = m.environment()


def fixture(root):
    root.mkdir(parents=True)
    for seed in m.REGISTRATION["seeds"]:
        directory = root / "prepared" / f"seed_{seed}"
        directory.mkdir(parents=True)
        for name in m.PREPARED_FILES:
            (directory / name).write_text("DEVELOPMENT LAYOUT FIXTURE; NOT TRAINING DATA\n")
        receipt = {"seed": seed, "namespace": "registered", "train_rows": 256,
                   "development_rows": 128, "prior_confirmation_used": False,
                   "dynamics": {"prior_parameters_changed": True},
                   "fits": {arm: {"parameter_l2_change": 1, "candidates": [None] * 15}
                            for arm in m.REGISTRATION["learned_readouts"]}}
        (directory / "TRAINING_RECEIPT.json").write_text(json.dumps(receipt))
    (root / "PREPARING.json").write_text('{"development_layout_fixture_only":true}\n')
    return root / "prepared" / f"seed_{m.REGISTRATION['seeds'][0]}"


def start_record():
    return {"schema": "development.layout.fixture", "registration": m.REGISTRATION,
            "registration_sha256": m.digest(m.REGISTRATION), "sources_sha256": SOURCES,
            "environment": ENVIRONMENT, "confirmation_constructed": False}


class LayoutTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hepta-layout-development-")
        self.base = Path(self.temp.name)
        self.root = self.base / "run"
        self.first = fixture(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_exact_nine_regular_files_per_seed(self):
        self.assertEqual(m.prepared_layout(self.root), [])
        self.assertEqual(len(m.artifacts(self.root)), 9 * len(m.REGISTRATION["seeds"]))
        SCENARIOS.append("exactly nine regular files per registered seed accepted")

    def test_empty_transport_tree_recorded_and_nonsemantic(self):
        before = m.artifacts(self.root)
        empty = self.first / "working_case" / "readbacks" / "empty_leaf"
        empty.mkdir(parents=True)
        expected = sorted(str(p.relative_to(self.root)) for p in
                          (empty, empty.parent, empty.parent.parent))
        self.assertEqual(m.prepared_layout(self.root), expected)
        self.assertEqual(m.artifacts(self.root), before)
        with patch.object(m, "verify_preparing", return_value=start_record()):
            manifest = m.prepare_manifest(self.root)
            self.assertEqual(manifest["empty_transport_directories_at_preparation"], expected)
            self.assertIs(manifest["empty_directories_are_nonsemantic"], True)
            self.assertEqual(m.verify_prepared(self.root), manifest)
            shutil.rmtree(self.first / "working_case")
            self.assertEqual(m.verify_prepared(self.root), manifest)
            (self.first / "working_case" / "new_empty").mkdir(parents=True)
            self.assertEqual(m.verify_prepared(self.root), manifest)
        SCENARIOS.extend(["empty-only working_case tree accepted and recorded",
                          "empty-directory removal and addition do not change prepared artifact identity"])

    def test_unexpected_layout_matrix(self):
        def missing_seed(root, first):
            shutil.rmtree(first)
        def seed_file(root, first):
            shutil.rmtree(first); first.write_text("not a directory")
        def seed_symlink(root, first):
            target = root / "moved_seed"; first.rename(target); first.symlink_to(target, target_is_directory=True)
        def artifact_directory(root, first):
            p = first / "TRAIN.npz"; p.unlink(); p.mkdir()
        def artifact_symlink(root, first):
            p = first / "TRAIN.npz"; p.unlink(); p.symlink_to(first / "DEVELOPMENT.npz")
        def nested_file(root, first):
            p = first / "working_case" / "nested"; p.mkdir(parents=True); (p / "unarchived.json").write_text("retained evidence")
        def nested_link(root, first):
            p = first / "working_case"; p.mkdir(); (p / "linked_file").symlink_to(first / "TRAIN.npz")
        def nested_directory_link(root, first):
            p = first / "working_case"; p.mkdir(); target = root / "empty_target"; target.mkdir(); (p / "linked_dir").symlink_to(target, target_is_directory=True)
        cases = {
            "missing seed": missing_seed,
            "additional seed": lambda root, first: (root / "prepared" / "seed_999999").mkdir(),
            "seed regular file": seed_file,
            "seed symlink": seed_symlink,
            "missing required file": lambda root, first: (first / "TRAIN.npz").unlink(),
            "additional file": lambda root, first: (first / "extra.json").write_text("extra"),
            "additional empty directory": lambda root, first: (first / "extra_empty").mkdir(),
            "artifact directory": artifact_directory,
            "artifact symlink": artifact_symlink,
            "working_case regular file": lambda root, first: (first / "working_case").write_text("not empty"),
            "nested unarchived file": nested_file,
            "nested file symlink": nested_link,
            "nested directory symlink": nested_directory_link,
        }
        for index, (name, mutate) in enumerate(cases.items()):
            with self.subTest(name=name):
                root = self.base / f"rejected_{index}"; first = fixture(root)
                mutate(root, first)
                with self.assertRaises(ValueError): m.prepared_layout(root)
                SCENARIOS.append(name + " rejected")

    def test_prepared_and_native_root_rejections(self):
        for name in ("prepared", "native"):
            for kind in ("symlink", "broken_symlink", "regular_file"):
                with self.subTest(root=name, kind=kind):
                    root = self.base / f"root_{name}_{kind}"; fixture(root)
                    path = root / name
                    if path.exists(): shutil.rmtree(path)
                    target = root / "external"
                    if kind == "symlink":
                        target.mkdir(); path.symlink_to(target, target_is_directory=True)
                    elif kind == "broken_symlink": path.symlink_to(target, target_is_directory=True)
                    else: path.write_text("not a directory")
                    with self.assertRaises(ValueError): m.artifacts(root)
                    if name == "prepared":
                        with self.assertRaises(ValueError): m.prepared_layout(root)
                    SCENARIOS.append(name + " root " + kind + " rejected")

    def test_native_descendant_symlink_rejection(self):
        native = self.root / "native"; native.mkdir()
        (native / "fixture_binary").write_text("not executable; layout test only")
        (native / "alias").symlink_to(native / "fixture_binary")
        with self.assertRaises(ValueError): m.artifacts(self.root)
        SCENARIOS.append("native descendant symlink rejected")

    def test_verify_prepared_checks_layout_even_with_matching_hashes(self):
        with patch.object(m, "verify_preparing", return_value=start_record()):
            record = m.prepare_manifest(self.root)
            (self.first / "extra_empty").mkdir()
            self.assertEqual(record["artifacts_sha256"], m.artifacts(self.root))
            with self.assertRaises(ValueError): m.verify_prepared(self.root)
            (self.first / "extra_empty").rmdir()
            pending = self.first / "working_case"; pending.mkdir()
            (pending / "unarchived.json").write_text("not allowed")
            record["artifacts_sha256"] = m.artifacts(self.root)
            (self.root / "PREPARED.json").write_text(json.dumps(record))
            with self.assertRaises(ValueError): m.verify_prepared(self.root)
        SCENARIOS.extend(["verify_prepared rejects undeclared empty directory despite unchanged file hashes",
                          "verify_prepared rejects working file even if an index contains its hash"])


if __name__ == "__main__":
    output = Path(__file__).resolve().parent
    before = m.sha(m.HERE / "lifecycle.py")
    if before != EXPECTED: raise RuntimeError("Unexpected lifecycle revision")
    started = time.perf_counter_ns(); log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(LayoutTests))
    passed = result.wasSuccessful() and before == m.sha(m.HERE / "lifecycle.py") and SOURCES == m.sources()
    record = {"schema": "hepta.prepared-layout.review-tests.v6", "passed": passed,
              "completed_utc": datetime.now(timezone.utc).isoformat(), "tests": result.testsRun,
              "scenarios": SCENARIOS, "lifecycle_sha256": before, "sources_sha256": SOURCES,
              "test_source_sha256": m.sha(__file__), "wall_ns": time.perf_counter_ns() - started,
              "development_fixtures_only": True, "scientific_data_generated": False,
              "initial_preparing_verification_mocked_to_isolate_layout": True,
              "prepare_manifest_and_verify_prepared_executed_without_mocking": True,
              "stdout": log.getvalue()}
    write_json(output / "RESULT.json", record)
    print(log.getvalue(), end="")
    print(json.dumps({"passed": passed, "tests": result.testsRun, "scenarios": len(SCENARIOS)}))
    raise SystemExit(0 if passed else 1)
