"""New bounded process/recovery smoke for the exact recovered original binary."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import sys
import time

REPO = Path('/workspace/scratch/d831a963ef2f/hepta-analytic')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
from experiments.analytic_event_neuron.native_adapter import Native


def main():
    destination = ROOT / 'smoke_001'
    destination.mkdir(exist_ok=False)
    started = time.perf_counter_ns()
    cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    header = {'schema': 'hepta.analytic-event.recovered-native-smoke.v6',
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'original_binary_sha256': 'b519cae26325f818d9596aab34504490a0b5355b9eb633369878e6f07a50e179',
              'new_execution': True, 'new_build': False,
              'scope': 'Exact original sparse kernel and typed NeuronRuntime/SparseJournal research adapter; not an Agentd owner or production activation'}
    (destination / 'STARTED.json').write_text(json.dumps(header, indent=2) + '\n')
    binary = ROOT / 'restored/native/analytic_event'
    receipt = ROOT / 'restored/native/BUILD_RECEIPT.json'
    outputs, calls, ticks = {}, 0, 0
    error = None
    try:
        with Native(binary, receipt) as native:
            outputs['public_history'] = native.sparse_features(
                [-0.5, 0.0, 0.2, 0.1], [0.0, 0.5, 1.0, 1.5],
                [True, False, True, True], case='r6.recovered.native.history', obs_var=[0.64] * 4)
            assert outputs['public_history']['original_sparse_tick_calls'] == 4
            assert len(outputs['public_history']['features']) == 20
            digest = hashlib.sha256(b'r6.actual.readback.smoke').hexdigest()
            outputs['retained'] = native.tick_pair('r6.recovered.native.pair', digest, (1 << 24) // 8)
            outputs['reset'] = native.tick_pair('r6.recovered.native.pair', digest, (1 << 24) // 8, reset_before_readout=True)
            assert outputs['retained']['features'] != outputs['reset']['features']
            outputs['typed_initial'] = native.typed('r6.recovered.native.typed', destination / 'owner', 0.1, 0.7, -0.5, 0.5)
            first = outputs['typed_initial']
            assert first['sequence'] == 1 and not first['recovered']
            assert sum(first['head']['probabilities_q24']) == (1 << 24)
            outputs['typed_recovered'] = native.typed('r6.recovered.native.typed', destination / 'owner', 0.2, 0.8, -0.5, 0.5, expected_checkpoint=first['checkpoint_after'])
            second = outputs['typed_recovered']
            assert second['sequence'] == 2 and second['recovered']
            assert second['checkpoint_before'] == first['checkpoint_after']
            calls += native.calls
            ticks += native.original_sparse_ticks
        with Native(binary, receipt) as native:
            outputs['after_process_restart'] = native.typed('r6.recovered.native.typed', destination / 'owner', 0.3, 0.9, -0.5, 0.5, expected_checkpoint=second['checkpoint_after'])
            third = outputs['after_process_restart']
            assert third['sequence'] == 3 and third['recovered']
            assert third['checkpoint_before'] == second['checkpoint_after']
            before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (destination / 'owner').iterdir()}
            try:
                native.typed('r6.recovered.native.typed', destination / 'owner', 0.4, 1.0, -0.5, 0.5, expected_checkpoint='00' * 32)
            except ValueError as exc:
                outputs['stale_checkpoint_rejection'] = str(exc)
            else:
                raise AssertionError('Stale checkpoint was accepted')
            after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (destination / 'owner').iterdir()}
            assert before == after
            calls += native.calls
            ticks += native.original_sparse_ticks
        for key in ('public_history', 'retained', 'reset', 'typed_initial', 'typed_recovered', 'after_process_restart'):
            assert outputs[key]['authority'] == 'DENY_ALL'
        for key in ('typed_initial', 'typed_recovered', 'after_process_restart'):
            assert outputs[key]['abstain'] and outputs[key]['original_neuron_runtime'] and outputs[key]['original_sparse_journal']
    except Exception as exc:
        error = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        output_path = destination / 'OUTPUTS.json'
        output_path.write_text(json.dumps(outputs, indent=2, sort_keys=True) + '\n')
        after_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
        result = {**header, 'finished_utc': datetime.now(timezone.utc).isoformat(),
                  'passed': error is None, 'error': error, 'successful_native_requests': calls,
                  'original_sparse_ticks': ticks, 'stale_checkpoint_rejected_without_state_mutation': error is None,
                  'real_process_restart_verified': error is None,
                  'wall_ns': time.perf_counter_ns() - started,
                  'children_user_seconds': after_cpu.ru_utime - cpu.ru_utime,
                  'children_system_seconds': after_cpu.ru_stime - cpu.ru_stime,
                  'output_sha256': hashlib.sha256(output_path.read_bytes()).hexdigest(),
                  'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'native_energy': None, 'production_promotion': False}
        (destination / 'RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
        print(json.dumps(result))
    if error is not None:
        raise RuntimeError(error)


if __name__ == '__main__':
    main()
