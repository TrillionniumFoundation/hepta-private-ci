from pathlib import Path

template = Path('/tmp/aen-r3-readme-template.md').read_text()
replacements = {
'@@MILESTONES@@': '''| 工作包 | 已完成交付 | 本轮验收结果 |
| --- | --- | --- |
| 1．数学与事件合同 | 条件状态、物理时间、观察阶段、阈值、终点标签、首达诊断、静默／缺失、复位与有效域 | 合同固定；相同阈值 call／put 共享分布，所有 profile 明确边界 |
| 2．解析核与独立参照 | CDF／survival／log-tail、窄区间质量、解析梯度、传播、独立积分与退化分布 | 10/10 检查组通过；有限区间投影误差单列 |
| 3．可训练原型及机制对照 | 连续参数拟合、整数事件、probit／Gaussian、历史、原 sparse、直接量化及消融 | 参数确实改变；continuous 优于历史／原 sparse；event 非劣通过，优效未通过，匹配直接量化等价 |
| 4．带实际后续动作的任务 | 隐藏状态、噪声传感器、付费等待／修复／停止及最终交付评分 | 15 个主场景完整；反馈 analytic−numeric 的 +0.01 优效通过 |
| 5．实际 Hepta 反馈链 | 原 native binary、版本化 owner、text／PNG 交付回读、状态更新、动作与最终评分、原生重放 | 17,280 次反馈控制完整；实际损失、费用、请求、tick 和文件成本分项记录；未测成本明确为空 |
| 6．运行时与扩大研究 | Q24 预测头、状态恢复、跨进程延续、校准、12 窗口保留、漂移及重尾 | 五种子运行时资格全部通过；校准与保留联合门槛未通过；没有生产升级 |''',
'@@MAIN_RESULTS@@': '''Gaussian 确认包含 1,920 条独立轨迹。主统计以最终回读的实际误差和支付费用为准：

| 注册主比较 | 平均净效用差 | 98.333% 校正区间 | +0.01 优效 |
| --- | ---: | --- | --- |
| analytic − history | **+0.16740443** | **[+0.12264185, +0.21804070]** | **通过** |
| analytic − native | **+0.36430730** | **[+0.29757732, +0.43774180]** | **通过** |
| event_adaptive − analytic | −0.00010928 | [−0.00053775, +0.00028631] | 未通过 |

事件非劣是单列的事前判据：校正区间下界必须大于 −0.01，五个 seed 的均值也分别大于 −0.01。本轮两项均满足，因此 **event_adaptive 通过非劣**。它没有通过相对连续模型的优效门槛。

| 主任务策略 | 平均净效用 | 平均平方误差 | 平均实付费用 |
| --- | ---: | ---: | ---: |
| continuous analytic | 0.52602160 | 0.35644454 | 0.11753385 |
| adaptive event | 0.52591232 | 0.35655382 | 0.11753385 |
| fixed event | 0.52582474 | 0.35991223 | 0.11426302 |
| event without residual | 0.52752147 | 0.35537176 | 0.11710677 |
| retrained Round 2 event | 0.52696989 | 0.34819417 | 0.12483594 |
| history | 0.35861717 | 0.46139325 | 0.17998958 |
| original sparse | 0.16171430 | 0.62069716 | 0.21758854 |
| earlier stochastic pulse | −0.06391842 | 0.77852519 | 0.28539323 |''',
'@@MAIN_MECHANISM@@': '''机制核验覆盖三种定律：adaptive 与 continuous **动作分歧为 0、额外实付费用为 0、未认证决策为 0**；残余效用差来自量化交付误差。adaptive 与同网格 `event_direct` 的概率、动作、误差、费用及效用逐项精确相同。analytic 与等价 Gaussian 对照动作完全一致，最大数值差约 `1.07e-14`。

Gaussian 条件下，adaptive 相对本轮重新训练的 Round 2 编码，均值差为 −0.00105757，描述性 95% 区间为 [−0.01136187, +0.00721869]；相对 fixed 为 +0.00008758，区间 [−0.00285830, +0.00405940]；相对去残差版为 −0.00160915，区间 [−0.00598567, +0.00166411]。这些消融没有建立 adaptive 的效用优势。相对旧随机 pulse 的差为 +0.58983074，区间 [0.50675589, 0.69280834]，保留为次要描述结果。

Gaussian adaptive 共发送 **14,108 个包、2,868,039 个序列化字节、774,559 个逻辑单位事件**，平均每轨迹 7.3479 包、1,493.7703 字节、403.4161 单位事件；88 个 refinement 包，109 次精度重标定。跨三种定律合计 42,283 包、8,595,047 字节、2,331,691 单位事件、267 个 refinement 包和 335 次精度重标定。fixed 有 562 个未认证决策，去残差版有 10,003 个；未认证本身不等同于选择错误。

| 分布偏移（描述性） | analytic−history | analytic−native | adaptive−analytic |
| --- | --- | --- | --- |
| drift shift | +0.19758033；[0.16245827, 0.23438281] | +0.60922793；[0.50577160, 0.73833808] | −0.00004959；[−0.00045281, 0.00033614] |
| Student-t(4) | +0.19630414；[0.15431359, 0.23924441] | +0.36328900；[0.29519768, 0.44310621] | −0.00013801；[−0.00055611, 0.00023521] |

以上偏移区间为未经主比较家族调整的 95% 描述区间，没有据此宣布总体非劣。analytic 的初始 classwise ECE／95% coverage 在 Gaussian 为 0.01536／94.90%，漂移为 0.05973／89.32%，Student-t 为 0.01678／93.91%；动作收益与概率校准分别验收。''',
'@@COSTS@@': '''| 已完成流程的测量范围 | wall time | 已观测 CPU／native 工作量 |
| --- | ---: | --- |
| 主任务 15 scope 外层，含评价／重放／封存 | 2,622.518565 s | 成功评价与审计共 333,870 sparse ticks |
| 主任务 evaluation（嵌套） | 1,008.946063 s | parent CPU 972.286993 s；26,517 requests／172,590 ticks |
| 主任务 audit（嵌套） | 917.683909 s | 23,040 native requests／161,280 ticks |
| 反馈训练与开发 | 294.819240 s | parent CPU 206.496015 s；99,840 requests／192,000 ticks |
| 反馈确认 phase，含正式评价及重放 | 1,374.976404 s | controller CPU 238.387101 s；正式执行 93,633 ticks，重放同量 |
| 独立运行时资格 phase | 14.231647 s | controller CPU 4.427341 s；345 实际 native ticks |
| 主统计 CLI | 2.668662 s | 独立记录，未重新生成科学数据 |
| 反馈统计 CLI | 10.007976 s | 独立记录，未重新生成科学数据 |

反馈训练、正式执行和重放已覆盖 214,842 次成功请求、379,266 ticks，另有运行时资格 345 ticks。正式反馈的 93,633 ticks 分为 21,369 typed 与 72,264 sparse。policy worker 的 964.508991 s wall／567.491110 s CPU、反馈 audit 的 356.264438 s，以及 runtime native IPC 的 1.618615 s 都是各自外层过程内的嵌套测量。

主任务实际重开 284,084 次观察、产生 629,684 个传输文件；主确认归档共 211,270,461 bytes、652,874 个成员（包含 15 个成员清单）。运行时 journal 写入的记录字节为 160,080，885 个 owner 证据文件压缩为 504,363 bytes；底层存储写放大未测。

初始 MAIN 失败尝试和开发反馈 seed701 失败尝试的完整 wall／CPU／native 调用数未能记录，均保留 `null`，不是零。**86,400 是完成的注册主控制执行数；全部尝试的额外执行总数未知。** MAIN 恢复调用外层 507.519157 s 与最后三个成功 scope 的 498.018047 s 重叠，不另加到 2,622.518565 s。恢复过程树的 Linux `RUSAGE_CHILDREN` 为 user 368.910295 s、system 106.799103 s，不能解释为原 native 单独 CPU。

完整账本见 [MAIN_EXECUTION_COSTS.json](evidence/results/MAIN_EXECUTION_COSTS.json)、[FEEDBACK_RUNTIME_ACCOUNTING.json](evidence/results/FEEDBACK_RUNTIME_ACCOUNTING.json)、[FEEDBACK_EXECUTION_COSTS.json](evidence/results/FEEDBACK_EXECUTION_COSTS.json)、[RUNTIME_EXECUTION_COSTS.json](evidence/results/RUNTIME_EXECUTION_COSTS.json)。''',
'@@REVIEW_TOTALS@@': '''| 独立复核 | 成功断言／核验范围 | 结果 |
| --- | --- | --- |
| 主任务 | 6,310,624 个断言；15 场景；172,800 个 PNG 独立解码；全部主／次／OOD 统计重算 | 通过；最大统计差 `1.11e-16` |
| 反馈／运行时／成本 | 4,540,562 个断言；315,155 个反馈归档成员；62,165 次 PNG 交付；885 个 runtime 成员；3,357 个失败开发成员 | 通过；8 组各 4,000 次 bootstrap 独立复算，最大差 `1.39e-17` |
| 校准／保留 | 25,946 个断言；60 窗口；20 组 bootstrap 重算；最大均值差 `2.66e-15` | 通过；统计最大差 `9.71e-17` |

独立主复核见 [MAIN_CONFIRMATION_REVIEW.json](evidence/MAIN_CONFIRMATION_REVIEW.json)，反馈／运行时复核见 [FEEDBACK_RUNTIME_INDEPENDENT_REVIEW.json](evidence/results/reviews/FEEDBACK_RUNTIME_INDEPENDENT_REVIEW.json)。独立 reviewer 读取并重建全部交付证据；真实 native 推理重放由冻结执行审计完成，两层各有独立收据。''',
}
for marker, text in replacements.items():
    assert template.count(marker) == 1, marker
    template = template.replace(marker, text)
template = template.replace('190,080 个期限测量、86,400 次控制执行', '190,080 个期限测量、86,400 次完成的注册控制执行')
template = template.replace('确认数据没有重新生成。后续为缓解', '这些归档恢复没有重新生成科学数据。后续为缓解')
template = template.replace('资源与复核问题全部留痕：', '''MAIN 操作中断单独保留：第一次 `seed_1009_gaussian` 在共享磁盘耗尽期间退出；原日志在异常堆栈中截断，具体异常类型及 errno 没有记录。失败尝试的 **43,132 个原文件**、原始日志及身份清单完整封存。完成封存后使用原冻结 CLI 在同一个 seed 下恢复，前 12 个完成 scope 不重跑。恢复执行重新调用确定性数据生成器，但最终 `DATA.npz`、`DATASET.json`、全部轨迹 ID、dataset digest 和 `MODELS.json` 与失败尝试逐字节一致；独立复核又从最终完成归档验证了这些身份。失败尝试不计入效用估计，也不增加独立样本量；额外未测成本单列。

资源与复核问题全部留痕：''')
template = template.replace('本轮完成数学合同、', '本轮把受控隐藏状态任务与实际 native 计算、文件交付／回读链结合，完成数学合同、', 1)
target = Path('/workspace/scratch/d831a963ef2f/hepta-analytic/experiments/analytic_event_neuron/round3/README.md')
target.write_text(template)
print(target, len(template.encode()), 'remaining restoration marker', template.count('@@RESTORATION@@'))
