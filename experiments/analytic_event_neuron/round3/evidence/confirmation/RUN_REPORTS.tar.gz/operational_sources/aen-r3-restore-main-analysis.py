"""Package existing main analysis and reproduce frozen statistics after safe restore."""

import datetime
import hashlib
import json
from pathlib import Path
import resource
import stat
import subprocess
import sys
import tempfile
import time

from experiments.analytic_event_neuron.round3 import freeze
from experiments.analytic_event_neuron.round3.evidence.package_evidence import package
from experiments.analytic_event_neuron.round2.restore_evidence import (
    materialize, restore, verify_members,
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


repo = Path("/workspace/scratch/d831a963ef2f/hepta-analytic")
run = Path("/tmp/aen-round3-20261028")
restored = Path("/tmp/aen-round3-restore-check/run")
output = Path("/tmp/aen-r3-main-analysis-archives.json")
receipt = run / "archival_reviews/MAIN_ANALYSIS_RESTORE_AND_RECOMPUTE.json"
log = run / "archival_reviews/MAIN_ANALYSIS_RECOMPUTE.log"
if any(path.exists() for path in (output, receipt, log, restored / "main", restored / "MAIN_RESULTS.json")):
    raise FileExistsError("Refusing to overwrite an existing analysis restore or its receipts")
created = datetime.datetime.now(datetime.timezone.utc).isoformat()
frozen = freeze.verify(restored)
if sha(restored / "FREEZE.json") != sha(run / "FREEZE.json"):
    raise ValueError("Restored freeze identity differs from the original")
index = json.loads((run / "main/RUN_INDEX.json").read_text())
if not index["complete"] or len(index["scopes"]) != 15:
    raise ValueError("Only complete registered main study may be restored")
paths = ["main/RUN_INDEX.json", *[entry["analysis"] for entry in index["scopes"]]]
if len(paths) != len(set(paths)) or len(paths) != 16:
    raise ValueError("Analysis inventory must be exactly 15 scopes and one index")
for entry in index["scopes"]:
    if sha(run / entry["analysis"]) != entry["analysis_sha256"] or not entry["audit_passed"]:
        raise ValueError("Changed or unaudited analysis")
original = {relative: sha(run / relative) for relative in sorted(paths)}
modes = {relative: stat.S_IMODE((run / relative).stat().st_mode) for relative in paths}
descriptor = package(run, paths, repo,
    repo / "experiments/analytic_event_neuron/round3/evidence/confirmation", "MAIN_ANALYSIS")
write(output, [descriptor])
with tempfile.TemporaryDirectory(prefix="aen-r3-main-analysis-materialize-") as temporary:
    archive = materialize(repo, descriptor, Path(temporary))
    expected = verify_members(archive, descriptor["member_manifest"])
    if expected != original:
        raise ValueError("Bundle member set or bytes differ from original analysis")
    restore(archive, restored, descriptor["member_manifest"], expected)
for relative in paths:
    if sha(restored / relative) != original[relative]:
        raise ValueError("Restored analysis bytes differ")
    if stat.S_IMODE((restored / relative).stat().st_mode) != modes[relative]:
        raise ValueError("Restored analysis file mode differs")
freeze.verify(restored)
command = [sys.executable, "-m", "experiments.analytic_event_neuron.round3.statistics",
           "--run-dir", str(restored)]
log.parent.mkdir(parents=True, exist_ok=True)
start = time.perf_counter_ns()
before = resource.getrusage(resource.RUSAGE_CHILDREN)
with log.open("xb") as sink:
    process = subprocess.run(command, cwd=repo, stdout=sink, stderr=subprocess.STDOUT)
elapsed = time.perf_counter_ns() - start
after = resource.getrusage(resource.RUSAGE_CHILDREN)
if process.returncode != 0:
    raise RuntimeError("Frozen statistics failed; retained recomputation log: " + str(log))
result = restored / "MAIN_RESULTS.json"
same_bytes = result.read_bytes() == (run / "MAIN_RESULTS.json").read_bytes()
same_content = json.loads(result.read_text()) == json.loads((run / "MAIN_RESULTS.json").read_text())
if not same_bytes or not same_content:
    raise ValueError("Restored frozen statistics do not exactly reproduce the original")
freeze.verify(restored)
freeze.verify(run)
if original != {relative: sha(run / relative) for relative in sorted(paths)}:
    raise ValueError("Original analysis changed during packaging/restoration")
document = {
    "schema": "hepta.analytic-event.round3.main-analysis-restore-recompute.v1",
    "created_utc": created,
    "completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_commit": frozen["source_commit"],
    "passed": True,
    "archive": descriptor,
    "descriptor_file": str(output),
    "descriptor_sha256": sha(output),
    "source_analysis_and_index_bytes": sum((run / relative).stat().st_size for relative in paths),
    "restored_destination": str(restored),
    "restored_members": len(expected),
    "all_member_bytes_exact": True,
    "all_member_modes_exact": True,
    "member_sha256": original,
    "original_inputs_unchanged": True,
    "frozen_sources_verified": len(frozen["sources_sha256"]),
    "frozen_prepared_artifacts_verified": len(frozen["artifacts_sha256"]),
    "freeze_sha256": sha(restored / "FREEZE.json"),
    "freeze_verified_before_and_after_recompute": True,
    "prepared_storage": "Previously actually restored prepared artifacts were later deduplicated into exact-hash hardlinks to immutable originals; see RESTORED_COPY_DEDUPLICATION.json.",
    "analysis_storage": "New ordinary files extracted from the byte-verified archive by the existing safe restorer.",
    "safe_restore_source": "experiments/analytic_event_neuron/round2/restore_evidence.py",
    "safe_restore_source_sha256": sha(repo / "experiments/analytic_event_neuron/round2/restore_evidence.py"),
    "recompute": {
        "command": command,
        "returncode": process.returncode,
        "wall_ns": elapsed,
        "child_user_cpu_seconds": after.ru_utime - before.ru_utime,
        "child_system_cpu_seconds": after.ru_stime - before.ru_stime,
        "log_relative_to_run": str(log.relative_to(run)),
        "log_sha256": sha(log),
        "original_result_sha256": sha(run / "MAIN_RESULTS.json"),
        "restored_result_sha256": sha(result),
        "result_bytes_exact": same_bytes,
        "result_json_content_exact": same_content,
    },
    "scientific_data_regenerated": False,
    "model_fitting_performed": False,
    "native_inference_rerun": False,
    "archive_statistics_dependency": "Frozen statistics require the restored analysis, complete index and verified prepared/source bindings; original full main execution archives are not read by this recomputation.",
    "driver_source_sha256": sha(Path(__file__)),
}
write(receipt, document)
print(json.dumps({"passed": True, "archive_bytes": descriptor["bytes"],
    "restored_members": len(expected), "sources": len(frozen["sources_sha256"]),
    "prepared": len(frozen["artifacts_sha256"]), "result_sha256": sha(result),
    "receipt_sha256": sha(receipt), "statistics_wall_ns": elapsed}), flush=True)
