"""Run only after the parent explicitly authorizes the planned full-scope restore."""

import datetime
import hashlib
import json
from pathlib import Path
import os
import stat
import tarfile
import tempfile
import time

from experiments.analytic_event_neuron.round3 import freeze
from experiments.analytic_event_neuron.round2.restore_evidence import (
    file_sha, restore, verify_members,
)


run = Path("/tmp/aen-round3-20261028")
scope = "seed_607_gaussian"
archive = run / "main/archives" / (scope + ".tar.gz")
plan_path = run / "archival_reviews/MAIN_FULL_SCOPE_RESTORE_PLAN.json"
receipt = run / "archival_reviews/MAIN_FULL_SCOPE_RESTORE.json"
plan = json.loads(plan_path.read_text())
if receipt.exists():
    raise FileExistsError("Refusing to overwrite a completed full-scope restore receipt")
filesystem = os.statvfs("/tmp")
free_before = filesystem.f_bfree * filesystem.f_frsize
if free_before < plan["recommended_free_bytes_with_32MiB_margin"]:
    raise RuntimeError("Insufficient current free blocks for the planned safe extraction")
if filesystem.f_ffree < plan["required_new_inodes_estimate"] + 1000:
    raise RuntimeError("Insufficient free inodes for the planned safe extraction")
started = time.perf_counter_ns()
created = datetime.datetime.now(datetime.timezone.utc).isoformat()
frozen = freeze.verify(run)
if file_sha(archive) != plan["registered_archive_sha256"]:
    raise ValueError("Original completed scope archive changed")
review_path = run / "independent_main_review" / (scope + ".json")
review = json.loads(review_path.read_text())
if not review["passed"] or review["archive_sha256"] != file_sha(archive):
    raise ValueError("Full-scope restore must use the independently reviewed archive bytes")
expected = verify_members(archive, "ARCHIVE_MANIFEST.json")
with tarfile.open(archive, "r:gz") as source:
    modes = {member.name: stat.S_IMODE(member.mode) for member in source if member.isfile()}
    manifest_sha = hashlib.sha256(source.extractfile("ARCHIVE_MANIFEST.json").read()).hexdigest()
if len(expected) != plan["data_files_excluding_manifest"] or len(modes) != plan["archive_files_including_manifest"]:
    raise ValueError("Planned member count differs from the verified source")
all_hashes = {**expected, "ARCHIVE_MANIFEST.json": manifest_sha}
with tempfile.TemporaryDirectory(prefix="aen-r3-main-full-scope-") as temporary:
    destination = Path(temporary) / scope
    restore(archive, destination, "ARCHIVE_MANIFEST.json", expected)
    for relative, digest in all_hashes.items():
        member = destination / relative
        if file_sha(member) != digest:
            raise ValueError("Actual extracted member bytes differ")
        if stat.S_IMODE(member.stat().st_mode) != modes[relative]:
            raise ValueError("Actual extracted member mode differs")
    observed_files = {str(path.relative_to(destination)) for path in destination.rglob("*") if path.is_file()}
    if observed_files != set(all_hashes):
        raise ValueError("Actual extracted file set differs")
    allocated_data = sum((destination / relative).stat().st_blocks * 512 for relative in all_hashes)
    directories = [destination, *[path for path in destination.rglob("*") if path.is_dir()]]
    allocated_directories = sum(path.stat().st_blocks * 512 for path in directories)
    actual_destination = str(destination)
    directory_count = len(directories)
freeze.verify(run)
if file_sha(archive) != plan["registered_archive_sha256"]:
    raise ValueError("Source archive changed during restoration")
record = {
    "schema": "hepta.analytic-event.round3.main-full-scope-restore.v1",
    "passed": True,
    "created_utc": created,
    "completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "wall_ns": time.perf_counter_ns() - started,
    "source_commit": frozen["source_commit"],
    "scope": scope,
    "representative_full_scope_actual_extractions": 1,
    "all_registered_main_scopes_actually_extracted_by_this_check": False,
    "full_scope_coverage_note": "All 15 completed main scopes have separate full member-hash checks and frozen inference/native replay. This additional check physically extracts one representative complete scope only.",
    "archive_sha256": file_sha(archive),
    "archive_bytes": archive.stat().st_size,
    "independent_review_sha256": file_sha(review_path),
    "plan_sha256": file_sha(plan_path),
    "actual_safe_restore_performed": True,
    "restored_destination": actual_destination,
    "data_members_excluding_manifest": len(expected),
    "all_extracted_files_including_manifest": len(all_hashes),
    "directory_count_including_scope_root": directory_count,
    "all_member_bytes_exact": True,
    "all_member_modes_exact": True,
    "actual_allocated_data_bytes": allocated_data,
    "actual_allocated_directory_bytes": allocated_directories,
    "free_bytes_before_extraction": free_before,
    "temporary_restore_removed_after_verification": True,
    "original_archive_unchanged_and_retained": True,
    "frozen_sources_verified": len(frozen["sources_sha256"]),
    "frozen_prepared_artifacts_verified": len(frozen["artifacts_sha256"]),
    "scientific_data_regenerated": False,
    "model_fitting_performed": False,
    "native_inference_rerun": False,
    "safe_restore_source_sha256": file_sha(freeze.BASE / "round2/restore_evidence.py"),
    "driver_source_sha256": file_sha(Path(__file__)),
}
with receipt.open("x") as output:
    json.dump(record, output, sort_keys=True, indent=2)
    output.write("\n")
print(json.dumps({"passed": True, "scope": scope, "data_members": len(expected),
    "files_including_manifest": len(all_hashes), "allocated_data_bytes": allocated_data,
    "allocated_directory_bytes": allocated_directories, "receipt_sha256": file_sha(receipt)}), flush=True)
