(async () => {
  const q = s => "'" + s.replace(/'/g, "'\\''") + "'";
  const repo = "TrillionniumFoundation/hepta-private-ci";
  const root = "/workspace/scratch/d831a963ef2f/hepta-analytic/";
  async function py(code, maximum = 24000) {
    let value = await tools.exec_command({cmd: "python -c " + q(code), max_output_tokens: maximum});
    let output = value.output;
    while (value.session_id && value.exit_code === undefined) {
      value = await tools.write_stdin({session_id: value.session_id, chars: "", yield_time_ms: 1000, max_output_tokens: maximum});
      output += value.output;
    }
    if (value.exit_code !== 0) throw Error(JSON.stringify(value));
    return output.trim();
  }
  const job = JSON.parse(await py("from pathlib import Path; print(Path('/tmp/aen-r3-publish-job.json').read_text())"));
  const plan = job.files;
  const state = JSON.parse(await py("from pathlib import Path; print(Path('/tmp/aen-r3-publication-state.json').read_text())", 50000));
  async function save() {
    await py("from pathlib import Path; import os; p=Path('/tmp/aen-r3-publication-state.json.tmp'); p.write_text(" + JSON.stringify(JSON.stringify(state) + "\n") + "); os.replace(p, '/tmp/aen-r3-publication-state.json')");
  }
  if (!plan.length) { text({no_new_blobs: true, head: state.head}); return; }
  for (const file of plan) {
    if (state.blobs[file.path] === file.git_sha) continue;
    const chunks = [];
    for (let start = 0; start < file.bytes; start += 2400000) {
      const offsets = [];
      for (let offset = start; offset < Math.min(start + 2400000, file.bytes); offset += 300000) offsets.push(offset);
      const result = await Promise.allSettled(offsets.map(offset => py(
        "from pathlib import Path; import base64; f=Path(" + JSON.stringify(root + file.path) + ").open('rb'); f.seek(" + offset + "); print(base64.b64encode(f.read(300000)).decode())", 400000)));
      for (const item of result) {
        if (item.status !== "fulfilled") throw item.reason;
        chunks.push(item.value);
      }
    }
    const content = chunks.join("");
    if (content.length !== 4 * Math.ceil(file.bytes / 3)) throw Error("Unexpected base64 length: " + file.path);
    const blob = await tools.mcp__codex_apps__github_create_blob({repository_full_name: repo, content, encoding: "base64"});
    if (blob.structuredContent?.sha !== file.git_sha) throw Error("Git blob hash mismatch: " + file.path);
    state.blobs[file.path] = file.git_sha;
    await save();
    notify({uploaded: file.path, bytes: file.bytes});
  }
  const treeResult = await tools.mcp__codex_apps__github_create_tree({repository_full_name: repo, base_tree_sha: state.tree,
    tree_elements: plan.map(file => ({path: file.path, mode: "100644", type: "blob", sha: file.git_sha}))});
  const tree = treeResult.structuredContent?.sha;
  if (!tree) throw Error(JSON.stringify(treeResult));
  const commitResult = await tools.mcp__codex_apps__github_create_commit({repository_full_name: repo, parent_sha: state.head, tree_sha: tree, message: job.message});
  const head = commitResult.structuredContent?.sha;
  if (!head) throw Error(JSON.stringify(commitResult));
  const update = await tools.mcp__codex_apps__github_update_ref({repository_full_name: repo,
    branch_name: "research/analytic-event-neuron-20261027", expected_sha: state.head, sha: head, force: false});
  if (update.isError || update.structuredContent?.success !== true) throw Error(JSON.stringify(update));
  state.commits.push({sha: head, tree, message: job.message, files: plan.map(file => file.path)});
  state.head = head; state.tree = tree;
  await save();
  text({head, tree, files: plan.length, bytes: plan.reduce((total, file) => total + file.bytes, 0)});
})()
