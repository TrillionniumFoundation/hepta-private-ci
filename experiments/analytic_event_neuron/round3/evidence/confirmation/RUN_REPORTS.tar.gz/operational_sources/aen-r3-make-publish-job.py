"""Build a publication job from exact completed artifact paths."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--manifest', action='append', default=[])
p.add_argument('--path', action='append', default=[])
p.add_argument('--message', required=True)
a = p.parse_args()
root = Path('/workspace/scratch/d831a963ef2f/hepta-analytic')
state = json.loads(Path('/tmp/aen-r3-publication-state.json').read_text())
paths = list(a.path)
for manifest in a.manifest:
    document = json.loads(Path(manifest).read_text())
    for logical in (document['archives'] if isinstance(document, dict) else document):
        paths.extend(item['path'] for item in logical.get('parts', [logical]))
files = []
for relative in dict.fromkeys(paths):
    path = root / relative
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Path outside repository')
    if not path.exists():
        if relative not in state['blobs']:
            raise FileNotFoundError(path)
        continue
    data = path.read_bytes()
    git_sha = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if state['blobs'].get(relative) == git_sha:
        continue
    files.append({'path': relative, 'bytes': len(data), 'git_sha': git_sha,
                  'sha256': hashlib.sha256(data).hexdigest()})
job = {'message': a.message, 'files': files}
Path('/tmp/aen-r3-publish-job.json').write_text(json.dumps(job, indent=2) + '\n')
print(json.dumps({'new_blobs': len(files), 'bytes': sum(f['bytes'] for f in files), 'message': a.message}))
