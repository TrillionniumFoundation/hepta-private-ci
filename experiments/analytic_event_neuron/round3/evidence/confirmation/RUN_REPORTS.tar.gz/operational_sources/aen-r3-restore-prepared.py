from pathlib import Path
import hashlib
import json
import shutil
import tempfile
import time
from experiments.analytic_event_neuron.round3.evidence.package_evidence import package, sha
from experiments.analytic_event_neuron.round2.restore_evidence import materialize, verify_members, restore
from experiments.analytic_event_neuron.round3.freeze import verify

root = Path('/tmp/aen-round3-20261028')
repo = Path('/workspace/scratch/d831a963ef2f/hepta-analytic')
destination = Path('/tmp/aen-round3-restore-check/run')
registration = json.loads(Path('/tmp/aen-r3-preconfirmation-archives.json').read_text())
publication = json.loads(Path('/tmp/aen-r3-publication-state.json').read_text())
frozen = verify(root)
rows = []
started = time.perf_counter_ns()
for item in registration:
    if not item['name'].startswith('FEEDBACK_PREPARED_'):
        continue
    seed = item['name'].split('_')[-1]
    all_present = all((repo / part['path']).exists() for part in item['parts'])
    reconstructed = False
    if not all_present:
        if any((repo / part['path']).exists() for part in item['parts']):
            raise ValueError('Unexpected incomplete physical copy')
        actual = package(root, [f'feedback_prepared/seed_{seed}'], repo,
                         repo / 'experiments/analytic_event_neuron/round3/evidence/preconfirmation', item['name'])
        if actual != item:
            raise ValueError('Repackaging differs from the preconfirmation published bytes')
        reconstructed = True
    for part in item['parts']:
        payload = (repo / part['path']).read_bytes()
        git = hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()
        if publication['blobs'].get(part['path']) != git:
            raise ValueError('Physical copy differs from published Git blob')
    with tempfile.TemporaryDirectory(prefix='aen-r3-prepared-restore-') as temporary:
        archive = materialize(repo, item, Path(temporary))
        expected = verify_members(archive, item['member_manifest'])
        restore(archive, destination, item['member_manifest'], expected)
    removed = []
    if reconstructed:
        for part in item['parts']:
            (repo / part['path']).unlink()
            removed.append(part)
    rows.append({'name': item['name'], 'archive_sha256': item['sha256'],
        'restored_files': len(expected), 'missing_copy_reconstituted_exactly_from_frozen_members': reconstructed,
        'exact_published_part_bytes_verified': True, 'reconstituted_part_copies_removed_after_restore': removed})
    print(json.dumps({'prepared_archive_restored': item['name'], 'data_files': len(expected)}), flush=True)
shutil.copyfile(root / 'FREEZE.json', destination / 'FREEZE.json')
restored = verify(destination)
verify(root)
receipt = {'schema': 'hepta.analytic-event.round3.preparation-restoration.v1', 'passed': True,
    'source_commit': restored['source_commit'], 'physical_source_commit': frozen['source_commit'],
    'frozen_sources_verified': len(restored['sources_sha256']),
    'frozen_prepared_artifacts_restored_and_verified': len(restored['artifacts_sha256']),
    'source_and_original_prepared_bytes_unchanged': True, 'scientific_data_regenerated': False,
    'core_and_calibration_restore_log_sha256': sha('/tmp/aen-r3-core-restore.log'),
    'feedback_preparation_archives': rows, 'actual_restore_destination': str(destination),
    'script_sha256': sha(__file__), 'wall_ns': time.perf_counter_ns() - started}
(root / 'reviews/PREPARED_RESTORATION.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps({'passed': True, 'frozen_artifacts_restored': len(restored['artifacts_sha256']), 'frozen_sources_verified': len(restored['sources_sha256'])}), flush=True)
