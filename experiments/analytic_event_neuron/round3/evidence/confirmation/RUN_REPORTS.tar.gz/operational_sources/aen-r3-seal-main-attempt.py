"""Seal an already terminated partial main attempt without changing science."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

REPO = Path('/workspace/scratch/d831a963ef2f/hepta-analytic')
RUN = Path('/tmp/aen-round3-20261028')
sys.path.insert(0, str(REPO))
from experiments.analytic_event_neuron import task
from experiments.analytic_event_neuron.round3 import freeze
from experiments.analytic_event_neuron.round3.evidence.package_evidence import package, sha
from experiments.analytic_event_neuron.run import load_data

scope = 'seed_1009_gaussian'
canonical = RUN / 'main/unpacked' / scope
sealed = RUN / 'operational_attempts/main_seed_1009_gaussian_attempt1'
producer_log = Path('/tmp/aen-r3-main-confirmation.log')
descriptor_path = Path('/tmp/aen-r3-main-operational-archives.json')
receipt_path = RUN / 'MAIN_OPERATIONAL_RECOVERY.json'
if not canonical.is_dir() or sealed.exists() or receipt_path.exists() or descriptor_path.exists():
    raise ValueError('Expected exactly one untouched failed canonical attempt')
verified = freeze.verify(RUN)
index_path = RUN / 'main/RUN_INDEX.json'
index_bytes = index_path.read_bytes()
index = json.loads(index_bytes)
if len(index['scopes']) != 12 or index['complete'] or any(e['scope'] == scope for e in index['scopes']):
    raise ValueError('Completed index is not the declared 12-scope checkpoint')
completed = []
for entry in index['scopes']:
    if (sha(RUN / entry['archive']) != entry['archive_receipt']['sha256']
            or sha(RUN / entry['analysis']) != entry['analysis_sha256'] or not entry['audit_passed']):
        raise ValueError('Completed artifact changed: ' + entry['scope'])
    completed.append({'scope': entry['scope'], 'archive_sha256': entry['archive_receipt']['sha256'],
                      'analysis_sha256': entry['analysis_sha256']})
original = {}
directories = []
for path in sorted(canonical.rglob('*')):
    if path.is_symlink():
        raise ValueError('Unexpected symbolic link in failed attempt')
    relative = path.relative_to(canonical).as_posix()
    if path.is_dir():
        directories.append({'path': relative, 'mode': path.stat().st_mode & 0o777})
    elif path.is_file():
        original[relative] = {'sha256': sha(path), 'bytes': path.stat().st_size,
                              'mode': path.stat().st_mode & 0o777}
    else:
        raise ValueError('Unexpected special file in failed attempt')
if any('__pycache__' in Path(name).parts for name in original):
    raise ValueError('Packager would exclude a file; preserve it explicitly first')
data = load_data(canonical / 'DATA.npz')
metadata = json.loads((canonical / 'DATASET.json').read_text())
if (data['seed'] != 32001009 or data['split'] != 'confirmation' or data['law'] != 'gaussian'
        or len(data['ids']) != 384 or metadata['dataset_digest'] != task.dataset_digest(data)
        or metadata['npz_sha256'] != original['DATA.npz']['sha256']
        or original['MODELS.json']['sha256'] != verified['artifacts_sha256']['training/seed_1009/MODELS.json']):
    raise ValueError('Failed attempt data/model identity does not match frozen registration')
log_bytes = producer_log.read_bytes()
log_sha = hashlib.sha256(log_bytes).hexdigest()
stat = os.statvfs(RUN)
before = {'schema': 'hepta.analytic-event.round3.failed-main-attempt.v1',
    'recorded_utc': datetime.now(timezone.utc).isoformat(), 'scope': scope, 'attempt': 1,
    'source_commit': verified['source_commit'], 'freeze_sha256': sha(RUN / 'FREEZE.json'),
    'frozen_sources_verified': len(verified['sources_sha256']),
    'frozen_prepared_artifacts_verified': len(verified['artifacts_sha256']),
    'index_sha256': hashlib.sha256(index_bytes).hexdigest(), 'completed_scopes': completed,
    'reported_producer_exit_code': 1, 'exit_code_provenance': 'Parent observed original session30811 completion',
    'exception_class': None, 'exception_errno': None, 'exception_final_message': None,
    'failure_interpretation': 'Failure coincided with observed shared-disk exhaustion; original final exception line is absent from retained log, so exact causal exception remains unknown.',
    'producer_log': {'original_path': str(producer_log), 'sha256': log_sha, 'bytes': len(log_bytes),
                     'ends_with_newline': log_bytes.endswith(b'\n'), 'tail_verbatim': log_bytes[-1000:].decode('utf-8', errors='replace')},
    'original_files': original, 'original_directories': directories,
    'original_file_count': len(original), 'original_file_bytes': sum(v['bytes'] for v in original.values()),
    'zero_byte_files': [name for name, value in original.items() if value['bytes'] == 0],
    'possibly_truncated_files_preserved_without_normalization': True,
    'data_identity': {'data_seed': data['seed'], 'split': data['split'], 'law': data['law'],
        'trajectories': len(data['ids']), 'npz_sha256': original['DATA.npz']['sha256'],
        'dataset_sha256': task.dataset_digest(data), 'dataset_metadata_sha256': original['DATASET.json']['sha256'],
        'model_file_sha256': original['MODELS.json']['sha256'], 'first_id': str(data['ids'][0]),
        'last_id': str(data['ids'][-1]),
        'ids_sha256': hashlib.sha256(json.dumps(data['ids'].tolist(), separators=(',', ':')).encode()).hexdigest()},
    'failed_attempt_costs': {'native_requests': None, 'native_ticks': None, 'wall_ns': None,
        'parent_cpu_ns': None, 'child_cpu_ns': None, 'reason': 'Execution exited before a completed instrumentation receipt; unmeasured values are unknown, not zero.'},
    'available_file_system_free_bytes_at_inspection': stat.f_bfree * stat.f_frsize,
    'included_in_utility_estimation': False, 'new_independent_sample': False,
    'scientific_source_models_seeds_or_gates_changed': False}
sealed.parent.mkdir(parents=True, exist_ok=True)
canonical.rename(sealed)
if canonical.exists():
    raise AssertionError('Atomic rename did not clear canonical failed path')
(sealed / 'OPERATIONAL_PRODUCER_LOG.raw').write_bytes(log_bytes)
(sealed / 'OPERATIONAL_COMPLETED_INDEX.json').write_bytes(index_bytes)
(sealed / 'OPERATIONAL_FAILURE_STATE.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
shutil.copy2(__file__, sealed / 'OPERATIONAL_SEAL_SCRIPT.py')
for name, expected in original.items():
    if sha(sealed / name) != expected['sha256'] or (sealed / name).stat().st_size != expected['bytes']:
        raise ValueError('Failed file changed during inspection/rename: ' + name)
descriptor = package(RUN, [sealed.relative_to(RUN).as_posix()], REPO,
    REPO / 'experiments/analytic_event_neuron/round3/evidence/operational',
    'main_seed_1009_gaussian_attempt1', restore_root='run')
if descriptor['data_members'] != len(original) + 4 or not descriptor['all_member_hashes_verified']:
    raise ValueError('Not every failed file plus recovery metadata was archived')
descriptor_path.write_text(json.dumps([descriptor], indent=2, sort_keys=True) + '\n')
if index_path.read_bytes() != index_bytes or producer_log.read_bytes() != log_bytes:
    raise ValueError('Index or original producer log changed during sealing')
freeze.verify(RUN)
shutil.rmtree(sealed)
if canonical.exists() or sealed.exists():
    raise AssertionError('Failed-attempt temporary paths were not cleared')
receipt = {**{k: v for k, v in before.items() if k not in ('original_files', 'original_directories')},
    'schema': 'hepta.analytic-event.round3.main-operational-recovery.v1',
    'archive': descriptor, 'original_inventory_member': 'operational_attempts/main_seed_1009_gaussian_attempt1/OPERATIONAL_FAILURE_STATE.json',
    'canonical_failed_path': str(canonical), 'canonical_failed_path_cleared': True,
    'atomic_rename_before_packaging': True, 'all_original_failed_files_retained': True,
    'archive_verified_before_deleting_uncompressed_failed_attempt': True,
    'completed_index_unchanged': True, 'original_log_unchanged': True,
    'producer_restarted_by_this_script': False,
    'resumption': 'Parent may use original frozen CLI. It verifies and skips the12 indexed scopes and retries the same registered seed1009 Gaussian task in a fresh canonical directory.',
    'completed_utc': datetime.now(timezone.utc).isoformat()}
receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'receipt_path': str(receipt_path), 'receipt_sha256': sha(receipt_path),
                  'descriptor_path': str(descriptor_path), 'archive': descriptor,
                  'data_identity': before['data_identity'], 'original_file_count': len(original),
                  'zero_byte_file_count': len(before['zero_byte_files'])}, sort_keys=True), flush=True)
