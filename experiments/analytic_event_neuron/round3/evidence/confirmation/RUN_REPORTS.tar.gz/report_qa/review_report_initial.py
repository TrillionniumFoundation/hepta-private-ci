"""Report-only numeric QA of retained pre-edit snapshots; no scientific execution."""
from pathlib import Path
import hashlib
import json
R=Path('/tmp/aen-round3-20261028');Q=R/'report_qa'
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=load(R/'FEEDBACK_RESULTS.json');c=load(R/'calibration_confirmation/RESULTS.json');r=load(R/'RUNTIME_RESULTS.json')
cost=load(R/'reviews/FEEDBACK_RUNTIME_ACCOUNTING_INDEPENDENT.json')
t=Q/'README_TEMPLATE_QA_SNAPSHOT.md';b=Q/'BUILD_REPORT_QA_SNAPSHOT.py'
rows={s.split('|')[1].strip().replace('**',''):[x.strip().replace('**','') for x in s.split('|')[2:-1]] for s in t.read_text().splitlines() if s.startswith('|')}
checks=[]
def check(name,a,x,tol=0):
 checks.append(dict(name=name,passed=abs(a-x)<=tol,displayed=a,actual=x,tolerance=tol))
def num(x):return float(x.replace('−','-').replace('%',''))
for label,arm in [('Gaussian / probit','gaussian'),('event / 同网格直接量化','event'),('analytic → sparse 读出','analytic'),('历史模型','history'),('numeric → sparse 读出','numeric'),('zero / reset 读出','zero')]:
 for j,k in enumerate(('utility','squared_error','cost')):check(label+' '+k,num(rows[label][j]),f['arms'][arm][k],5.00001e-9)
for label,key,tol in [('event − Gaussian','event_vs_gaussian',5.00001e-11),('analytic − numeric','analytic_vs_numeric',5.00001e-9),('analytic − Gaussian','analytic_vs_gaussian',5.00001e-9)]:
 row=rows[label];v=f['contrasts'][key]
 check(key+' mean',num(row[0]),v['mean_difference'],tol)
 for j,x in enumerate(row[1].strip('[]').split(',')):check(key+' CI'+str(j),num(x),v['interval'][j],tol)
 check(key+' superiority',row[2]=='通过',v['empirical_superiority_001']);check(key+' NI',row[3]=='通过',v['empirical_noninferiority_001'])
for label,arm in [('frozen','frozen'),('protected FP64','protected'),('protected Q24','protected_q24'),('calibrated','calibrated'),('calibrated Q24','calibrated_q24'),('unconstrained','calibrated_unconstrained'),('replay','replay'),('online','online')]:
 row=rows[label];v=c['arms'][arm]
 expected=[v['worst_window_old_nll_increase'],v['shifted_nll_difference']['mean_difference'],v['shifted_calibration']['classwise_ece'],100*v['shifted_coverage95']]
 for j,(x,tol) in enumerate(zip(expected,(5.00001e-7,5.00001e-7,5.00001e-6,.00500001))):check(arm+' numeric'+str(j),num(row[j]),x,tol)
 check(arm+' retention',row[4]=='通过',v['passes_original_bounded_retention_gate']);check(arm+' joint',row[5]=='通过',v['passes_joint_empirical_gate'])
for name,a,x,tol in [('gain decomposition',.01275455+.01811979,f['contrasts']['analytic_vs_numeric']['mean_difference'],1e-8),('event wall ms',40.02,f['arms']['event']['wall_ns']/1e6,.005),('gaussian wall ms',13.24,f['arms']['gaussian']['wall_ns']/1e6,.005),('runtime histories',160,r['unique_histories'],0),('runtime ordinary',320,r['ordinary_forecasts'],0),('runtime fresh processes',10,r['fresh_processes'],0),('runtime ticks',345,r['native_ticks'],0),('runtime in-process ticks',340,r['in_process_native_ticks'],0),('runtime continuation ticks',5,r['recovery_native_ticks'],0),('runtime checks',1340,r['checks'],0),('actual head fits',75,cost['trained_gradient_fits'],0),('development candidates',375,cost['development_selection_candidates'],0),('no calibration joint pass',False,any(x['passes_joint_empirical_gate'] for x in c['arms'].values()),0)]:check(name,a,x,tol)
findings=[
 ('QA01','opening','Gaussian更强 should say sample mean higher; analytic-minus-Gaussian CI crosses zero, superiority/NI fail.'),
 ('QA02','section6 calibration','Identical statistics apply to7 native Q24 arms only; continuous Gaussian/probit ECE differs.'),
 ('QA03','section8 domain','Distinguish source domain and decoder/native intersection: positive typed variance>=2^-24, all4 typed parameters abs<=8, thresholds strictly ordered after Q24.'),
 ('QA04','section8 time','time is observed-stage count1/2; sequence is independent monotone request index. Actual continuation sequence3,time2,counts[0,0].'),
 ('QA05','section7 numeric','protected drift NLL -0.017611483127053688 rounds to -0.017611, not -0.017612.'),
 ('QA06','section7 labels','512 fit/256 dev are labelled trajectories per window; three scored horizons. Existing extra-dev-label disclosure correct.'),
 ('QA07','section7 table header','Worst window first averages5seeds; .01904416 is separately worst individual seed/window.'),
 ('QA08','builder binding','Report-only builder should verify freeze, phase/result identity, exact coordinates, archive/analysis SHA before copying. Calibration binds global_freeze_sha256+registration, not nonexistent source_commit.'),
 ('QA09','builder aggregate','Document administrative AND of primary superiority, anycalibration joint andruntime; no new gate. Mismatch is descriptive; eventNI is implied when same-interval superiority passes.'),
 ('QA10','section7 profile','Optional: name the calibration Gaussian moment projection, not an exact mixture density. Existing no-new-joint-path statement correct.'),
 ('QA11','section11 DQN','Separate this round supervised fitting/dev selection (no DQN updates) from the paper excluding general practical sampled-Q convergence.')]
main=load(R/'main/RUN_INDEX.json')
paths=[R/'FEEDBACK_RESULTS.json',R/'calibration_confirmation/RESULTS.json',R/'RUNTIME_RESULTS.json',R/'reviews/FEEDBACK_STATISTICS_INDEPENDENT.json',R/'reviews/FEEDBACK_RUNTIME_ACCOUNTING_INDEPENDENT.json']
out=dict(schema='hepta.round3.final-report-initial-qa.v1',status='INITIAL_SNAPSHOT_FINDINGS_PENDING_CORRECTED_DRAFT_REVIEW',no_scientific_execution=True,no_scientific_or_report_source_modified_by_reviewer=True,no_writes_to_run_reviews=True,input_snapshots={t.name:sha(t),b.name:sha(b)},reviewer_sha256=sha(Path(__file__)),bound_result_sha256={str(p.relative_to(R)):sha(p) for p in paths},numeric_checks=checks,numeric_checks_count=len(checks),numeric_checks_passed=sum(x['passed'] for x in checks),findings=[dict(id=i,location=loc,issue=issue) for i,loc,issue in findings],verified_claims=['Whole-trajectory/seed bootstrap; dependent stages/horizons not independent samples.','Matched63-wide numeric/analytic controls and training budget; no complete memory-removal interpretation.','Calibration extra dev labels disclosed, empirical vs universal certificates separated.','No new function class, end-to-end hard-spike backpropagation, production upgrade or energy gain asserted.','Time/CPU/archive hierarchy and unknown failed costs retained; confidence0/abstain/DENY_ALL; non-atomic owners.'],literature_verified=[dict(url='https://arxiv.org/abs/2606.16846v1',scope='Official abstract: Bellman-target regularity/approximation, no full practical sampled-Q convergence.'),dict(url='https://arxiv.org/html/1611.02024v2',scope='Section3.2 Algorithm3 accumulates/rounds/subtracts; equation2 proves equivalent direct rounding.')],pending=[dict(item='MAIN final results/cost/milestones',observed_scopes=len(main['scopes']),complete=main['complete'],required_scopes=15),dict(item='Final manifest, restore assertions, figures',status='Final manifest not yet present; parent confirms formal names RUN_REPORTS/MAIN_ANALYSIS. Recheck only newly completed/changed lines.')],invocation_notes=[dict(kind='JS syntax error',impact='Malformed workdir argument prevented all nested calls; corrected read batch succeeded.'),dict(kind='QA reader KeyError',impact='Initial inline reader used nonexistent shifted_nll_change; corrected to shifted_nll_difference.mean_difference, no report/science created.'),dict(kind='Infrastructure ENOSPC before execution',impact='Bubblewrap marker creation failed exit101; queued script never executed. Root recovered exact published duplicate storage; no scientific source/data changed.')])
p=Q/'REPORT_QA_INITIAL.json'
with p.open('x') as fp:json.dump(out,fp,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False);fp.write('\n')
print(json.dumps(dict(path=str(p),sha256=sha(p),checks=len(checks),passed=sum(x['passed'] for x in checks),failures=[x['name'] for x in checks if not x['passed']]),ensure_ascii=False))
