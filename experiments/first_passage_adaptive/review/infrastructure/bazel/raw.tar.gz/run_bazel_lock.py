"""Record canonical Bazel lock regeneration/check without changing gate policy."""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


ROOT = Path('/workspace/scratch/65d421def718')
WORKSPACE = ROOT / 'bazel_lock_work'
EVIDENCE = ROOT / 'bazel_lock_evidence'
CACHE = ROOT / 'bazel-lock-cache'
BAZEL = ROOT / 'bazel-audit-tools/bazel-9.0.0-linux-x86_64'


def file_identity(path):
    content = path.read_bytes()
    return {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}


def identities():
    paths = [
        'MODULE.bazel',
        'MODULE.bazel.lock',
        'codex-rs/Cargo.toml',
        'codex-rs/Cargo.lock',
        'codex-rs/rust-toolchain.toml',
    ]
    return {path: file_identity(WORKSPACE / path) for path in paths}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['update', 'error'])
    parser.add_argument('record_id')
    args = parser.parse_args()
    if not re.fullmatch(r'[a-z0-9_-]+', args.record_id):
        parser.error('record_id must be a simple lowercase filename stem')
    log_path = EVIDENCE / f'{args.record_id}.log'
    receipt_path = EVIDENCE / f'{args.record_id}.json'
    if log_path.exists() or receipt_path.exists():
        parser.error('evidence record already exists')
    command = [
        str(BAZEL),
        f'--output_user_root={CACHE / "user"}',
        '--noexperimental_remote_repo_contents_cache',
        f'--host_jvm_args=-Djavax.net.ssl.trustStore={CACHE / "managed-runtime-cacerts"}',
        '--host_jvm_args=-Djavax.net.ssl.trustStorePassword=changeit',
        'mod',
        'deps',
        f'--lockfile_mode={args.mode}',
        f'--repository_cache={CACHE / "repository"}',
        '--repo_contents_cache=',
        f'--disk_cache={CACHE / "disk"}',
        '--color=no',
        '--curses=no',
    ]
    env = os.environ.copy()
    env['PATH'] = (
        f'{ROOT / "rust-toolchain-1.96.0/bin"}:'
        f'{ROOT / "task-tools/bin"}:' + env['PATH']
    )
    env['CARGO_HOME'] = str(ROOT / 'security-cargo-home')
    receipt = {
        'schema': 'hepta.bazel-lock-command.v1',
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'workspace': str(WORKSPACE),
        'command': command,
        'canonical_equivalence': f'bazel mod deps --lockfile_mode={args.mode}',
        'environment_note': 'Original proxy and trust variables preserved. Scratch cache/tool paths, explicit JDK CA truststore, and materialized local repository contents replace the failing experimental virtual repository cache. No dependency, lock, or test gate disabled.',
        'cargo_cache': env['CARGO_HOME'],
        'bazel_binary': file_identity(BAZEL),
        'before': identities(),
    }
    with log_path.open('xb') as log:
        process = subprocess.Popen(command, cwd=WORKSPACE, env=env,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in iter(process.stdout.readline, b''):
            log.write(line)
            log.flush()
            text = line.decode('utf-8', errors='replace').rstrip()
            if 'no actions running' not in text:
                print(text if len(text) <= 600 else text[:400] + ' [full line in log]',
                      flush=True)
        return_code = process.wait()
    receipt.update({
        'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'exit_code': return_code,
        'after': identities(),
        'log': {'path': log_path.name, **file_identity(log_path)},
    })
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'receipt': str(receipt_path), 'exit_code': return_code}), flush=True)
    raise SystemExit(return_code)


if __name__ == '__main__':
    main()
