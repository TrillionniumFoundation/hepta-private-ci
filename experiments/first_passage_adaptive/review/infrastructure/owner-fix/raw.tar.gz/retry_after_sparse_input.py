"""Retry the same canonical check after restoring its omitted tracked input."""

import run_two_owner_fix as workflow


workflow.EVIDENCE = workflow.ROOT / 'owner_fix_evidence/retry_after_sparse_input'
workflow.main()
