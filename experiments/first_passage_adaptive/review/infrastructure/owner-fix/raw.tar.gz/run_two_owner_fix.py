"""Run one authorized two-crate canonical fix and retain exact source changes."""

import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess


ROOT = Path('/workspace/scratch/65d421def718')
REPO = ROOT / 'bazel_lock_work'
EVIDENCE = ROOT / 'owner_fix_evidence'
OWNERS = ['codex-rs/hepta-memory', 'codex-rs/hepta-automation']
GUARDS = ['codex-rs/Cargo.toml', 'codex-rs/Cargo.lock', 'MODULE.bazel', 'MODULE.bazel.lock']


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sources():
    result = {}
    for owner in OWNERS:
        for path in (REPO / owner).rglob('*'):
            if path.is_file() and path.suffix in {'.rs', '.toml'}:
                result[str(path.relative_to(REPO))] = path.read_bytes()
    return result


def source_identities(values):
    return {path: {'bytes': len(data), 'sha256': digest(data)}
            for path, data in sorted(values.items())}


def main():
    EVIDENCE.mkdir(exist_ok=True)
    log_path = EVIDENCE / 'two-owner-fix.log'
    receipt_path = EVIDENCE / 'two-owner-fix.json'
    assert not log_path.exists() and not receipt_path.exists()
    before = sources()
    before_guards = {path: digest((REPO / path).read_bytes()) for path in GUARDS}
    (EVIDENCE / 'before_sources.json').write_text(json.dumps(source_identities(before), indent=2) + '\n')
    (EVIDENCE / 'before_git.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', *OWNERS], cwd=REPO))
    command = [str(ROOT / 'task-tools/bin/just'), 'fix', '-p', 'codex-hepta-memory', '-p', 'codex-hepta-automation', '--locked']
    controls = {
        'CARGO_HOME': str(ROOT / 'security-cargo-home'),
        'CARGO_TARGET_DIR': str(ROOT / 'security-target'),
        'CARGO_BUILD_JOBS': '2',
        'CARGO_PROFILE_DEV_DEBUG': '0',
        'CARGO_INCREMENTAL': '0',
    }
    env = os.environ.copy()
    env.update(controls)
    env['PATH'] = f'{ROOT / "rust-toolchain-1.96.0/bin"}:{ROOT / "task-tools/bin"}:' + env['PATH']
    initial_free = shutil.disk_usage(ROOT).free
    receipt = {
        'schema': 'hepta.two-owner-canonical-fix.v1',
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'command': command,
        'working_directory': str(REPO),
        'controlled_environment': controls,
        'guards_before': before_guards,
        'initial_free_bytes': initial_free,
        'scope': 'One canonical cargo clippy --fix --tests invocation for the two specified first-party packages; no additional feature matrix.',
    }
    if initial_free < 640 * 1024 * 1024:
        receipt.update({'execution_started': False, 'reason': 'Less than 640 MiB free before compilation; preserve workspace and evidence capacity.'})
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps(receipt), flush=True)
        return
    interrupted = False
    with log_path.open('xb') as log:
        process = subprocess.Popen(command, cwd=REPO, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        try:
            for line in iter(process.stdout.readline, b''):
                log.write(line)
                log.flush()
                print(line.decode('utf-8', errors='replace').rstrip(), flush=True)
            return_code = process.wait()
        except KeyboardInterrupt:
            # The caller sends Ctrl-C only to this invocation's terminal if
            # disk capacity becomes unsafe. No PID-based cancellation is used.
            interrupted = True
            signal.signal(signal.SIGINT, signal.SIG_IGN)
            return_code = process.wait()
    after = sources()
    (EVIDENCE / 'after_sources.json').write_text(json.dumps(source_identities(after), indent=2) + '\n')
    changes = []
    diffs = []
    for path in sorted(set(before) | set(after)):
        if before.get(path) == after.get(path):
            continue
        changes.append({'path': path, 'before_sha256': digest(before[path]) if path in before else None, 'after_sha256': digest(after[path]) if path in after else None})
        diffs.extend(difflib.unified_diff(before.get(path, b'').decode().splitlines(keepends=True), after.get(path, b'').decode().splitlines(keepends=True), fromfile='before/' + path, tofile='after/' + path))
    (EVIDENCE / 'automatic_fix.diff').write_text(''.join(diffs))
    after_guards = {path: digest((REPO / path).read_bytes()) for path in GUARDS}
    receipt.update({
        'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'execution_started': True,
        'exit_code': return_code,
        'interrupted_via_own_terminal': interrupted,
        'guards_after': after_guards,
        'guards_unchanged': before_guards == after_guards,
        'source_changes': changes,
        'final_free_bytes': shutil.disk_usage(ROOT).free,
        'log': {'path': log_path.name, 'bytes': log_path.stat().st_size, 'sha256': digest(log_path.read_bytes())},
    })
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'exit_code': return_code, 'changed_files': len(changes), 'guards_unchanged': before_guards == after_guards, 'receipt': str(receipt_path)}), flush=True)
    raise SystemExit(return_code)


if __name__ == '__main__':
    main()
