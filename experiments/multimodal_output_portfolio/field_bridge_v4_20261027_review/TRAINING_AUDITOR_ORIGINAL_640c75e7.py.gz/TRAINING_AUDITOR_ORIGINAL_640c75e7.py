"""Independent, read-only V4 training trace / checkpoint / cost audit.

No training runner, model constructor, observer, corpus, or forward is imported.
NumPy independently reconstructs translation and frozen-head decisions. Torch
is imported only to deserialize hash-bound adapters with weights_only=True.
Journal consistency is not OS isolation or a replay of all tensor operations.
"""
import argparse
import ast
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import time
import unittest

import numpy as np

HERE = Path(__file__).resolve().parent
PORTFOLIO = HERE.parent
SCIENCE = PORTFOLIO / "field_bridge_v4_20261027"
SEEDS = (17, 29, 43)
METHODS = ("ordinary_0", "ordinary_1", "ordinary_2", "ordinary_3", "raw_field",
           "origin_field", "origin_generic", "origin_richer", "origin_h7")
SCHEDULES = (14000, 14001, 14002, 14003)
PANEL = (0, 1, 2, 3, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29)
ROLES = tuple("qualification_" + suffix for suffix in ("gradient", "rehearsal", "probe", "guard"))
OLD_PROTOCOL_SHA = "a267e91deb23aff25bdb27cf23f8274b5bfa8217c51ee962f3360297f6daa7c7"
NAMES = ("current_hard_value", "adapt_image_bce", "adapt_text_ce", "clean_joint_loss",
         "effective_operator_displacement", "momentum_rms", "normalized_learning_time",
         "next_weighted_clipped_gradient_rms", "gradient_momentum_cosine",
         "response_image_bce_derivative_along_v", "response_text_ce_derivative_along_v",
         "clean_joint_loss_derivative_along_v", "adapt_digit_ce", "clean_image_bce",
         "clean_text_ce", "clean_digit_ce", *tuple("module_displacement_"+str(i) for i in range(8)),
         "text_margin_mean", "text_margin_q10", "image_margin_mean", "image_margin_q10",
         "text_margin_below_025", "image_margin_below_01")
TIMING_KEYS = ("policy_control_wall_ns", "policy_control_cpu_ns", "checkpoint_serialization_wall_ns")


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def object_sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def valid_hash(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def vector(value, size, label):
    result = np.asarray(value, dtype=np.float64)
    need(result.shape == (size,) and np.isfinite(result).all(), label + " shape/nonfinite")
    return result


def near(actual, expected, label, atol=1e-12):
    a, b = np.asarray(actual, dtype=np.float64), np.asarray(expected, dtype=np.float64)
    need(a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all(), label + " invalid values")
    error = float(np.max(np.abs(a-b))) if a.size else 0.
    need(error <= atol, label + f" differs by {error}")
    return error


def identity(value, label):
    need(isinstance(value, dict) and set(value) == {"parameters", "optimizer"}
         and all(valid_hash(v) for v in value.values()), label + " invalid identity")


def translated(raw, observed, fit):
    raw, observed, fit = (vector(v, 30, k) for v, k in ((raw, "raw"), (observed, "origin"), (fit, "fit")))
    result = raw.copy()
    selected = np.asarray(PANEL)
    result[selected] = raw[selected] - (observed[selected] - fit[selected])
    return result


def head_prediction(head, raw):
    """Independent reconstruction, with intermediate values retained for checks."""
    mode = head["mode"]
    dimension = {"field":12, "generic":12, "richer":30, "h7":7}[mode]
    need(head["dimension"] == dimension and head["ridge"] == 1.0
         and head["fit_rows"] == 24 and head["prediction_clipping"] is False,
         "Frozen-head specification changed")
    need(head["feature_names"] == list(NAMES) and head["coefficient_count"] == (dimension+1)*4,
         "Head feature/coefficient inventory changed")
    raw = vector(raw, 30, "head input")
    mean, scale = vector(head["raw_mean"], 30, "raw mean"), vector(head["raw_scale"], 30, "raw scale")
    pmean = vector(head["projected_mean"], dimension, "projected mean")
    pscale = vector(head["projected_scale"], dimension, "projected scale")
    projection, coefficients = np.asarray(head["projection"]), np.asarray(head["coefficients"])
    need(projection.shape == (30, dimension) and coefficients.shape == (dimension+1, 4)
         and np.isfinite(projection).all() and np.isfinite(coefficients).all()
         and np.all(scale >= 1e-6) and np.all(pscale >= 1e-6), "Invalid frozen linear operator")
    standardized = np.divide(np.subtract(raw, mean), scale)
    projected = np.matmul(standardized, projection)
    normalized = np.divide(np.subtract(projected, pmean), pscale)
    design = np.empty(dimension+1, dtype=np.float64)
    design[0], design[1:] = 1., normalized
    prediction = np.matmul(design, coefficients)
    need(np.isfinite(prediction).all(), "Nonfinite independently reconstructed prediction")
    return prediction, {"raw_standardized_max_abs": float(np.max(np.abs(standardized))),
                        "projected_standardized_max_abs": float(np.max(np.abs(normalized)))}


def fit_initial(bank):
    need(bank["schema"] == "hepta.field-bridge.v3.terminal-reference-bank.1"
         and bank["feature_names"] == list(NAMES), "Wrong frozen bank")
    rows = [r for r in bank["records"] if r["step"] == 0]
    need(len(rows) == 4 and {r["trajectory"] for r in rows} == {0,1,2,3}, "Missing fit origins")
    values = np.stack([vector(row["state"],30,"fit origin") for row in rows])
    need(np.array_equal(values[:, PANEL], np.repeat(values[0:1, PANEL],4,axis=0)), "Fit origins need averaging")
    initial = {k:rows[0]["state_checkpoint"][k] for k in ("parameters", "optimizer")}
    need(all({k:r["state_checkpoint"][k] for k in initial} == initial for r in rows), "Fit initial parameter/SGD differs")
    return values[0], initial


def base_policy(protocol, seed, method, scope, head, origin):
    constant = method.startswith("ordinary_")
    return {"schema":"hepta.field-bridge.v4.policy.1", "study_id":protocol["study_id"], "seed":seed,
        "method":method, "action_index":int(method[-1]) if constant else None,
        "head_sha256":None if head is None else object_sha(head), "scope":scope,
        "panel_indices":list(PANEL), "fit_initial":origin.tolist(),
        "transform":"raw[I]-(observed_initial[I]-fit_initial[I]); other coordinates unchanged",
        "uses_translated_prediction_state":method.startswith("origin_"),
        "observed_initial_rule":"existing first step-zero probe/guard measurement; immutable through rejection",
        "predictor":"frozen V3 two normalizations, projection, linear head; np.argmax first tie",
        "ordinary_constant_full_path":constant, "steps":288, "macro_steps":48}


def counters(value, label):
    need(isinstance(value, dict) and all(isinstance(k,str) and type(v) is int and v >= 0 for k,v in value.items()),
         label + " must contain nonnegative integer counters")
    need(all(not any(word in key for word in ("audit", "endpoint", "terminal_fit", "native")) or amount == 0
             for key,amount in value.items()), label + " contains forbidden training work")
    return {key:amount for key,amount in value.items() if amount}


def add_forward(result, prefix, calls, examples, action):
    result.update({prefix+"_calls":calls, prefix+"_examples":examples,
                   prefix+"_refinement_examples":examples*(1+(action != 0))})


def hard_cost(prefix, pairs, batches, action):
    result = {}
    add_forward(result, prefix+"_generator", batches, pairs, action)
    result[prefix+"_reward_observer_calls"] = 2*batches
    result[prefix+"_reward_observer_digit_examples"] = 2*pairs
    return result


def expected_feature_cost(protocol, allocation, seed):
    p = protocol["training"]
    action = p["fixed_actions"][str(seed)]
    probe = allocation["roles"]["qualification_probe"]["pairs"] * len(p["conditions"])
    guard = allocation["roles"]["qualification_guard"]["pairs"]
    probe_batches = len(p["conditions"])*int(np.ceil(allocation["roles"]["qualification_probe"]["pairs"]/p["panel_batch_size"]))
    guard_batches = int(np.ceil(guard/p["panel_batch_size"]))
    gradient_examples = p["adapt_batch_size"] + p["rehearsal_batch_size"]
    result = hard_cost("current_hard_value", probe, probe_batches, action)
    for prefix in ("directional_generator", "directional_teacher"):
        add_forward(result,prefix,2,gradient_examples,action)
    result.update(directional_backward_calls=1, directional_backward_examples=gradient_examples,
                  directional_gradient_measurements=1, feature_probe_reverse_calls=3,
                  feature_probe_reverse_examples=2*probe+guard)
    add_forward(result,"adapt_feature_probe",probe_batches,probe,action)
    add_forward(result,"clean_feature_probe",guard_batches,guard,action)
    add_forward(result,"margin_generator",probe_batches,probe,action)
    result.update(margin_reward_observer_calls=2*probe_batches, margin_reward_observer_digit_examples=2*probe)
    return result


def expected_block_cost(protocol, allocation, seed, action_index, accepted):
    p = protocol["training"]
    action = p["fixed_actions"][str(seed)]
    n = p["macro_steps"]
    examples = n*(p["adapt_batch_size"]+p["rehearsal_batch_size"])
    guard = allocation["roles"]["qualification_guard"]["pairs"]
    result = hard_cost("candidate_guard",guard,int(np.ceil(guard/p["panel_batch_size"])),action)
    for prefix in ("gradient_generator", "gradient_teacher"):
        add_forward(result,prefix,2*n,examples,action)
    result.update(gradient_backward_calls=n, gradient_backward_examples=examples,
                  scheduled_gradient_microsteps=n, transaction_snapshots=1)
    if action_index:
        result["optimizer_steps"] = n
    if accepted:
        result["accepted_blocks"] = 1
    else:
        result.update(rejected_blocks=1, discarded_gradient_microsteps=n)
    return result


def schedule_sha(protocol, seed, sid, step):
    p = protocol["training"]
    rows = [{"step":t,"adapt_seed":seed*100003+p["batch_seed_offset"]+sid*1009+t,
             "clean_seed":seed*100003+p["rehearsal_seed_offset"]+sid*1009+t,
             "noise_seed":p["forward_seed_offset"]+t,"condition":p["conditions"][t % len(p["conditions"])]}
            for t in range(step,step+48)]
    return object_sha(rows)


def trace_audit(rows, done, protocol, allocation, seed, sid, method, head, expected_base,
                initial_identity, baseline_guard, parameter_count, trace_bytes, checkpoint_bytes):
    need(len(rows)==12 and [r["record_index"] for r in rows]==list(range(12)), "Incomplete decision/outcome journal")
    clocks = [r["committed_monotonic_ns"] for r in rows]
    need(all(type(v) is int and v > 0 for v in clocks) and all(a<b for a,b in zip(clocks,clocks[1:])), "Journal clock is not strictly increasing")
    need(done["study_id"]==protocol["study_id"] and done["seed"]==seed and done["method"]==method
         and done["schedule_id"]==sid and done["schema"]=="hepta.field-bridge.v4.trained-path.1",
         "Path study/method/seed/schedule identity differs")
    need(done["source_roles"]==list(ROLES) and done["endpoint_accessed"] is False
         and done["best_step_selection"] is False and done["final_step"]==288, "Path scope/terminal time differs")
    origin = vector(rows[0]["raw_state"],30,"first measured state")
    realized = {**expected_base,"observed_initial":origin.tolist(),"schedule_id":sid}
    need(done["policy_identity"]==realized and done["policy_sha256"]==object_sha(realized)
         and done["base_policy_sha256"]==object_sha(expected_base), "Frozen or realized policy identity differs")
    need(len(done["decisions"])==6, "Path decision summary is incomplete")
    previous = initial_identity
    identity(previous,"initial state")
    resources, actions, accepted_all, errors, scales = Counter(), [], [], [], []
    learning_rate = protocol["training"]["learning_rate"]
    baseline = np.asarray(baseline_guard["values"],dtype=np.float64)
    nprobe = allocation["roles"]["qualification_probe"]["pairs"]*4
    nguard = allocation["roles"]["qualification_guard"]["pairs"]
    need(baseline.shape==(nguard,) and np.isfinite(baseline).all(), "Invalid original guard baseline")
    feature_cost = expected_feature_cost(protocol,allocation,seed)
    for position,step in enumerate(range(0,288,48)):
        decision,outcome = rows[2*position:2*position+2]
        need(decision["schema"]=="hepta.field-bridge.v4.decision.1" and decision["kind"]=="decision_before_update"
             and decision["study_id"]==protocol["study_id"] and decision["seed"]==seed and decision["method"]==method
             and decision["schedule_id"]==sid and decision["step"]==step, "Decision path identity differs")
        raw = vector(decision["raw_state"],30,"raw feature")
        need(np.array_equal(decision["observed_initial"],origin)
             and np.array_equal(decision["calibration_context"],origin[list(PANEL)])
             and decision["panel_indices"]==list(PANEL)
             and np.array_equal(decision["fit_initial"],expected_base["fit_initial"]), "First calibration capture changed")
        mapped = translated(raw,origin,expected_base["fit_initial"])
        need(np.array_equal(decision["mapped_state"],mapped), "Fourteen-field translation differs")
        use_mapped = method.startswith("origin_")
        need(decision["prediction_state_kind"]==("mapped" if use_mapped else "raw"), "Wrong predictor state")
        if head is None:
            need(decision["predictions"] is None, "Ordinary control fitted a predictor")
            chosen = int(method[-1])
        else:
            prediction,scale = head_prediction(head,mapped if use_mapped else raw)
            errors.append(near(decision["predictions"],prediction,"Frozen head prediction"))
            scales.append(scale)
            chosen = int(np.argmax(prediction))
        need(type(decision["action_index"]) is int and decision["action_index"]==chosen, "Independent argmax/constant action differs")
        need(decision["base_policy_sha256"]==done["base_policy_sha256"]
             and decision["policy_sha256"]==done["policy_sha256"], "Decision policy SHA differs")
        identity(decision["before"],"decision before")
        need(decision["before"]==previous, "Parameter or SGD discontinuity between blocks")
        need(decision["schedule_sha256"]==schedule_sha(protocol,seed,sid,step), "Scheduled 48-step minibatch/noise sequence differs")
        current = np.asarray(decision["current_reward_values"],dtype=np.float64)
        need(current.shape==(nprobe,) and np.isfinite(current).all()
             and len(decision["current_output_sha256"])==nprobe
             and all(valid_hash(h) for h in decision["current_output_sha256"]), "Invalid probe observations")
        near(raw[0],current.mean(),"Current hard feature")
        near(raw[6],step/288,"Learning-time feature",atol=0.)
        near(raw[4],np.sqrt(np.mean(np.square(raw[16:24]))),"Operator displacement summary")
        feature = decision["feature_receipt"]
        need(feature["names"]==list(NAMES) and feature["before"]==previous
             and feature["state_grad_rng_invariant"] is True, "Feature state-preservation receipt differs")
        measured = feature["measured"]
        g,m = measured["gradient_l2"], measured["momentum_l2"]
        need(np.isfinite([g,m,measured["gradient_momentum_dot"]]).all() and g>=0 and m>=0, "Invalid direction norms")
        near(raw[7],g/np.sqrt(parameter_count),"Gradient RMS")
        near(raw[5],m/np.sqrt(parameter_count),"Momentum RMS")
        cosine = np.clip(measured["gradient_momentum_dot"]/(g*m),-1.,1.) if g*m>0 else 0.
        near(raw[8],cosine,"Gradient/momentum cosine")
        need(all(valid_hash(measured[k]) for k in ("gradient_sha256","momentum_sha256","direction_sha256"))
             and measured["next_gradient"]["optimizer_advanced"] is False, "Directional measurement advanced optimizer or lacks tensor identity")
        need(counters(feature["resources"],"feature costs")==feature_cost, "Feature workload counters differ")
        resources.update(feature_cost)
        digest = object_sha(decision)
        need(outcome["schema"]=="hepta.field-bridge.v4.block-outcome.1" and outcome["kind"]=="block_outcome"
             and outcome["study_id"]==protocol["study_id"] and outcome["decision_sha256"]==digest
             and outcome["policy_sha256"]==done["policy_sha256"], "Outcome is not bound to its committed decision")
        receipt = outcome["receipt"]
        need(receipt["start"]==step and receipt["end"]==step+48 and receipt["action_index"]==chosen
             and receipt["multiplier"]==protocol["training"]["multipliers"][chosen]
             and receipt["schedule_id"]==sid and receipt["schedule_sha256"]==decision["schedule_sha256"]
             and receipt["before"]==previous and receipt["clock_advances_on_rejection"] is True,
             "Block span/action/schedule/clock differs")
        for key in ("candidate","after"):
            identity(receipt[key],"block "+key)
        guard = np.asarray(receipt["guard_values"],dtype=np.float64)
        need(guard.shape==(nguard,) and np.isfinite(guard).all() and len(receipt["guard_output_sha256"])==nguard
             and all(valid_hash(v) for v in receipt["guard_output_sha256"]), "Invalid raw guard observations")
        delta = float(np.mean(guard-baseline))
        near(receipt["guard_delta"],delta,"Raw empirical guard delta")
        accepted = delta >= protocol["training"]["guard_min_delta"]
        need(type(receipt["accepted"]) is bool and receipt["accepted"]==accepted, "Guard accept/reject predicate differs")
        if not accepted or chosen==0:
            need(receipt["after"]==previous, "Rejected/zero block failed parameter and SGD restoration")
        if accepted:
            need(receipt["after"]==receipt["candidate"], "Accepted state differs from candidate")
        if chosen==0:
            need(receipt["candidate"]==previous, "Zero-action candidate changed parameters or SGD")
        if accepted and chosen:
            learning_rate = protocol["training"]["learning_rate"]*protocol["training"]["multipliers"][chosen]
        for key in ("first_gradient","last_gradient"):
            gradient = receipt[key]
            need(gradient["optimizer_advanced"] is (chosen!=0)
                 and np.isfinite([gradient["loss"],gradient["unclipped_gradient_norm"]]).all()
                 and gradient["unclipped_gradient_norm"]>=0, "First/last gradient receipt differs")
        block_cost = expected_block_cost(protocol,allocation,seed,chosen,accepted)
        need(counters(receipt["resources"],"block costs")==block_cost, "Block workload/rejection/zero counters differ")
        resources.update(block_cost)
        summary = {"step":step,"action_index":chosen,"accepted":accepted,"decision_sha256":digest}
        need(done["decisions"][position]==summary, "Path decision summary is not exact")
        previous = receipt["after"]
        actions.append(chosen)
        accepted_all.append(accepted)
    need(done["final_identity"]==previous, "Terminal identity does not follow all six blocks")
    resources.update(panel_origin_captures=1,panel_origin_calibration_context_values=14,
                     panel_origin_calibration_context_bytes=112,panel_origin_translation_calls=6,
                     panel_origin_coordinates=84,policy_prediction_calls=0 if head is None else 6,
                     training_trace_bytes=trace_bytes,checkpoint_bytes=checkpoint_bytes)
    actual = counters(done["resources"],"path costs")
    for key in TIMING_KEYS:
        need(type(done["resources"].get(key,0)) is int and done["resources"].get(key,0)>=0, "Invalid measured control/I/O cost")
        resources[key] = done["resources"].get(key,0)
    expected = {k:v for k,v in resources.items() if v}
    need(actual==expected, "Path total counters do not match independent feature/block/storage reconstruction")
    need(type(done["wall_ns"]) is int and done["wall_ns"]>0 and type(done["cpu_ns"]) is int and done["cpu_ns"]>=0,
         "Missing inclusive path timing")
    need(done["wall_ns"]>=resources["policy_control_wall_ns"]+resources["checkpoint_serialization_wall_ns"]
         and done["cpu_ns"]>=resources["policy_control_cpu_ns"], "Control/serialization time exceeds its containing path")
    return {"seed":seed,"method":method,"schedule_id":sid,"actions":actions,"accepted":accepted_all,
            "policy_sha256":done["policy_sha256"],"base_policy_sha256":done["base_policy_sha256"],
            "max_prediction_error":max(errors,default=0.),"normalization_ranges":scales,
            "expected_final_learning_rate":learning_rate,"resources":expected,
            "final_identity":previous,"path_wall_ns":done["wall_ns"],"path_cpu_ns":done["cpu_ns"],
            "representation_storage":{"active_calibration_array_bytes":112,
                "audit_numeric_payload_per_decision_for_raw_mapped_observed_fit_and_context":(4*30+14)*8,
                "trace_compressed_bytes":trace_bytes,
                "scope":"112B is active calibration payload only; full30 audit metadata, Python containers, temporary vectors, head arrays, and serialized logs are additional."}}


class Inputs:
    def __init__(self):
        self.identities = {}
        self.read_bytes = 0
        self.read_calls = 0
        self.checkpoint_loads = 0

    def data(self,path,expected=None):
        path = Path(path).resolve()
        raw = path.read_bytes()
        self.read_bytes += len(raw)
        self.read_calls += 1
        digest = hashlib.sha256(raw).hexdigest()
        need(expected is None or digest==expected,"Input SHA mismatch: "+str(path))
        need(str(path) not in self.identities or self.identities[str(path)]["sha256"]==digest,"Input changed while reading: "+str(path))
        self.identities[str(path)] = {"sha256":digest,"bytes":len(raw)}
        return raw

    def json(self,path,expected=None):
        return json.loads(self.data(path,expected))

    def files(self,root,expected,exact=True,exclude=()):
        root = Path(root).resolve()
        need(expected,"Empty file inventory")
        for relative,digest in expected.items():
            path = (root/relative).resolve()
            need(not Path(relative).is_absolute() and path.is_relative_to(root) and path.is_file(),"Unsafe/missing inventory entry")
            self.data(path,digest)
        if exact:
            actual = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()
                      and str(p.relative_to(root)) not in exclude}
            need(actual==set(expected),"Unexpected/missing file in "+str(root))

    def unchanged(self):
        for path,record in list(self.identities.items()):
            self.data(path,record["sha256"])


def tensor_array(value,label):
    import torch
    need(isinstance(value,torch.Tensor) and value.device.type=="cpu" and value.layout==torch.strided,label+" is not a dense CPU tensor")
    result = value.detach().contiguous().numpy()
    need(np.isfinite(result).all(),label+" contains nonfinite values")
    return result


def saved_state_identity(parameters,optimizer):
    digest = hashlib.sha256()
    for name,value in parameters.items():
        digest.update(name.encode())
        digest.update(tensor_array(value,"parameter "+name).tobytes())
    parameter_sha = digest.hexdigest()
    digest = hashlib.sha256(json.dumps(optimizer["param_groups"],sort_keys=True).encode())
    for index,fields in sorted(optimizer["state"].items()):
        digest.update(str(index).encode())
        for name,value in sorted(fields.items()):
            digest.update(name.encode())
            digest.update(tensor_array(value,"optimizer "+name).tobytes())
    return {"parameters":parameter_sha,"optimizer":digest.hexdigest()}


def checkpoint_audit(inputs,path,digest,protocol,seed,metadata_expected,*,old=False):
    import torch
    raw = inputs.data(path,digest)
    value = torch.load(io.BytesIO(raw),map_location="cpu",weights_only=True)
    inputs.checkpoint_loads += 1
    expected_schema = "hepta.field-bridge.v3.complete-adapter.1" if old else "hepta.field-bridge.v4.complete-adapter.1"
    need(value["schema"]==expected_schema and value["training_configuration"]==protocol["training"],"Checkpoint schema/configuration differs")
    need(value["metadata"]==metadata_expected and value["metadata"]["seed"]==seed,"Checkpoint metadata differs")
    if not old:
        need(value["study_id"]==protocol["study_id"],"Checkpoint study identity differs")
    state = value if old else value["state"]
    parameters,optimizer = state["parameters"],state["optimizer"]
    expected_names = {name+suffix for name in protocol["training"]["adapter_modules"] for suffix in (".up",".down")}
    need(set(parameters)==expected_names and len(parameters)==16,"Checkpoint adapter capacity differs")
    shapes = {}
    count = 0
    for name,tensor in parameters.items():
        array = tensor_array(tensor,name)
        need(array.dtype==np.float32 and array.ndim==2 and array.shape[0 if name.endswith('.down') else 1]==8,
             "Adapter dtype/rank differs")
        shapes[name] = list(array.shape)
        count += array.size
    need(set(optimizer)=={"param_groups","state"} and len(optimizer["param_groups"])==1,"Incomplete/non-SGD optimizer structure")
    group = optimizer["param_groups"][0]
    need(group["params"]==list(range(16)) and group["momentum"]==protocol["training"]["momentum"]
         and group["dampening"]==0 and group["weight_decay"]==0 and group["nesterov"] is False
         and group["maximize"] is False and group["differentiable"] is False
         and group["foreach"] is None and group["fused"] is None,"Plain-SGD semantics differ")
    need(set(optimizer["state"]).issubset(set(range(16))),"Unknown optimizer parameter state")
    ordered = list(parameters.values())
    for index,fields in optimizer["state"].items():
        need(set(fields)=={"momentum_buffer"},"Unexpected SGD state fields")
        buffer = tensor_array(fields["momentum_buffer"],"momentum buffer")
        need(buffer.shape==tuple(ordered[index].shape) and buffer.dtype==np.float32,"Momentum tensor inventory differs")
    actual = saved_state_identity(parameters,optimizer)
    need(state["identity"]==actual,"Saved parameter/SGD tensors do not match recorded identity")
    gradient_sha,rng_sha = None,None
    if not old:
        need(set(state)=={"parameters","optimizer","gradients","identity","rng"},"Incomplete full transaction state")
        need(len(state["gradients"])==16,"Missing incoming gradients")
        hasher = hashlib.sha256()
        for parameter,gradient in zip(ordered,state["gradients"],strict=True):
            if gradient is None:
                hasher.update(b"none\0")
            else:
                array = tensor_array(gradient,"saved gradient")
                need(tuple(array.shape)==tuple(parameter.shape) and array.dtype==np.float32,"Saved gradient shape/dtype differs")
                hasher.update(str((tuple(gradient.shape),str(gradient.dtype))).encode()+b"\0")
                hasher.update(array.tobytes())
        gradient_sha = hasher.hexdigest()
        rng = tensor_array(state["rng"],"saved RNG")
        need(rng.dtype==np.uint8 and rng.ndim==1 and rng.size>0,"Incomplete CPU RNG snapshot")
        rng_sha = hashlib.sha256(rng.tobytes()).hexdigest()
    need(valid_hash(value["frozen_base_sha256"]),"Missing frozen base identity")
    return {"file_sha256":digest,"bytes":len(raw),"identity":actual,"parameter_count":int(count),
            "parameter_shapes":shapes,"learning_rate":group["lr"],"momentum_state_parameters":len(optimizer["state"]),
            "gradient_tensor_sha256":gradient_sha,"rng_sha256":rng_sha,"frozen_base_sha256":value["frozen_base_sha256"]}


def required_sources(portfolio):
    science = portfolio/"field_bridge_v4_20261027"
    result = set(science.glob("*.py"))
    result.update(science/name for name in ("PROTOCOL.json","SOURCE_ALLOCATION.json","SOURCE_IDENTITIES.json.gz"))
    result.add(portfolio/"field_bridge_v4_20261027_review/training_panel_origin.py")
    result.update(portfolio/"field_bridge_v3_20261027"/name for name in (
        "__init__.py","PROTOCOL.json","training_common.py","assets.py","learning.py","training_features.py",
        "training_bank.py","training_policy.py","source_roles.py"))
    for directory in ("field_bridge_20261027","v6"):
        result.update((portfolio/directory).glob("*.py"))
    result.add(portfolio/"field_bridge_20261027/PROTOCOL.json")
    return sorted(result)


def full_audit(run,old_run,protocol_path,freeze_path,inputs):
    run,old_run,protocol_path,freeze_path = map(lambda p:Path(p).resolve(),(run,old_run,protocol_path,freeze_path))
    need(not (run/"evaluate").exists(),"This is a pre-endpoint audit; endpoint execution already exists")
    protocol = inputs.json(protocol_path)
    p,q = protocol["training"],protocol["qualification"]
    need(protocol["schema"]=="hepta.field-bridge.v4.panel-origin-protocol.1" and protocol["seeds"]==list(SEEDS)
         and q["methods"]==list(METHODS) and q["schedule_ids"]==list(SCHEDULES)
         and p["steps"]==288 and p["macro_steps"]==48 and p["multipliers"]==[0.,.25,1.,2.],"Registered study inventory differs")
    need(protocol["panel_origin"]["translated_indices"]==list(PANEL),"Panel intervention changed")
    freeze = inputs.json(freeze_path)
    need(freeze["study_id"]==protocol["study_id"] and "train" in freeze["allowed_phases"]
         and re.fullmatch(r"[0-9a-f]{40}",freeze["registered_commit"])
         and freeze["protocol_sha256"]==inputs.identities[str(protocol_path)]["sha256"],"Training source freeze identity differs")
    source_map = {}
    for path in required_sources(protocol_path.parent.parent):
        relative = str(path.relative_to(protocol_path.parent.parent))
        inputs.data(path,freeze["source_files"].get(relative))
        digest = inputs.identities[str(path.resolve())]["sha256"]
        need(freeze["source_files"].get(relative)==digest,"Missing mandatory frozen dependency: "+relative)
        source_map[relative] = digest
    for relative,digest in freeze["source_files"].items():
        path = (protocol_path.parent.parent/relative).resolve()
        need(path.is_relative_to(protocol_path.parent.parent),"Unsafe frozen source path")
        inputs.data(path,digest)
    old_protocol = inputs.json(protocol_path.parent.parent/"field_bridge_v3_20261027/PROTOCOL.json",OLD_PROTOCOL_SHA)
    need(old_protocol["training"]==p and protocol["old_training_protocol_sha256"]==OLD_PROTOCOL_SHA,"V3 numerics were edited")
    allocation = inputs.json(protocol_path.parent/"SOURCE_ALLOCATION.json",protocol["source_allocation_sha256"])
    need(allocation["manifest_sha256"]==protocol["source_manifest_sha256"],"Source allocation identity differs")
    scope = {"study_id":protocol["study_id"],"protocol_sha256":inputs.identities[str(protocol_path)]["sha256"],
        "source_allocation_sha256":protocol["source_allocation_sha256"],"source_manifest_sha256":protocol["source_manifest_sha256"],
        "source_files_sha256":object_sha(source_map),"registered_commit":freeze["registered_commit"],
        "freeze_sha256":inputs.identities[str(freeze_path)]["sha256"],"old_training_protocol_sha256":OLD_PROTOCOL_SHA}
    selection = inputs.json(old_run/"DEVELOPMENT_SELECTION.json",freeze["old_artifacts"]["DEVELOPMENT_SELECTION.json"])
    need(selection["passed"] is False and selection["ordinary_action_indices"]==q["ordinary_action_indices"]
         and selection["selected_adaptive"]=="richer","Old failed gate or comparators changed")
    seal = inputs.json(run/"TRAINING_SEAL.json")
    need(seal["schema"]=="hepta.field-bridge.v4.training-seal.1" and seal["study_id"]==protocol["study_id"]
         and seal["paths"]==108 and seal["gradient_microsteps"]==31104 and seal["gradient_examples"]==2985984
         and seal["all_training_completed_before_any_endpoint"] is True and seal["observer_names_during_training"]==["reward"],
         "Missing complete pre-endpoint training seal")
    cost_paths = {f"PHASE_RECEIPTS/train-{seed}.json" for seed in SEEDS}
    need({name for name in seal["files"] if not name.startswith("train/")}==cost_paths,
         "Seal must bind exactly three training phase-cost receipts")
    inputs.files(run/"train",{name.removeprefix("train/"):v for name,v in seal["files"].items() if name.startswith("train/")})
    for name in cost_paths:
        inputs.data(run/name,seal["files"][name])
    asset_source = inputs.data(protocol_path.parent.parent/"field_bridge_v3_20261027/assets.py").decode()
    literals = {node.targets[0].id:ast.literal_eval(node.value) for node in ast.parse(asset_source).body
                if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)
                and node.targets[0].id in {"PINNED","ORIGINAL_ARCHIVE"}}
    path_results,seed_results,total = [],[],Counter()
    for seed in SEEDS:
        old = {}
        for category,filename in (("bank","BANK.json"),("fit","CONTROLLERS.json"),("reference","REFERENCE.json")):
            for name in (filename,"COMPLETE.json"):
                relative = f"{category}/{seed}/{name}"
                old[category+":"+name] = inputs.json(old_run/relative,freeze["old_artifacts"][relative])
                if name==filename:
                    pin = protocol["frozen_v3_learning_artifacts"][str(seed)][relative]
                    need(inputs.identities[str((old_run/relative).resolve())]==pin,"Protocol-pinned V3 artifact differs")
        bank,fitted,reference = old["bank:BANK.json"],old["fit:CONTROLLERS.json"],old["reference:REFERENCE.json"]
        bank_sha = inputs.identities[str(old_run/f"bank/{seed}/BANK.json")]["sha256"]
        head_sha = inputs.identities[str(old_run/f"fit/{seed}/CONTROLLERS.json")]["sha256"]
        ref_sha = inputs.identities[str(old_run/f"reference/{seed}/REFERENCE.json")]["sha256"]
        need(bank["seed"]==fitted["seed"]==reference["seed"]==seed
             and bank["training_configuration_sha256"]==fitted["training_configuration_sha256"]==reference["training_configuration_sha256"]==object_sha(p)
             and fitted["bank_sha256"]==bank_sha and fitted["reference_sha256"]==bank["reference_sha256"]==ref_sha
             and reference["selected_action_index"]==bank["reference_action_index"],"Frozen head/bank/reference chain differs")
        for category,filename,digest in (("bank","BANK.json",bank_sha),("fit","CONTROLLERS.json",head_sha),("reference","REFERENCE.json",ref_sha)):
            need(old[category+":COMPLETE.json"]["files"][filename]==digest,"Old COMPLETE does not bind its artifact")
        origin,initial = fit_initial(bank)
        zero = next(row for row in reference["candidates"] if row["action_index"]==0)
        zero_info = checkpoint_audit(inputs,old_run/f"reference/{seed}/constant-0.pt",
            old["reference:COMPLETE.json"]["files"]["constant-0.pt"],protocol,seed,zero["checkpoint"]["metadata"],old=True)
        need(zero_info["identity"]==initial=={k:zero["checkpoint"][k] for k in initial}
             and zero_info["momentum_state_parameters"]==0 and zero_info["learning_rate"]==p["learning_rate"],"Old zero-action checkpoint is not the initial parameter/SGD state")
        old_assets = inputs.json(old_run/f"reference/{seed}/ASSET_IDENTITIES.json",
            old["reference:COMPLETE.json"]["files"]["ASSET_IDENTITIES.json"])
        directory = run/"train"/str(seed)
        need(not (directory/"FAILED.json").exists(),"Training phase has a recorded failure")
        start = inputs.json(directory/"START.json")
        done = inputs.json(directory/"COMPLETE.json",seal["model_seed_complete_sha256"][str(seed)])
        assets = inputs.json(directory/"ASSET_IDENTITIES.json")
        seed_scope = {**scope,"bank_sha256":bank_sha,"controller_file_sha256":head_sha,"reference_file_sha256":ref_sha}
        need(start["schema"]=="hepta.field-bridge.v4.phase-start.1" and start["phase"]=="train"
             and start["study_id"]==protocol["study_id"] and start["seed"]==seed and start["scope"]==seed_scope
             and start["source_files"]==source_map and start["requested_roles"]==list(ROLES)
             and start["loaded_observer_names"]==["reward"] and start["training_seal_sha256"] is None
             and start["started_unix_ns"]<seal["sealed_unix_ns"],"Training start/source/observer/timing identity differs")
        asset = assets["identities"]
        need(assets["schema"]=="hepta.field-bridge.v4.asset-identities.1" and assets["study_id"]==protocol["study_id"]
             and asset==old_assets and asset["loaded_observers"]==["reward"]
             and asset["pinned_files"]==literals["PINNED"] and asset["original_archive_sha256"]==literals["ORIGINAL_ARCHIVE"]
             and set(asset["models"])=={str(seed)},"Historical generator/observer asset identity differs")
        need(done["schema"]=="hepta.field-bridge.v4.trained-seed.1" and done["study_id"]==protocol["study_id"]
             and done["seed"]==seed and done["scope"]==seed_scope and done["methods"]==list(METHODS)
             and done["schedule_ids"]==list(SCHEDULES) and done["source_roles"]==list(ROLES)
             and done["observer_names"]==["reward"] and done["endpoint_accessed"] is False,"Seed inventory/scope differs")
        inputs.files(directory,done["files"],exclude=("COMPLETE.json",))
        expected_paths = {f"{m}/schedule-{s}" for m in METHODS for s in SCHEDULES}
        need(set(done["paths"])==expected_paths,"Not all 36 paths are retained")
        guard = done["baseline_guard"]
        nguard = allocation["roles"]["qualification_guard"]["pairs"]
        need(len(guard["source_ids"])==len(guard["values"])==len(guard["output_sha256"])==nguard
             and len({tuple(x) for x in guard["source_ids"]})==nguard
             and all(valid_hash(x) for x in guard["output_sha256"]),"Original guard baseline is incomplete")
        near(guard["mean"],np.mean(guard["values"]),"Original guard mean")
        summed = Counter()
        for method in METHODS:
            mode = None if method.startswith("ordinary_") else "field" if method=="raw_field" else method.removeprefix("origin_")
            head = None if mode is None else fitted["controllers"][mode]
            policy = base_policy(protocol,seed,method,seed_scope,head,origin)
            for sid in SCHEDULES:
                relative = f"{method}/schedule-{sid}"
                path = directory/relative
                record = inputs.json(path/"COMPLETE.json",done["paths"][relative]["complete_sha256"])
                need(set(record["files"])=={"checkpoint.pt","decisions-and-outcomes.jsonl.gz"},"Training path contains unexpected media/endpoint work")
                inputs.files(path,record["files"],exclude=("COMPLETE.json",))
                trace = inputs.data(path/"decisions-and-outcomes.jsonl.gz",record["files"]["decisions-and-outcomes.jsonl.gz"])
                rows = [json.loads(row) for row in gzip.decompress(trace).splitlines()]
                checkpoint = checkpoint_audit(inputs,path/"checkpoint.pt",record["files"]["checkpoint.pt"],protocol,seed,record["checkpoint"]["metadata"])
                need(checkpoint["file_sha256"]==record["checkpoint"]["file_sha256"]
                     and checkpoint["identity"]==record["final_identity"]=={k:record["checkpoint"][k] for k in initial}
                     and checkpoint["frozen_base_sha256"]==zero_info["frozen_base_sha256"]
                     and checkpoint["parameter_shapes"]==zero_info["parameter_shapes"],"Checkpoint tensor/base/architecture binding differs")
                expected_metadata = {"study_id":protocol["study_id"],"seed":seed,"method":method,"schedule_id":sid,
                    "policy_sha256":record["policy_sha256"],"base_policy_sha256":record["base_policy_sha256"],
                    "source_roles":list(ROLES),"endpoint_accessed":False}
                need(record["checkpoint"]["metadata"]==expected_metadata
                     and record["policy_sha256"]==done["paths"][relative]["policy_sha256"],"Checkpoint policy/role provenance differs")
                result = trace_audit(rows,record,protocol,allocation,seed,sid,method,head,policy,initial,guard,
                                     checkpoint["parameter_count"],len(trace),checkpoint["bytes"])
                near(checkpoint["learning_rate"],result["expected_final_learning_rate"],"Final SGD learning rate",atol=0.)
                if method=="ordinary_0":
                    need(checkpoint["identity"]==zero_info["identity"] and checkpoint["momentum_state_parameters"]==0,
                         "Complete zero path changed actual saved parameters/momentum")
                result["checkpoint"] = checkpoint
                path_results.append(result)
                summed.update(result["resources"])
        original_cost = hard_cost("original_guard",nguard,int(np.ceil(nguard/p["panel_batch_size"])),p["fixed_actions"][str(seed)])
        summed.update(original_cost)
        need(counters(done["resources"],"seed costs")==dict(summed),"Seed ledger does not equal all paths plus original guard")
        phase = inputs.json(run/f"PHASE_RECEIPTS/train-{seed}.json",seal["files"][f"PHASE_RECEIPTS/train-{seed}.json"])
        need(phase["schema"]=="hepta.field-bridge.v4.phase-cost-receipt.1" and phase["study_id"]==protocol["study_id"]
             and phase["phase"]=="train" and phase["seed"]==seed and phase["scope"]==seed_scope
             and phase["complete_sha256"]==seal["model_seed_complete_sha256"][str(seed)],"Unbound training phase cost receipt")
        for key in ("preflight_verification_wall_ns","preflight_verification_cpu_ns","postflight_verification_wall_ns",
                    "postflight_verification_cpu_ns","phase_wall_ns","phase_cpu_ns"):
            need(type(phase[key]) is int and phase[key]>=0,"Invalid complete training phase timing")
        need(phase["preflight_verification_wall_ns"]==start["preflight_verification_wall_ns"]
             and phase["preflight_verification_cpu_ns"]==start["preflight_verification_cpu_ns"],"Preflight timing changed after training")
        seed_paths = [path for path in path_results if path["seed"]==seed]
        for clock in ("wall","cpu"):
            contained = sum(path[f"path_{clock}_ns"] for path in seed_paths)
            contained += phase[f"preflight_verification_{clock}_ns"]+phase[f"postflight_verification_{clock}_ns"]
            need(phase[f"phase_{clock}_ns"]>=contained,"Training phase time is shorter than its disjoint recorded components")
        total.update(summed)
        seed_results.append({"seed":seed,"paths":36,"resources":dict(summed),"original_guard_resources":original_cost,
                             "parameter_count":zero_info["parameter_count"],"initial_identity":initial,
                             "seed_wall_ns":done["wall_ns"],"scope":seed_scope,"phase_cost":phase})
        print(f"independent training audit seed={seed}: 36 paths verified",file=sys.stderr,flush=True)
    need(len(path_results)==108 and total["scheduled_gradient_microsteps"]==31104
         and total["gradient_backward_examples"]==2985984 and total["directional_gradient_measurements"]==648
         and total["accepted_blocks"]+total["rejected_blocks"]==648,"All-path work totals differ")
    inputs.unchanged()
    return {"study_id":protocol["study_id"],"paths":path_results,"seeds":seed_results,"resources":dict(total),
        "training_seal_sha256":inputs.identities[str(run/"TRAINING_SEAL.json")]["sha256"],
        "declared_training_audit_observer_work":0,"declared_training_endpoint_work":0,
        "old_zero_checkpoint_reads":3,"new_checkpoint_reads":108,"independent_head_predictions":360,
        "control_context_scope":"14 retained float64 calibration values (112B) plus frozen fit context and full raw30 audit metadata; not a 112B total-memory claim.",
        "time_scope":"Path CPU/wall includes model/optimizer initialization, feature/block work, journals and checkpoint I/O. Three separately sealed phase-cost receipts include source verification and asset/corpus/context setup. Their explicit exclusions are retained; interpreter startup is not claimed to be timed.",
        "audit_limits":[
            "SHA and causal ordering checks establish consistency of retained records, not independent OS/process isolation or exclusion of unlogged I/O.",
            "No model forward, observer evaluation, gradient computation, optimization step, source tensor load, or training replay is performed by this auditor.",
            "Every final checkpoint parameter and SGD tensor is independently hashed. Intermediate zero/rejected restorations are checked against committed before/candidate/after identities, not intermediate full tensor snapshots.",
            "Raw loss/derivative observations are checked for recorded arithmetic consistency where possible; they are not recomputed from data and models.",
            "Source-disjointness, endpoint outputs, bootstrap intervals and substantive qualification gates are handled by separate independent review."]}


def self_test():
    """Synthetic arithmetic/transaction contracts; never open study roles."""
    contract_cost=Counter()
    class Contracts(unittest.TestCase):
        def run_fixture(self,fixture):
            return trace_audit(**fixture)

        def test_complete_synthetic_zero_path(self):
            result=self.run_fixture(synthetic_trace("ordinary_0"))
            self.assertEqual(result['actions'],[0]*6)
            self.assertEqual(result['resources']['scheduled_gradient_microsteps'],288)
            self.assertEqual(result['resources'].get('optimizer_steps',0),0)

        def test_complete_synthetic_adaptive_rejections(self):
            result=self.run_fixture(synthetic_trace("origin_field"))
            self.assertEqual(result['actions'],[3]*6)
            self.assertEqual(result['accepted'].count(False),2)
            self.assertEqual(result['resources']['optimizer_steps'],288)
            self.assertEqual(result['resources']['discarded_gradient_microsteps'],96)

        def test_wrong_translation_even_with_recommitted_journal(self):
            fixture=synthetic_trace("origin_field")
            fixture['rows'][2]['mapped_state'][4]+=.1
            recommit_synthetic(fixture)
            with self.assertRaisesRegex(ValueError,'translation'):self.run_fixture(fixture)

        def test_recaptured_origin_after_rejection_rejected(self):
            fixture=synthetic_trace("origin_field")
            row=fixture['rows'][4]
            row['observed_initial']=deepcopy(row['raw_state'])
            row['calibration_context']=[row['raw_state'][i] for i in PANEL]
            row['mapped_state']=translated(row['raw_state'],row['observed_initial'],row['fit_initial']).tolist()
            recommit_synthetic(fixture)
            with self.assertRaisesRegex(ValueError,'capture'):self.run_fixture(fixture)

        def test_wrong_frozen_prediction_rejected_after_recommit(self):
            fixture=synthetic_trace("origin_field")
            fixture['rows'][0]['predictions'][0]+=.001
            recommit_synthetic(fixture)
            with self.assertRaisesRegex(ValueError,'prediction'):self.run_fixture(fixture)

        def test_ordinary_action_cannot_change(self):
            fixture=synthetic_trace("ordinary_0")
            fixture['rows'][0]['action_index']=1
            recommit_synthetic(fixture)
            with self.assertRaisesRegex(ValueError,'constant action'):self.run_fixture(fixture)

        def test_failed_restore_is_not_hidden_by_next_before_hash(self):
            fixture=synthetic_trace("origin_field")
            receipt=fixture['rows'][3]['receipt']
            receipt['after']=deepcopy(receipt['candidate'])
            fixture['rows'][4]['before']=deepcopy(receipt['after'])
            recommit_synthetic(fixture)
            with self.assertRaisesRegex(ValueError,'restoration'):self.run_fixture(fixture)

        def test_zero_candidate_cannot_change_sgd(self):
            fixture=synthetic_trace("ordinary_0")
            fixture['rows'][1]['receipt']['candidate']['optimizer']='e'*64
            with self.assertRaisesRegex(ValueError,'Accepted state|Zero-action'):self.run_fixture(fixture)

        def test_rejected_computation_must_remain_charged(self):
            fixture=synthetic_trace("origin_field")
            del fixture['rows'][3]['receipt']['resources']['discarded_gradient_microsteps']
            fixture['done']['resources']['discarded_gradient_microsteps']-=48
            with self.assertRaisesRegex(ValueError,'workload'):self.run_fixture(fixture)

        def test_guard_cannot_be_changed_only_by_boolean(self):
            fixture=synthetic_trace("origin_field")
            fixture['rows'][3]['receipt']['accepted']=True
            fixture['done']['decisions'][1]['accepted']=True
            with self.assertRaisesRegex(ValueError,'predicate'):self.run_fixture(fixture)

        def test_original_guard_values_not_just_declared_delta(self):
            fixture=synthetic_trace("origin_field")
            fixture['rows'][3]['receipt']['guard_delta']=0.1
            with self.assertRaisesRegex(ValueError,'guard delta'):self.run_fixture(fixture)

        def test_journal_binding_and_complete_288_step_span(self):
            fixture=synthetic_trace("origin_field")
            fixture['rows'][1]['decision_sha256']='f'*64
            with self.assertRaisesRegex(ValueError,'committed decision'):self.run_fixture(fixture)
            fixture=synthetic_trace("origin_field")
            fixture['rows'][-1]['receipt']['end']=287
            with self.assertRaisesRegex(ValueError,'Block span'):self.run_fixture(fixture)

        def test_trace_physical_bytes_must_match_cost(self):
            fixture=synthetic_trace("origin_field")
            fixture['done']['resources']['training_trace_bytes']-=1
            with self.assertRaisesRegex(ValueError,'Path total'):self.run_fixture(fixture)

        def test_trace_nonmonotone_commit_clock_rejected(self):
            fixture=synthetic_trace("origin_field")
            fixture['rows'][2]['committed_monotonic_ns']=1
            recommit_synthetic(fixture)
            with self.assertRaisesRegex(ValueError,'clock'):self.run_fixture(fixture)

        def checkpoint_fixture(self,mutation=None):
            import tempfile
            import torch
            protocol,_=synthetic_config()
            protocol['training'].update(adapter_modules=[f'module{i}' for i in range(8)],momentum=.9)
            parameters={}
            for name in protocol['training']['adapter_modules']:
                parameters[name+'.down']=torch.as_tensor(np.arange(16,dtype=np.float32).reshape(8,2).copy())
                parameters[name+'.up']=torch.as_tensor(np.zeros((2,8),dtype=np.float32))
            optimizer={'state':{},'param_groups':[{'params':list(range(16)),'lr':.2,'momentum':.9,
                'dampening':0,'weight_decay':0,'nesterov':False,'maximize':False,'differentiable':False,
                'foreach':None,'fused':None}]}
            state={'parameters':parameters,'optimizer':optimizer,'gradients':[None]*16,
                   'rng':torch.get_rng_state(),'identity':saved_state_identity(parameters,optimizer)}
            metadata={'seed':17,'synthetic_fixture':True}
            record={'schema':'hepta.field-bridge.v4.complete-adapter.1','study_id':protocol['study_id'],
                    'training_configuration':protocol['training'],'metadata':metadata,'state':state,
                    'frozen_base_sha256':'9'*64}
            if mutation:
                mutation(record)
            with tempfile.TemporaryDirectory(prefix='hepta-v4-auditor-contract-') as directory:
                path=Path(directory)/'synthetic-checkpoint.pt'
                torch.save(record,path)
                contract_cost['synthetic_checkpoint_files_written']+=1
                contract_cost['synthetic_checkpoint_bytes_written']+=path.stat().st_size
                reader=Inputs()
                try:
                    return checkpoint_audit(reader,path,hashlib.sha256(path.read_bytes()).hexdigest(),protocol,17,metadata)
                finally:
                    contract_cost['synthetic_weights_only_reads']+=reader.checkpoint_loads
                    contract_cost['synthetic_checkpoint_bytes_read']+=reader.read_bytes

        def test_weights_only_checkpoint_actual_tensor_identity(self):
            result=self.checkpoint_fixture()
            self.assertEqual(result['parameter_count'],256)
            self.assertEqual(result['momentum_state_parameters'],0)
            self.assertTrue(valid_hash(result['gradient_tensor_sha256']))
            self.assertTrue(valid_hash(result['rng_sha256']))

        def test_rehashed_checkpoint_file_cannot_hide_parameter_mutation(self):
            def mutate(record):
                record['state']['parameters']['module0.down'][0,0]+=1
            with self.assertRaisesRegex(ValueError,'Saved parameter/SGD tensors'):
                self.checkpoint_fixture(mutate)

        def test_rehashed_checkpoint_file_cannot_hide_sgd_mutation(self):
            def mutate(record):
                import torch
                record['state']['optimizer']['state'][0]={'momentum_buffer':torch.ones((8,2))}
            with self.assertRaisesRegex(ValueError,'Saved parameter/SGD tensors'):
                self.checkpoint_fixture(mutate)

        def test_full_checkpoint_cannot_drop_gradient_snapshot(self):
            def mutate(record):
                record['state']['gradients'].pop()
            with self.assertRaisesRegex(ValueError,'Missing incoming gradients'):
                self.checkpoint_fixture(mutate)

        def test_translation_changes_exactly_fourteen_fields(self):
            raw=np.arange(30,dtype=float);observed=raw+3;fit=raw-2
            actual=translated(raw,observed,fit)
            expected=raw.copy();expected[list(PANEL)]-=5
            self.assertTrue(np.array_equal(actual,expected))
            self.assertTrue(np.array_equal(actual[[i for i in range(30) if i not in PANEL]],raw[[i for i in range(30) if i not in PANEL]]))

        def test_first_panel_maps_to_fit_without_averaging(self):
            first=np.arange(30,dtype=float);fit=-first
            self.assertTrue(np.array_equal(translated(first,first,fit)[list(PANEL)],fit[list(PANEL)]))

        def test_nonfinite_is_rejected(self):
            raw=np.zeros(30);raw[0]=np.nan
            with self.assertRaises(ValueError):translated(raw,np.zeros(30),np.zeros(30))

        def test_head_two_normalizations_projection_intercept(self):
            head=synthetic_head();raw=np.arange(30,dtype=float)
            actual,_=head_prediction(head,raw)
            z=(raw[:12]-1)/2
            projected=(z-3)/4
            expected=np.array([1.,2.,3.,4.])+projected.sum()*np.array([.1,.2,.3,.4])
            np.testing.assert_allclose(actual,expected,atol=1e-14,rtol=0)

        def test_lowest_index_argmax_tie(self):
            head=synthetic_head();head['coefficients']=np.zeros((13,4)).tolist()
            self.assertEqual(int(np.argmax(head_prediction(head,np.zeros(30))[0])),0)

        def test_cost_includes_rejected_nonzero_optimizer_steps(self):
            p,a=synthetic_config()
            cost=expected_block_cost(p,a,17,3,False)
            self.assertEqual(cost['optimizer_steps'],48)
            self.assertEqual(cost['discarded_gradient_microsteps'],48)
            self.assertEqual(cost['gradient_backward_examples'],4608)

        def test_zero_still_computes_full_gradients(self):
            p,a=synthetic_config();cost=expected_block_cost(p,a,17,0,True)
            self.assertEqual(cost.get('optimizer_steps',0),0)
            self.assertEqual(cost['scheduled_gradient_microsteps'],48)
            self.assertEqual(cost['gradient_generator_examples'],4608)

        def test_directional_feature_work_included(self):
            p,a=synthetic_config();cost=expected_feature_cost(p,a,17)
            self.assertEqual(cost['directional_backward_examples'],96)
            self.assertEqual(cost['feature_probe_reverse_examples'],1280)
            self.assertEqual(cost['current_hard_value_reward_observer_digit_examples'],1024)

        def test_forbidden_training_counter_rejected(self):
            with self.assertRaises(ValueError):counters({'audit_observer_calls':1},'synthetic')
            with self.assertRaises(ValueError):counters({'endpoint_generator_calls':1},'synthetic')

        def test_negative_or_float_counter_rejected(self):
            for value in (-1,1.0,True):
                with self.assertRaises(ValueError):counters({'gradient_backward_calls':value},'synthetic')

        def test_schedule_has_all_48_steps_and_binds_time(self):
            p,_=synthetic_config()
            self.assertNotEqual(schedule_sha(p,17,14000,0),schedule_sha(p,17,14000,48))
            self.assertNotEqual(schedule_sha(p,17,14000,0),schedule_sha(p,17,14001,0))

        def test_canonical_commit_binds_prediction_and_clock(self):
            row={'predictions':[1.,2.,3.,4.],'record_index':0,'committed_monotonic_ns':1}
            changed=deepcopy(row);changed['predictions'][0]=5
            self.assertNotEqual(object_sha(row),object_sha(changed))
            changed=deepcopy(row);changed['committed_monotonic_ns']=2
            self.assertNotEqual(object_sha(row),object_sha(changed))

    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Contracts)
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    return {"passed":result.wasSuccessful(),"tests_run":result.testsRun,"failures":len(result.failures),
            "errors":len(result.errors),"log":stream.getvalue(),"synthetic_only":True,
            "synthetic_contract_operations":dict(contract_cost)}


def synthetic_head():
    return {"mode":"field","dimension":12,"ridge":1.,"fit_rows":24,"prediction_clipping":False,
            "feature_names":list(NAMES),"coefficient_count":52,"raw_mean":np.ones(30).tolist(),
            "raw_scale":(np.ones(30)*2).tolist(),"projection":np.eye(30)[:,:12].tolist(),
            "projected_mean":(np.ones(12)*3).tolist(),"projected_scale":(np.ones(12)*4).tolist(),
            "coefficients":np.vstack((np.arange(1,5),np.tile(np.arange(1,5)/10,(12,1)))).tolist()}


def synthetic_config():
    return {"study_id":"synthetic.v4.audit.contract","training":{"fixed_actions":{"17":0},"conditions":["heavy_noise","missing","occlusion","clean"],
        "panel_batch_size":128,"macro_steps":48,"adapt_batch_size":64,"rehearsal_batch_size":32,
        "learning_rate":.2,"multipliers":[0.,.25,1.,2.],"guard_min_delta":0.,
        "batch_seed_offset":1600000,"rehearsal_seed_offset":2600000,"forward_seed_offset":1107}}, {
        "roles":{"qualification_probe":{"pairs":128},"qualification_guard":{"pairs":256}}}


def recommit_synthetic(fixture):
    for position in range(6):
        digest=object_sha(fixture['rows'][2*position])
        fixture['rows'][2*position+1]['decision_sha256']=digest
        fixture['done']['decisions'][position]['decision_sha256']=digest


def synthetic_trace(method):
    protocol,allocation=synthetic_config()
    seed,sid=17,14000
    head=None if method.startswith('ordinary_') else synthetic_head()
    if head is not None:
        head['coefficients']=np.zeros((13,4)).tolist();head['coefficients'][0][3]=1.
    initial={'parameters':'a'*64,'optimizer':'b'*64}
    fit=np.linspace(0.,.29,30)
    expected_base=base_policy(protocol,seed,method,{'synthetic':True},head,fit)
    states=[]
    for index in range(6):
        raw=np.linspace(.1,.39,30)+index*.01
        raw[0]=.25+index*.01
        raw[16:24]=0. if head is None else index*.01
        raw[4]=np.sqrt(np.mean(raw[16:24]**2))
        raw[5]=0. if head is None or index==0 else .002*index
        raw[6]=index/6
        raw[7]=.01+.002*index
        raw[8]=.2 if raw[5] else 0.
        states.append(raw)
    origin=states[0]
    realized={**expected_base,'observed_initial':origin.tolist(),'schedule_id':sid}
    done={'schema':'hepta.field-bridge.v4.trained-path.1','study_id':protocol['study_id'],
        'seed':seed,'method':method,'schedule_id':sid,'source_roles':list(ROLES),
        'endpoint_accessed':False,'best_step_selection':False,'final_step':288,
        'policy_identity':realized,'policy_sha256':object_sha(realized),'base_policy_sha256':object_sha(expected_base),
        'decisions':[],'wall_ns':100000,'cpu_ns':100000}
    rows=[];previous=deepcopy(initial);total=Counter()
    guard_baseline={'values':[.4]*256}
    for index,raw in enumerate(states):
        mapped=translated(raw,origin,fit)
        prediction=None if head is None else head_prediction(head,mapped if method.startswith('origin_') else raw)[0]
        chosen=int(method[-1]) if prediction is None else int(np.argmax(prediction))
        accepted=True if head is None else index not in (1,3)
        g,m=raw[7]*np.sqrt(128),raw[5]*np.sqrt(128)
        feature_cost=expected_feature_cost(protocol,allocation,seed)
        feature={'names':list(NAMES),'before':deepcopy(previous),'state_grad_rng_invariant':True,
            'measured':{'gradient_l2':g,'momentum_l2':m,'gradient_momentum_dot':raw[8]*g*m,
                'gradient_sha256':'1'*64,'momentum_sha256':'2'*64,'direction_sha256':'3'*64,
                'next_gradient':{'optimizer_advanced':False}},'resources':feature_cost}
        decision={'schema':'hepta.field-bridge.v4.decision.1','kind':'decision_before_update',
            'study_id':protocol['study_id'],'seed':seed,'method':method,'schedule_id':sid,'step':48*index,
            'raw_state':raw.tolist(),'mapped_state':mapped.tolist(),'observed_initial':origin.tolist(),
            'calibration_context':origin[list(PANEL)].tolist(),'fit_initial':fit.tolist(),'panel_indices':list(PANEL),
            'prediction_state_kind':'mapped' if method.startswith('origin_') else 'raw',
            'predictions':None if prediction is None else prediction.tolist(),'action_index':chosen,
            'base_policy_sha256':done['base_policy_sha256'],'policy_sha256':done['policy_sha256'],
            'before':deepcopy(previous),'schedule_sha256':schedule_sha(protocol,seed,sid,48*index),
            'current_reward_values':[float(raw[0])]*512,'current_output_sha256':['4'*64]*512,
            'feature_receipt':feature,'record_index':2*index,'committed_monotonic_ns':2*index+1}
        candidate=deepcopy(previous) if chosen==0 else {'parameters':object_sha(['p',index]),'optimizer':object_sha(['o',index])}
        guard=np.full(256,.4 if head is None else .41 if accepted else .39)
        block_cost=expected_block_cost(protocol,allocation,seed,chosen,accepted)
        receipt={'start':index*48,'end':(index+1)*48,'action_index':chosen,
            'multiplier':protocol['training']['multipliers'][chosen],'schedule_id':sid,
            'schedule_sha256':decision['schedule_sha256'],'before':deepcopy(previous),'candidate':candidate,
            'after':deepcopy(candidate if accepted else previous),'clock_advances_on_rejection':True,
            'guard_values':guard.tolist(),'guard_output_sha256':['5'*64]*256,
            'guard_delta':float(np.mean(guard-.4)),'accepted':accepted,
            'first_gradient':{'optimizer_advanced':chosen!=0,'loss':1.,'unclipped_gradient_norm':.2},
            'last_gradient':{'optimizer_advanced':chosen!=0,'loss':1.,'unclipped_gradient_norm':.2},'resources':block_cost}
        digest=object_sha(decision)
        outcome={'schema':'hepta.field-bridge.v4.block-outcome.1','kind':'block_outcome',
            'study_id':protocol['study_id'],'decision_sha256':digest,'policy_sha256':done['policy_sha256'],
            'receipt':receipt,'record_index':2*index+1,'committed_monotonic_ns':2*index+2}
        rows.extend((decision,outcome));previous=receipt['after']
        done['decisions'].append({'step':48*index,'action_index':chosen,'accepted':accepted,'decision_sha256':digest})
        total.update(feature_cost);total.update(block_cost)
    total.update(panel_origin_captures=1,panel_origin_calibration_context_values=14,panel_origin_calibration_context_bytes=112,
        panel_origin_translation_calls=6,panel_origin_coordinates=84,policy_prediction_calls=0 if head is None else 6,
        training_trace_bytes=2048,checkpoint_bytes=1024,policy_control_wall_ns=10,policy_control_cpu_ns=10,
        checkpoint_serialization_wall_ns=10)
    done.update(final_identity=previous,resources={k:v for k,v in total.items() if v})
    return {'rows':rows,'done':done,'protocol':protocol,'allocation':allocation,'seed':seed,'sid':sid,'method':method,
            'head':head,'expected_base':expected_base,'initial_identity':initial,'baseline_guard':guard_baseline,
            'parameter_count':128,'trace_bytes':2048,'checkpoint_bytes':1024}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',type=Path)
    parser.add_argument('--v3-run',type=Path,default=Path('/tmp/hepta-field-v3-run'))
    parser.add_argument('--protocol',type=Path,default=SCIENCE/'PROTOCOL.json')
    parser.add_argument('--freeze',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    need(not args.output.exists(),'Refusing to overwrite an audit result')
    started,cpu=time.perf_counter_ns(),time.process_time_ns()
    inputs=Inputs()
    result={"schema":"hepta.field-bridge.v4.independent-training-audit.1",
            "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "authority":"DENY_ALL","requires_calibration":True,"native_owner_integration":False,
            "scientific_gate_changed":False,"generator_calls":0,"observer_calls":0,"native_tick_calls":0,
            "gradient_or_optimizer_updates":0,"source_role_tensor_loads":0,"network_calls":0}
    try:
        if args.self_test:
            result.update(self_test())
        else:
            need(args.run is not None and args.freeze is not None,'Actual audit requires run and training freeze')
            result.update(full_audit(args.run,args.v3_run,args.protocol,args.freeze,inputs))
            result.update(passed=True,synthetic_only=False)
    except Exception as error:
        result.update(passed=False,error_type=type(error).__name__,error=str(error))
    result.update(wall_ns=time.perf_counter_ns()-started,cpu_ns=time.process_time_ns()-cpu,
        input_files=inputs.identities,auditor_io_read_bytes=inputs.read_bytes,auditor_io_read_calls=inputs.read_calls,
        weights_only_checkpoint_loads=inputs.checkpoint_loads,
        cost_scope='This auditor invocation only, including verification and deserialization; prior source/schema reading was separate and untimed.')
    with args.output.open('x') as stream:
        json.dump(result,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps({"passed":result['passed'],"output":str(args.output),"error":result.get('error'),
                      "wall_ns":result['wall_ns'],"weights_only_checkpoint_loads":inputs.checkpoint_loads}))
    return 0 if result['passed'] else 2


if __name__=='__main__':
    raise SystemExit(main())
