# Identify the failing Matrix session stage

The Windows case returned only Error: Initialization. Its whole 26-case batch finished in 15.70 seconds, below the 20-second startup deadline. Three fallible stages map to the same error: encrypted client construction, session publication and reload. Add stage context to the test return path only. All calls, token values, deadlines, finalization error and complete session equality remain unchanged; this is diagnostic work, not a runtime fix or passing result.

Source review found that session publication renames the file and then calls ordinary File::open on the parent directory, which Windows does not support without a directory handle flag. This is a concrete incompatible path, but the original generic log does not establish whether that call was the first failure in this run. The diagnostic case must execute before claiming that location.
