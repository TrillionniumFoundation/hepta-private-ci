# Require a real running child before testing interruption

The real Windows run received a no-active-turn error. The fixture uses the shared synthetic /tmp/project cwd without creating it and accepts TurnStarted as proof that its child is alive. The actual user-shell implementation emits TurnStarted before validating its environment, cwd or spawning a process, so this precondition is insufficient. The current Windows default shell selection prefers PowerShell; the original log does not establish an incorrect shell.

Give this one case an owned TempDir cwd and use that same configuration for the embedded server and thread. Keep the original 30-second shell command, adding a readiness line, and wait for the real output of that child. A prematurely completed turn is an explicit fixture failure. The original five-second event wait and final control, operation-channel and shutdown-event assertions remain. No production logic, skip or timeout increases. Native execution is pending.
