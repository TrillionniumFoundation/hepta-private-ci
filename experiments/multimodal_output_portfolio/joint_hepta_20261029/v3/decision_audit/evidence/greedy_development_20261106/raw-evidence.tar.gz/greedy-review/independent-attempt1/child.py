from pathlib import Path
import json, sys
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import dual_runtime as runtime
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.r2_greedy_policy import DevelopmentGreedy
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_transition_capture import SyntheticBackend
job = json.load(sys.stdin)
assert set(job) == {"request", "model", "output"}
out = Path(job["output"])
controller = DevelopmentGreedy(*job["model"], out / "policy", maximum_decisions=4)
backend = SyntheticBackend()
report = runtime.run(runtime.Request(**job["request"]), backend, controller, out,
    horizon=4, deadline_seconds=30, cpu_tariff=0.02, wall_tariff=0.001)
runtime.write_json(out / "backend_calls.json", backend.calls)
print(json.dumps({"status": report["status"], "history": report["history"]}))
