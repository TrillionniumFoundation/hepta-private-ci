
import json, sys
from pathlib import Path
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import dual_runtime as runtime
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.r2_greedy_policy import DevelopmentGreedy
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_transition_capture import SyntheticBackend
job = json.load(sys.stdin)
assert set(job) == {'request', 'model', 'output'}
output = Path(job['output'])
controller = DevelopmentGreedy(*job['model'], output / 'policy')
backend = SyntheticBackend()
report = runtime.run(runtime.Request(**job['request']), backend, controller, output,
                     horizon=8, deadline_seconds=30, cpu_tariff=0.02, wall_tariff=0.001)
runtime.write_json(output / 'backend_calls.json', backend.calls)
print(json.dumps({'status': report['status'], 'history': report['history']}))
