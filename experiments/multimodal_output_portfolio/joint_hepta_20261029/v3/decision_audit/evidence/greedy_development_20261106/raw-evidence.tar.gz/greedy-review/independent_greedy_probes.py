"""Narrow D review: reuse an existing synthetic C fit; no fit or real-model call."""
from pathlib import Path
from dataclasses import asdict
from unittest.mock import patch
import hashlib
import json
import math
import resource
import shutil
import subprocess
import sys
import time
import traceback

ROOT = Path('/workspace/scratch/e5ae6a941e52')
REPO = ROOT / 'r2-protocol'
BASE = REPO / 'experiments/multimodal_output_portfolio/joint_hepta_20261029/v3/decision_audit'
sys.path.insert(0, str(REPO))
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import dual_runtime as runtime
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import r2_action_value as av
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import r2_greedy_policy as greedy
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_transition_capture import SyntheticBackend

WORKER = '''from pathlib import Path
import json, sys
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import dual_runtime as runtime
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.r2_greedy_policy import DevelopmentGreedy
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_transition_capture import SyntheticBackend
job = json.load(sys.stdin)
assert set(job) == {"request", "model", "output"}
out = Path(job["output"])
controller = DevelopmentGreedy(*job["model"], out / "policy", maximum_decisions=4)
backend = SyntheticBackend()
report = runtime.run(runtime.Request(**job["request"]), backend, controller, out,
    horizon=4, deadline_seconds=30, cpu_tariff=0.02, wall_tariff=0.001)
runtime.write_json(out / "backend_calls.json", backend.calls)
print(json.dumps({"status": report["status"], "history": report["history"]}))
'''


def digest(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    with Path(path).open('x') as f:
        f.write(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')


def main():
    out = ROOT / 'greedy-review/independent-attempt1'
    out.mkdir()
    start = time.process_time(), time.perf_counter()
    child0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    sources = ('r2_greedy_policy.py', 'r2_action_value.py', 'dual_runtime.py',
               'transition_capture.py', 'transition_capture_read.py', 'test_transition_capture.py')
    before = {name: digest(BASE / name) for name in sources}
    (out / 'executed-source').mkdir()
    for name in sources:
        shutil.copyfile(BASE / name, out / 'executed-source' / name)
    result = {'schema': 'hepta.r2.greedy-independent-probe.v1', 'status': 'failed',
              'scope': 'Existing synthetic C checkpoint; original runtime with synthetic backend; no new fit',
              'source_before': before, 'probes': [], 'new_fit_calls': 0,
              'real_generator_model_calls': 0, 'independent_labels': False,
              'baseline_qualified': False, 'no_update': True}
    try:
        previous = ROOT / 'greedy-review/trace-init-original-probe'
        model = out / 'model'
        model.mkdir()
        for name in ('checkpoint.json', 'FIT.json'):
            shutil.copyfile(previous / 'fit-1' / name, model / name)
        binding = [str(model / 'checkpoint.json'), digest(model / 'checkpoint.json')['sha256'], digest(model / 'FIT.json')['sha256']]
        assert binding[1] == '7f45b79a24b6daa4a7aac830fccc480e7af25cb2a4bab9b542e1d6f7d50fceb3'
        assert binding[2] == '6c7dc6bfd28249e4ccab71e62733fe6896caacf3f2ff3008076a31d5058de2b2'
        checkpoint = json.loads((model / 'checkpoint.json').read_bytes())
        assert checkpoint['initial_parameter_sha256'] != checkpoint['parameter_sha256']
        image = out / 'input.png'
        shutil.copyfile(previous / 'input-0.png', image)
        request = runtime.Request('independent-synthetic-greedy-control', str(image), digest(image)['sha256'], 'Describe shapes.')
        result['model_binding'] = binding
        result['initial_parameter_sha256'] = checkpoint['initial_parameter_sha256']
        result['parameter_sha256'] = checkpoint['parameter_sha256']
        job = {'request': asdict(request), 'model': binding, 'output': str(out / 'cold-process')}
        save(out / 'CHILD-INPUT.json', job)
        (out / 'child.py').write_text(WORKER)
        command = [sys.executable, '-B', '-c', WORKER]
        run = subprocess.run(command, input=json.dumps(job), text=True, capture_output=True,
                             cwd=REPO, timeout=45)
        (out / 'child.stdout').write_text(run.stdout)
        (out / 'child.stderr').write_text(run.stderr)
        save(out / 'CHILD-EXECUTION.json', {'argv': command, 'cwd': str(REPO), 'exit_code': run.returncode,
             'input_sha256': digest(out / 'CHILD-INPUT.json')['sha256'], 'source_sha256': digest(out / 'child.py')['sha256']})
        assert run.returncode == 0, run.stderr
        report = json.loads((out / 'cold-process/report.json').read_bytes())
        rows = [json.loads(p.read_bytes()) for p in sorted((out / 'cold-process/policy').glob('decision-*.json'))]
        assert rows and report['history'] and report['status'] not in ('failed', 'cancelled', 'timeout')
        assert any(action != 'stop' for action, _ in report['history'])
        predictor = av.ActionValue(*binding)
        controllers = [e for e in report['events'] if e['action'] == 'controller']
        for row, controller in zip(rows, controllers, strict=True):
            assert row['status'] == 'completed'
            assert row['prediction_calls'] <= 7
            assert row['metering']['wall_seconds'] <= controller['wall_seconds']
            assert row['metering']['cpu_seconds'] <= controller['cpu_seconds']
            expected, best = 'stop', 0.0
            calls = 0
            for c in row['candidates']:
                if c['legal']:
                    assert c['status'] == 'scored'
                    score = predictor.predict(row['view'], c['action'])
                    assert score == c['predicted_one_step_net_gain']
                    calls += 1
                    if score > best:
                        expected, best = c['action'], score
                else:
                    assert c['status'] == 'illegal' and c['predicted_one_step_net_gain'] is None
            assert calls == row['prediction_calls'] and row['choice'] == expected
        for field in ('cpu_seconds', 'wall_seconds', 'tariff_amount'):
            assert report[field] == math.fsum(e[field] for e in report['events'])
        assert math.isclose(report['tariff_amount'], report['cpu_seconds']*0.02 + report['wall_seconds']*0.001, rel_tol=1e-12)
        result['probes'].append({'name': 'cold_original_runner', 'passed': True,
            'history': report['history'], 'status': report['status'], 'decisions': len(rows),
            'prediction_calls': sum(row['prediction_calls'] for row in rows),
            'predictions_match_unmodified_C': True, 'net_target_not_subtracted_again': True,
            'costs_equal_original_event_sum_without_diagnostic_additions': True})

        def episode(name, fault):
            directory = out / name
            policy = greedy.DevelopmentGreedy(*binding, directory / 'policy')
            backend = SyntheticBackend()
            with fault:
                episode_report = runtime.run(request, backend, policy, directory,
                    horizon=4, deadline_seconds=30, cpu_tariff=0.02, wall_tariff=0.001)
            save(directory / 'policy_memory.json', policy.decisions)
            save(directory / 'backend_calls.json', backend.calls)
            assert episode_report['history'] == []
            assert not any(c[0] in ('describe', 'draw') for c in backend.calls)
            assert any(e['action'] == 'controller' for e in episode_report['events'])
            assert policy.fenced
            try:
                policy.choose(runtime.View('Describe shapes.', 'Describe shapes.', 0, None, None, '', (), 4, 30))
            except ValueError as error:
                assert 'fenced' in str(error)
            else:
                raise AssertionError('Failed controller was reused')
            return episode_report, policy.decisions[0]

        real_predict = av.ActionValue.predict
        def cancel_second(model, view, action):
            if action == 'text':
                raise KeyboardInterrupt('injected cancellation on second legal score')
            return real_predict(model, view, action)
        report, row = episode('cancel-during-score', patch.object(av.ActionValue, 'predict', cancel_second))
        assert report['status'] == 'cancelled' and row['status'] == 'cancelled'
        assert row['prediction_calls'] == 2
        assert row['candidates'][0]['status'] == 'scored'
        assert row['candidates'][1]['error']['type'] == 'KeyboardInterrupt'
        assert all(c['prediction_metering'] is not None for c in row['candidates'][:2])
        result['probes'].append({'name': 'cancel_during_score', 'passed': True,
            'prior_unselected_scoring_cost_retained': True, 'dispatch_count': 0, 'fenced': True})

        real_write = greedy.write_new
        def cancel_decision_write(path, value):
            if Path(path).name == 'decision-000.json':
                raise KeyboardInterrupt('injected cancellation on final decision trace write')
            return real_write(path, value)
        report, row = episode('cancel-during-decision-write', patch.object(greedy, 'write_new', cancel_decision_write))
        assert report['status'] == 'cancelled'
        assert row['trace_write_error']['type'] == 'KeyboardInterrupt'
        assert row['prediction_calls'] > 0 and row['choice'] is not None
        assert not (out / 'cancel-during-decision-write/policy/decision-000.json').exists()
        result['probes'].append({'name': 'cancel_during_decision_trace_write', 'passed': True,
            'proposed_choice_is_not_dispatched': True, 'disk_trace_missing_is_not_completed_evidence': True,
            'row_and_error_retained_by_test_harness': True, 'dispatch_count': 0, 'fenced': True})

        def fail_policy_write(path, value):
            if Path(path).name == 'POLICY.json':
                raise OSError('injected initial POLICY write failure')
            return real_write(path, value)
        report, row = episode('fail-policy-header', patch.object(greedy, 'write_new', fail_policy_write))
        assert report['status'] == 'failed' and row['prediction_calls'] == 0
        assert row['error']['type'] == 'OSError'
        result['probes'].append({'name': 'initial_trace_failure_and_reuse_fence', 'passed': True,
            'dispatch_count': 0, 'fenced': True,
            'previous_probe_exit1_was_observed_fence_with_stale_harness_expectation': True})
        result['status'] = 'passed'
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
    finally:
        result['source_after'] = {name: digest(BASE / name) for name in sources}
        result['sources_unchanged'] = before == result['source_after']
        if not result['sources_unchanged']:
            result['status'] = 'failed'
        child1 = resource.getrusage(resource.RUSAGE_CHILDREN)
        result['cost'] = {'current_process_cpu_seconds': time.process_time() - start[0],
            'inclusive_wall_seconds': time.perf_counter() - start[1],
            'waited_child_cpu_seconds': child1.ru_utime + child1.ru_stime - child0.ru_utime - child0.ru_stime,
            'scope': 'Review execution interval including nested runner/controller/predictions and child wait; child CPU is separate; excludes imports and final result write',
            'unknown': ['energy_joules', 'physical_io_bytes', 'source_authoring_and_full_external_startup_cost']}
        save(out / 'RESULT.json', result)
    print(json.dumps({'status': result['status'], 'probes': result['probes'], 'error': result.get('error'), 'sources_unchanged': result['sources_unchanged']}, ensure_ascii=False))
    return 0 if result['status'] == 'passed' else 1

if __name__ == '__main__':
    raise SystemExit(main())
