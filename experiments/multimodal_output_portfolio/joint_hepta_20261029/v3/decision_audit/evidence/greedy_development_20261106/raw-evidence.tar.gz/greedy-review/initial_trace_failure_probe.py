"""Original trace-init failure reproduction, synthetic captures/labels only."""

import hashlib
import importlib.util
import json
from pathlib import Path
from unittest.mock import patch

from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import dual_runtime as runtime
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_r2_action_value import ActionValueTests


root = Path('/workspace/scratch/e5ae6a941e52/greedy-review/trace-init-original-probe')
root.mkdir(parents=True, exist_ok=False)
source = root.parent / 'initial-r2_greedy_policy.py'
source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
name = 'experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.review_initial_greedy'
spec = importlib.util.spec_from_file_location(name, source)
greedy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(greedy)
helper = ActionValueTests()
helper.root, helper.counter = root, 0
captured = helper.capture(actions=('perceive', 'text', 'draft', 'verify', 'revise', 'text', 'refine', 'verify', 'stop'))
out, fit = helper.fit(helper.bundle([captured]))
assert fit['status'] == 'completed'
view = runtime.View(**captured[1]['transitions'][0]['before_view'])
policy = greedy.DevelopmentGreedy(out / 'checkpoint.json', fit['checkpoint']['sha256'],
                                  fit['fit_receipt']['sha256'], root / 'policy-trace')
original_write = greedy.write_new
failed_once = False


def fail_policy_once(path, value):
    global failed_once
    if Path(path).name == 'POLICY.json' and not failed_once:
        failed_once = True
        raise OSError('injected initial policy binding write failure')
    return original_write(path, value)


first_error = None
with patch.object(greedy, 'write_new', fail_policy_once):
    try:
        policy.choose(view)
    except OSError as error:
        first_error = str(error)
    second_choice = policy.choose(view)
result = {'scope': 'failure reproduction using actual C fit/loading on synthetic labels; no real model or labels',
          'source_sha256': source_sha, 'source_unchanged': source_sha == hashlib.sha256(source.read_bytes()).hexdigest(),
          'first_error': first_error, 'second_choice': second_choice,
          'policy_manifest_exists': (root / 'policy-trace/POLICY.json').exists(),
          'second_decision': policy.decisions[-1],
          'fit_checkpoint_sha256': fit['checkpoint']['sha256'], 'fit_receipt_sha256': fit['fit_receipt']['sha256']}
(root / 'RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'second_decision'}, sort_keys=True, indent=2))
