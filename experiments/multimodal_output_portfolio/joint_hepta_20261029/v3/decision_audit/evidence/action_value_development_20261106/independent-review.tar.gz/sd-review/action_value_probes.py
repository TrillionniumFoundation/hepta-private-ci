"""Review-only failure probes against the unchanged action-value source."""

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch
import warnings

from PIL import Image

from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import r2_action_value as av
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import dual_runtime as runtime
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_r2_action_value import ActionValueTests
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_transition_capture import SyntheticBackend
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.transition_capture import DevelopmentSource, TransitionCapture, file_identity
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.transition_capture_read import read_capture


root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=False)
results = {"scope": "synthetic review probes only; no real training or independent labels",
           "source_before": av.source_pins()}


def fixture(name):
    helper = ActionValueTests()
    helper.root = root / name
    helper.root.mkdir()
    helper.counter = 0
    return helper


# A real accepted checkpoint whose fit receipt records an over-budget terminal.
helper = fixture("receipt-rebinding")
bundle = helper.bundle([helper.capture()])
original_write, real_time, offset = av.write_new, av.time, [0.0]
clock = SimpleNamespace(process_time=real_time.process_time,
                        perf_counter=lambda: real_time.perf_counter() + offset[0])


def delayed_write(path, value):
    identity = original_write(path, value)
    if Path(path).name == "checkpoint.json":
        offset[0] = 1000.0
    return identity


with patch.object(av, "write_new", delayed_write), patch.object(av, "time", clock):
    output, report = helper.fit(bundle)
expected = report["checkpoint"]["sha256"]
before_rejected = False
try:
    av.ActionValue(output / "checkpoint.json", expected)
except ValueError:
    before_rejected = True
receipt = json.loads((output / "FIT.json").read_bytes())
receipt["status"] = "completed"
(output / "FIT.json").write_bytes(av.canonical(receipt))
after_accepted = True
try:
    av.ActionValue(output / "checkpoint.json", expected)
except ValueError:
    after_accepted = False
results["unpinned_fit_receipt"] = {"original_status": report["status"],
    "checkpoint_sha256": expected, "originally_rejected": before_rejected,
    "accepted_after_only_fit_status_changed": after_accepted}


# These are finite values admitted by validate_config. Loss/MSE may overflow.
helper = fixture("nonfinite-statistic")
bundle = helper.bundle([helper.capture()])
bundle["config"].update(learning_rate=1e-300, updates=1,
                         service_tariffs={action: 1e200 for action in runtime.ACTIONS})
output = helper.root / f"fit-{helper.counter}"
av.validate_config(bundle["config"])
error = None
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter("always")
    try:
        helper.fit(bundle)
    except Exception as exception:
        error = type(exception).__name__ + ": " + str(exception)
results["nonfinite_report"] = {"config_admitted": True, "exception_escaped_fit": error,
    "fit_receipt_exists": (output / "FIT.json").is_file(),
    "checkpoint_exists": (output / "checkpoint.json").is_file(),
    "warnings": [str(w.message) for w in caught]}


# Successful provider return followed by actual after-action deadline expiry.
helper = fixture("late-action")
image = helper.root / "input.png"
Image.new("RGB", (2, 2), (1, 2, 3)).save(image)
source = DevelopmentSource("train", "source-late", file_identity(image)["sha256"],
    hashlib.sha256(b"Describe shapes.").hexdigest(), "a" * 64)
request = runtime.Request(source.source_id, str(image), source.image_sha256, "Describe shapes.")
capture_dir = helper.root / "capture-late"


class SlowBackend(SyntheticBackend):
    def describe(self, *args, **kwargs):
        time.sleep(0.3)
        return super().describe(*args, **kwargs)


backend = SlowBackend()
episode = runtime.run(request, backend, runtime.FixedSchedule(("text", "stop")), capture_dir,
    deadline_seconds=0.2, recorder=TransitionCapture(source))
capture = read_capture(capture_dir)
entry = {"capture_id": "capture-late", "directory": capture_dir.name,
    "summary_sha256": file_identity(capture_dir / "transition_capture/SUMMARY.json")["sha256"],
    "declared_source": asdict(source), "split": "train", "source_cluster_id": "late-only"}
bundle = helper.bundle([(entry, capture, backend)])
output, report = helper.fit(bundle)
rows = json.loads((output / "TRAINING_ROWS.json").read_bytes()) if (output / "TRAINING_ROWS.json").exists() else []
results["late_action"] = {"episode_status": episode["status"],
    "events": [{k: e[k] for k in ("event_id", "action", "status", "detail")} for e in episode["events"]],
    "label": bundle["label_manifest"]["rows"], "fit_status": report["status"],
    "targets": [r["target"] for r in rows]}
results["source_after"] = av.source_pins()
assert results["source_before"] == results["source_after"]
(root / "RESULT.json").write_text(json.dumps(results, sort_keys=True, indent=2) + "\n")
print(json.dumps(results, sort_keys=True, indent=2))
