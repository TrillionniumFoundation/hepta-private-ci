"""Independent regression probes, using retained synthetic actual-action traces."""

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image

from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import r2_action_value as av
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit import dual_runtime as runtime
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_r2_action_value import ActionValueTests
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.test_transition_capture import SyntheticBackend
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.transition_capture import DevelopmentSource, TransitionCapture, file_identity
from experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit.transition_capture_read import read_capture


root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=False)
results = {"scope": "synthetic independent regression probes; no real model or labels",
           "source_before": av.source_pins()}


def fixture(name):
    helper = ActionValueTests()
    helper.root = root / name
    helper.root.mkdir()
    helper.counter = 0
    return helper


helper = fixture("receipt-rebinding")
bundle = helper.bundle([helper.capture()])
original_write, real_time, offset = av.write_new, av.time, [0.0]
clock = SimpleNamespace(process_time=real_time.process_time,
                        perf_counter=lambda: real_time.perf_counter() + offset[0])


def delayed_write(path, value):
    identity = original_write(path, value)
    if Path(path).name == "checkpoint.json":
        offset[0] = 1000.0
    return identity


with patch.object(av, "write_new", delayed_write), patch.object(av, "time", clock):
    output, report = helper.fit(bundle)
expected, fit_expected = report["checkpoint"]["sha256"], report["fit_receipt"]["sha256"]
rejections = []
for altered in (False, True):
    if altered:
        receipt = json.loads((output / "FIT.json").read_bytes())
        receipt["status"] = "completed"
        (output / "FIT.json").write_bytes(av.canonical(receipt))
    try:
        av.ActionValue(output / "checkpoint.json", expected, fit_expected)
    except ValueError as error:
        rejections.append(str(error))
    else:
        raise AssertionError("over-budget or rebound receipt accepted")
results["fit_receipt_rebinding"] = {"passed": True, "rejections": rejections,
                                   "original_fit_sha256": fit_expected}


helper = fixture("nonfinite-statistic")
bundle = helper.bundle([helper.capture()])
bundle["config"].update(learning_rate=1e-300, updates=1,
                         service_tariffs={action: 1e200 for action in runtime.ACTIONS})
av.validate_config(bundle["config"])
output, report = helper.fit(bundle)
assert report["status"] == "failed" and report["fit_receipt"] is not None
assert (output / "partial_state.json").is_file()
assert not (output / "checkpoint.json").exists()
json.loads((output / "FIT.json").read_bytes(), parse_constant=lambda x: (_ for _ in ()).throw(AssertionError(x)))
results["nonfinite_statistic"] = {"passed": True, "terminal": report["status"],
    "fit_receipt": report["fit_receipt"], "error": report["error"],
    "cpu_seconds": report["metering"]["cpu_seconds"], "wall_seconds": report["metering"]["wall_seconds"]}


helper = fixture("late-action")
image = helper.root / "input.png"
Image.new("RGB", (2, 2), (1, 2, 3)).save(image)
source = DevelopmentSource("train", "source-late", file_identity(image)["sha256"],
    hashlib.sha256(b"Describe shapes.").hexdigest(), "a" * 64)
request = runtime.Request(source.source_id, str(image), source.image_sha256, "Describe shapes.")
capture_dir = helper.root / "capture-late"


class SlowBackend(SyntheticBackend):
    def describe(self, *args, **kwargs):
        time.sleep(0.3)
        return super().describe(*args, **kwargs)


backend = SlowBackend()
episode = runtime.run(request, backend, runtime.FixedSchedule(("text", "stop")), capture_dir,
    deadline_seconds=0.2, recorder=TransitionCapture(source))
assert episode["status"] == "timeout"
capture = read_capture(capture_dir)
entry = {"capture_id": "capture-late", "directory": capture_dir.name,
    "summary_sha256": file_identity(capture_dir / "transition_capture/SUMMARY.json")["sha256"],
    "declared_source": asdict(source), "split": "train", "source_cluster_id": "late-only"}
bundle = helper.bundle([(entry, capture, backend)])
output, rejected = helper.fit(bundle)
assert rejected["status"] == "failed" and "Failure utility" in rejected["error"]["message"]
assert not (output / "checkpoint.json").exists()
assert rejected["retained_captures"][0]["status"] == "timeout"
bundle["label_manifest"]["rows"][0]["utility_after"] = -1.0
bundle["labels_sha256"] = av.digest(bundle["label_manifest"])
output, accepted = helper.fit(bundle)
assert accepted["status"] == "completed"
rows = json.loads((output / "TRAINING_ROWS.json").read_bytes())
assert len(rows) == 1 and rows[0]["action_status"] == "ok" and rows[0]["outcome_status"] == "timeout"
assert rows[0]["target"] <= -1
results["late_action_failure_label"] = {"passed": True, "episode_status": episode["status"],
    "positive_label_fit_status": rejected["status"], "corrected_label_fit_status": accepted["status"],
    "action_status": rows[0]["action_status"], "outcome_status": rows[0]["outcome_status"],
    "target": rows[0]["target"]}


results["cancellation_during_state_writes"] = []
for file_name in ("FIT.json", "partial_state.json"):
    helper = fixture("cancel-" + file_name)
    bundle = helper.bundle([helper.capture()])
    if file_name == "partial_state.json":
        bundle["config"]["maximum_wall_seconds"] = 1e-12
    original_write = av.write_new
    def interrupted_write(path, value):
        if Path(path).name == file_name:
            raise KeyboardInterrupt("injected SIGTERM-mapped cancellation at " + file_name)
        return original_write(path, value)
    with patch.object(av, "write_new", interrupted_write):
        output, report = helper.fit(bundle)
    assert report["status"] != "completed"
    if file_name == "FIT.json":
        assert report["status"] == "cancelled" and report["fit_receipt"] is None
    else:
        assert report["partial_state_write_error"]["type"] == "KeyboardInterrupt"
        assert report["fit_receipt"] is not None
    results["cancellation_during_state_writes"].append({"phase": file_name, "passed": True,
        "terminal": report["status"], "fit_receipt": report["fit_receipt"],
        "metering": report["metering"]})

results["source_after"] = av.source_pins()
assert results["source_before"] == results["source_after"]
results["all_probes_passed"] = True
(root / "RESULT.json").write_text(json.dumps(results, sort_keys=True, indent=2) + "\n")
print(json.dumps(results, sort_keys=True, indent=2))
