# Fresh NDU factorial: reporting and reproduction plan fixed before results

This document specifies how to report the already registered experiment. It changes no algorithm, source selection, optimizer, comparison, budget or success rule. No fresh NDU outcome has been supplied to this reporting task. The actual host freeze is in progress; publication and execution receipts must be obtained before reporting that either occurred.

The algorithm revision inspected here is `689c45e1903a6b28dcff6d05c7b732a07511f512`. A later registration commit will contain the resolved protocol. That publication HEAD, rather than the earlier algorithm commit, is the runner's `--source-commit`. `source-bindings.json` records all 40 inspected algorithm/published-source identities against the actual r2 census. The historical recovery experiment and its original full-002 archive pins remain unchanged.

## 1. Questions and fixed interpretation

The study separates two training factors in a constructed MNIST digit-pair text/image task:

| Cell | Base training objective | Gate training objective |
| --- | --- | --- |
| b0g0 | Supervised differentiable surrogate | Hard mean-best-plan imitation |
| b0g1 | Supervised differentiable surrogate | Direct finite entropic utility |
| b1g0 | Terminal-entropic differentiable surrogate | Hard mean-best-plan imitation |
| b1g1 | Terminal-entropic differentiable surrogate | Direct finite entropic utility |

The base factor compares aggregation of the original differentiable training loss. That loss is not the emitted-output observer score. Its effect includes refitting the two registered gate objectives on each resulting base; it is not a base-weight intervention holding one already fitted gate unchanged. The gate factor compares an objective package; it does not isolate risk aversion alone. Both gate fits on each frozen base receive the same emitted-output reward table, although the implementation separately enumerates that table for both fits and incurs both costs.

Deployment uses a frozen gate to select one of four fixed two-action plans, followed by the same three-action suffix. It has no forecast, search, dynamic controller, online parameter update, adaptive stopping or topology change. A favorable result can support a particular registered training-objective contrast in this domain. It cannot establish online-controller benefit, cell division, emergent general intelligence, production qualification or recovery of the lost historical models. Absolute scores must not be pooled with old full-002 scores or the separate V4 study.

## 2. Evidence request and archive contents

Retain the complete original owner directory, including all failures and logs, in a byte-manifested archive. Keep it separate from derived reporting files. Below, `OWNER` means the exact absolute directory in the published protocol, and paths are relative to that owner unless specified otherwise. These are expected outputs, not a claim that they already exist.

| Evidence | Exact paths or pattern | Required use |
| --- | --- | --- |
| Registration and publication | Published `fresh_factorial/protocol.json`; original freeze output, census, review and publication verification receipt | Bind algorithm source, resolved protocol, unique owner, exposure scope and pre-data publication |
| Harness execution | `harness-start.json`, `harness-summary.json`; `{prepare,bootstrap,gates,inference,replay,evaluate}-process.json` and corresponding `.log` | Check one invocation, exact executable/argv, six stages, completion, failures and resource costs |
| Prepared data | `data/data-receipt.json`, `data/cases.json`, `data/training-source.json`, `data/observer-source.json`, `data/reserved-sources.json` | Verify 90 cases, 180 distinct pixels, source disjointness and reserved identities |
| Prepared arrays | `data/{training,observer-training,observations,final-targets}.npz` | Preserve exact original bytes and receipt identities; reporting does not open final targets or prepare another cohort |
| Generation | `bootstrap/{source-freeze,generation-start,recipe-controls,bootstrap,bootstrap-seal}.json` | Verify fresh provenance, paired controls, observer separation and complete bootstrap seal |
| Observers | `bootstrap/{reward,audit}-observer.pt` and `.json` | Two new observers, 300 updates each; calibration is descriptive and never a selection criterion |
| Bases | `bootstrap/seed-{17,29,43}-{supervised,terminal_entropic_ndu}.pt` and corresponding `-training.json` | Six complete 2,000-update reports, identical paired initialization/schedules, reload identities |
| Gate training | `training/{source-freeze,training,training-seal}.json`; `training/seed{17,29,43}-{b0g0,b0g1,b1g0,b1g1}.pt` and corresponding `-training.json` | Twelve 120-update fits; frozen bases/reward observer, paired utilities and controls |
| Model generation seal | `model-seal.json` | Exact 20-model set, generation ID, optimizer totals, protocol/data/bootstrap/training bindings; no omitted or extra model |
| Inference and replay | In each of `inference/` and `replay/`: `source-freeze.json`, `run.json`, `rows.json`, `states.npz`, `run-seal.json`; additionally `replay/replay.json` | Complete row census and exact separate-process replay before final target access |
| Emitted artifacts | In both runs: `outputs/seed{seed}-{arm}/{case_id}/image.png` and `caption.txt` | Every file hash must match its row and seal; preserve all outputs without selecting favorable examples |
| Final access | `data/final-access-ndu-fresh-factorial.json`; successful copy `evaluation/final-access.json` | Exclusive claim predates the target read; generation and all preceding seals must match |
| Final scoring | `evaluation/{source-freeze,scored-rows,summary,evaluation-seal}.json` | Original 1,080 scored rows, three contrasts, all secondaries and arithmetic check |
| Failure evidence | Any stage `failure.json`, `evaluation/final-access-failure.json`, process failure/logs, external exit/status receipt | Preserve failures even if no summary/seal exists; do not manufacture missing intermediate metrics |
| Setup costs | Original environment availability/install receipts, cache materialization and transfer receipts supplied separately | Separate setup from the 1,800-second experiment budget |

The transport manifest should bind relative member paths, bytes and SHA256, identify the exact publication HEAD and protocol file/canonical hashes, and reject path traversal, symlinks and duplicate paths. Keep the original receipt bytes. A parsed projection is labeled as such and does not replace the original hash. When a file is absent after failure, record it as absent rather than inventing a normal schema or a zero value.

## 3. Integrity checks before any scientific conclusion

1. **Publication and source:** bind the externally verified registration HEAD, exact resolved protocol, all 40 algorithm/source pins and stage source-freeze records. Confirm publication preceded preparation. This is an external receipt check; a local Git commit alone is not proof of publication.
2. **Source scope:** retain `audited_known_v6_sources_only`, the 520 explicitly enumerated excluded pixel identities, the complete train/evaluator/validation exclusions and reserved future900–999/retention450–499. The 520 are not the total number of historically loaded or trained pixels. Full-002 weights remain unavailable. The new cohort must be exactly future120–179 and retention60–89, with no overlap or fallback sampling.
3. **Fresh generation:** verify two observers, six bases and twelve controlled base+gate files. Model-seal membership must be exactly 20, with 600 observer + 12,000 base + 1,440 gate updates. Bind the create-only generation receipt, actual checkpoint/report bytes, typed save/reload evidence and complete bootstrap/training seals. A synthetic-test success is not optimizer execution.
4. **Matched controls:** check seeds 17/29/43, independent initializer/schedule fingerprints, 2,000 sequential base history entries, paired initial/batch/action/noise recipe, and all gate report fields required by `matching.py`. Gate pairs must share source IDs, batch/scenario/update schedule, utility table and frozen base identity. Audit B must not enter base/gate fitting. Report the observed calibration accuracy without selecting or refitting an observer.
5. **Outputs and replay:** require the exact 90×3×4 = 1,080 row-key set, not just the count. There are 720 future and 360 retention rows. Match case/source/corruption/noise/model/action identities and both output hashes. Each `states.npz` has float32 shape `(1080,4,384)`: the state after the initial two-action plan, then after each of three fixed suffix actions. Separate replay must match all state values and all row fields except measured cost. Replay repeats the same implementation; it is not an independently implemented model.
6. **Final access and metrics:** bind the ledger to the exact model/data/training/inference/replay seals and confirm consumed status. On success require a complete evaluation seal, all 1,080 scored rows and 2,160 Audit B crop predictions. The original arithmetic audit must cover every row with maximum absolute difference at most `1e-7`. Its independence covers NumPy metric arithmetic on the same frozen OCR decisions, not OCR truth.
7. **Execution and resources:** inspect actual return codes, failures, environment equality, one invocation, no retry/resume, budget enforcement and partial artifacts. Never infer success from a model file or summary alone when a later gate failed.

The reporting pass can recompute weighted losses, factorial arithmetic and bootstrap statistics from sealed scored rows without invoking a model or reopening final targets. It must not call the evaluator again. The original final-target metric audit is evidence to verify, not a task to rerun on a second final access.

## 4. Primary estimands and uncertainty

For each source pair `i`, average loss over the three fixed seeds before constructing the four-cell vector `L_i = [L00,L01,L10,L11]`. The primary metric is

`joint_loss = 0.30*text_fact + 0.15*relation + 0.35*image_fact + 0.10*crossmodal_disagreement + 0.10*pixel_mse`.

Lower is better; utility is the fixed transform `1 - 2*joint_loss`, not an additional primary endpoint.

| Primary contrast | Coefficients on [b0g0,b0g1,b1g0,b1g1] | Predeclared interpretation |
| --- | --- | --- |
| Base main effect | [-0.5,-0.5,+0.5,+0.5] | Average effect of changing the base objective over both gate objectives |
| Gate main effect | [-0.5,+0.5,-0.5,+0.5] | Average effect of changing the gate objective over both base objectives |
| Interaction | [+1,-1,-1,+1] | Difference in the gate effect between the two base objectives |

Use all 60 future pairs, ten in each of the six registered corruption strata: clean, occlusion, missing, heavy_noise, wrong_hint and missing_no_hint. Draw 10,000 paired source bootstrap samples within strata using NumPy's registered generator seed431125 and the frozen stratum/order convention. Take linear percentile quantiles `0.05/6` and `1-0.05/6`. These are the registered Bonferroni family of three two-sided intervals; nominal per-contrast coverage is 98.333…%, with a nominal family level of 95%, subject to bootstrap validity rather than an exact finite-sample guarantee.

The resampling assumes source pairs are independent/exchangeable within their corruption strata and conditions on the selected source design, six fitted bases, twelve fitted gates, two fitted observers and three fixed seeds. It does not estimate uncertainty over training seeds, arbitrary tasks, domains or observer architectures. The three seed repetitions do not make 180 independent primary source units, and the 720 future rows are not independent observations.

For each main effect, `upper < 0` is the only improvement rule; `lower > 0` means a positive loss effect. An interval containing zero is unresolved, not equivalence and not proof of no effect. The interaction has a signed estimate/interval and no improvement boolean. A negative interaction means the gate-objective change lowers loss more (or raises it less) on the entropic base; it does not alone establish which cell is best. Preserve all three contrasts and avoid a new best-cell test, p-value, unregistered subgroup claim or changed tail calculation.

Reproduce estimates both by the matrix coefficients and expanded formulas, following the frozen `1e-15` arithmetic cross-check. For independent reporting, retain original summary values and separately record the maximum recomputation discrepancy with the exact analysis environment. Do not replace the primary summary with a different bootstrap or rounding procedure.

## 5. Secondary results and figures

Report the four cells for both future and clean retention: fixed-seed mean joint loss, joint factual accuracy and descriptive CVaR90. CVaR90 is the upper loss tail of the **per-source fixed-seed average**; for 60 future pairs it averages six worst values, and for 30 retention pairs three. Joint factual accuracy requires text digits, relation and Audit B image digits all correct. The code does not compute additional confidence intervals for these summaries.

Include all three per-seed four-cell summaries and effects, labeled descriptive. Clean retention is a cross-sectional cohort; it does not measure continual-learning forgetting. Training curves, observer calibration, gate training-plan counts and recorded deployment plan choices may help diagnose the result, but are not alternative primary tests or grounds to select a model. Any additional post-outcome analysis must be explicitly marked exploratory.

Produce a primary three-row contrast table and one static interval figure, using the same loss scale and a zero reference line. The interaction is labeled separately from the two main-effect improvement rules. Show the four-cell descriptive table and per-seed table without adding unregistered significance markers. Derived files may be `tables/primary-contrasts.csv`, `tables/cell-summary.csv`, `tables/per-seed-effects.csv`, `tables/costs.csv` and `figures/primary-contrasts.svg`; each is bound to original evidence hashes. No placeholder numeric result is generated now.

## 6. Cost accounting without double counting

Use the outer process receipts as the complete six-stage execution accounting. Report stage wall/CPU including import and exit, harness total wall, summed child-stage CPU, harness RSS and the recorded child RSS quantities. Summed child-stage CPU excludes the harness's own CPU; total harness wall includes its polling/coordination time. `harness-summary.new_evidence_bytes` is measured before writing that summary itself; the archived total is a separately recomputed byte count, not an unexplained mismatch.

| Level | Exact field source | Scope and aggregation |
| --- | --- | --- |
| Setup | Original installation/cache/transfer receipts | Report separately; never fold historical planning estimates into actual cost |
| Whole run | `harness-summary.total_wall_ns`, `total_stage_cpu_ns` | Headline execution cost; use original units then convert to seconds |
| Stage process | Each `*-process.json` | Include failed stages and imports/exits; sum CPU once, do not add nested costs |
| Inner stage | `data-receipt.cost`, `bootstrap.cost`, `training.cost`, both `run.cost`, `evaluation/summary.cost` | Diagnostic subset of process cost; stage timers exclude some final writes/seal/check operations |
| Observer fits | Two `bootstrap/*-observer.json`: `cost` and original `wall_ns` | Fit/calibration timers; save/reload and outer stage costs are separate nesting, not extra additive work |
| Base fits | Six base reports `elapsed_seconds`; `paired_execution_cost` | `elapsed_seconds` is per profile. Identical pair cost is repeated in both reports for a seed: count it once per seed, not six times |
| Gate fits | Twelve gate reports: `factorial_cost`; nested `costs.enumeration_wall_ns`, `optimization_wall_ns`, `total_wall_ns` | Count all twelve actual enumerations/fits. The nested values are not additive to `factorial_cost` or outer training cost |
| Inference/replay rows | Each `rows[].cost` | Includes neural work, output write/read and integrity checks. It is not pure network latency. Inference and required validation replay are separate costs |
| Scoring rows | `scored-rows.rows[].evaluation_cost` | Includes output reads, Audit B scoring and NumPy metric check; part of evaluation stage |
| Memory | `process_peak_rss_bytes`, `cumulative_completed_child_peak_rss_bytes`, `maximum_sampled_child_rss_bytes` | Process high-water marks are not incremental allocations. Cumulative child peak may belong to an earlier stage; never sum peaks or assign it to the current stage as a fresh measurement |
| Artifact size | Complete archive member manifest; model-seal file sizes; both states/output sets | Distinguish storage bytes, repeated serialized bases and logical array sizes; none is a process memory measurement |

The registered structural work per inference row is one encoder, one gate, two initial transitions, three suffix transitions, one joint decoder and two emitted modalities. On a complete run each pass therefore has 1,080 encoder/gate/decoder calls, 2,160 initial and 3,240 suffix transitions. Replay repeats this; the scorer adds 2,160 crop predictions. Structural equality does not imply equal latency, FLOPs or energy.

The report must state the 1,800-second total compute deadline, two CPU threads, 2-GiB sampled child RSS/finished-child peak limit and 1-GiB evidence bound. These are implemented guards, not kernel memory caps. Electrical energy, joint process-tree peak RSS and unrecorded operator/network time remain unmeasured. A cost estimate or historical full-002 timing is never substituted for an absent measurement.

## 7. Failure and nonpositive-result rules

| Actual state | Reporting treatment |
| --- | --- |
| Freeze or publication failed | No experiment claimed; preserve failed receipt and exact blocker |
| Preparation failed or source overlap | Preserve actual failure; no new range, cohort, owner or fallback sample |
| Bootstrap/gates incomplete or seal invalid | Report completed documented work and costs, not the planned 14,040 updates as actual; no accepted primary result |
| Inference/replay incomplete or mismatched | Report exact verified row prefix/count and failure; no subset-based primary analysis |
| Final claim exists, evaluator failed | State cohort consumed, preserve failure and logs; no retry/reselection/reopened targets |
| Evaluation sealed, later resource/harness failure | Preserve and show the sealed measurements with the protocol deviation; do not call the bounded run successful or silently discard its costs |
| Run complete, main interval crosses zero | Report unresolved effect, exact estimate/interval and all other registered contrasts; no equivalence claim |
| Run complete, main interval wholly positive | Report higher loss for that registered contrast; retain the unfavorable result |
| Crash or external termination omits a receipt | Label completion/consumption as established, absent or unknown from available originals; retain external status and do not recreate lost metrics |

The owner and publication remain fixed. A failed run is not automatically resumed, retried, assigned another output directory or given a larger budget. These rules concern this experiment; a future scientific study would need an independent registration and exposure review, with the present cohort treated as already exposed wherever appropriate.

## 8. Reproduction and final report order

There are three different deliverables. **Artifact verification** checks the original raw archive and all file/seal/receipt bindings without executing artifact code. **Analysis reproduction** reads sealed scored rows and reconstructs the three fixed contrasts, registered bootstrap and descriptive tables without any model or target access. **New scientific replication** is a future independently registered generation with a new provenance and source-use decision. Copying this owner or changing its protocol to rerun is not authorized by the current registration and does not yield a new confirmatory sample.

Original validators enforce the owner's published absolute paths. A transported archive is verified as an immutable copy with its original paths retained in receipts; do not rewrite its protocol paths to make those validators pass. Any separate archive verifier must state that it validates transported bytes and relative membership, not a new owner execution. The published historical command can be documented verbatim without executing it again.

The final human report should lead with completion status and all three primary estimates/intervals, then explain the four-cell comparison, effect directions and limits. Follow with source/model integrity, measured total and component costs, complete secondary tables, reproducibility links and deviations/failures. Include the original result files and whole evidence archive so the findings do not depend on a generated chart. A positive, unresolved, adverse or incomplete result uses the same structure.

This plan is a reporting artifact outside the experiment/census/owner roots. It does not claim that freeze, publication, training, replay, scoring or any measured scientific result has already succeeded.
