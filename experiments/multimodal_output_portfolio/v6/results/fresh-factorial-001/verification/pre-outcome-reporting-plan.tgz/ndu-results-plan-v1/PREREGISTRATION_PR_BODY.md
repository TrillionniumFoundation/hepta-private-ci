## Why

The earlier full-002 experiment does not separate base-objective effects from gate-objective effects, and its exact historical model archive could not be recovered. This adds an independent fresh matched 2×2 study. It preserves the original recovery experiment and archive pins, and will not pool new absolute scores with historical outcomes.

## Design and resulting behavior

- Cross supervised versus terminal-entropic base training with hard mean-best-plan imitation versus direct finite entropic gate fitting, at fixed seeds 17, 29 and 43.
- Train two fresh observers, six matched bases and twelve gates: 600 + 12,000 + 1,440 optimizer updates. Verify paired initialization/schedules, source/scenario controls and identical utility tables within each frozen base; seal exactly 20 model files before held-out inference.
- Use fixed fresh ranges future120–179 and retention60–89. The reviewed source boundary excludes 520 explicitly enumerated prior pixels, the full train/evaluator/validation pools and the reserved smoke ranges. Its scope is `audited_known_v6_sources_only`, not a universal claim about unretained history.
- Evaluate all 1,080 rows with equal structural inference work, a fixed three-action suffix and no dynamic controller, forecasting or search. Require separate-process byte/state replay before a create-only final-access claim.
- Report base main effect, gate main effect and interaction on future joint loss. Average fixed seeds first; use the registered 10,000 within-corruption paired source bootstrap and three multiplicity-adjusted intervals. Only a main effect with its upper endpoint below zero counts as an improvement. Interaction is signed, and all null/adverse results remain visible.
- Keep the original CPU package recipe and two-thread limit; bound the complete run to 1,800 seconds, sampled/finished-child RSS to 2 GiB and new evidence to 1 GiB. Preserve all costs, failures and partial artifacts, with setup measured separately and no automatic retries.

## Reviewable history

There are **11 source stages, followed by a separate resolved-registration commit**. Stages 1–7 implement custody, exposure/data separation, fresh generation, inference/scoring, budget/registration and synthetic gates. Stages 8–10 bind the exact published v6 evidence. Stage 11 is the narrow verified-source-capsule parser correction: it accepts the exact embedded original `data.py` source only after schema/path/content-hash verification, while preserving strict actual source-ID checks. The original failed scan remains evidence.

The separate registration records the actual named-root census, independent exposure review, fixed absolute owner and resolved protocol. The algorithm revision is `689c45e1903a6b28dcff6d05c7b732a07511f512`; execution must use the later published HEAD containing that protocol. This separation is a source/review history, not eleven experimental attempts.

## Validation and execution status

All 33 synthetic tests passed in the actual Python 3.12 environment and in independent review. The full old CI artifact, 56 historical rows, forecast-development sources and opaque member lineage were checked; no model was rerun for that review. Original full-002 weights remain missing.

This PR registers the study. Source and resolved protocol must be externally verified as published before the one bounded harness invocation. Scientific results, if execution completes, will be published with the complete raw evidence and a separate outcome report; this preregistration makes no result claim. Gate-objective effects are not isolated risk-aversion effects, and neither factor establishes online-controller, topology-evolution or AGI benefits.
