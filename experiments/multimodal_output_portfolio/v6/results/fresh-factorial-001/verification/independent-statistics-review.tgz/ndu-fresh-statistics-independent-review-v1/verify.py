#!/usr/bin/env python3
"""Independent JSON-only row census and fixed factorial analysis reproduction.

Never imports experiment code, executes models, or reads target/NPZ/image bytes.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import platform
import re
import sys

import numpy as np

ARCHIVE_SHA = "7a52402940d92489f4625bac035160d0eee3cf51c872422f5184445af6319735"
PROTOCOL_SHA = "a3531af321d47e82d98d31d2bb5db0cb9eb87809ac30a470468a7b7cde5c1e46"
SCORED_SHA = "189c765ccbe7797b3a59010a90d7ad5241dcbc95837244b2506bb8306bfb7954"
SOURCE_COMMIT = "ee7609048da0c12d542765e29422c0d3c647e0a5"
ARMS = ("b0g0", "b0g1", "b1g0", "b1g1")
NAMES = ("base_main_effect", "gate_main_effect", "interaction")
WEIGHTS = {"text_fact": .30, "relation": .15, "image_fact": .35,
           "crossmodal_disagreement": .10, "pixel_mse": .10}
PLANS = (("refine_semantic", "couple"), ("couple", "refine_image"),
         ("couple", "refine_text"), ("refine_image", "refine_text"))
EXPECTED_CALLS = {"audit_observer": 0, "decoder": 1, "emitted_modalities": 2,
                  "encoder": 1, "forecast": 0, "gate": 1,
                  "initial_transitions": 2, "search": 0, "suffix_transitions": 3}
SHA = re.compile(r"[0-9a-f]{64}")
SOURCE_ID = re.compile(r"mnist:(train|test):(0|[1-9][0-9]*):([0-9a-f]{64})")


def need(ok, message):
    if not ok:
        raise ValueError(message)


def identity(path):
    need(path.is_file() and not path.is_symlink(), "regular input file required: " + str(path))
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def read(path):
    need(path.suffix == ".json", "this review reads only JSON")
    identity(path)
    return json.loads(path.read_text(), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def execute(root):
    consumed = {}

    def load(relative):
        path = root / relative
        consumed[relative] = identity(path)
        return read(path)

    transfer = read(root.parent / "verified-transfer.json")
    archive = identity(root.parent / "reporting-metadata.tar.gz")
    need(archive == {"bytes": 3761485, "sha256": ARCHIVE_SHA}, "metadata archive differs")
    need(transfer["size"] == archive["bytes"] and transfer["sha256"] == ARCHIVE_SHA
         and transfer["files"] == 74, "verified transfer receipt differs")
    plan = load("protocol.json")
    need(consumed["protocol.json"]["sha256"] == PROTOCOL_SHA, "protocol bytes differ")
    protocol_hash = digest(plan)
    manifest = load("owner-manifest.json")
    owner_files = {entry["path"]: {"bytes": entry["size"], "sha256": entry["sha256"]}
                   for entry in manifest["files"]}
    need(len(owner_files) == len(manifest["files"]) == manifest["file_count"] == 4409,
         "owner manifest has duplicate or missing entries")
    need(manifest["source_commit"] == SOURCE_COMMIT and manifest["protocol_sha256"] == PROTOCOL_SHA,
         "owner manifest publication binding differs")
    need(sum(entry["bytes"] for entry in owner_files.values()) == manifest["total_bytes"],
         "owner byte census differs")

    def owner(relative):
        value = load("owner/" + relative)
        need(consumed["owner/" + relative] == owner_files[relative], "owner JSON identity differs: " + relative)
        return value

    data = owner("data/data-receipt.json")
    cases_record = owner("data/cases.json")
    need(data["files"]["cases.json"] == consumed["owner/data/cases.json"], "data case binding differs")
    need(data["protocol_canonical_sha256"] == protocol_hash, "data protocol differs")
    need(cases_record["target_labels_emitted"] is False, "case metadata contains target labels")
    cases = cases_record["cases"]
    need(plan["seeds"] == [17, 29, 43] and tuple(plan["arms"]) == ARMS
         and plan["expected_rows"] == 1080 and plan["arm_order_seed"] == 431125,
         "registered seed/arm/row ordering differs")
    need(plan["case_ranges"] == {"future": {"offset": 120, "count": 60},
                                  "retention": {"offset": 60, "count": 30}}, "registered case ranges differ")
    corruptions = ["clean", "occlusion", "missing", "heavy_noise", "wrong_hint", "missing_no_hint"]
    need(plan["corruptions"] == corruptions and plan["common_inference_calls"] == EXPECTED_CALLS,
         "registered corruption/work schedule differs")
    expected_cases = [(split, offset + ordinal, corruptions[ordinal % 6] if split == "future" else "clean")
                      for split, offset, count in (("future", 120, 60), ("retention", 60, 30))
                      for ordinal in range(count)]
    need(len(cases) == len(expected_cases) == 90, "case count differs")
    sources, pixels = [], []
    for case, (split, index, corruption) in zip(cases, expected_cases, strict=True):
        need(set(case) == {"case_id", "split", "index", "corruption", "source_ids"}, "case fields differ")
        need(case["case_id"] == f"{split}-{index:04}" and case["split"] == split
             and case["index"] == index and case["corruption"] == corruption, "case schedule differs")
        need(len(case["source_ids"]) == 2, "source pair is incomplete")
        for source in case["source_ids"]:
            match = SOURCE_ID.fullmatch(source)
            origin, bound = ("test", 10000) if split == "future" else ("train", 60000)
            need(match is not None and match[1] == origin and int(match[2]) < bound,
                 "invalid final-cohort source identity")
            sources.append(source)
            pixels.append(match[3])
    need(len(set(sources)) == len(set(pixels)) == 180, "source identities or pixels repeated")
    need(not set(pixels).intersection(plan["exposed_source_pixels"]), "new case pixel occurs in original exposure exclusions")
    case_map = {case["case_id"]: case for case in cases}
    trained = owner("training/training.json")
    models = {(model["seed"], model["arm"]): model for model in trained["models"]}
    need(set(models) == {(seed, arm) for seed in plan["seeds"] for arm in ARMS}
         and len(trained["models"]) == 12, "row model key census differs")
    model_seal = owner("model-seal.json")
    expected = {(seed, arm, case["case_id"]) for seed in plan["seeds"] for arm in ARMS for case in cases}
    rng = np.random.default_rng(431125)
    expected_order = [(seed, ARMS[int(i)], case["case_id"]) for seed in plan["seeds"]
                      for case in cases for i in rng.permutation(4)]
    runs = {}
    output_bindings = 0
    for stage in ("inference", "replay"):
        rows = owner(stage + "/rows.json")["rows"]
        seal = owner(stage + "/run-seal.json")
        run = owner(stage + "/run.json")
        need(run["protocol_canonical_sha256"] == protocol_hash and run["completed_rows"] == 1080
             and run["final_targets_opened"] is False and run["stage"] == stage
             and run["model_seal_sha256"] == consumed["owner/model-seal.json"]["sha256"]
             and run["training_canonical_sha256"] == digest(trained), "run identity differs")
        need(len(rows) == 1080, "run row count differs")
        required = {"rows.json", "run.json", "states.npz", "source-freeze.json"}
        if stage == "replay":
            required.add("replay.json")
        keys = []
        for ordinal, row in enumerate(rows):
            key = row["seed"], row["arm"], row["case_id"]
            keys.append(key)
            need(key == expected_order[ordinal] and row["row_index"] == ordinal, "row order/index differs")
            case, model = case_map[key[2]], models[key[:2]]
            need(all(row[field] == case[field] for field in case), "row source/corruption differs")
            need(row["noise_seed"] == row["seed"] * 10000 + row["index"]
                 and row["checkpoint_file_sha256"] == model["checkpoint_file_sha256"]
                 and row["snapshot_sha256"] == model["snapshot_sha256"], "row noise/model binding differs")
            choice = row["initial_plan_index"]
            need(type(choice) is int and 0 <= choice < 4 and row["initial_plan"] == list(PLANS[choice])
                 and row["fixed_suffix"] == plan["fixed_suffix"] and row["calls"] == EXPECTED_CALLS,
                 "row action/call schedule differs")
            need(len(row["state_keys"]) == 4 and all(SHA.fullmatch(x) for x in row["state_keys"]),
                 "state-key metadata differs")
            stem = f"outputs/seed{key[0]}-{key[1]}/{key[2]}"
            paths = {"image": stem + "/image.png", "text": stem + "/caption.txt"}
            need(row["paths"] == paths, "row output path differs")
            for kind, relative in paths.items():
                need(not PurePosixPath(relative).is_absolute() and ".." not in PurePosixPath(relative).parts,
                     "unsafe row output path")
                bound = seal["files"][relative]
                need(bound == owner_files[stage + "/" + relative]
                     and bound["sha256"] == row["output_sha256"][kind], "row output manifest/seal hash differs")
                required.add(relative)
                output_bindings += 1
        need(len(set(keys)) == 1080 and set(keys) == expected, "run key census differs")
        need(set(seal["files"]) == required, "run seal required-set differs")
        for relative, bound in seal["files"].items():
            need(bound == owner_files[stage + "/" + relative], "run seal/owner manifest differs")
        runs[stage] = rows
    for first, repeated in zip(runs["inference"], runs["replay"], strict=True):
        need({k: v for k, v in first.items() if k != "cost"}
             == {k: v for k, v in repeated.items() if k != "cost"}, "replay row differs beyond recorded cost")
    scored = owner("evaluation/scored-rows.json")["rows"]
    need(consumed["owner/evaluation/scored-rows.json"]["sha256"] == SCORED_SHA, "scored rows bytes differ")
    summary = owner("evaluation/summary.json")
    seal = owner("evaluation/evaluation-seal.json")
    need(set(seal["files"]) == {"final-access.json", "scored-rows.json", "source-freeze.json", "summary.json"},
         "evaluation seal required-set differs")
    for relative, bound in seal["files"].items():
        owner("evaluation/" + relative)
        need(bound == consumed["owner/evaluation/" + relative], "evaluation seal byte binding differs")
    need(len(scored) == 1080 and summary["protocol_canonical_sha256"] == protocol_hash, "scored census/protocol differs")
    row_lookup, maximum_metric_difference = {}, 0.
    for row, original in zip(scored, runs["inference"], strict=True):
        added = {"metrics", "audit_observer_file_sha256", "evaluation_cost"}
        need(set(row) == set(original) | added and {k: v for k, v in row.items() if k not in added} == original,
             "scoring altered an inference binding")
        need(row["audit_observer_file_sha256"] == model_seal["model_files"]["bootstrap/audit-observer.pt"]["sha256"],
             "scored audit observer binding differs")
        metric = row["metrics"]
        need(all(math.isfinite(metric[k]) and 0 <= metric[k] <= 1 for k in WEIGHTS), "invalid metric component")
        loss = math.fsum(WEIGHTS[k] * metric[k] for k in WEIGHTS)
        diff = abs(loss - metric["joint_loss"])
        maximum_metric_difference = max(maximum_metric_difference, diff)
        need(diff <= 1e-15 and abs(metric["utility"] - (1 - 2 * metric["joint_loss"])) <= 1e-15,
             "weighted metric or utility arithmetic differs")
        fact = int(metric["text_fact"] == metric["relation"] == metric["image_fact"] == 0)
        need(type(metric["joint_fact_correct"]) is int and metric["joint_fact_correct"] == fact,
             "joint fact arithmetic differs")
        key = row["seed"], row["arm"], row["case_id"]
        need(key not in row_lookup and key in expected, "duplicate or unknown scored key")
        row_lookup[key] = metric["joint_loss"]
    need(set(row_lookup) == expected, "scored key census differs")
    primary = plan["primary"]
    need(primary["metric"] == "joint_loss" and primary["split"] == "future"
         and primary["fixed_seed_average_first"] is True and primary["stratify"] == "corruption"
         and primary["contrasts"] == list(NAMES) and primary["alpha"] == .05
         and primary["family_size"] == 3 and primary["bootstrap_replicates"] == 10000
         and primary["bootstrap_seed"] == 431125, "registered primary analysis differs")
    future = [case for case in cases if case["split"] == "future"]
    means = np.array([[math.fsum(row_lookup[seed, arm, case["case_id"]] for seed in (17, 29, 43)) / 3
                       for arm in ARMS] for case in future], dtype=np.float64)
    expanded = np.column_stack(((means[:, 2] + means[:, 3] - means[:, 0] - means[:, 1]) / 2,
                                (means[:, 1] + means[:, 3] - means[:, 0] - means[:, 2]) / 2,
                                means[:, 3] - means[:, 2] - means[:, 1] + means[:, 0]))
    coefficients = np.array([[-.5, -.5, 1], [-.5, .5, -1], [.5, -.5, -1], [.5, .5, 1]])
    formula_difference = float(np.max(np.abs(expanded - means @ coefficients)))
    need(formula_difference <= 1e-15, "independent contrast formulas disagree")
    rng = np.random.default_rng(431125)
    strata = [np.array([i for i, case in enumerate(future) if case["corruption"] == corruption])
              for corruption in corruptions]
    need([len(x) for x in strata] == [10] * 6, "future source strata differ")
    draws = np.concatenate([rng.choice(indices, size=(10000, 10), replace=True) for indices in strata], axis=1)
    tails = [.05 / 6, 1 - .05 / 6]
    recomputed, differences = {}, []
    for i, name in enumerate(NAMES):
        values = expanded[:, i]
        interval = np.quantile(values[draws].mean(axis=1), tails, method="linear")
        result = {"estimate": float(values.mean()), "interval": list(map(float, interval)),
                  "direction": "negative" if interval[1] < 0 else "positive" if interval[0] > 0 else "unresolved",
                  "main_effect_improvement": bool(interval[1] < 0) if i < 2 else None}
        saved = summary["primary"][name]
        delta = max(abs(saved["estimate"] - result["estimate"]),
                    *(abs(a - b) for a, b in zip(saved["interval"], result["interval"], strict=True)))
        need(delta <= 1e-15 and result["direction"] == saved["direction"]
             and result["main_effect_improvement"] == saved["main_effect_improvement"], "saved primary statistics differ")
        recomputed[name], differences = result, [*differences, delta]
    saved_sources = summary["source_differences"]
    need(len(saved_sources) == 60, "saved source differences census differs")
    source_difference = 0.
    for i, (case, saved) in enumerate(zip(future, saved_sources, strict=True)):
        need(saved["case_id"] == case["case_id"] and saved["corruption"] == case["corruption"], "source contrast ordering differs")
        source_difference = max(source_difference, *(abs(saved["fixed_seed_mean_losses"][a] - means[i, j]) for j, a in enumerate(ARMS)),
                                *(abs(saved[name] - expanded[i, j]) for j, name in enumerate(NAMES)))
    need(source_difference <= 1e-15, "saved source means/contrasts differ")
    need(summary["bootstrap"]["seed"] == 431125 and summary["bootstrap"]["replicates"] == 10000
         and summary["bootstrap"]["quantiles"] == tails and summary["bootstrap"]["strata"] == 6
         and summary["bootstrap"]["source_pairs"] == 60, "saved bootstrap recipe differs")
    need("torch" not in sys.modules, "unexpected Torch import")
    return {"schema": "hepta.ndu-fresh-independent-statistics-review.v1", "reviewed_at_utc": datetime.now(timezone.utc).isoformat(),
            "metadata_archive": archive, "source_commit": SOURCE_COMMIT, "protocol_file_sha256": PROTOCOL_SHA,
            "protocol_canonical_sha256": protocol_hash, "inputs_read": consumed,
            "scope": "JSON-only independent key/source/action/output-hash binding and fixed statistical arithmetic; no original experiment module imported",
            "cases": {"future": 60, "retention": 30, "distinct_source_ids": 180, "distinct_pixel_hashes": 180,
                      "observed_prior_exclusion_overlap": 0},
            "rows": {"inference": 1080, "replay": 1080, "scored": 1080, "unique_keys_each": 1080,
                     "future_each": 720, "retention_each": 360, "exact_registered_order": True,
                     "replay_all_row_fields_except_cost_equal": True, "scored_rows_retain_all_inference_fields": True},
            "output_hash_bindings_to_both_original_seals_and_owner_manifest": output_bindings,
            "run_required_set_sizes": {"inference": 2164, "replay": 2165, "evaluation": 4},
            "metric_arithmetic_max_abs_difference": maximum_metric_difference,
            "expanded_vs_matrix_max_abs_difference": formula_difference,
            "original_source_means_and_contrasts_max_abs_difference": source_difference,
            "primary": recomputed, "original_primary_max_abs_difference": max(differences),
            "bootstrap": {"replicates": 10000, "seed": 431125, "strata": 6, "source_pairs_per_stratum": 10,
                          "source_pairs": 60, "fixed_seed_average_first": True, "quantiles": tails, "quantile_method": "linear"},
            "interpretation": "all three registered intervals contain zero; neither main effect meets upper<0; this is unresolved rather than equivalence/no effect",
            "uncertainty_scope": "source resampling conditional on these fitted models/observers and three fixed seeds; no training-population or general-intelligence claim",
            "analysis_environment": {"python": platform.python_version(), "numpy": np.__version__, "torch_imported": False},
            "not_reperformed": ["model training/inference", "OCR/ground-truth scoring", "pixel MSE from target arrays", "state tensor comparison", "binary output payload hashing on local machine"],
            "opaque_payload_scope": "original output/state/model hashes are metadata bindings to the owner manifest; main-host raw-byte verification remains separately attributed",
            "result": "passed", "production_authority": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--packet", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = execute(args.packet)
    args.output.mkdir(parents=False, exist_ok=False)
    with (args.output / "review.json").open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"result": result["result"], "rows": result["rows"], "primary": result["primary"],
                      "maximum_primary_difference": result["original_primary_max_abs_difference"]}, indent=2))
