# Independent fresh NDU row and primary-statistics review

**Passed for the declared JSON-only scope.** The original inference, replay and
scored-row files each contain the exact 1,080 registered `(seed, arm, case_id)`
keys: 720 future rows and 360 retention rows. All 90 cases have distinct source
pairs, totaling 180 distinct source IDs and pixel hashes. None of those pixel
hashes occurs in the protocol's 520 audited prior exclusions.

The review checks registered case/arm order, case source/corruption/index,
common noise recipe, action plan, fixed suffix, model/snapshot IDs and structural
call counts. All inference/replay row fields other than recorded cost agree.
Every scored row preserves its entire inference row. All 4,320 emitted-output
references match both the original run seal and the complete owner manifest;
the expected seal membership is exactly 2,164 / 2,165 / 4 for inference, replay
and evaluation respectively.

The independent analysis averages the three fixed seeds for each source first,
uses expanded factorial formulas, checks them against a separate matrix form,
and recomputes the registered 10,000 paired within-stratum bootstrap draws with
NumPy seed 431125. There are six strata of ten future source pairs. The linear
percentile endpoints are 0.05/6 and 1-0.05/6. Maximum discrepancy from the original
three point estimates and six interval endpoints is
`1.3877787807814457e-17`.

For human reporting, retain these **original sealed summary** values:

| Contrast | Original estimate | Original interval | Registered interpretation |
| --- | ---: | --- | --- |
| Base main effect | -0.004488275341896549 | [-0.018601761109984696, 0.00952468958099943] | Unresolved; main-effect improvement false |
| Gate main effect | 0.00021129128316210217 | [-0.00583400633768179, 0.005700083451009255] | Unresolved; main-effect improvement false |
| Interaction | 0.004296420299344582 | [-0.003909223574058465, 0.012771636407460173] | Unresolved; no improvement boolean |

All three intervals contain zero. This does not establish equivalence or absence
of an effect. Uncertainty is conditional on the fitted models, observers and
three fixed seeds; the resampled units are 60 source pairs, not 720 independent
rows or a population of newly trained seeds.

## Inputs and independent scope

The input metadata archive is 3,761,485 bytes, SHA256
`7a52402940d92489f4625bac035160d0eee3cf51c872422f5184445af6319735`.
The publication source commit is
`ee7609048da0c12d542765e29422c0d3c647e0a5`.
The scored-row original is 2,149,546 bytes, SHA256
`189c765ccbe7797b3a59010a90d7ad5241dcbc95837244b2506bb8306bfb7954`.
The original summary SHA256 is
`d8ec3a2430cd3f491c1ae58fbd88371d8ef62fc6c3f57a871e1dfaab90398a88`.

`results/review.json` records every JSON input actually consumed. The helper
imports only Python standard-library modules and NumPy 2.3.5; it does not import
the original experiment, statistics or evaluator modules. Local Python is
3.12.14, while the original experiment reports 3.12.3. The numerical comparison
above measures the actual analysis agreement; it is not an assertion of arbitrary
cross-host bit equivalence.

No model training, inference, OCR or final-target scoring was rerun. No final
target, NPZ, PT or PNG file was opened. Pixel MSE is an original observed metric
component; this review independently checks weighted-loss/utility/factual-score
arithmetic from the retained components. State keys and output hashes are
metadata bindings. The main host's separate raw archive verification is the
source of claims about the complete model/output/array bytes, not this local
metadata review. The model/source/control/cost review is assigned separately.

## Reproduction of this analysis only

Use the already downloaded metadata packet and a new derived report directory:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 verify.py \
  --packet /absolute/path/to/ndu-fresh-metadata-transfer-v1/unpacked \
  --output /absolute/path/to/new-derived-statistics-review
```

The helper validates the neighboring original metadata archive identity and
transfer receipt, then reads supplied JSON. It never contacts a host, launches
a model/evaluator, or updates the experiment owner/final-access ledger.

## Reviewer implementation correction

`initial-reviewer-assumption-failure.log` preserves the first local helper
failure. The draft helper incorrectly required all source IDs to come from the
official MNIST test partition. The original pinned `data.py` assigns future
cases to official test and retention cases to a disjoint official-train pool.
The helper was corrected to verify that exact split rule (120 future/test
pixels and 60 retention/train pixels), including the original partition index
bounds. This was a reviewer-code correction. No experiment input, row, protocol,
model, scientific analysis rule or final access was changed or repeated.
