import pathlib,hashlib,json,tomllib,subprocess,time,datetime,re
root=pathlib.Path("/home/qian-qi/work/cell-s0s5-20261108-1628");source=root/"matrix-source";out=root/"matrix-validation"
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=source/"codex-rs/Cargo.toml";text=manifest.read_text();old='# Matrix SDK/eyeball-im still require imbl 6.x. Backport the upstream 7.0.2\n# bitmap import and patched chunk dependency without changing their public API.\nimbl = { path = "third_party/imbl-6.1.0" }\n';assert text.count(old)==1;manifest.write_text(text.replace(old,""))
f=source/"codex-rs/third_party/starlark-0.14.2-blake3-backport/HEPTA_PATCH.md";txt=f.read_text();old="4395d80da451d94f6029f0d4dd38ee585ff062";assert old in txt;f.write_text(txt.replace(old,"4395d80da451d94f60fe29f0d4dd38ee585ff062"))
lock=source/"codex-rs/Cargo.lock";(out/"matrix-resolver-before-metadata-Cargo.lock").write_bytes(lock.read_bytes())
records=[]
for label,argv in [("matrix-allfeatures-metadata",["cargo","metadata","--format-version","1","--all-features"]),("matrix-bazel-lock-update",["just","bazel-lock-update"]),("matrix-allfeatures-locked-metadata",["cargo","metadata","--locked","--format-version","1","--all-features"])]:
    stdout=out/(label+".json"if "metadata"in label else label+".stdout.log");stderr=out/(label+".stderr.log");assert not stdout.exists()and not stderr.exists()
    before=sha(lock.read_bytes());started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();print(json.dumps({"started":argv}),flush=True)
    with stdout.open("wb")as a,stderr.open("wb")as b:r=subprocess.run(argv,cwd=source/"codex-rs",stdout=a,stderr=b)
    rec={"argv":argv,"exit_code":r.returncode,"wall_seconds":time.monotonic()-t,"started_at":started,"stdout":str(stdout),"stderr":str(stderr),"stdout_sha256":sha(stdout.read_bytes()),"stderr_sha256":sha(stderr.read_bytes()),"cargo_before_sha256":before,"cargo_after_sha256":sha(lock.read_bytes())};records.append(rec);(out/"MATRIX_GRAPH_GENERATION_COMMANDS.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps(rec),flush=True)
    if r.returncode:print(stderr.read_text(errors="replace")[-12000:],flush=True);raise SystemExit(r.returncode)
    if "--locked"in argv:assert before==sha(lock.read_bytes())
before=tomllib.loads((out/"original/codex-rs/Cargo.lock").read_text());after=tomllib.loads(lock.read_text())
def key(q):return(q["name"],q["version"],q.get("source",""))
def graph(m):
    packages={key(q):q for q in m["package"]};index={}
    for k in packages:index.setdefault(k[0],[]).append(k)
    edges={}
    for k,q in packages.items():
        resolved=[]
        for dep in q.get("dependencies",[]):
            pieces=dep.split(" ",2);cand=index[pieces[0]]
            if len(pieces)>1:cand=[x for x in cand if x[1]==pieces[1]]
            if len(pieces)>2:cand=[x for x in cand if x[2]==pieces[2][1:-1]]
            assert len(cand)==1,(k,dep,cand);resolved.append(cand[0])
        edges[k]=set(resolved)
    return packages,edges
a,ae=graph(before);b,be=graph(after)
changes=[]
for k in sorted(a.keys()|b.keys()):
    if k not in a:changes.append({"key":k,"kind":"added","package":b[k]})
    elif k not in b:changes.append({"key":k,"kind":"removed","package":a[k]})
    elif ae[k]!=be[k]or {k2:v for k2,v in a[k].items()if k2!="dependencies"}!={k2:v for k2,v in b[k].items()if k2!="dependencies"}:
        changes.append({"key":k,"kind":"changed","removed_edges":sorted(ae[k]-be[k]),"added_edges":sorted(be[k]-ae[k]),"checksum_unchanged":a[k].get("checksum")==b[k].get("checksum")})
m=json.loads((out/"matrix-allfeatures-locked-metadata.json").read_text());ids={p["id"]:p for p in m["packages"]};nodes={n["id"]:n for n in m["resolve"]["nodes"]};members=set(m["workspace_members"])
inspected=[]
for name in ["matrix-sdk","matrix-sdk-crypto","matrix-sdk-sqlite","vodozemac","rama-crypto","starlark","imbl","libsqlite3-sys","time","blake3","ulid"]:
    for p in m["packages"]:
        if p["name"]==name:inspected.append({"name":name,"version":p["version"],"source":p["source"],"workspace_member":p["id"]in members,"manifest_path":p["manifest_path"],"features":nodes[p["id"]]["features"]})
sdk=next(p for p in m["packages"]if p["name"]=="codex-hepta-matrix-sdk")
crypto_deps=[d for d in sdk["dependencies"]if d["name"]=="matrix-sdk-crypto"]
assert len(crypto_deps)==1 and crypto_deps[0]["kind"]=="dev" and not crypto_deps[0]["uses_default_features"]and not crypto_deps[0]["features"]
for name in ["rama-crypto","starlark","matrix-sdk-sqlite"]:
    p=next(p for p in m["packages"]if p["name"]==name);assert p["id"]not in members
assert [p["version"]for p in m["packages"]if p["name"]=="vodozemac"]==["0.11.2"]
assert [p["version"]for p in m["packages"]if p["name"]=="libsqlite3-sys"]==["0.37.0"]
assert not any(p["name"]=="pin-utils"for p in m["packages"])
vodo=next(p for p in m["packages"]if p["name"]=="vodozemac")
crypto_path=pathlib.Path(vodo["manifest_path"]).parent
imbl=next(p for p in m["packages"]if p["name"]=="imbl");imbl_toml=tomllib.loads(pathlib.Path(imbl["manifest_path"]).read_text());assert imbl["version"]=="7.0.2" and imbl_toml["dependencies"]["imbl-sized-chunks"]["version"]=="0.2.0"and"bitmaps"not in imbl_toml["dependencies"]
windows=[c for c in changes if c["kind"]=="changed"and any(e[0].startswith("windows")for e in c["removed_edges"]+c["added_edges"])]
record={"schema":"hepta.matrix.final-resolved-graph.v1","baseline_sha256":sha((out/"original/codex-rs/Cargo.lock").read_bytes()),"candidate_sha256":sha(lock.read_bytes()),"module_lock_sha256":sha((source/"MODULE.bazel.lock").read_bytes()),"baseline_packages":len(a),"candidate_packages":len(b),"actual_semantic_changes":changes,"windows_actual_edge_changes":windows,"selected_packages":inspected,"test_only_crypto_edge":crypto_deps,"vodo_manifest_sha256":sha(pathlib.Path(vodo["manifest_path"]).read_bytes()),"vodo_vcs":json.loads((crypto_path/".cargo_vcs_info.json").read_text()),"unused_imbl_patch_retired":True,"imbl_upstream_chunks_version":"0.2.0"}
(out/"MATRIX_FINAL_GRAPH_REVIEW.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({k:v for k,v in record.items()if k!="actual_semantic_changes"}),flush=True)
print(json.dumps({"semantic_delta":[{"key":c["key"],"kind":c["kind"],"removed_edges":c.get("removed_edges"),"added_edges":c.get("added_edges")}for c in changes]}),flush=True)
