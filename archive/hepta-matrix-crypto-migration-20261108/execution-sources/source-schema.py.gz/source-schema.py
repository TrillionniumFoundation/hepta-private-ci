import pathlib,hashlib,json,sqlite3,shutil,urllib.parse,tarfile,tomllib,subprocess,os
root=pathlib.Path("/home/qian-qi/work/cell-s0s5-20261108-1628");out=root/"matrix-validation";source=root/"matrix-source";oldsource=root/"matrix-old-source"
def sha(b):return hashlib.sha256(b).hexdigest()
frozen=json.loads((out/"OLD_SDK018_FIXTURE_V3_FROZEN.json").read_text());consumer=json.loads((out/"MATRIX_OLD018_TO_NEW019_V1_RESULT.json").read_text());assert consumer["consumer_exit_code"]==0
schemas={}
for label,src in [("old018",pathlib.Path(frozen["fixture"])),("new019",pathlib.Path(consumer["consumer_fixture_copy"]))]:
    dest=out/("schema-inspection-"+label);assert not dest.exists();shutil.copytree(src,dest);items=[]
    for f in sorted(dest.rglob("*")):
        if not f.is_file():continue
        with f.open("rb")as stream:header=stream.read(16)
        if header!=b"SQLite format 3\0":continue
        con=sqlite3.connect("file:"+urllib.parse.quote(str(f))+"?mode=ro",uri=True)
        tables=[r[0]for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        version=None
        if "kv"in tables:
            r=con.execute("SELECT value FROM kv WHERE key=?",("version",)).fetchone()
            if r is not None:
                v=r[0]
                if isinstance(v,bytes)and len(v)==1:version=v[0]
                elif isinstance(v,int):version=v
                else:raise RuntimeError("unexpected database version encoding")
        items.append({"path":str(f.relative_to(dest)),"sdk_db_version":version,"sqlite_user_version":con.execute("PRAGMA user_version").fetchone()[0],"tables":tables})
        con.close()
    schemas[label]=items
def versions(items):return {pathlib.Path(x["path"]).name:x["sdk_db_version"]for x in items if x["sdk_db_version"]is not None}
record={"schema":"hepta.matrix.actual-database-migration.v1","method":"Read schema metadata from isolated copies, never opening the frozen producer original or consumer evidence copy","producer_archive_sha256":frozen["archive_sha256"],"old_versions":versions(schemas["old018"]),"new_versions":versions(schemas["new019"]),"stores":schemas,"rollback_policy":"No old-binary reopen guarantee. Upstream 0.18 does not reject all future database versions; rollback requires a consistent independent pre-upgrade backup."}
(out/"MATRIX_ACTUAL_SCHEMA_MIGRATION.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({k:v for k,v in record.items()if k!="stores"}),flush=True)
for name,srcpath in [("old",pathlib.Path(frozen["fixture"])),("new",pathlib.Path(consumer["consumer_fixture_copy"]))]:
    expected={f["path"]:f["sha256"]for f in frozen["files"]}if name=="old"else consumer["copy_after"]
    actual={str(f.relative_to(srcpath)):sha(f.read_bytes())for f in srcpath.rglob("*")if f.is_file()};assert actual==expected
audits=[]
for name,sourcefile,dirpath in [("matrix-sdk-sqlite","MATRIX_SQLITE_OFFICIAL_SOURCE_COMMIT.json","codex-rs/third_party/matrix-sdk-sqlite-0.19.1"),("rama-crypto","RAMA_OFFICIAL_SOURCE_COMMIT.json","codex-rs/third_party/rama-crypto-0.3.0-time-backport"),("starlark","STARLARK_OFFICIAL_SOURCE_COMMIT.json","codex-rs/third_party/starlark-0.14.2-blake3-backport")]:
    r=json.loads((out/sourcefile).read_text());commit=r["commit"];fetched=subprocess.check_output(["git","ls-tree","-r","-z",commit,"--",dirpath],cwd=source).decode();files={x.split("\t",1)[1]:x.split()[2]for x in fetched.split("\0")if x};delta=[]
    for rel,blob in files.items():
        data=(source/rel).read_bytes();actual=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
        if actual!=blob:delta.append(rel)
    assert sorted(pathlib.Path(x).name for x in delta)==["Cargo.toml","Cargo.toml.orig"],(name,delta)
    audits.append({"crate":name,"original_commit":commit,"original_tree":r["tree"],"original_archive_sha256":r["archive_sha256"],"original_tracked_files":len(files),"changed_original_files":delta,"all_original_rust_and_assets_unchanged":True})
lock=tomllib.loads((source/"codex-rs/Cargo.lock").read_text());vodo=next(p for p in lock["package"]if p["name"]=="vodozemac");assert vodo["version"]=="0.11.2"and vodo["checksum"]=="cafdb6875115a436251b280d741286a9cec7fc4daab0588ea26481dd8e2bab2f"
provenance={"schema":"hepta.matrix.source-audit.v1","vendors":audits,"vodo_resolved_registry_identity":vodo,"five_second_startup_retained":"Duration::from_secs(5)"in(source/"codex-rs/hepta-matrix-sdk/src/sdk.rs").read_text(),"existing_store_directory_retained":'"matrix-sdk-0.18"'in(source/"codex-rs/hepta-matrix-sdk/src/config.rs").read_text()}
assert provenance["five_second_startup_retained"]and provenance["existing_store_directory_retained"]
(out/"MATRIX_BACKPORT_SOURCE_AUDIT.json").write_text(json.dumps(provenance,indent=2)+"\n");print(json.dumps(provenance),flush=True)
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=oldsource,text=True).strip()=="ad1e07b004d96b748411db655249dc6a7cf2409c"
tracked=["MODULE.bazel.lock","codex-rs/Cargo.lock","codex-rs/hepta-matrix-sdk/Cargo.toml"]
patch=subprocess.check_output(["git","diff","--binary","HEAD","--",*tracked],cwd=oldsource)
for rel in ["codex-rs/hepta-matrix-sdk/tests/store_version_migration.rs","codex-rs/hepta-matrix-sdk/tests/support/crypto_migration.rs"]:
    r=subprocess.run(["git","diff","--no-index","--binary","--","/dev/null",rel],cwd=oldsource,capture_output=True);assert r.returncode==1;patch+=r.stdout
(out/"matrix-old018-producer-v3.patch").write_bytes(patch)
print(json.dumps({"old_producer_patch_sha256":sha(patch),"old_producer_patch_bytes":len(patch)}),flush=True)
