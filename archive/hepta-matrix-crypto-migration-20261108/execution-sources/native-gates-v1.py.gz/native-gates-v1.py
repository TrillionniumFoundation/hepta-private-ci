import pathlib,hashlib,json,subprocess,time,datetime,re,tomllib
root=pathlib.Path("/home/qian-qi/work/cell-s0s5-20261108-1628");source=root/"matrix-source";out=root/"matrix-validation"
def sha(b):return hashlib.sha256(b).hexdigest()
consumer=json.loads((out/"MATRIX_OLD018_TO_NEW019_V1_RESULT.json").read_text());assert consumer["consumer_exit_code"]==0 and consumer["source_unchanged"]and consumer["original_fixture_unchanged"]
paths=list(consumer["source_after"])+["codex-rs/third_party/matrix-sdk-sqlite-0.19.1/Cargo.toml","codex-rs/third_party/rama-crypto-0.3.0-time-backport/Cargo.toml","codex-rs/third_party/starlark-0.14.2-blake3-backport/Cargo.toml"]
def inputs():return {p:sha((source/p).read_bytes())for p in paths}
before=inputs();assert all(before[p]==v for p,v in consumer["source_after"].items())
records=[]
def run(label,argv,cwd):
    stdout=out/(label+".stdout.log");stderr=out/(label+".stderr.log");assert not stdout.exists()and not stderr.exists()
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();print(json.dumps({"started":argv,"label":label}),flush=True)
    with stdout.open("wb")as a,stderr.open("wb")as b:r=subprocess.run(argv,cwd=cwd,stdout=a,stderr=b)
    rec={"label":label,"argv":argv,"cwd":str(cwd),"started_at":started,"wall_seconds":time.monotonic()-t,"exit_code":r.returncode,"stdout":str(stdout),"stderr":str(stderr),"stdout_sha256":sha(stdout.read_bytes()),"stderr_sha256":sha(stderr.read_bytes()),"inputs_after":inputs()};records.append(rec);(out/"MATRIX_NATIVE_GATE_COMMANDS.json").write_text(json.dumps(records,indent=2)+"\n")
    print(json.dumps({k:v for k,v in rec.items()if k!="inputs_after"}),flush=True)
    content=stdout.read_text(errors="replace")+stderr.read_text(errors="replace");summary=[l for l in content.splitlines()if "Summary ["in l or "Starting "in l or "PASS "in l and any(s in l for s in ["certs::","mitm_upstream_client_trusts_startup_custom_ca","encrypted_state_identity_session_and_queues_survive_restart"])]
    print(json.dumps({"selected_summary_lines":summary}),flush=True)
    if r.returncode:print(content[-14000:],flush=True)
    return r.returncode,stdout,stderr
code,stdout,stderr=run("matrix-shared-graph-scoped-tests",["just","test","--locked","-p","codex-hepta-matrix-sdk","-p","codex-network-proxy","-p","codex-execpolicy","-p","codex-aws-auth"],source/"codex-rs")
assert inputs()==before,"scoped test modified its inputs"
if code:raise SystemExit(code)
deny_exe=root/"ci-tools/bin/cargo-deny"
version=subprocess.run([str(deny_exe),"--version"],capture_output=True,text=True);assert version.returncode==0 and"0.19.0"in version.stdout
code,stdout,stderr=run("matrix-final-cargo-deny",[str(deny_exe),"--log-level","warn","--manifest-path","./codex-rs/Cargo.toml","--all-features","check"],source)
combined=stdout.read_text(errors="replace")+stderr.read_text(errors="replace");errors=[l for l in combined.splitlines()if re.match(r"^error(?:\\[|:)",l)]
after=inputs()
record={"schema":"hepta.matrix.native-gates.v1","source_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,text=True).strip(),"baseline":"7b142f8478c711409e4a585a5c62c1ef0dff9ebb","commands":records,"inputs_before":before,"inputs_after":after,"inputs_unchanged":before==after,"cargo_deny_version":version.stdout.strip(),"cargo_deny_exit_code":code,"error_headers":errors,"rustsec_2026_0441_present":"RUSTSEC-2026-0441"in combined,"rustsec_2026_0451_present":"RUSTSEC-2026-0451"in combined}
(out/"MATRIX_NATIVE_GATES_RESULT.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({k:v for k,v in record.items()if k not in ["commands","inputs_before","inputs_after"]}),flush=True)
if after!=before:
    (out/"matrix-after-deny-Cargo.lock").write_bytes((source/"codex-rs/Cargo.lock").read_bytes())
    raise RuntimeError("security gate changed inputs; retain output and review exact graph before claiming final validation")
raise SystemExit(code)
