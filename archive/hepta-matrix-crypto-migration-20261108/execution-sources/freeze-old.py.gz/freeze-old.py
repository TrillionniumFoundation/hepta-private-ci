import pathlib,hashlib,json,tarfile,os,datetime,urllib.request,tomllib,subprocess
root=pathlib.Path("/home/qian-qi/work/cell-s0s5-20261108-1628")
out=root/"matrix-validation";fixture=out/"old-sdk018-fixture-v3";old=root/"matrix-old-source";candidate=root/"matrix-source"
def sha(data):return hashlib.sha256(data).hexdigest()
assert fixture.is_dir()
archive=out/"old-sdk018-fixture-v3-original.tar.gz"
assert not archive.exists()
files=[]
for f in sorted(fixture.rglob("*")):
    assert not f.is_symlink(),str(f)
    if f.is_file():files.append({"path":str(f.relative_to(fixture)),"size":f.stat().st_size,"mode":oct(f.stat().st_mode&0o777),"sha256":sha(f.read_bytes())})
assert files
with tarfile.open(archive,"w:gz")as t:t.add(fixture,arcname=fixture.name)
archive.chmod(0o600)
source_files={}
for rel in ["Cargo.toml","Cargo.lock","hepta-matrix-sdk/Cargo.toml","hepta-matrix-sdk/src/sdk.rs","hepta-matrix-sdk/src/config.rs","hepta-matrix-sdk/tests/store_version_migration.rs","hepta-matrix-sdk/tests/support/crypto_migration.rs"]:
    f=old/"codex-rs"/rel;source_files[rel]=sha(f.read_bytes())
record={"schema":"hepta.matrix.old-encrypted-fixture.v1","producer":"actual SDK 0.18.0 with one test-only direct crypto0.18 edge","producer_job":"1a1bc6aa048-138b0-255","fixture":str(fixture),"created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"original_archive":str(archive),"archive_sha256":sha(archive.read_bytes()),"files":files,"producer_source_sha256":source_files,"real_user_data":False,"subsequent_consumers_must_use_copy":True}
(out/"OLD_SDK018_FIXTURE_V3_FROZEN.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({k:v for k,v in record.items()if k not in ["files","producer_source_sha256"]}|{"files_count":len(files)}),flush=True)
registry=pathlib.Path("/home/qian-qi/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f")
for name in ["starlark-0.14.2","blake3-1.8.2","rama-crypto-0.3.0"]:
    p=registry/name
    if p.is_dir():
        m=tomllib.loads((p/"Cargo.toml").read_text())
        print(json.dumps({"source":str(p),"package":m["package"],"blake3":m.get("dependencies",{}).get("blake3"),"vcs":json.loads((p/".cargo_vcs_info.json").read_text())if(p/".cargo_vcs_info.json").exists()else None}),flush=True)
        if name.startswith("starlark"):
            hits=[]
            for f in p.rglob("*.rs"):
                for n,line in enumerate(f.read_text().splitlines(),1):
                    if "blake3" in line:hits.append({"path":str(f.relative_to(p)),"line":n,"text":line.strip()})
            print(json.dumps({"starlark_blake3_calls":hits}),flush=True)
url="https://crates.io/api/v1/crates/starlark"
with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"hepta-source-compatibility-audit/1.0"}),timeout=30)as r:raw=r.read()
(out/"starlark-official-metadata.json").write_bytes(raw)
m=json.loads(raw)
print(json.dumps({"official_url":url,"metadata_sha256":sha(raw),"versions":[{"num":v["num"],"checksum":v["checksum"],"yanked":v["yanked"],"rust_version":v.get("rust_version")}for v in m["versions"][:15]]}),flush=True)
