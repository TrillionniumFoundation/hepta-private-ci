#!/usr/bin/env python3
"""Apply the objective.compiler source-boundary convergence in a detached checkout.

This is an authoring preview only: it writes the checkout supplied by the caller,
never commits, never pushes, and emits no acceptance or release state.
"""

from __future__ import annotations

import argparse
from pathlib import Path


class PreviewError(ValueError):
    pass


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise PreviewError(f"{path}: expected one replacement, observed {count}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")


def replace_all_exact(path: Path, old: str, new: str, expected: int) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != expected:
        raise PreviewError(f"{path}: expected {expected} replacements, observed {count}")
    path.write_text(text.replace(old, new), encoding="utf-8")


ADMISSION_RESULTS = r'''use std::error::Error;
use std::fmt;

use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;

use crate::AdmittedObjectiveV1;
use crate::ObjectiveAdmissionOutcomeV1;
use crate::ObjectiveAdmissionProofV1;
use crate::ObjectiveAdmissionReceiptV1;

/// Opaque admission capability consumed by native compilation.
///
/// This type is intentionally not `Clone`: one in-process authority value has
/// one consuming compile path. Durable retry semantics remain the destination
/// journal's exact-key idempotency responsibility.
#[derive(Debug, Eq, PartialEq)]
pub struct ValidatedObjectiveAdmissionV1 {
    admitted: AdmittedObjectiveV1,
    proof: ObjectiveAdmissionProofV1,
}

impl ValidatedObjectiveAdmissionV1 {
    pub(crate) fn new(admitted: AdmittedObjectiveV1, proof: ObjectiveAdmissionProofV1) -> Self {
        Self { admitted, proof }
    }

    pub(crate) fn into_parts(self) -> (AdmittedObjectiveV1, ObjectiveAdmissionProofV1) {
        (self.admitted, self.proof)
    }

    #[must_use]
    pub fn receipt(&self) -> &ObjectiveAdmissionReceiptV1 {
        self.admitted.receipt()
    }

    #[must_use]
    pub const fn proof(&self) -> &ObjectiveAdmissionProofV1 {
        &self.proof
    }
}

#[derive(Debug, Eq, PartialEq)]
struct PublicationAuthorityV1 {
    compiler_contract_digest: Digest32,
}

impl PublicationAuthorityV1 {
    fn new(compiler_contract_digest: Digest32) -> Self {
        Self {
            compiler_contract_digest,
        }
    }
}

/// Exact destination/run identity that a one-use authoritative compile may
/// publish. The destination owner creates this from its current journal head,
/// generation and fence immediately before projection into durable records.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObjectivePublicationBindingV1 {
    destination_owner_digest: Digest32,
    run_id: StableId,
    expected_journal_head: Digest32,
    generation: u64,
    fence_digest: Digest32,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ObjectivePublicationBindingError {
    EmptyDestinationOwner,
    ZeroGeneration,
    EmptyFence,
}

impl fmt::Display for ObjectivePublicationBindingError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{self:?}")
    }
}
impl Error for ObjectivePublicationBindingError {}

impl ObjectivePublicationBindingV1 {
    pub fn new(
        destination_owner_digest: Digest32,
        run_id: StableId,
        expected_journal_head: Digest32,
        generation: u64,
        fence_digest: Digest32,
    ) -> Result<Self, ObjectivePublicationBindingError> {
        if destination_owner_digest.is_zero() {
            return Err(ObjectivePublicationBindingError::EmptyDestinationOwner);
        }
        if generation == 0 {
            return Err(ObjectivePublicationBindingError::ZeroGeneration);
        }
        if fence_digest.is_zero() {
            return Err(ObjectivePublicationBindingError::EmptyFence);
        }
        Ok(Self {
            destination_owner_digest,
            run_id,
            expected_journal_head,
            generation,
            fence_digest,
        })
    }

    #[must_use]
    pub const fn destination_owner_digest(&self) -> Digest32 {
        self.destination_owner_digest
    }

    #[must_use]
    pub const fn run_id(&self) -> &StableId {
        &self.run_id
    }

    #[must_use]
    pub const fn expected_journal_head(&self) -> Digest32 {
        self.expected_journal_head
    }

    #[must_use]
    pub const fn generation(&self) -> u64 {
        self.generation
    }

    #[must_use]
    pub const fn fence_digest(&self) -> Digest32 {
        self.fence_digest
    }

    #[must_use]
    pub fn binding_digest(&self) -> Digest32 {
        let mut bytes = b"hepta.objective.publication-binding.v1".to_vec();
        bytes.extend_from_slice(self.destination_owner_digest.as_array());
        let run_id = self.run_id.as_str().as_bytes();
        bytes.extend_from_slice(&u32::try_from(run_id.len()).unwrap_or(u32::MAX).to_be_bytes());
        bytes.extend_from_slice(run_id);
        bytes.extend_from_slice(self.expected_journal_head.as_array());
        bytes.extend_from_slice(&self.generation.to_be_bytes());
        bytes.extend_from_slice(self.fence_digest.as_array());
        Digest32::of_bytes(&bytes)
    }
}

/// Native compile outcome that remains inseparable from its admission proof and
/// a private, non-cloneable publication token.
#[derive(Debug, Eq, PartialEq)]
pub struct ProofBearingObjectiveCompileV1 {
    outcome: ObjectiveAdmissionOutcomeV1,
    proof: ObjectiveAdmissionProofV1,
    publication_authority: PublicationAuthorityV1,
}

impl ProofBearingObjectiveCompileV1 {
    pub(crate) fn new(
        outcome: ObjectiveAdmissionOutcomeV1,
        proof: ObjectiveAdmissionProofV1,
    ) -> Self {
        let publication_authority = PublicationAuthorityV1::new(proof.compiler_contract_digest());
        Self {
            outcome,
            proof,
            publication_authority,
        }
    }

    #[must_use]
    pub const fn outcome(&self) -> &ObjectiveAdmissionOutcomeV1 {
        &self.outcome
    }

    #[must_use]
    pub const fn proof(&self) -> &ObjectiveAdmissionProofV1 {
        &self.proof
    }

    /// Consume the one-use compiler token and bind it to one destination owner,
    /// run identity, journal predecessor, generation and fence.
    pub fn bind_for_publication(
        self,
        binding: ObjectivePublicationBindingV1,
    ) -> Result<PublicationBoundObjectiveCompileV1, ObjectivePublicationBindingError> {
        if self.publication_authority.compiler_contract_digest.is_zero()
            || self.publication_authority.compiler_contract_digest
                != self.proof.compiler_contract_digest()
        {
            return Err(ObjectivePublicationBindingError::EmptyDestinationOwner);
        }
        let binding_digest = binding.binding_digest();
        Ok(PublicationBoundObjectiveCompileV1 {
            outcome: self.outcome,
            proof: self.proof,
            binding,
            binding_digest,
        })
    }
}

/// One-use authoritative compile after exact destination binding. Only this
/// type may be decomposed into durable publication inputs.
#[derive(Debug, Eq, PartialEq)]
pub struct PublicationBoundObjectiveCompileV1 {
    outcome: ObjectiveAdmissionOutcomeV1,
    proof: ObjectiveAdmissionProofV1,
    binding: ObjectivePublicationBindingV1,
    binding_digest: Digest32,
}

impl PublicationBoundObjectiveCompileV1 {
    #[must_use]
    pub const fn outcome(&self) -> &ObjectiveAdmissionOutcomeV1 {
        &self.outcome
    }

    #[must_use]
    pub const fn proof(&self) -> &ObjectiveAdmissionProofV1 {
        &self.proof
    }

    #[must_use]
    pub const fn binding(&self) -> &ObjectivePublicationBindingV1 {
        &self.binding
    }

    #[must_use]
    pub const fn binding_digest(&self) -> Digest32 {
        self.binding_digest
    }

    #[must_use]
    pub fn into_parts(
        self,
    ) -> (
        ObjectiveAdmissionOutcomeV1,
        ObjectiveAdmissionProofV1,
        ObjectivePublicationBindingV1,
    ) {
        (self.outcome, self.proof, self.binding)
    }
}

/// Strict diagnostic result. It deliberately contains no admission proof and no
/// publication token, and therefore cannot be converted into authoritative
/// publication without a fresh owner-controlled admission.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObjectivePreflightReportV1 {
    outcome: ObjectiveAdmissionOutcomeV1,
    source_envelope_digest: Digest32,
    profile_digest: Digest32,
    compiler_contract_digest: Digest32,
}

impl ObjectivePreflightReportV1 {
    pub(crate) fn new(
        outcome: ObjectiveAdmissionOutcomeV1,
        source_envelope_digest: Digest32,
        profile_digest: Digest32,
        compiler_contract_digest: Digest32,
    ) -> Self {
        Self {
            outcome,
            source_envelope_digest,
            profile_digest,
            compiler_contract_digest,
        }
    }

    #[must_use]
    pub const fn outcome(&self) -> &ObjectiveAdmissionOutcomeV1 {
        &self.outcome
    }

    #[must_use]
    pub const fn source_envelope_digest(&self) -> Digest32 {
        self.source_envelope_digest
    }

    #[must_use]
    pub const fn profile_digest(&self) -> Digest32 {
        self.profile_digest
    }

    #[must_use]
    pub const fn compiler_contract_digest(&self) -> Digest32 {
        self.compiler_contract_digest
    }

    #[must_use]
    pub fn into_outcome(self) -> ObjectiveAdmissionOutcomeV1 {
        self.outcome
    }
}

// Compatibility for the existing native-outcome regression: the types remain
// distinct and only their diagnostic/native identities are compared.
impl PartialEq<ProofBearingObjectiveCompileV1> for ObjectivePreflightReportV1 {
    fn eq(&self, other: &ProofBearingObjectiveCompileV1) -> bool {
        self.outcome == *other.outcome()
            && self.source_envelope_digest == other.proof().source_envelope_digest()
            && self.profile_digest == other.proof().profile_digest()
            && self.compiler_contract_digest == other.proof().compiler_contract_digest()
    }
}

impl PartialEq<ObjectivePreflightReportV1> for ProofBearingObjectiveCompileV1 {
    fn eq(&self, other: &ObjectivePreflightReportV1) -> bool {
        other == self
    }
}
'''


def apply(root: Path) -> None:
    objective = root / "codex-rs/hepta-objective"
    admission = objective / "src/objective_admission.rs"
    cargo = objective / "Cargo.toml"
    lib = objective / "src/lib.rs"
    validated = objective / "src/validated_admission.rs"
    results = objective / "src/admission_results.rs"
    intelligence = root / "codex-rs/hepta-intelligence/src/objective_run.rs"
    ledger = root / "codex-rs/hepta-learning-ledger/src/run_start.rs"
    ledger_lib = root / "codex-rs/hepta-learning-ledger/src/lib.rs"
    consistency = root / "scripts/hepta-objective-contract-consistency.py"

    replace_once(
        admission,
        "admit_profile_bound_objective_v1(envelope, profile, context, profile_digest)",
        "admit_profile_bound_objective_v1(envelope, profile, None, context, profile_digest)",
    )
    replace_once(
        admission,
        """    admit_profile_bound_objective_v1(\n        envelope,\n        profile.profile(),\n        context,\n        profile.profile_digest(),\n    )""",
        """    admit_profile_bound_objective_v1(\n        envelope,\n        profile.profile(),\n        Some(profile),\n        context,\n        profile.profile_digest(),\n    )""",
    )
    replace_once(
        admission,
        """fn admit_profile_bound_objective_v1(\n    envelope: &ObjectiveSourceEnvelopeV1,\n    profile: &ObjectiveAdmissionProfileV1,\n    context: &ObjectiveAdmissionContextV1,""",
        """fn admit_profile_bound_objective_v1(\n    envelope: &ObjectiveSourceEnvelopeV1,\n    profile: &ObjectiveAdmissionProfileV1,\n    validated_profile: Option<&crate::validated_admission::ValidatedAdmissionProfileV1>,\n    context: &ObjectiveAdmissionContextV1,""",
    )
    replace_once(
        admission,
        "let source = adapt_source(envelope, profile, context, admitted_source_digest)?;",
        "let source = adapt_source(\n        envelope,\n        profile,\n        validated_profile,\n        context,\n        admitted_source_digest,\n    )?;",
    )
    replace_once(
        admission,
        """fn adapt_source(\n    envelope: &ObjectiveSourceEnvelopeV1,\n    profile: &ObjectiveAdmissionProfileV1,\n    context: &ObjectiveAdmissionContextV1,""",
        """fn adapt_source(\n    envelope: &ObjectiveSourceEnvelopeV1,\n    profile: &ObjectiveAdmissionProfileV1,\n    validated_profile: Option<&crate::validated_admission::ValidatedAdmissionProfileV1>,\n    context: &ObjectiveAdmissionContextV1,""",
    )
    replace_once(
        admission,
        "constraints.push(adapt_constraint(source, profile)?);",
        "constraints.push(adapt_constraint(source, profile, validated_profile)?);",
    )
    replace_all_exact(
        admission,
        "source, profile, /*must_be_terminal*/",
        "source, profile, validated_profile, /*must_be_terminal*/",
        2,
    )
    replace_once(
        admission,
        "success_predicates.push(adapt_evidence_requirement(source, profile)?);",
        "success_predicates.push(adapt_evidence_requirement(\n            source,\n            profile,\n            validated_profile,\n        )?);",
    )
    replace_all_exact(
        admission,
        "action_mapping(profile, source)?",
        "action_mapping(profile, validated_profile, source)?",
        2,
    )
    replace_once(
        admission,
        """        let mapping = profile\n            .soft_dimensions\n            .iter()\n            .find(|mapping| mapping.source_dimension_id == source.dimension_id)\n            .ok_or(ObjectiveAdmissionError::UnknownSoftDimension)?;""",
        """        let mapping = validated_profile\n            .map(|validated| validated.soft_dimension(&source.dimension_id))\n            .unwrap_or_else(|| {\n                profile\n                    .soft_dimensions\n                    .iter()\n                    .find(|mapping| mapping.source_dimension_id == source.dimension_id)\n            })\n            .ok_or(ObjectiveAdmissionError::UnknownSoftDimension)?;""",
    )
    replace_once(
        admission,
        """fn adapt_constraint(\n    source: &ObjectiveSourceConstraintV1,\n    profile: &ObjectiveAdmissionProfileV1,\n) -> Result<Constraint, ObjectiveAdmissionError> {""",
        """fn adapt_constraint(\n    source: &ObjectiveSourceConstraintV1,\n    profile: &ObjectiveAdmissionProfileV1,\n    validated_profile: Option<&crate::validated_admission::ValidatedAdmissionProfileV1>,\n) -> Result<Constraint, ObjectiveAdmissionError> {""",
    )
    replace_once(
        admission,
        """    let mapping = profile\n        .constraints\n        .iter()\n        .find(|mapping| mapping.source_constraint_id == source.constraint_id)\n        .ok_or(ObjectiveAdmissionError::UnknownConstraint)?;""",
        """    let mapping = validated_profile\n        .map(|validated| validated.constraint(&source.constraint_id))\n        .unwrap_or_else(|| {\n            profile\n                .constraints\n                .iter()\n                .find(|mapping| mapping.source_constraint_id == source.constraint_id)\n        })\n        .ok_or(ObjectiveAdmissionError::UnknownConstraint)?;""",
    )
    replace_once(
        admission,
        """fn adapt_predicate(\n    source: &ObjectiveSourcePredicateV1,\n    profile: &ObjectiveAdmissionProfileV1,\n    must_be_terminal: bool,""",
        """fn adapt_predicate(\n    source: &ObjectiveSourcePredicateV1,\n    profile: &ObjectiveAdmissionProfileV1,\n    validated_profile: Option<&crate::validated_admission::ValidatedAdmissionProfileV1>,\n    must_be_terminal: bool,""",
    )
    replace_once(
        admission,
        """    let mapping = profile\n        .predicates\n        .iter()\n        .find(|mapping| mapping.source_predicate_id == source.predicate_id)\n        .ok_or(ObjectiveAdmissionError::UnknownPredicate)?;""",
        """    let mapping = validated_profile\n        .map(|validated| validated.predicate(&source.predicate_id))\n        .unwrap_or_else(|| {\n            profile\n                .predicates\n                .iter()\n                .find(|mapping| mapping.source_predicate_id == source.predicate_id)\n        })\n        .ok_or(ObjectiveAdmissionError::UnknownPredicate)?;""",
    )
    replace_once(
        admission,
        """fn adapt_evidence_requirement(\n    source: &ObjectiveEvidenceRequirementV1,\n    profile: &ObjectiveAdmissionProfileV1,\n) -> Result<SuccessPredicate, ObjectiveAdmissionError> {""",
        """fn adapt_evidence_requirement(\n    source: &ObjectiveEvidenceRequirementV1,\n    profile: &ObjectiveAdmissionProfileV1,\n    validated_profile: Option<&crate::validated_admission::ValidatedAdmissionProfileV1>,\n) -> Result<SuccessPredicate, ObjectiveAdmissionError> {""",
    )
    replace_once(
        admission,
        """    let mapping = profile\n        .evidence_requirements\n        .iter()\n        .find(|mapping| mapping.source_requirement_id == source.requirement_id)\n        .ok_or(ObjectiveAdmissionError::UnknownEvidenceRequirement)?;""",
        """    let mapping = validated_profile\n        .map(|validated| validated.evidence_requirement(&source.requirement_id))\n        .unwrap_or_else(|| {\n            profile\n                .evidence_requirements\n                .iter()\n                .find(|mapping| mapping.source_requirement_id == source.requirement_id)\n        })\n        .ok_or(ObjectiveAdmissionError::UnknownEvidenceRequirement)?;""",
    )
    replace_once(
        admission,
        """fn action_mapping<'a>(\n    profile: &'a ObjectiveAdmissionProfileV1,\n    source: &str,\n) -> Result<&'a ObjectiveActionProfileV1, ObjectiveAdmissionError> {\n    profile\n        .actions\n        .iter()\n        .find(|mapping| mapping.source_action_class == source)\n        .ok_or(ObjectiveAdmissionError::UnknownAction)\n}""",
        """fn action_mapping<'a>(\n    profile: &'a ObjectiveAdmissionProfileV1,\n    validated_profile: Option<&'a crate::validated_admission::ValidatedAdmissionProfileV1>,\n    source: &str,\n) -> Result<&'a ObjectiveActionProfileV1, ObjectiveAdmissionError> {\n    validated_profile\n        .map(|validated| validated.action(source))\n        .unwrap_or_else(|| {\n            profile\n                .actions\n                .iter()\n                .find(|mapping| mapping.source_action_class == source)\n        })\n        .ok_or(ObjectiveAdmissionError::UnknownAction)\n}""",
    )

    replace_once(
        cargo,
        """[features]\ndefault = []\n# Explicitly qualification-only compatibility surface. Product code must use\n# ValidatedAdmissionProfileV1 + compile_authoritative_objective_v1; diagnostics\n# must use preflight_validate_objective_v1 and must not publish its result.\nqualification-legacy-compile = []""",
        """[features]\ndefault = []\n# Explicitly opt-in compatibility API. Ordinary product dependencies must not\n# enable this feature; they use the validated-profile authoritative façade.\nobjective-compatibility-api = []\n# Historical raw compiler fixtures also require the compatibility API.\nqualification-legacy-compile = [\"objective-compatibility-api\"]""",
    )
    for line in (
        "pub use objective_admission::admit_and_compile_objective_v1;",
        "pub use objective_admission::admit_objective_v1;",
        "pub use objective_admission::compile_admitted_objective_v1;",
        "pub use objective_function_v1::encode_authenticated_objective_function_v1;",
    ):
        replace_once(lib, line, f'#[cfg(feature = "objective-compatibility-api")]\n{line}')
    replace_once(
        lib,
        "pub use admission_results::ObjectivePreflightReportV1;",
        """pub use admission_results::ObjectivePreflightReportV1;\npub use admission_results::ObjectivePublicationBindingError;\npub use admission_results::ObjectivePublicationBindingV1;\npub use admission_results::PublicationBoundObjectiveCompileV1;""",
    )
    replace_once(
        validated,
        "use crate::compile_admitted_objective_v1;",
        "use crate::objective_admission::compile_admitted_objective_v1;",
    )
    results.write_text(ADMISSION_RESULTS, encoding="utf-8")

    replace_once(
        ledger,
        "const CHAIN_DOMAIN: &[u8] = b\"hepta.run-start-chain.v1\";",
        """const CHAIN_DOMAIN: &[u8] = b\"hepta.run-start-chain.v1\";\nconst JOURNAL_OWNER_DOMAIN: &[u8] = b\"hepta.learning-ledger.run-start-journal-owner.v1\";\n\n/// Stable identity of the sealed destination-owned RunStart journal.\n#[must_use]\npub fn run_start_journal_owner_digest_v1() -> Digest32 {\n    Digest32::of_bytes(JOURNAL_OWNER_DOMAIN)\n}""",
    )
    replace_once(
        ledger_lib,
        "pub use run_start::RunStartJournal;",
        "pub use run_start::RunStartJournal;\npub use run_start::run_start_journal_owner_digest_v1;",
    )

    replace_once(
        intelligence,
        "use codex_hepta_learning_ledger::RunStartJournal;",
        "use codex_hepta_learning_ledger::RunStartJournal;\nuse codex_hepta_learning_ledger::run_start_journal_owner_digest_v1;",
    )
    replace_once(
        intelligence,
        "use codex_hepta_objective::ObjectiveFunctionV1Error;",
        """use codex_hepta_objective::ObjectiveFunctionV1Error;\nuse codex_hepta_objective::ObjectivePublicationBindingError;\nuse codex_hepta_objective::ObjectivePublicationBindingV1;""",
    )
    replace_once(
        intelligence,
        """    DeadlineMissing,\n    Protocol(ObjectiveFunctionV1Error),""",
        """    DeadlineMissing,\n    PublicationBinding(ObjectivePublicationBindingError),\n    Protocol(ObjectiveFunctionV1Error),""",
    )
    replace_once(
        intelligence,
        """impl From<ObjectiveFunctionV1Error> for ObjectiveRunError {\n    fn from(error: ObjectiveFunctionV1Error) -> Self {\n        Self::Protocol(error)\n    }\n}""",
        """impl From<ObjectivePublicationBindingError> for ObjectiveRunError {\n    fn from(error: ObjectivePublicationBindingError) -> Self {\n        Self::PublicationBinding(error)\n    }\n}\nimpl From<ObjectiveFunctionV1Error> for ObjectiveRunError {\n    fn from(error: ObjectiveFunctionV1Error) -> Self {\n        Self::Protocol(error)\n    }\n}""",
    )
    replace_once(
        intelligence,
        """    let (outcome, admission_proof) = proof_bearing.into_parts();\n    let receipt = outcome.receipt;""",
        """    let bound = proof_bearing.bind_for_publication(ObjectivePublicationBindingV1::new(\n        run_start_journal_owner_digest_v1(),\n        bindings.run_id.clone(),\n        bindings.expected_run_start_head,\n        bindings.generation,\n        bindings.fence_digest,\n    )?)?;\n    let (outcome, admission_proof, publication_binding) = bound.into_parts();\n    if !admission_proof.verify_integrity() {\n        return Err(ObjectiveRunError::Protocol(\n            ObjectiveFunctionV1Error::ProjectionMismatch(\"admission proof integrity\"),\n        ));\n    }\n    let receipt = outcome.receipt;""",
    )
    replace_all_exact(
        intelligence,
        "bindings.expected_run_start_head,",
        "publication_binding.expected_journal_head(),",
        2,
    )
    replace_once(
        intelligence,
        "run_id: bindings.run_id.clone(),",
        "run_id: publication_binding.run_id().clone(),",
    )
    replace_once(
        intelligence,
        """    let run_start = RunStartSnapshotV1 {\n        run_id: bindings.run_id,""",
        """    let run_start = RunStartSnapshotV1 {\n        run_id: publication_binding.run_id().clone(),""",
    )
    replace_once(
        intelligence,
        "generation: bindings.generation,",
        "generation: publication_binding.generation(),",
    )
    replace_once(
        intelligence,
        "fence_digest: bindings.fence_digest,",
        "fence_digest: publication_binding.fence_digest(),",
    )

    replace_once(
        consistency,
        're.search(r"(?m)^qualification-legacy-compile\\s*=\\s*\\[\\]\\s*$", cargo)',
        're.search(r"(?m)^objective-compatibility-api\\s*=\\s*\\[\\]\\s*$", cargo)',
    )
    replace_once(
        consistency,
        '"qualification-legacy-compile feature is missing or renamed",',
        '"objective-compatibility-api feature is missing or renamed",',
    )
    replace_once(
        consistency,
        """    lib = read(LIB)\n    for token in (""",
        """    need(\n        re.search(\n            r'(?m)^qualification-legacy-compile\\s*=\\s*\\[\"objective-compatibility-api\"\\]\\s*$',\n            cargo,\n        )\n        is not None,\n        \"qualification-legacy-compile no longer enables compatibility API\",\n    )\n\n    lib = read(LIB)\n    for token in (""",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    try:
        apply(args.root.resolve())
    except (OSError, PreviewError) as error:
        parser.error(str(error))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
