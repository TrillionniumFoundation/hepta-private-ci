#!/usr/bin/env python3
"""One-shot closure for the remaining knowledge.graph delivery contracts.

The transformation is fail-closed: each structural edit must match the exact
candidate source shape. The script is temporary and is removed by its workflow
before the resulting source commit is pushed.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def write(path: str, text: str) -> None:
    (ROOT / path).write_text(text, encoding="utf-8")


def replace_once(path: str, old: str, new: str) -> None:
    text = read(path)
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{path}: expected one exact predecessor, found {count}")
    write(path, text.replace(old, new, 1))


def replace_exact(path: str, old: str, new: str, expected: int) -> None:
    text = read(path)
    count = text.count(old)
    if count != expected:
        raise SystemExit(
            f"{path}: expected {expected} exact predecessors, found {count}"
        )
    write(path, text.replace(old, new))


def regex_once(path: str, pattern: str, replacement: str) -> None:
    text = read(path)
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.DOTALL)
    if count != 1:
        raise SystemExit(f"{path}: expected one regex predecessor, found {count}")
    write(path, updated)


# ---------------------------------------------------------------------------
# Kernel: make the charged work/budget authoritative diagnostics and leave
# unbounded execution only behind explicitly named oracle exports.
# ---------------------------------------------------------------------------

replace_once(
    "codex-rs/hepta-kg/src/generation.rs",
    """    pub selected_supports_cloned: u64,
    pub omitted_edges: u64,
}
""",
    """    pub selected_supports_cloned: u64,
    pub omitted_edges: u64,
    /// Total endpoint inspections, edge-support inspections and retained
    /// support copies charged by this operation.
    pub support_work_charged: u64,
    /// The admitted bound for a bounded external query. `None` identifies the
    /// explicitly named unbounded reference/oracle path.
    pub support_work_budget: Option<u64>,
}
""",
)

replace_once(
    "codex-rs/hepta-kg/src/generation.rs",
    """    if MEASURE_WORK {
        debug_assert_eq!(work.omitted_edges, saturating_u64(omitted_count));
    }
    Ok((result, work))
}
""",
    """    if MEASURE_WORK {
        debug_assert_eq!(work.omitted_edges, saturating_u64(omitted_count));
        work.support_work_charged = work
            .visibility_supports_inspected
            .saturating_add(work.relation_supports_inspected)
            .saturating_add(work.selected_supports_cloned);
        work.support_work_budget = None;
    }
    Ok((result, work))
}
""",
)

replace_once(
    "codex-rs/hepta-kg/src/indexed_query.rs",
    """        result.result_digest = compute_query_result_digest(&result);
        Ok((result, work))
    }
}
""",
    """        result.result_digest = compute_query_result_digest(&result);
        work.support_work_charged = support_work;
        work.support_work_budget = Some(maximum_support_work);
        debug_assert_eq!(
            support_work,
            work.visibility_supports_inspected
                .saturating_add(work.relation_supports_inspected)
                .saturating_add(work.selected_supports_cloned)
        );
        Ok((result, work))
    }
}
""",
)

replace_once(
    "codex-rs/hepta-kg/src/lib.rs",
    """pub use generation::publish_generation;
pub use generation::query_relations;
pub use generation::query_relations_with_work;
pub use prompt_factor::PromptFactorProjectionErrorV1;
""",
    """pub use generation::publish_generation;
pub use prompt_factor::PromptFactorProjectionErrorV1;
""",
)

replace_once(
    "codex-rs/hepta-kg/src/lib.rs",
    """pub fn query_relations_reference_unbounded(
    generation: &KnowledgeGenerationV2,
    query: KnowledgeRelationQueryV2,
) -> Result<KnowledgeRelationResultV2, KnowledgeGenerationErrorV2> {
    generation::query_relations(generation, query)
}

const MAX_EDGES: usize = 65_536;
""",
    """pub fn query_relations_reference_unbounded(
    generation: &KnowledgeGenerationV2,
    query: KnowledgeRelationQueryV2,
) -> Result<KnowledgeRelationResultV2, KnowledgeGenerationErrorV2> {
    generation::query_relations(generation, query)
}

/// Explicit unbounded reference/oracle query with diagnostic work counters.
///
/// The returned `support_work_budget` is `None`. Product-facing callers must use
/// [`VerifiedKnowledgeGenerationV2::query_relations_external`].
pub fn query_relations_reference_unbounded_with_work(
    generation: &KnowledgeGenerationV2,
    query: KnowledgeRelationQueryV2,
) -> Result<
    (KnowledgeRelationResultV2, KnowledgeRelationQueryWorkV2),
    KnowledgeGenerationErrorV2,
> {
    generation::query_relations_with_work(generation, query)
}

const MAX_EDGES: usize = 65_536;
""",
)

# Convert any cross-crate/raw test imports to the explicit oracle names. The
# internal generation module keeps its private implementation names.
for candidate in (ROOT / "codex-rs").rglob("*.rs"):
    relative = candidate.relative_to(ROOT).as_posix()
    if relative == "codex-rs/hepta-prompt-optimizer/src/canonical.rs":
        continue
    text = candidate.read_text(encoding="utf-8")
    original = text
    if "use codex_hepta_kg::query_relations;\n" in text:
        text = text.replace(
            "use codex_hepta_kg::query_relations;\n",
            "use codex_hepta_kg::query_relations_reference_unbounded;\n",
        )
        text = re.sub(
            r"(?<![A-Za-z0-9_:])query_relations\(",
            "query_relations_reference_unbounded(",
            text,
        )
    if "use codex_hepta_kg::query_relations_with_work;\n" in text:
        text = text.replace(
            "use codex_hepta_kg::query_relations_with_work;\n",
            "use codex_hepta_kg::query_relations_reference_unbounded_with_work;\n",
        )
        text = re.sub(
            r"(?<![A-Za-z0-9_:])query_relations_with_work\(",
            "query_relations_reference_unbounded_with_work(",
            text,
        )
    text = text.replace(
        "crate::query_relations(",
        "crate::query_relations_reference_unbounded(",
    )
    text = text.replace(
        "crate::query_relations_with_work(",
        "crate::query_relations_reference_unbounded_with_work(",
    )
    if text != original:
        candidate.write_text(text, encoding="utf-8")

# ---------------------------------------------------------------------------
# Existing graph-bound optimizer: consume authoritative work fields rather than
# recomputing an implicit sum in every caller.
# ---------------------------------------------------------------------------

replace_once(
    "codex-rs/hepta-prompt-optimizer/src/graph.rs",
    """    let relation_support_work = relation_work
        .visibility_supports_inspected
        .saturating_add(relation_work.relation_supports_inspected)
        .saturating_add(relation_work.selected_supports_cloned);

    let mut conflicts = BTreeSet::new();
""",
    """    let relation_support_work = relation_work.support_work_charged;
    let relation_support_work_budget = relation_work.support_work_budget.ok_or_else(|| {
        Error::FactorGraph("bounded factor query omitted its admitted budget".to_string())
    })?;
    if relation_support_work_budget != DEFAULT_QUERY_SUPPORT_WORK_V2 {
        return Err(Error::FactorGraph(
            "bounded factor query used an unexpected default budget".to_string(),
        ));
    }

    let mut conflicts = BTreeSet::new();
""",
)

replace_once(
    "codex-rs/hepta-prompt-optimizer/src/graph.rs",
    "        relation_support_work_budget: DEFAULT_QUERY_SUPPORT_WORK_V2,\n",
    "        relation_support_work_budget,\n",
)

# ---------------------------------------------------------------------------
# Canonical prompt portfolio path: it was the remaining product consumer of the
# raw reference scan. Require an owner-built verified view, expose a lowerable
# budget, preserve typed exhaustion, and bind work plus budget in the receipt.
# ---------------------------------------------------------------------------

replace_once(
    "codex-rs/hepta-prompt-optimizer/src/canonical.rs",
    """use codex_hepta_kg::KnowledgeGenerationV2;
use codex_hepta_kg::KnowledgeRelationKindV2;
use codex_hepta_kg::KnowledgeRelationQueryV2;
use codex_hepta_kg::query_relations;
""",
    """use codex_hepta_kg::KnowledgeQueryAdmissionErrorV2;
use codex_hepta_kg::KnowledgeRelationKindV2;
use codex_hepta_kg::KnowledgeRelationQueryV2;
use codex_hepta_kg::VerifiedKnowledgeGenerationV2;
""",
)

replace_once(
    "codex-rs/hepta-prompt-optimizer/src/canonical.rs",
    """    pub factor_ids: Vec<StableId>,
    pub interaction_digest: Digest32,
    pub expected_utility_q32: FixedQ32,
""",
    """    pub factor_ids: Vec<StableId>,
    pub interaction_digest: Digest32,
    pub graph_query_support_work: u64,
    pub graph_query_support_work_budget: u64,
    pub expected_utility_q32: FixedQ32,
""",
)

replace_once(
    "codex-rs/hepta-prompt-optimizer/src/canonical.rs",
    """pub struct PromptPortfolioRequestV1 {
    pub portfolio_id: StableId,
    pub graph_query_id: StableId,
    pub token_budget: u64,
""",
    """pub struct PromptPortfolioRequestV1 {
    pub portfolio_id: StableId,
    pub graph_query_id: StableId,
    /// `None` selects the public library default. A caller may lower the
    /// per-request support-work budget but cannot raise the hard ceiling.
    pub maximum_graph_support_work: Option<u64>,
    pub token_budget: u64,
""",
)

replace_once(
    "codex-rs/hepta-prompt-optimizer/src/canonical.rs",
    "    graph: &KnowledgeGenerationV2,\n",
    "    graph: &VerifiedKnowledgeGenerationV2,\n",
)

replace_once(
    "codex-rs/hepta-prompt-optimizer/src/canonical.rs",
    """    graph
        .validate()
        .map_err(|e| CanonicalPromptError::KnowledgeGraph(format!("{e:?}")))?;
    if graph.generation_vector_digest != priced.candidates.generation_vector_digest {
""",
    """    let generation = graph.generation();
    if generation.generation_vector_digest != priced.candidates.generation_vector_digest {
""",
)

replace_once(
    "codex-rs/hepta-prompt-optimizer/src/canonical.rs",
    """    let relation_result = query_relations(
        graph,
        KnowledgeRelationQueryV2 {
            query_id: request.graph_query_id,
            generation_digest: graph.generation_digest,
            seed_node_ids: factor_ids.clone(),
            valid_at_unix_seconds: Some(
                i64::try_from(now_unix_ms / 1000).map_err(|_| CanonicalPromptError::InvalidTime)?,
            ),
            relation_kinds: vec![
                KnowledgeRelationKindV2::PromptComplements,
                KnowledgeRelationKindV2::PromptSubstitutes,
                KnowledgeRelationKindV2::PromptConflicts,
                KnowledgeRelationKindV2::PromptRequires,
                KnowledgeRelationKindV2::PromptDominates,
                KnowledgeRelationKindV2::PromptRedundant,
                KnowledgeRelationKindV2::PromptSupersedes,
            ],
            maximum_edges: MAX_CANONICAL_INTERACTION_EDGES,
        },
    )
    .map_err(|e| CanonicalPromptError::KnowledgeGraph(format!("{e:?}")))?;
""",
    """    let (relation_result, relation_work) = graph
        .query_relations_external(
            KnowledgeRelationQueryV2 {
                query_id: request.graph_query_id,
                generation_digest: generation.generation_digest,
                seed_node_ids: factor_ids.clone(),
                valid_at_unix_seconds: Some(
                    i64::try_from(now_unix_ms / 1000)
                        .map_err(|_| CanonicalPromptError::InvalidTime)?,
                ),
                relation_kinds: vec![
                    KnowledgeRelationKindV2::PromptComplements,
                    KnowledgeRelationKindV2::PromptSubstitutes,
                    KnowledgeRelationKindV2::PromptConflicts,
                    KnowledgeRelationKindV2::PromptRequires,
                    KnowledgeRelationKindV2::PromptDominates,
                    KnowledgeRelationKindV2::PromptRedundant,
                    KnowledgeRelationKindV2::PromptSupersedes,
                ],
                maximum_edges: MAX_CANONICAL_INTERACTION_EDGES,
            },
            request.maximum_graph_support_work,
        )
        .map_err(map_graph_query_error)?;
    let graph_query_support_work = relation_work.support_work_charged;
    let graph_query_support_work_budget = relation_work.support_work_budget.ok_or_else(|| {
        CanonicalPromptError::KnowledgeGraph(
            "bounded graph query omitted its admitted budget".to_string(),
        )
    })?;
""",
)

canonical_path = "codex-rs/hepta-prompt-optimizer/src/canonical.rs"
canonical = read(canonical_path)
generation_digest_count = canonical.count("graph.generation_digest")
if generation_digest_count < 3:
    raise SystemExit(
        f"{canonical_path}: expected at least three generation digest uses, "
        f"found {generation_digest_count}"
    )
canonical = canonical.replace(
    "graph.generation_digest",
    "generation.generation_digest",
)
write(canonical_path, canonical)

replace_once(
    canonical_path,
    """        interaction_digest,
        expected_utility,
        total_token_upper_bound,
""",
    """        interaction_digest,
        graph_query_support_work,
        graph_query_support_work_budget,
        expected_utility,
        total_token_upper_bound,
""",
)

replace_once(
    canonical_path,
    """            factor_ids: selected_ids,
            interaction_digest,
            expected_utility_q32: expected_utility,
""",
    """            factor_ids: selected_ids,
            interaction_digest,
            graph_query_support_work,
            graph_query_support_work_budget,
            expected_utility_q32: expected_utility,
""",
)

replace_once(
    canonical_path,
    """    interaction_digest: Digest32,
    expected_utility: FixedQ32,
    total_tokens: u32,
""",
    """    interaction_digest: Digest32,
    graph_query_support_work: u64,
    graph_query_support_work_budget: u64,
    expected_utility: FixedQ32,
    total_tokens: u32,
""",
)

replace_once(
    canonical_path,
    """    let mut bytes = b"hepta.prompt-optimizer.portfolio-receipt.v1".to_vec();
""",
    """    let mut bytes = b"hepta.prompt-optimizer.portfolio-receipt.v2".to_vec();
""",
)

replace_once(
    canonical_path,
    """    push_ids(&mut bytes, factor_ids);
    bytes.extend_from_slice(&expected_utility.raw().to_be_bytes());
""",
    """    push_ids(&mut bytes, factor_ids);
    bytes.extend_from_slice(&graph_query_support_work.to_be_bytes());
    bytes.extend_from_slice(&graph_query_support_work_budget.to_be_bytes());
    bytes.extend_from_slice(&expected_utility.raw().to_be_bytes());
""",
)

replace_once(
    canonical_path,
    """fn ensure_digest(name: &'static str, digest: Digest32) -> Result<(), CanonicalPromptError> {
""",
    """fn map_graph_query_error(error: KnowledgeQueryAdmissionErrorV2) -> CanonicalPromptError {
    match error {
        KnowledgeQueryAdmissionErrorV2::InvalidBudget {
            requested_support_work,
            maximum_support_work,
        } => CanonicalPromptError::InvalidGraphQueryBudget {
            requested_support_work,
            maximum_support_work,
        },
        KnowledgeQueryAdmissionErrorV2::BudgetExceeded {
            maximum_support_work,
            attempted_support_work,
        } => CanonicalPromptError::GraphQueryBudgetExceeded {
            maximum_support_work,
            attempted_support_work,
        },
        KnowledgeQueryAdmissionErrorV2::Query(error) => {
            CanonicalPromptError::KnowledgeGraph(error.to_string())
        }
    }
}

fn ensure_digest(name: &'static str, digest: Digest32) -> Result<(), CanonicalPromptError> {
""",
)

replace_once(
    canonical_path,
    """    KnowledgeGraph(String),
    GenerationVectorMismatch,
""",
    """    KnowledgeGraph(String),
    InvalidGraphQueryBudget {
        requested_support_work: u64,
        maximum_support_work: u64,
    },
    GraphQueryBudgetExceeded {
        maximum_support_work: u64,
        attempted_support_work: u64,
    },
    GenerationVectorMismatch,
""",
)

# Canonical tests use a verified owner view and prove receipt binding plus typed
# exhaustion. There are no production callers of this candidate-only API yet.
tests_path = "codex-rs/hepta-prompt-optimizer/src/canonical_tests.rs"
replace_once(
    tests_path,
    """use codex_hepta_kg::KnowledgeEdgeIdentityV2;
""",
    """use codex_hepta_kg::DEFAULT_QUERY_SUPPORT_WORK_V2;
use codex_hepta_kg::KnowledgeEdgeIdentityV2;
""",
)
replace_once(
    tests_path,
    """use codex_hepta_kg::KnowledgeSupportV2;
use codex_hepta_kg::build_complete_generation;
""",
    """use codex_hepta_kg::KnowledgeSupportV2;
use codex_hepta_kg::VerifiedKnowledgeGenerationV2;
use codex_hepta_kg::build_complete_generation;
""",
)
replace_once(
    tests_path,
    """) -> KnowledgeGenerationV2 {
""",
    """) -> VerifiedKnowledgeGenerationV2 {
""",
)
replace_once(
    tests_path,
    """    build_complete_generation(
        Generation::new(1).unwrap_or_else(|error| panic!("generation: {error}")),
""",
    """    let generation = build_complete_generation(
        Generation::new(1).unwrap_or_else(|error| panic!("generation: {error}")),
""",
)
replace_once(
    tests_path,
    """    )
    .unwrap_or_else(|error| panic!("graph: {error}"))
}

fn verifier() -> LearningEvidenceVerifierV1 {
""",
    """    )
    .unwrap_or_else(|error| panic!("graph: {error}"));
    VerifiedKnowledgeGenerationV2::new(generation)
        .unwrap_or_else(|error| panic!("verified graph: {error}"))
}

fn verifier() -> LearningEvidenceVerifierV1 {
""",
)
replace_once(
    tests_path,
    """            graph_query_id: id("query:bundle"),
            token_budget: 2,
""",
    """            graph_query_id: id("query:bundle"),
            maximum_graph_support_work: None,
            token_budget: 2,
""",
)
replace_once(
    tests_path,
    """            graph_query_id: id("query:conflict"),
            token_budget: 2,
""",
    """            graph_query_id: id("query:conflict"),
            maximum_graph_support_work: None,
            token_budget: 2,
""",
)
replace_once(
    tests_path,
    """    assert_eq!(
        selected.optimality,
        PromptOptimalityDisclosureV1::HeuristicNoCertificate
    );
}
""",
    """    assert_eq!(
        selected.optimality,
        PromptOptimalityDisclosureV1::HeuristicNoCertificate
    );
    assert!(selected.receipt.graph_query_support_work > 0);
    assert_eq!(
        selected.receipt.graph_query_support_work_budget,
        DEFAULT_QUERY_SUPPORT_WORK_V2
    );
    assert!(
        selected.receipt.graph_query_support_work
            <= selected.receipt.graph_query_support_work_budget
    );
}
""",
)
replace_once(
    tests_path,
    """            factor_ids: vec![id("factor:a")],
            interaction_digest: digest("interaction"),
            expected_utility_q32: FixedQ32::from_raw(10),
""",
    """            factor_ids: vec![id("factor:a")],
            interaction_digest: digest("interaction"),
            graph_query_support_work: 1,
            graph_query_support_work_budget: DEFAULT_QUERY_SUPPORT_WORK_V2,
            expected_utility_q32: FixedQ32::from_raw(10),
""",
)

replace_once(
    tests_path,
    """#[test]
fn incomplete_candidate_completeness_cannot_be_authenticated_for_pricing() {
""",
    """#[test]
fn portfolio_query_budget_exhaustion_is_distinct() {
    let priced = priced(vec![
        ("factor:a", "realization:a", 1, 100),
        ("factor:b", "realization:b", 1, 90),
    ]);
    let graph = graph(
        &["factor:a", "factor:b"],
        vec![(
            "factor:a",
            KnowledgeRelationKindV2::PromptComplements,
            "factor:b",
        )],
    );
    let error = select_portfolio_v1(
        &priced,
        &graph,
        Vec::new(),
        &verifier(),
        PromptPortfolioRequestV1 {
            portfolio_id: id("portfolio:budget"),
            graph_query_id: id("query:budget"),
            maximum_graph_support_work: Some(1),
            token_budget: 2,
            maximum_selected_factors: 2,
            requested_valid_until_unix_ms: 5_000,
        },
        100,
    )
    .expect_err("bounded graph work must not return partial portfolio success");
    assert!(matches!(
        error,
        CanonicalPromptError::GraphQueryBudgetExceeded {
            maximum_support_work: 1,
            attempted_support_work: 2,
        }
    ));
}

#[test]
fn incomplete_candidate_completeness_cannot_be_authenticated_for_pricing() {
""",
)

# ---------------------------------------------------------------------------
# Cognitive retrieval: use the typed bounded entry and never classify legitimate
# resource exhaustion as durable-store corruption.
# ---------------------------------------------------------------------------

retrieval_path = "codex-rs/hepta-memory/src/cognitive_retrieval.rs"
replace_once(
    retrieval_path,
    """use codex_hepta_contracts::Sha256Digest;
use codex_hepta_kg::KnowledgeRelationQueryV2;
""",
    """use codex_hepta_contracts::Sha256Digest;
use codex_hepta_kg::DEFAULT_QUERY_SUPPORT_WORK_V2;
use codex_hepta_kg::KnowledgeQueryAdmissionErrorV2;
use codex_hepta_kg::KnowledgeRelationQueryV2;
""",
)

replace_once(
    retrieval_path,
    """            let query_result = generation
                .verified
                .query_relations(KnowledgeRelationQueryV2 {
                    query_id: StableId::new("query:cognitive-retrieval-graph-v2").map_err(
                        |error| {
                            CognitiveStoreError::Corrupt(format!(
                                "invalid canonical KG retrieval query identity: {error}"
                            ))
                        },
                    )?,
                    generation_digest: generation.verified.generation().generation_digest,
                    seed_node_ids: vec![seed_node_id],
                    relation_kinds,
                    valid_at_unix_seconds: Some(now),
                    maximum_edges: u32::try_from(remaining).map_err(|_| {
                        CognitiveStoreError::Invalid(
                            "graph retrieval limit exceeds u32".to_string(),
                        )
                    })?,
                })
                .map_err(|error| {
                    CognitiveStoreError::Corrupt(format!(
                        "persisted KG generation failed canonical V2 query: {error}"
                    ))
                })?;
""",
    """            let (query_result, query_work) = generation
                .verified
                .query_relations_external(
                    KnowledgeRelationQueryV2 {
                        query_id: StableId::new("query:cognitive-retrieval-graph-v2").map_err(
                            |error| {
                                CognitiveStoreError::Corrupt(format!(
                                    "invalid canonical KG retrieval query identity: {error}"
                                ))
                            },
                        )?,
                        generation_digest: generation.verified.generation().generation_digest,
                        seed_node_ids: vec![seed_node_id],
                        relation_kinds,
                        valid_at_unix_seconds: Some(now),
                        maximum_edges: u32::try_from(remaining).map_err(|_| {
                            CognitiveStoreError::Invalid(
                                "graph retrieval limit exceeds u32".to_string(),
                            )
                        })?,
                    },
                    None,
                )
                .map_err(map_bounded_kg_query_error)?;
            if query_work.support_work_budget != Some(DEFAULT_QUERY_SUPPORT_WORK_V2)
                || query_work.support_work_charged > DEFAULT_QUERY_SUPPORT_WORK_V2
            {
                return Err(CognitiveStoreError::Corrupt(
                    "bounded KG retrieval query returned an invalid work receipt".to_string(),
                ));
            }
""",
)

replace_once(
    retrieval_path,
    """fn bounded_fts_query(query: &str) -> Option<String> {
""",
    """pub(crate) fn map_bounded_kg_query_error(
    error: KnowledgeQueryAdmissionErrorV2,
) -> CognitiveStoreError {
    match error {
        KnowledgeQueryAdmissionErrorV2::InvalidBudget {
            requested_support_work,
            maximum_support_work,
        } => CognitiveStoreError::Corrupt(format!(
            "internal KG query requested invalid support-work budget \
             {requested_support_work}; maximum is {maximum_support_work}"
        )),
        KnowledgeQueryAdmissionErrorV2::BudgetExceeded {
            maximum_support_work,
            attempted_support_work,
        } => CognitiveStoreError::Unavailable(format!(
            "bounded KG retrieval support-work budget {maximum_support_work} \
             exhausted at {attempted_support_work}; narrow the request"
        )),
        KnowledgeQueryAdmissionErrorV2::Query(error) => CognitiveStoreError::Corrupt(format!(
            "persisted KG generation failed canonical V2 query: {error}"
        )),
    }
}

fn bounded_fts_query(query: &str) -> Option<String> {
""",
)

retrieval_tests = "codex-rs/hepta-memory/src/cognitive_retrieval_tests.rs"
replace_once(
    retrieval_tests,
    """fn assert_graph_bound_distribution(
""",
    """#[test]
fn graph_query_budget_exhaustion_is_retryable_not_corruption() {
    let exhausted = crate::cognitive_retrieval::map_bounded_kg_query_error(
        codex_hepta_kg::KnowledgeQueryAdmissionErrorV2::BudgetExceeded {
            maximum_support_work: 7,
            attempted_support_work: 8,
        },
    );
    assert!(matches!(
        exhausted,
        CognitiveStoreError::Unavailable(message)
            if message.contains("support-work budget 7 exhausted at 8")
    ));

    let semantic = crate::cognitive_retrieval::map_bounded_kg_query_error(
        codex_hepta_kg::KnowledgeQueryAdmissionErrorV2::Query(
            codex_hepta_kg::KnowledgeGenerationErrorV2::DigestMismatch("query_generation"),
        ),
    );
    assert!(matches!(semantic, CognitiveStoreError::Corrupt(_)));
}

fn assert_graph_bound_distribution(
""",
)

# ---------------------------------------------------------------------------
# Public contract and operation evidence.
# ---------------------------------------------------------------------------

resource_test = "codex-rs/hepta-kg/tests/query_resource_contract.rs"
replace_once(
    resource_test,
    """use codex_hepta_kg::query_relations_reference_unbounded;
""",
    """use codex_hepta_kg::query_relations_reference_unbounded;
use codex_hepta_kg::query_relations_reference_unbounded_with_work;
""",
)
replace_once(
    resource_test,
    """    assert_eq!(empty_work.relation_edges_scanned, 0);

    assert!(matches!(
""",
    """    assert_eq!(empty_work.relation_edges_scanned, 0);
    assert_eq!(empty_work.support_work_charged, 0);
    assert_eq!(empty_work.support_work_budget, Some(1));

    assert!(matches!(
""",
)
replace_once(
    resource_test,
    """    let bounded = verified
        .query_relations_external(query(&generation, "node:a"), None)
        .unwrap_or_else(|error| panic!("default bounded query: {error}"))
        .0;
    let reference = query_relations_reference_unbounded(&generation, query(&generation, "node:a"))
        .unwrap_or_else(|error| panic!("explicit unbounded oracle: {error}"));
    assert_eq!(bounded, reference);
""",
    """    let (bounded, bounded_work) = verified
        .query_relations_external(query(&generation, "node:a"), None)
        .unwrap_or_else(|error| panic!("default bounded query: {error}"));
    assert_eq!(
        bounded_work.support_work_budget,
        Some(DEFAULT_QUERY_SUPPORT_WORK_V2)
    );
    assert_eq!(
        bounded_work.support_work_charged,
        bounded_work
            .visibility_supports_inspected
            .saturating_add(bounded_work.relation_supports_inspected)
            .saturating_add(bounded_work.selected_supports_cloned)
    );
    let reference = query_relations_reference_unbounded(&generation, query(&generation, "node:a"))
        .unwrap_or_else(|error| panic!("explicit unbounded oracle: {error}"));
    let (_, reference_work) =
        query_relations_reference_unbounded_with_work(&generation, query(&generation, "node:a"))
            .unwrap_or_else(|error| panic!("unbounded oracle work: {error}"));
    assert_eq!(reference_work.support_work_budget, None);
    assert_eq!(
        reference_work.support_work_charged,
        reference_work
            .visibility_supports_inspected
            .saturating_add(reference_work.relation_supports_inspected)
            .saturating_add(reference_work.selected_supports_cloned)
    );
    assert_eq!(bounded, reference);
""",
)

measurement = "codex-rs/hepta-kg/tests/operation_measurement.rs"
replace_once(
    measurement,
    """    let cold = verified
        .query_relations_external(query.clone(), None)
        .unwrap_or_else(|error| panic!("cold bounded query: {error}"))
        .0;
    let cold_bounded_query_ns = started.elapsed().as_nanos();
    assert_eq!(cold.edges.len(), 1);
""",
    """    let (cold, cold_work) = verified
        .query_relations_external(query.clone(), None)
        .unwrap_or_else(|error| panic!("cold bounded query: {error}"));
    let cold_bounded_query_ns = started.elapsed().as_nanos();
    let cold_support_work_charged = cold_work.support_work_charged;
    let cold_support_work_budget = cold_work
        .support_work_budget
        .unwrap_or_else(|| panic!("bounded query must report its admitted budget"));
    assert_eq!(cold.edges.len(), 1);
    assert!(cold_support_work_charged > 0);
    assert_eq!(cold_support_work_budget, DEFAULT_QUERY_SUPPORT_WORK_V2);
    assert!(cold_support_work_charged <= cold_support_work_budget);
""",
)
replace_once(
    measurement,
    """\\\"iterations\\\":{iterations},\\\"defaultSupportWork\\\":{DEFAULT_QUERY_SUPPORT_WORK_V2},\\\"maximumSupportWork\\\":{MAX_QUERY_SUPPORT_WORK_V2}}}\"
""",
    """\\\"iterations\\\":{iterations},\\\"coldSupportWorkCharged\\\":{cold_support_work_charged},\\\"coldSupportWorkBudget\\\":{cold_support_work_budget},\\\"defaultSupportWork\\\":{DEFAULT_QUERY_SUPPORT_WORK_V2},\\\"maximumSupportWork\\\":{MAX_QUERY_SUPPORT_WORK_V2}}}\"
""",
)

# ---------------------------------------------------------------------------
# Documentation and exact-evidence contract rows.
# ---------------------------------------------------------------------------

query_doc = "docs/modules/knowledge.graph/QUERY_BUDGET_20260928.md"
replace_once(
    query_doc,
    """Exhaustion never returns a truncated successful result, never claims an exact omitted count for unfinished work, never mutates the generation and does not poison later requests.

The source-compatible `query_relations_with_work_budget` retains its historical `InvalidQueryLimit` mapping. New external callers should use the explicit admission type. `query_relations_reference_unbounded` is the deliberately named full-scan oracle operation for trusted migration/equivalence work; it is not an external request path.
""",
    """Exhaustion never returns a truncated successful result, never claims an exact omitted count for unfinished work, never mutates the generation and does not poison later requests.

Every successful work receipt now carries authoritative `support_work_charged` and `support_work_budget` fields. Bounded calls return `Some(admitted_budget)`; the explicitly named unbounded reference-with-work operation returns `None`. Consumers do not need to reconstruct the charge from a growing set of counters.

The source-compatible `query_relations_with_work_budget` retains its historical `InvalidQueryLimit` mapping. New external callers should use the explicit admission type. The ambiguous public raw full-scan re-exports are removed; `query_relations_reference_unbounded` and `query_relations_reference_unbounded_with_work` are the deliberately named oracle operations for trusted migration/equivalence work, not external request paths.

The cognitive GraphOneHop consumer, the graph-bound prompt optimizer and the canonical prompt-portfolio selector all call `query_relations_external` on owner-created immutable verified views. The canonical selector accepts a lowerable budget and binds both actual charge and admitted budget in its portfolio receipt. Cognitive retrieval maps legitimate budget exhaustion to an unavailable/narrow-request outcome rather than misreporting durable-store corruption; semantic/source-cut failures remain corruption evidence.
""",
)

replace_once(
    query_doc,
    """The diagnostic work counters are operation accounting, not byte-perfect allocator/RSS or latency metrics. Actual peak RSS, database/WAL growth, elapsed times and contention require native measurement.
""",
    """The diagnostic work counters are operation accounting, not byte-perfect allocator/RSS or latency metrics. `operation_measurement.rs` records the cold query's authoritative charge and admitted budget in addition to phase timings. Actual peak RSS, database/WAL growth, elapsed times and contention require native measurement.
""",
)

acceptance_doc = "docs/modules/knowledge.graph/ACCEPTANCE_EXTENSION_20260928.md"
replace_once(
    acceptance_doc,
    """`query_relations_reference_unbounded` is the explicitly named full-scan oracle operation. It is retained for migration, trusted-owner comparison and equivalence testing; it is not the external resource contract. The older budgeted method remains source-compatible and maps admission/exhaustion to its historical `InvalidQueryLimit` error.
""",
    """`query_relations_reference_unbounded` and `query_relations_reference_unbounded_with_work` are the explicitly named full-scan oracle operations. The ambiguous public raw full-scan re-exports are removed. The oracle names are retained for migration, trusted-owner comparison and equivalence testing; they are not the external resource contract. The older bounded compatibility method remains source-compatible and maps admission/exhaustion to its historical `InvalidQueryLimit` error.
""",
)

replace_once(
    acceptance_doc,
    """The product call paths are now closed over bounded indexed views rather than the unbounded oracle. Cognitive retrieval retains one verified view per owner SQLite read transaction and uses the library default budget, which is above the composed owner's bounded node/edge occurrence ceiling. `PromptFactorProjectionV1` seals one shared immutable verified view and the optimizer calls `query_relations_external` on that view. Repeated optimizer calls therefore reuse structural validation and indexes, while any temporal cut supplied by a query would still be evaluated per call. The graph-bound optimizer receipt binds both charged support work and the applicable default budget.
""",
    """The product call paths are now closed over bounded indexed views rather than the unbounded oracle. Cognitive retrieval retains one verified view per owner SQLite read transaction and uses the library default budget; budget exhaustion is classified as unavailable/narrow-request rather than durable corruption. `PromptFactorProjectionV1` seals one shared immutable verified view and the graph-bound optimizer calls `query_relations_external` on that view. The canonical prompt-portfolio selector now also requires an owner-created `VerifiedKnowledgeGenerationV2`, accepts a caller-lowerable budget and preserves typed invalid-admission versus runtime-exhaustion errors. Repeated calls reuse structural validation and indexes, while temporal visibility remains per-request. Both prompt optimizer receipt families bind actual charged work and admitted budget.
""",
)

replace_once(
    acceptance_doc,
    """`codex-rs/hepta-kg/tests/query_resource_contract.rs` proves that true empty, invalid budget, exhausted budget and explicit unbounded reference execution cannot be confused. The prompt optimizer additionally proves that its real owner projection distinguishes exhaustion from a true empty result. The existing public acceptance matrix continues to compare complete indexed/reference results, including request/result digests and exact omitted counts.
""",
    """`codex-rs/hepta-kg/tests/query_resource_contract.rs` proves that true empty, invalid budget, exhausted budget and explicit unbounded reference execution cannot be confused, and verifies authoritative charged-work/budget fields. Both prompt optimizer consumers prove bounded execution; the canonical selector proves typed budget exhaustion and receipt binding. Cognitive retrieval proves that exhaustion is not classified as store corruption. The existing public acceptance matrix continues to compare complete indexed/reference results, including request/result digests and exact omitted counts.
""",
)

replace_once(
    acceptance_doc,
    """The prompt optimizer's product receipt separately binds the actual support-work charge and default budget used by its bounded indexed query. These are regression observations, not host-independent service-level claims. The native SQLite measurement separately records durable mutation, query, reopen, writer, reader and complete contention-round distributions, plus bounded-query work and storage/process observations.
""",
    """The prompt optimizers' product receipts separately bind the actual support-work charge and admitted budget used by their bounded indexed queries. The operation metric also records the cold query's charge and budget. These are regression observations, not host-independent service-level claims. The native SQLite measurement separately records durable mutation, query, reopen, writer, reader and complete contention-round distributions, plus bounded-query work and storage/process observations.
""",
)

evidence_script = "scripts/hepta_kg_contract_evidence.py"
replace_once(
    evidence_script,
    """DELIVERY_TESTS = (
    "committed_unknown_result_reconciles_exact_receipt_after_reopen",
    "competing_head_reopen_selects_one_complete_receipt",
)
""",
    """DELIVERY_TESTS = (
    "committed_unknown_result_reconciles_exact_receipt_after_reopen",
    "competing_head_reopen_selects_one_complete_receipt",
)
PRODUCT_QUERY_TESTS = (
    "portfolio_query_budget_exhaustion_is_distinct",
    "graph_query_budget_exhaustion_is_retryable_not_corruption",
)
""",
)
replace_once(
    evidence_script,
    """        "iterations",
        "defaultSupportWork",
        "maximumSupportWork",
""",
    """        "iterations",
        "coldSupportWorkCharged",
        "coldSupportWorkBudget",
        "defaultSupportWork",
        "maximumSupportWork",
""",
)
replace_once(
    evidence_script,
    """    if metrics["defaultSupportWork"] > metrics["maximumSupportWork"]:
        fail("default support-work budget exceeds the library maximum")
    return metrics
""",
    """    if metrics["defaultSupportWork"] > metrics["maximumSupportWork"]:
        fail("default support-work budget exceeds the library maximum")
    if metrics["coldSupportWorkCharged"] > metrics["coldSupportWorkBudget"]:
        fail("cold query charge exceeds its admitted support-work budget")
    if metrics["coldSupportWorkBudget"] != metrics["defaultSupportWork"]:
        fail("cold query did not use the declared default support-work budget")
    return metrics
""",
)
replace_once(
    evidence_script,
    """        require_test_names(evidence / "cognitive-owner.log", RECOVERY_TESTS)
        require_test_names(evidence / "delivery-consistency.log", DELIVERY_TESTS)
""",
    """        require_test_names(evidence / "cognitive-owner.log", RECOVERY_TESTS)
        require_test_names(
            evidence / "cognitive-owner.log", (PRODUCT_QUERY_TESTS[1],)
        )
        require_test_names(
            evidence / "prompt-optimizer.log", (PRODUCT_QUERY_TESTS[0],)
        )
        require_test_names(evidence / "delivery-consistency.log", DELIVERY_TESTS)
""",
)
replace_once(
    evidence_script,
    """                "cognitive-owner.log",
                "delivery-consistency.log",
""",
    """                "cognitive-owner.log",
                "prompt-optimizer.log",
                "delivery-consistency.log",
""",
)
replace_once(
    evidence_script,
    """        contracts.extend(
            [
                contract(
                    "lost acknowledgement retry reconciles the exact committed write receipt after reopen",
""",
    """        contracts.extend(
            [
                contract(
                    "all product KG consumers use bounded typed query admission and preserve exhaustion classification",
                    "VerifiedKnowledgeGenerationV2::query_relations_external",
                    list(PRODUCT_QUERY_TESTS),
                    [
                        "prompt-optimizer.log",
                        "cognitive-owner.log",
                        "operation-metrics.log",
                    ],
                    args.tested_sha,
                    args.tested_tree,
                    environment_id,
                ),
                contract(
                    "lost acknowledgement retry reconciles the exact committed write receipt after reopen",
""",
)

evidence_tests = "scripts/test_hepta_kg_contract_evidence.py"
replace_once(
    evidence_tests,
    """        "iterations": 128,
        "defaultSupportWork": 100,
""",
    """        "iterations": 128,
        "coldSupportWorkCharged": 4,
        "coldSupportWorkBudget": 100,
        "defaultSupportWork": 100,
""",
)

# Fail if any public/cross-crate ambiguous raw entry remains.
violations: list[str] = []
for candidate in (ROOT / "codex-rs").rglob("*.rs"):
    relative = candidate.relative_to(ROOT).as_posix()
    text = candidate.read_text(encoding="utf-8")
    for needle in (
        "pub use generation::query_relations;",
        "pub use generation::query_relations_with_work;",
        "use codex_hepta_kg::query_relations;",
        "use codex_hepta_kg::query_relations_with_work;",
        "codex_hepta_kg::query_relations(",
        "codex_hepta_kg::query_relations_with_work(",
        "crate::query_relations(",
        "crate::query_relations_with_work(",
    ):
        if needle in text:
            violations.append(f"{relative}: {needle}")
if violations:
    raise SystemExit(
        "ambiguous unbounded query entry remains:\n" + "\n".join(violations)
    )

print("PASS_HEPTA_KG_REMAINING_FOUR_SOURCE_PATCH")
