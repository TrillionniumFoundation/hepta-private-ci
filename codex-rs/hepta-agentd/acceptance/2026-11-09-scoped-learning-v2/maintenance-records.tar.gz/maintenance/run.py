import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time

repo = Path('/home/qq/hepta-scoped-maintenance-8fda2cd1-d9bbb5-20261109/source')
root = Path('/home/qq/hepta-scoped-maintenance-8fda2cd1-d9bbb5-20261109/evidence')
name, *command = sys.argv[1:]
assert name and command and '/' not in name
root.mkdir(parents=True, exist_ok=True)
result_path = root / (name + '.json')
log_path = root / (name + '.log')
assert not result_path.exists() and not log_path.exists()
env = os.environ.copy()
env.update({
    'RUSTUP_HOME': '/home/qq/.rustup',
    'RUSTUP_TOOLCHAIN': '1.96.0',
    'CARGO_HOME': '/home/qq/.cargo',
    'PATH': '/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer:/home/qq/.cargo/bin:/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:' + env['PATH'],
    'CARGO_TARGET_DIR': '/home/qq/hepta-scoped-maintenance-8fda2cd1-d9bbb5-20261109/target',
    'CARGO_INCREMENTAL': '0',
    'CARGO_BUILD_JOBS': '1',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CODEX_REPO_ROOT': str(repo),
    'PYTHONDONTWRITEBYTECODE': '1',
})
for directory in sorted(Path('/usr/lib').glob('llvm-*/lib'), reverse=True):
    if list(directory.glob('libclang.so*')):
        env.setdefault('LIBCLANG_PATH', str(directory))
        break
include = subprocess.check_output(['cc', '-print-file-name=include']).decode().strip()
env.setdefault('BINDGEN_EXTRA_CLANG_ARGS', '-isystem' + include)
helper = None

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo).decode()

def source(label):
    names = sorted(set(git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')) - {''})
    files = []
    for relative in names:
        path = repo / relative
        if path.is_symlink():
            data = os.readlink(path).encode()
            kind = 'symlink'
        elif path.is_file():
            data = path.read_bytes()
            kind = 'file'
        else:
            files.append({'path': relative, 'kind': 'absent_or_directory'})
            continue
        files.append({'path': relative, 'kind': kind, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    manifest_bytes = (json.dumps(files, sort_keys=True, separators=(',', ':')) + '\n').encode()
    manifest_path = root / f'{name}.{label}.files.json.gz'
    manifest_path.write_bytes(gzip.compress(manifest_bytes, mtime=0))
    changed = set(git('diff', '--name-only', 'HEAD', '-z').split('\0'))
    changed.update(git('ls-files', '--others', '--exclude-standard', '-z').split('\0'))
    overlay_path = root / f'{name}.{label}.overlay.tar.gz'
    with tarfile.open(overlay_path, 'w:gz') as archive:
        for relative in sorted(changed - {''}):
            if (repo / relative).is_file() or (repo / relative).is_symlink():
                archive.add(repo / relative, arcname=relative, recursive=False)
    diff = git('diff', '--binary', 'HEAD')
    return {
        'commit': git('rev-parse', 'HEAD').strip(),
        'tree': git('rev-parse', 'HEAD^{tree}').strip(),
        'status': git('status', '--porcelain'),
        'tracked_diff': diff,
        'tracked_diff_sha256': hashlib.sha256(diff.encode()).hexdigest(),
        'all_files_manifest': manifest_path.name,
        'all_files_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
        'overlay_file': overlay_path.name,
        'overlay_sha256': hashlib.sha256(overlay_path.read_bytes()).hexdigest(),
        'changed_paths': sorted(changed - {''}),
    }

before = source('before')
start = time.time()
record = {
    'name': name, 'command': command, 'cwd': str(repo), 'source_before': before,
    'start_unix_seconds': start, 'build_jobs': 1, 'test_debug': 0, 'dev_debug': 0,
    'target_dir': env['CARGO_TARGET_DIR'],
    'toolchain': env['RUSTUP_TOOLCHAIN'],
    'helper': helper,
    'bindgen_extra_clang_args': env['BINDGEN_EXTRA_CLANG_ARGS'],
}
result_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'start': name, 'commit': before['commit'], 'source_manifest_sha256': before['all_files_manifest_sha256'], 'log': str(log_path)}), flush=True)
with log_path.open('wb') as log:
    result = subprocess.run(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
junit_paths = [repo / 'codex-rs/target/nextest/local/junit.xml', Path(env['CARGO_TARGET_DIR']) / 'nextest/local/junit.xml']
for candidate in junit_paths:
    if candidate.is_file() and candidate.stat().st_mtime >= start:
        data = candidate.read_bytes()
        copy = root / (name + '.junit.xml')
        copy.write_text(data.decode())
        record['junit'] = {'original_path': str(candidate), 'file': copy.name, 'sha256': hashlib.sha256(data).hexdigest()}
        break
after = source('after')
raw = log_path.read_bytes()
compressed = gzip.compress(raw, mtime=0)
gz = log_path.with_suffix('.log.gz')
gz.write_bytes(compressed)
record.update({
    'source_after': after, 'exit_code': result.returncode,
    'elapsed_seconds': time.time() - start,
    'source_unchanged': before['all_files_manifest_sha256'] == after['all_files_manifest_sha256'],
    'log_file': gz.name, 'raw_log_sha256': hashlib.sha256(raw).hexdigest(),
    'log_gzip_sha256': hashlib.sha256(compressed).hexdigest(), 'raw_log_bytes': len(raw),
})
result_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'finish': name, 'exit_code': result.returncode, 'seconds': record['elapsed_seconds'], 'source_unchanged': record['source_unchanged']}), flush=True)
sys.exit(result.returncode)
