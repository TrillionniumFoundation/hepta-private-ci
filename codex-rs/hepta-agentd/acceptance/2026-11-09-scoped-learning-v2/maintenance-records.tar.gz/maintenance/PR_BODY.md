## Why

Medium-cadence Cell or Organ learning needs a frozen component boundary before training results can advance to evaluation or durable recovery. A later NoUpdate decision must not admit an earlier candidate that changed a protected base or representation.

## Changes

- Freeze the original request, owner set, complete selected components, Cell/Organ scope and training update-rule digest.
- Enforce the boundary at the explicit native learning channel before recording Training, checkpoint publication or Evaluation dispatch, and recheck every retained Training observation during restore.
- Preserve the base, encoder, tokenizer, normalizer, numeric/output/state schemas and state semantics. Cell scope preserves the Organ adapter; Organ scope preserves the Cell adapter. BaseRelease requires a separate slow-release owner.
- Bind schema-2 protected checkpoint records to the frozen scope; refuse profile downgrade or rebinding without rewriting the original owner record.
- Keep NoUpdate on the retained Selection and NextUse path. Shared immutable weights, low-rank execution and private local state are preserved; the channel adds no chain-finality wait and issues no settlement award or chainwork.
- Repair the scoped checkpoint tests to reuse their existing support module, then apply the official formatter to the scoped implementation. No lint allowance, dependency or authority changes were added by this maintenance.

## Source and validation

Final maintenance head: d2ebadca8bb95a7f208bf0538690125acdd784eb.
Final tree: 5a23c73d908a551631280384474f10944aff88fb.
The maintenance is two commits above d81cb97c5b01aea0df03d84d40336b25576337de, on the original learning branch based on #5393 at bdf35d0991a02cdf201cc098257132fe3282f99f.

Fresh focused regression ran on 8fda2cd1b4e6e052d5dd232d6ba53e45c507eba9 / tree eb059277eaa039d60333394c9e25730a02ce4a98:

- 11 checkpoint/profile/scope tests passed; 757 outside the selection; zero retries.
- The complete 11,218-file source manifest was identical before and after execution.
- The 11 cases match the historical d81 checkpoint roster after the declared module-path move. These are repeated engineering checks, not additional independent scientific samples.
- Scoped just fix and lib/tests Clippy with -D warnings both passed on the same 8fda source without modifying bytes.
- Official just fmt --base bdf35d0991a02cdf201cc098257132fe3282f99f and its check passed. The nine-file maintenance delta is Rust layout/import formatting only. Native tests were not rerun after maintenance, following AGENTS.md.

The earlier local attempt on 8fda stopped during compilation with ENOSPC: zero tests executed. Its raw files were retained in the original workspace, which subsequently became unavailable; those raw files have not been transferred into the current evidence. Remote staging also retained an index-copy mismatch; all three source blobs were verified identical before resetting only the isolated copy's index.

The real-model observations and their outcome limitations retain their original d81 source identity. They are not relabeled as executions of this maintenance head.

## Qualification boundary

Draft. V2 is explicit opt-in; legacy V1 keeps its original semantics and receives no V2 qualification. Component identity checks do not prove opaque composition bytes or tensor compatibility; the original artifact/loading/adoption owners retain that duty. The slow-release owner, complete production daemon/stage-owner wiring, independent evaluation, real settlement, deployed FinalUse, work-cost qualification and consensus activation remain open. HOLD_NO_GO remains.
