#!/bin/sh
printf 'curated plugin'
